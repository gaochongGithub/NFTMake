// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {


    // onLoad () {}

    start () {
        this.initFullScreen();
    }

    initFullScreen() {
        if (cc.view.getFrameSize().width > cc.view.getFrameSize().height) {
            cc.view.setDesignResolutionSize(1334, 750, cc.ResolutionPolicy.SHOW_ALL);
        }
        if (!cc.sys.isMobile) {
            return;
        }
        if (window.location.search.indexOf("NOFULL") >= 0) {
            return;
        }
        this.initGameDiv();

        var self = this;
        window.addEventListener("resize", function () {
            self.showSwipeTip();
        }, false);
        // window.onresize = function(){
        // }
        this.showSwipeTip();


    }
    private _isFullscreenEnabled: any = null;
    private screenHeight: number = 0;
    private isSafari: boolean = false;

    private rerotation: any = null;
    private swipeTip: any = null;/**滑动的div */
    private initHeight: number = 0;/**初始高 */
    private gameDiv: any = null;
    private gameCanvas: any = null;
    initGameDiv() {
        document.body.style.margin = "0 auto";
        document.body.style.overflow = "auto";
        // var gameDiv = document.createElement('div');
        // gameDiv.id = 'GameDiv';
        var gameDiv = document.getElementById('GameDiv')!;
        gameDiv.style.margin = '0 auto';
        gameDiv.style.position = 'relative';
        gameDiv.style.height = '100vh';
        gameDiv.style.width = '100%';
        // document.body.appendChild(gameDiv);
        this.gameDiv = gameDiv;

        var gameCanvas = document.getElementById('GameCanvas');
        // document.body.removeChild(gameCanvas!);
        // gameDiv.appendChild(gameCanvas!);
        this.gameCanvas = gameCanvas;

        this._isFullscreenEnabled = this.isFullscreenEnabled();

        this.swipeTip = document.getElementById('swipeTip');
        this.swipeTip.style.backgroundImage = "url(img/swipe_2.gif)";

        var ua = navigator.userAgent;
        this.isSafari = ua.match(/iPhone/i) != null && ua.match(/safari/i) != null && ua.match(/Version/i) != null;

    }
    showSwipeTip() {
        if (this.rerotation != window.orientation) {
            this.rerotation = window.orientation;
            this.initHeight = window.innerHeight;
            if (this.rerotation == 0 || this.rerotation == 180) {
                this.screenHeight = Math.max(window.screen.width, window.screen.height);
            } else {
                this.screenHeight = Math.min(window.screen.width, window.screen.height);
            }
        }
        var h = window.innerHeight;
        var isFull = (this.screenHeight == h) || (h > this.initHeight);
        if (isFull) {
            if (this.swipeTip.style.visibility != 'hidden') {
                this.swipeTip.style.zIndex = '-1';
                this.swipeTip.style.visibility = 'hidden';
                // console.log("isFull");
                this.setGameDiv();

                setTimeout(() => {
                    window.scrollTo(0, 1);

                }, 1000);

            }
        } else {
            if (this.swipeTip.style.visibility != 'visible') {
                this.swipeTip.style.zIndex = '996';
                this.swipeTip.style.height = (window.innerHeight + 420) + "px";
                this.swipeTip.style.display = 'block';
                this.swipeTip.style.visibility = 'visible';
                setTimeout(() => {
                    window.scrollTo(0, 1);
                }, 500);

            }
        }
    }
    //
    setGameDiv() {
        var position = 'absolute';
        var gameWidth = '100%';
        var gameHeight = '100%';

        if (cc.sys.isMobile) {
            var clientWidth = document.documentElement.clientWidth;
            var clientHeight = document.documentElement.clientHeight;
            var widthRatio = clientWidth / 750;
            var heightRatio = clientHeight / 1334;
            var devicePixelRatio = cc.view.getDevicePixelRatio();// 750 / clientWidth;

            // var width = (widthRatio > heightRatio) ? 750 * heightRatio:'100%';
            var height = (widthRatio > heightRatio) ? window.innerHeight * widthRatio * devicePixelRatio : -1;
            // if(width != '100%') {
            //     if(width > clientWidth)
            //         position = 'relative';
            //     gameWidth += 'px';
            // }
            if (height != -1) {
                if (height > clientHeight) {
                    position = 'relative';
                }
                if (this.isSafari)
                    height = height * 0.97;
                gameHeight = Math.round(height) + 'px';
            }

        }

        document.body.style.position = position;
        this.gameDiv.style.height = gameHeight;
        // gameDiv.style.width = gameWidth;
        // game.canvas!.style.height = gameHeight;
        this.gameCanvas.style.height = gameHeight;
        cc.view._resizeEvent();
        // console.log(gameHeight);
    }
    //
    isFullscreenEnabled() {
        let el = document as any;
        return el.fullscreenEnabled ||
            el.msFullscreenEnabled ||
            // el.webkitFullscreenEnabled ||
            el.mozFullScreenEnabled || false;

    }
}
