// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { SingtonClass } from "./SingtonClass";
// import Web3 from "./web3/dist/web3.min.js";

const { ccclass, property } = cc._decorator;

declare var Web3;

@ccclass
export default class NewClass extends SingtonClass {
    web3: any;
    private myAddr: any;
    private _func: Function = null!;
    public web3Data: any;
    public isChange:boolean = true;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {

        // this.changeAdress();
    }

    //获取web3
    getWeb3() {

        let w = window as any;
        if (typeof w.ethereum !== 'undefined') {
            this.web3 = new Web3(w.ethereum); // eslint-disable-line
        } else if (w.web3) {
            this.web3 = new Web3(w.web3.currentProvider);
        } else {
            this.web3 = new Web3(new Web3.providers.HttpProvider('https://data-seed-prebsc-1-s2.binance.org:8545/'));
        }
    }

    //调起弹框
    async clickCall() {
        let w = window as any;
        await w.ethereum.enable();
    }
    async getAddress(getMsg: any, cb: Function) {
        let w = window as any;
        if (w.ethereum.selectedAddress) {
            this.myAddr = w.ethereum.selectedAddress;
        } else {
            await w.ethereum.request({ method: "eth_requestAccounts" });
            this.myAddr = w.ethereum.address;
        }
        // const accounts = await new this.web3.eth.getAccounts()
        // console.log(accounts, "结果");
        // console.log(this.myAddr, "获取地址");

        const msg = getMsg;
        this.web3.currentProvider.sendAsync({
            method: 'personal_sign',
            params: [msg, this.myAddr],
            from: this.myAddr
        }, (err, res) => {
            if (err) return console.error(err)
            if (res.error) {
                return console.error(res.error.message)
            }
            let sig = this.getWalletType() + " " + res.result;

            var obj = {
                address: this.myAddr,
                sig: this.getWalletType() + " " + res.result, // 签名，两部分，第一部分是钱包类型，第二部分是用私钥对消息进行的加密结果，消息 "KAKANFT TROLAND: Confirm to connect your wallet to the game"
            }
            // console.log(obj , "地址")
            this.web3Data = obj;
            cb(sig);
        })
    }
    getWeb3Data() {
        return this.web3Data;
    }
    async getUserAddress(){
        const accounts = await new this.web3.eth.getAccounts();
        return accounts[0];
    }
    //获取类型
    getWalletType() {
        let w = window as any;
        if (!w.ethereum) {
            return 'no'
        } else if (w.ethereum.isImToken) {
            return 'imtoken'
        } else if (w.ethereum.isTokenPocket) {
            return 'tokenpocket'
        } else if (w.ethereum.rpcUrl && w.ethereum.rpcUrl.indexOf('bitkeep') !== -1) {
            return 'bitkeep'
        } else if (w.ethereum.isMetaMask && w.ethereum._metamask) {
            return 'metamask'
        } else if (w.ethereum.isCoin98) {
            return 'coin98'
        } else {
            return 'unknown'
        }
    }
    //获取合约信息
    contractCall(abi, addres: string) {
        var MyContract = new this.web3.eth.Contract(abi, addres);
        // this.changeAdress();
        return MyContract;
    }
    //切换钱包地址
    changeAdress() {
        let w = window as any;
        // w.ethereum.on("accountsChanged", function(accounts) {
        //     console.log("切换账套号了",accounts[0],this.web3Data.address);//一旦切换账号这里就会执行
        // });
        var isChange = true;
        var self = this;
        new this.web3.eth.getAccounts().then((data) => {
            // var draess = data[0].toUpperCase();
            var address = data[0].toLowerCase();
            // console.log(address , this.web3Data.address , address === this.web3Data.address,"供货及");
            if (address === self.web3Data.address) {
                isChange = true;
                self.isChange = true;
                console.log("没有切换");
                //提示
            }else{
                isChange = false;
                self.isChange = false;
                console.log("切换账户");
            }
            // console.log(address , this.web3Data.address , address === self.web3Data.address , isChange , "??????");
        });
        console.log(isChange , self.isChange,"回家");
        return isChange;
    }
}
