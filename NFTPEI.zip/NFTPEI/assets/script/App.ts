
import { Base64 } from './Base64';
import ContractCall from './ContractCall';
const { ccclass, property } = cc._decorator;
export interface MyObject {
  [key: string]: any
}
@ccclass('App')
export class App {
  /**
 *获取合约
 */
  public static get ContractCall(): ContractCall {
    return ContractCall.getSingtonInstance();
  }

  /**
  *Base64解码
  */
  public static get Base64(): Base64 {
    return Base64.getSingtonInstance();
  }
  
}
