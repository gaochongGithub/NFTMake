// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {


    start() {

    }
    public static catpureNodeForNative(node: cc.Node, imageType = ".png", imageName = "Image") {

        let camera = node.addComponent(cc.Camera);
        
        // 由于渲染问题，需要调整垂直翻转
        
        node.scaleY *= -1;
        
        // 设置你想要的截图内容的 cullingMask
        
        // camera.cullingMask = 0xffffffff;
        
        // 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
        
        let texture = new cc.RenderTexture();
        
        let gl = cc.game["_renderContext"];
        
        // 如果截图内容中不包含 Mask 组件，可以不用传递第三个参数
        
        let winSize = cc.winSize;
        
        texture.initWithSize.call(texture, winSize.width, winSize.height, imageType == ".png" ? gl.STENCIL_INDEX8 : null);
        
        // texture.setFlipY(true);
        
        camera.targetTexture = texture;
        
        // 渲染一次摄像机，即更新一次内容到 RenderTexture 中
        
        camera.render(node);
        
        // 这样我们就能从 RenderTexture 中获取到数据了
        
        // 获取指定像素的点信息(2.2.0以后改变了相机的渲染方式，需要调整)
        
        let size = node.getContentSize();
        
        let pixels = new Uint8Array(size.width * size.height * 4);
        
        let x = texture.width / 2 - size.width / 2;
        
        let y = texture.height / 2 - size.height / 2;
        
        let w = size.width;
        
        let h = size.height;
        
        let data = texture.readPixels(pixels, x, y, w, h);
        
        //存储所截图片
        
        console.log("路径：", jsb.fileUtils.getWritablePath());
        
        let filePath = jsb.fileUtils.getWritablePath() + imageName + imageType;
        
        let success = jsb['saveImageData'](data, size.width, size.height, filePath);
        
        if (success) {
        
        return filePath;
        
        }
        
        else
        
        return null;
        
        }
    // clickShoePart(part) {
    //     this.shoePart = part[0];
    //     this.test1 = part[1];
    //     this.currentType = part[0];
    // }
    // //颜色
    // onClickShoeColor(colorNum) {
    //     // console.log(colorNum , "颜色");
    //     this.colorNum = colorNum[1];
    //     this[this.currentType + "Num"] = this.replaceStrNum(this[this.currentType + "Num"], 1, colorNum[1]);
    //     this.getShoePartImg();
    // }
    // //
    // replaceStrNum(str, index, char) {
    //     const strAry = str.split('-');
    //     strAry[index] = char;
    //     return strAry.join('-');
    // }
    // //材质
    // onClickShoeTexture(materialNum) {
    //     // console.log(materialNum , "材质");
    //     this.material = materialNum[1];
    //     this[this.currentType + "Num"] = this.replaceStrNum(this[this.currentType + "Num"], 2, materialNum[1]);
    //     this.getShoePartImg();
    // }
    // //图案
    // onClickShoePattern(patternNum) {
    //     // console.log(patternNum , "图案");
    //     this.patternNum = patternNum[1];
    //     this[this.currentType + "Num"] = this.replaceStrNum(this[this.currentType + "Num"], 3, patternNum[1]);
    //     this.getShoePatternImg(patternNum[1]);
    // }
    // //获取图片
    // getShoePartImg() {
    //     var self = this;
    //     console.log(this.shoePart + "/shoeMaterial_" + this.material + "/" + this.shoePart + "_" + this.colorNum, "地址");
    //     console.log(this.test1,this.colorNum , this.material);
    //     // 加载 Img
    //     cc.resources.load(this.shoePart + "/shoeMaterial_" + this.material + "/" + this.shoePart + "_" + this.colorNum, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             return;
    //         }
    //         self[self.shoePart].spriteFrame = spriteFrame;
    //     });
    // }
    // //改材质
    // setShoePart(part,materialNum,colorNum,patternNum) {
    //     this.shoePart = part[0];
    //     this.currentType = part[0];
    //     this.material = materialNum[1];
    //     this.colorNum = colorNum[1];
    //     this.patternNum = patternNum[1];
    //     this.getShoePartImg1(part[0]);
    //     this.getShoePatternImg1(patternNum[1],part[0]);
    // }
    // getShoePartImg1(shoePart) {
    //     var self = this;
    //     // console.log(shoePart + "/shoeMaterial_" + this.material + "/" + shoePart + "_" + this.colorNum, "颜色");
    //     // 加载 Img
    //     cc.resources.load(shoePart + "/shoeMaterial_" + this.material + "/" + shoePart + "_" + this.colorNum, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             return;
    //         }
    //         self[shoePart].spriteFrame = spriteFrame;
    //     });
    // }
    // getShoePatternImg1(num: string,shoePart) {
    //     var self = this;
    //     if (Number(num) == Number("00")) {
    //         self[shoePart].node.children[0].active = false;
    //         return;
    //     }
    //     self[shoePart].node.children[0].active = true;
    //     cc.resources.load(shoePart + "/shoePattern/" + shoePart + "_" + num, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             self[shoePart].node.children[0].active = false;
    //             return;
    //         }
    //         self[shoePart].node.children[0].getComponent(cc.Sprite).spriteFrame = spriteFrame;
    //     });

    // }
    // //获取图片
    // getShoePatternImg(num: string) {
    //     var self = this;
    //     if (Number(num) == Number("00")) {
    //         self[self.shoePart].node.children[0].active = false;
    //         return;
    //     }
    //     self[self.shoePart].node.children[0].active = true;
    //     cc.resources.load(this.shoePart + "/shoePattern/" + this.shoePart + "_" + num, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             self[self.shoePart].node.children[0].active = false;
    //             return;
    //         }
    //         self[self.shoePart].node.children[0].getComponent(cc.Sprite).spriteFrame = spriteFrame;
    //     });

    // }
    // //设置图案
    // setResetSpr(spr, name, color, parrents) {
    //     cc.resources.load(name + "/shoeMaterial_01/" + name + "_" + color, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             return;
    //         }
    //         spr.spriteFrame = spriteFrame;
    //     });
    //     cc.resources.load(name + "/shoePattern/" + name + "_" + parrents, cc.SpriteFrame, function (err, spriteFrame) {
    //         if (err) {
    //             spr.node.children[0].active = false;
    //             return;
    //         }
    //         spr.node.children[0].getComponent(cc.Sprite).spriteFrame = spriteFrame;
    //     });
    // }
    // //重置
    // resetShoe() {
    //     // this.shoePart = "shoeFlank";
    //     // this.currentType = "shoeFlank";
    //     //部位-颜色-材质-图案
    //     this.shoeFlankNum = "11-01-01-00";
    //     this.shoeFrontNum = "12-06-01-00";
    //     this.shoeSideNum = "13-01-01-00";

    //     this.shoeLaterNum = "14-06-01-00";
    //     this.shoeVelcroNum = "15-08-01-08";
    //     this.shoeTongueNum = "16-01-01-01";

    //     this.shoeLaceNum = "17-08-01-05";
    //     this.shoeSoleNum = "18-02-00-00";
    //     this.shoeLightNum = "19-04-00-00";
    //     this.shoeBgNum = "20-00-00-07";

    //     this.setResetSpr(this.shoeSide, "shoeSide", this.shoeSideNum.split("-")[1], this.shoeSideNum.split("-")[3]);
    //     this.setResetSpr(this.shoeTongue, "shoeTongue", this.shoeTongueNum.split("-")[1], this.shoeTongueNum.split("-")[3]);
    //     this.setResetSpr(this.shoeLace, "shoeLace", this.shoeLaceNum.split("-")[1], this.shoeLaceNum.split("-")[3]);

    //     this.setResetSpr(this.shoeLater, "shoeLater", this.shoeLaterNum.split("-")[1], this.shoeLaterNum.split("-")[3]);
    //     this.setResetSpr(this.shoeFront, "shoeFront", this.shoeFrontNum.split("-")[1], this.shoeFrontNum.split("-")[3]);
    //     this.setResetSpr(this.shoeFlank, "shoeFlank", this.shoeFlankNum.split("-")[1], this.shoeFlankNum.split("-")[3]);

    //     this.setResetSpr(this.shoeVelcro, "shoeVelcro", this.shoeVelcroNum.split("-")[1], this.shoeVelcroNum.split("-")[3]);
    //     this.setResetSpr(this.shoeSole, "shoeSole", this.shoeSoleNum.split("-")[1], this.shoeSoleNum.split("-")[3]);
    //     this.setResetSpr(this.shoeLight, "shoeLight", this.shoeLightNum.split("-")[1], this.shoeLightNum.split("-")[3]);
    //     this.setResetSpr(this.shoeBg, "shoeBg", this.shoeBgNum.split("-")[1], this.shoeBgNum.split("-")[3]);
    // }
    // clickMint() {
    //     this.getShoeId(this.shoeFlankNum);
    //     this.getShoeId(this.shoeFrontNum);
    //     this.getShoeId(this.shoeSideNum);

    //     this.getShoeId(this.shoeLaterNum);
    //     this.getShoeId(this.shoeVelcroNum);
    //     this.getShoeId(this.shoeTongueNum);

    //     this.getShoeId(this.shoeLaceNum);
    //     this.getShoeId(this.shoeSoleNum);
    //     this.getShoeId(this.shoeLightNum);
    //     this.getShoeId(this.shoeBgNum);

    //     // console.log(this.shoeFlankNum , this.shoeFrontNum , this.shoeSideNum , this.shoeLaterNum , this.shoeVelcroNum , this.shoeTongueNum , this.shoeLaceNum,this.shoeSoleNum,this.shoeLightNum,this.shoeBgNum);
    //     return this.shoeIdNum;
    // }
    // //获取数值处理
    // getServerData(data){
    //     // var data = "11060202120701021304010014010100150601081602010117080105180200001906000020000008";
    //     var result = "";
    //     for(let i = 0;i<data.length;i++){
    //         if(i%8==0 && i!=0){
    //             result +=','+data[i];
    //         }else if(i%2==0 && i!=0){
    //             result += "-"+data[i];
    //         }else{
    //             result += data[i];
    //         }
    //     }
    //     var id = result.split(",");
    //     for(let i=0;i<id.length;i++){
    //         let idArr = id[i].split("-");
    //         this.setShoePart(this.getPart(idArr[0]),this.setMaterial(idArr),this.setColor(idArr),this.setPattern(idArr));
    //     }
    // }
    // //获取部位
    // getPart(data){
    //     var part = [];
    //     switch(data){
    //         case "11":
    //             part.push("shoeFlank");
    //             break;
    //         case "12":
    //             part.push("shoeFront");
    //             break;
    //         case "13":
    //             part.push("shoeSide");
    //             break;
    //         case "14":
    //             part.push("shoeLater");
    //             break;
    //         case "15":
    //             part.push("shoeVelcro");
    //             break;
    //         case "16":
    //             part.push("shoeTongue");
    //             break;
    //         case "17":
    //             part.push("shoeLace");
    //             break;
    //         case "18":
    //             part.push("shoeSole");
    //             break;
    //         case "19":
    //             part.push("shoeLight");
    //             break;
    //         case "20":
    //             part.push("shoeBg");
    //             break;
    //     }
    //     return part;
    // }
    // //材质处理
    // setMaterial(data){
    //     var material = [];
    //     material.push("material");
    //     var str = data[2];
    //     if(str == "00"){
    //         str = "01";
    //     }
    //     material.push(str);
    //     return material;
    // }
    // //颜色处理
    // setColor(data){
    //     var color = [];
    //     color.push("color");
    //     color.push(data[1]);
    //     return color; 
    // }
    // //图案处理
    // setPattern(data){
    //     var pattern = [];
    //     pattern.push("pattern");
    //     pattern.push(data[3]);
    //     return pattern; 
    // }
    // //获取ID
    // getShoeId(str) {
    //     var id = str.split("-");
    //     let shoePart = id[0] + id[1] + id[2] + id[3];
    //     this.shoeIdNum += shoePart;
    // }
    // update (dt) {}
}
