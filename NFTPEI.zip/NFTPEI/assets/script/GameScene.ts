// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
import { App } from "./App";
import TextureRender from "./TextureRender";
import JSEncrypt from "./rsa/jsencrypt"
// import JSEncrypt from "./rsa/jsencrypt.min";
const { ccclass, property } = cc._decorator;

@ccclass
export default class GameScene extends TextureRender {

    @property({type:cc.Sprite , tooltip:"背景"})
    bg: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"项链"})
    xianglian: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"衣服"})
    yifu: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"头发"})
    toufa: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"嘴"})
    zui: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"鼻子"})
    bizi: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"眼睛"})
    yan: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"报纸"})
    baozhi: cc.Sprite = null;

    @property({type:cc.Sprite , tooltip:"右手"})
    youshou: cc.Sprite = null;

    private nfeId = "";
    private nfeIdArr = [];
    private currentNum:number = 0;
    private repeatNum:number = 0;
    onLoad() {
        
    }
    start() {
        // cc.view.enableRetina(true)
        // cc.view.enableAntiAlias(false);
        var data = {
            list:[],
            num:0,
            repeat:0
        }
        // cc.sys.localStorage.setItem("nftID", JSON.stringify(data));

        var idList = JSON.parse(cc.sys.localStorage.getItem("nftID"));
        if(idList && idList.list.length > 0){
            this.nfeIdArr = idList.list;
            this.currentNum = idList.num;
            this.repeatNum = idList.repeat;
            this.fileNum = idList.num
        }
        console.log(idList,this.fileNum);

        

        // var s = this.nfeIdArr.join(",")+",";
        // // console.log(s , "这个是");
        // var arr = [1,3,5,76,156,9,3]
        // for(var i=0;i<this.nfeIdArr.length;i++) {
        //     if(s.replace(this.nfeIdArr[i]+",","").indexOf(this.nfeIdArr[i]+",")>-1) {
        //         console.log("数组中有重复元素：" + this.nfeIdArr[i]);
        //         break;
        //     }
        // }

        // var isBol = this.isRepeat(this.nfeIdArr);


        let w = window as any;
        if(w.ethereum.isTokenPocket){
   
        }else{
            
        }
    }
    isRepeat(arr){
        var hash = {};
        for(var i in arr) {
           if(hash[arr[i]])
             return true;
           hash[arr[i]] = true;
       }
       return false;
     }
    onclickInit() {
        this.init();
        // create capture
        var self = this;
        this.createCanvas();
        var img = this.createImg();

        // this.shoeImgSrc = img.src;
        this.scheduleOnce(() => {
            for(var i=0;i<this.nfeIdArr.length;i++){
                if(this.nfeIdArr[i] == this.nfeId){
                    console.log(this.nfeIdArr[i] , this.nfeId);
                    this.repeatNum++;
                    return;
                }
            }
            
            this.nfeIdArr.push(this.nfeId);
            // this.showImage(img);
            this.downloadImg();
            var data = {
                list:this.nfeIdArr,
                num:this.fileNum,
                repeat:this.repeatNum,
            }
            cc.sys.localStorage.setItem("nftID", JSON.stringify(data));
            
        }, 1);

        // this.clickSpecifyShoe();
    }
    //生成指定鞋子
    clickSpecifyShoe(){
        //1569  
        for(var i=0;i<2200;i++){
            this.scheduleOnce(()=>{
                this.nfeId = "";
                this.getShoePartImg(this.randNum(0,4),this.bg,"00","bg");
                this.getShoePartImg(this.randNum(0,3),this.xianglian,"01","xianglian");
                this.getShoePartImg(this.randNum(0,3),this.yifu,"02","yifu");

                this.getShoePartImg(this.randNum(0,3),this.toufa,"03","toufa");
                this.getShoePartImg(this.randNum(0,3),this.zui,"04","zui");
                this.getShoePartImg(this.randNum(0,3),this.bizi,"05","bizi");

                this.getShoePartImg(this.randNum(0,3),this.yan,"06","yan");
                this.getShoePartImg(this.randNum(0,3),this.baozhi,"07","baozhi");
                this.getShoePartImg(this.randNum(0,3),this.youshou,"08","youshou");
                
            },i*2.5)
            this.scheduleOnce(()=>{
                this.onclickInit()
            },i*3.5)
            
        }

    }

    //获取随机数
    randNum(m,n){
        var num = parseInt(Math.random()*(n - m +1)+m);
        // num >= 10 ? num : "0" + num
        return (num).toString();
    }
    getShoePartImg(rand,spr,pos,file) {
        var self = this;

        this.nfeId += "0"+rand; 
        cc.resources.load(file+"/"+rand, cc.SpriteFrame, function (err, spriteFrame) {
            if (err) {
                // spr.node.active = false;
                return;
            }
            // spr.node.active = true;
            spr.spriteFrame = spriteFrame;
        });
    }
}
