"use strict";
cc._RF.push(module, 'f3521WIyRdLTJyxAyzqcAVg', 'App');
// script/App.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.App = void 0;
var Base64_1 = require("./Base64");
var ContractCall_1 = require("./ContractCall");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var App = /** @class */ (function () {
    function App() {
    }
    Object.defineProperty(App, "ContractCall", {
        /**
       *获取合约
       */
        get: function () {
            return ContractCall_1.default.getSingtonInstance();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(App, "Base64", {
        /**
        *Base64解码
        */
        get: function () {
            return Base64_1.Base64.getSingtonInstance();
        },
        enumerable: false,
        configurable: true
    });
    App = __decorate([
        ccclass('App')
    ], App);
    return App;
}());
exports.App = App;

cc._RF.pop();