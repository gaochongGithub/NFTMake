"use strict";
cc._RF.push(module, 'd5191dgP+BEaILeFO86Ppm/', 'ShoeCtrl');
// script/ShoeCtrl.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NewClass.prototype.start = function () {
    };
    NewClass.catpureNodeForNative = function (node, imageType, imageName) {
        if (imageType === void 0) { imageType = ".png"; }
        if (imageName === void 0) { imageName = "Image"; }
        var camera = node.addComponent(cc.Camera);
        // 由于渲染问题，需要调整垂直翻转
        node.scaleY *= -1;
        // 设置你想要的截图内容的 cullingMask
        // camera.cullingMask = 0xffffffff;
        // 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
        var texture = new cc.RenderTexture();
        var gl = cc.game["_renderContext"];
        // 如果截图内容中不包含 Mask 组件，可以不用传递第三个参数
        var winSize = cc.winSize;
        texture.initWithSize.call(texture, winSize.width, winSize.height, imageType == ".png" ? gl.STENCIL_INDEX8 : null);
        // texture.setFlipY(true);
        camera.targetTexture = texture;
        // 渲染一次摄像机，即更新一次内容到 RenderTexture 中
        camera.render(node);
        // 这样我们就能从 RenderTexture 中获取到数据了
        // 获取指定像素的点信息(2.2.0以后改变了相机的渲染方式，需要调整)
        var size = node.getContentSize();
        var pixels = new Uint8Array(size.width * size.height * 4);
        var x = texture.width / 2 - size.width / 2;
        var y = texture.height / 2 - size.height / 2;
        var w = size.width;
        var h = size.height;
        var data = texture.readPixels(pixels, x, y, w, h);
        //存储所截图片
        console.log("路径：", jsb.fileUtils.getWritablePath());
        var filePath = jsb.fileUtils.getWritablePath() + imageName + imageType;
        var success = jsb['saveImageData'](data, size.width, size.height, filePath);
        if (success) {
            return filePath;
        }
        else
            return null;
    };
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();