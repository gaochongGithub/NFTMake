"use strict";
cc._RF.push(module, '80092cWiohCyK8KXCmv9Cxi', 'init');
// script/init.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        // onLoad () {}
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isFullscreenEnabled = null;
        _this.screenHeight = 0;
        _this.isSafari = false;
        _this.rerotation = null;
        _this.swipeTip = null; /**滑动的div */
        _this.initHeight = 0; /**初始高 */
        _this.gameDiv = null;
        _this.gameCanvas = null;
        return _this;
    }
    NewClass.prototype.start = function () {
        this.initFullScreen();
    };
    NewClass.prototype.initFullScreen = function () {
        if (cc.view.getFrameSize().width > cc.view.getFrameSize().height) {
            cc.view.setDesignResolutionSize(1334, 750, cc.ResolutionPolicy.SHOW_ALL);
        }
        if (!cc.sys.isMobile) {
            return;
        }
        if (window.location.search.indexOf("NOFULL") >= 0) {
            return;
        }
        this.initGameDiv();
        var self = this;
        window.addEventListener("resize", function () {
            self.showSwipeTip();
        }, false);
        // window.onresize = function(){
        // }
        this.showSwipeTip();
    };
    NewClass.prototype.initGameDiv = function () {
        document.body.style.margin = "0 auto";
        document.body.style.overflow = "auto";
        // var gameDiv = document.createElement('div');
        // gameDiv.id = 'GameDiv';
        var gameDiv = document.getElementById('GameDiv');
        gameDiv.style.margin = '0 auto';
        gameDiv.style.position = 'relative';
        gameDiv.style.height = '100vh';
        gameDiv.style.width = '100%';
        // document.body.appendChild(gameDiv);
        this.gameDiv = gameDiv;
        var gameCanvas = document.getElementById('GameCanvas');
        // document.body.removeChild(gameCanvas!);
        // gameDiv.appendChild(gameCanvas!);
        this.gameCanvas = gameCanvas;
        this._isFullscreenEnabled = this.isFullscreenEnabled();
        this.swipeTip = document.getElementById('swipeTip');
        this.swipeTip.style.backgroundImage = "url(img/swipe_2.gif)";
        var ua = navigator.userAgent;
        this.isSafari = ua.match(/iPhone/i) != null && ua.match(/safari/i) != null && ua.match(/Version/i) != null;
    };
    NewClass.prototype.showSwipeTip = function () {
        if (this.rerotation != window.orientation) {
            this.rerotation = window.orientation;
            this.initHeight = window.innerHeight;
            if (this.rerotation == 0 || this.rerotation == 180) {
                this.screenHeight = Math.max(window.screen.width, window.screen.height);
            }
            else {
                this.screenHeight = Math.min(window.screen.width, window.screen.height);
            }
        }
        var h = window.innerHeight;
        var isFull = (this.screenHeight == h) || (h > this.initHeight);
        if (isFull) {
            if (this.swipeTip.style.visibility != 'hidden') {
                this.swipeTip.style.zIndex = '-1';
                this.swipeTip.style.visibility = 'hidden';
                // console.log("isFull");
                this.setGameDiv();
                setTimeout(function () {
                    window.scrollTo(0, 1);
                }, 1000);
            }
        }
        else {
            if (this.swipeTip.style.visibility != 'visible') {
                this.swipeTip.style.zIndex = '996';
                this.swipeTip.style.height = (window.innerHeight + 420) + "px";
                this.swipeTip.style.display = 'block';
                this.swipeTip.style.visibility = 'visible';
                setTimeout(function () {
                    window.scrollTo(0, 1);
                }, 500);
            }
        }
    };
    //
    NewClass.prototype.setGameDiv = function () {
        var position = 'absolute';
        var gameWidth = '100%';
        var gameHeight = '100%';
        if (cc.sys.isMobile) {
            var clientWidth = document.documentElement.clientWidth;
            var clientHeight = document.documentElement.clientHeight;
            var widthRatio = clientWidth / 750;
            var heightRatio = clientHeight / 1334;
            var devicePixelRatio = cc.view.getDevicePixelRatio(); // 750 / clientWidth;
            // var width = (widthRatio > heightRatio) ? 750 * heightRatio:'100%';
            var height = (widthRatio > heightRatio) ? window.innerHeight * widthRatio * devicePixelRatio : -1;
            // if(width != '100%') {
            //     if(width > clientWidth)
            //         position = 'relative';
            //     gameWidth += 'px';
            // }
            if (height != -1) {
                if (height > clientHeight) {
                    position = 'relative';
                }
                if (this.isSafari)
                    height = height * 0.97;
                gameHeight = Math.round(height) + 'px';
            }
        }
        document.body.style.position = position;
        this.gameDiv.style.height = gameHeight;
        // gameDiv.style.width = gameWidth;
        // game.canvas!.style.height = gameHeight;
        this.gameCanvas.style.height = gameHeight;
        cc.view._resizeEvent();
        // console.log(gameHeight);
    };
    //
    NewClass.prototype.isFullscreenEnabled = function () {
        var el = document;
        return el.fullscreenEnabled ||
            el.msFullscreenEnabled ||
            // el.webkitFullscreenEnabled ||
            el.mozFullScreenEnabled || false;
    };
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();