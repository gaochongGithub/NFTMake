"use strict";
cc._RF.push(module, 'a127f/KEIxDcLDhi0XykZ41', 'GameScene');
// script/GameScene.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var TextureRender_1 = require("./TextureRender");
// import JSEncrypt from "./rsa/jsencrypt.min";
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameScene = /** @class */ (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        _this.xianglian = null;
        _this.yifu = null;
        _this.toufa = null;
        _this.zui = null;
        _this.bizi = null;
        _this.yan = null;
        _this.baozhi = null;
        _this.youshou = null;
        _this.nfeId = "";
        _this.nfeIdArr = [];
        _this.currentNum = 0;
        _this.repeatNum = 0;
        return _this;
    }
    GameScene.prototype.onLoad = function () {
    };
    GameScene.prototype.start = function () {
        // cc.view.enableRetina(true)
        // cc.view.enableAntiAlias(false);
        var data = {
            list: [],
            num: 0,
            repeat: 0
        };
        // cc.sys.localStorage.setItem("nftID", JSON.stringify(data));
        var idList = JSON.parse(cc.sys.localStorage.getItem("nftID"));
        if (idList && idList.list.length > 0) {
            this.nfeIdArr = idList.list;
            this.currentNum = idList.num;
            this.repeatNum = idList.repeat;
            this.fileNum = idList.num;
        }
        console.log(idList, this.fileNum);
        // var s = this.nfeIdArr.join(",")+",";
        // // console.log(s , "这个是");
        // var arr = [1,3,5,76,156,9,3]
        // for(var i=0;i<this.nfeIdArr.length;i++) {
        //     if(s.replace(this.nfeIdArr[i]+",","").indexOf(this.nfeIdArr[i]+",")>-1) {
        //         console.log("数组中有重复元素：" + this.nfeIdArr[i]);
        //         break;
        //     }
        // }
        // var isBol = this.isRepeat(this.nfeIdArr);
        var w = window;
        if (w.ethereum.isTokenPocket) {
        }
        else {
        }
    };
    GameScene.prototype.isRepeat = function (arr) {
        var hash = {};
        for (var i in arr) {
            if (hash[arr[i]])
                return true;
            hash[arr[i]] = true;
        }
        return false;
    };
    GameScene.prototype.onclickInit = function () {
        var _this = this;
        this.init();
        // create capture
        var self = this;
        this.createCanvas();
        var img = this.createImg();
        // this.shoeImgSrc = img.src;
        this.scheduleOnce(function () {
            for (var i = 0; i < _this.nfeIdArr.length; i++) {
                if (_this.nfeIdArr[i] == _this.nfeId) {
                    console.log(_this.nfeIdArr[i], _this.nfeId);
                    _this.repeatNum++;
                    return;
                }
            }
            _this.nfeIdArr.push(_this.nfeId);
            // this.showImage(img);
            _this.downloadImg();
            var data = {
                list: _this.nfeIdArr,
                num: _this.fileNum,
                repeat: _this.repeatNum,
            };
            cc.sys.localStorage.setItem("nftID", JSON.stringify(data));
        }, 1);
        // this.clickSpecifyShoe();
    };
    //生成指定鞋子
    GameScene.prototype.clickSpecifyShoe = function () {
        var _this = this;
        //1569  
        for (var i = 0; i < 2200; i++) {
            this.scheduleOnce(function () {
                _this.nfeId = "";
                _this.getShoePartImg(_this.randNum(0, 4), _this.bg, "00", "bg");
                _this.getShoePartImg(_this.randNum(0, 3), _this.xianglian, "01", "xianglian");
                _this.getShoePartImg(_this.randNum(0, 3), _this.yifu, "02", "yifu");
                _this.getShoePartImg(_this.randNum(0, 3), _this.toufa, "03", "toufa");
                _this.getShoePartImg(_this.randNum(0, 3), _this.zui, "04", "zui");
                _this.getShoePartImg(_this.randNum(0, 3), _this.bizi, "05", "bizi");
                _this.getShoePartImg(_this.randNum(0, 3), _this.yan, "06", "yan");
                _this.getShoePartImg(_this.randNum(0, 3), _this.baozhi, "07", "baozhi");
                _this.getShoePartImg(_this.randNum(0, 3), _this.youshou, "08", "youshou");
            }, i * 2.5);
            this.scheduleOnce(function () {
                _this.onclickInit();
            }, i * 3.5);
        }
    };
    //获取随机数
    GameScene.prototype.randNum = function (m, n) {
        var num = parseInt(Math.random() * (n - m + 1) + m);
        // num >= 10 ? num : "0" + num
        return (num).toString();
    };
    GameScene.prototype.getShoePartImg = function (rand, spr, pos, file) {
        var self = this;
        this.nfeId += "0" + rand;
        cc.resources.load(file + "/" + rand, cc.SpriteFrame, function (err, spriteFrame) {
            if (err) {
                // spr.node.active = false;
                return;
            }
            // spr.node.active = true;
            spr.spriteFrame = spriteFrame;
        });
    };
    __decorate([
        property({ type: cc.Sprite, tooltip: "背景" })
    ], GameScene.prototype, "bg", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "项链" })
    ], GameScene.prototype, "xianglian", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "衣服" })
    ], GameScene.prototype, "yifu", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "头发" })
    ], GameScene.prototype, "toufa", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "嘴" })
    ], GameScene.prototype, "zui", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "鼻子" })
    ], GameScene.prototype, "bizi", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "眼睛" })
    ], GameScene.prototype, "yan", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "报纸" })
    ], GameScene.prototype, "baozhi", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "右手" })
    ], GameScene.prototype, "youshou", void 0);
    GameScene = __decorate([
        ccclass
    ], GameScene);
    return GameScene;
}(TextureRender_1.default));
exports.default = GameScene;

cc._RF.pop();