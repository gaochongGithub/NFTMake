"use strict";
cc._RF.push(module, '735c8m8F55N0rNIVzD6+UVy', 'TextureRender');
// script/TextureRender.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TextureRender = /** @class */ (function (_super) {
    __extends(TextureRender, _super);
    function TextureRender() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.camera = null;
        _this.fileName = 0;
        _this.fileNum = 0;
        return _this;
        // init() {
        //     let texture = new cc.RenderTexture();
        //     // let gl = cc.game._renderContext;
        //     texture.initWithSize(600, 600,cc.gfx.RB_FMT_S8);
        //     this.camera = this.node.addComponent(cc.Camera);
        //     this.camera.targetTexture = texture;
        //     this.texture = texture;
        // }
        // // create the img element
        // createImg() {
        //     // return the type and dataUrl
        //     var dataURL = this._canvas.toDataURL("image/png");
        //     var img = document.createElement("img");
        //     img.src = dataURL;
        //     return img;
        // }
        // // create the canvas and context, filpY the image Data
        // createCanvas() {
        //     let width = this.texture.width;
        //     let height = this.texture.height;
        //     if (!this._canvas) {
        //         this._canvas = document.createElement('canvas');
        //         this._canvas.width = width;
        //         this._canvas.height = height;
        //     } else {
        //         this.clearCanvas();
        //     }
        //     let ctx = this._canvas.getContext('2d');
        //     this.camera.render();
        //     let data = this.texture.readPixels();
        //     // write the render data
        //     let rowBytes = width * 4;
        //     for (let row = 0; row < height; row++) {
        //         let srow = height - 1 - row;
        //         let imageData = ctx.createImageData(width, 1);
        //         let start = srow * width * 4;
        //         for (let i = 0; i < rowBytes; i++) {
        //             imageData.data[i] = data[start + i];
        //         }
        //         ctx.putImageData(imageData, 0, row);
        //     }
        //     return this._canvas;
        // }
        // getTargetArea() {
        //     let targetPos = this.targetNode.convertToWorldSpaceAR(cc.v2(0, 0))
        //     let y = cc.winSize.height - targetPos.y - this.targetNode.height / 2;
        //     let x = cc.winSize.width - targetPos.x - this.targetNode.width / 2;
        //     return {
        //         x,
        //         y
        //     }
        // }
        // // show on the canvas
        // showImage(img) {
        //     let y = this.getTargetArea().y;
        //     let x = this.getTargetArea().x;
        //     // let rect = new cc.Rect(750, 80, 1334, 750)
        //     let texture = new cc.Texture2D();
        //     texture.initWithElement(img);
        //     let spriteFrame = new cc.SpriteFrame();
        //     spriteFrame.setTexture(texture);
        //     // spriteFrame.setRect(rect)
        //     let node = new cc.Node();
        //     let sprite = node.addComponent(cc.Sprite);
        //     sprite.spriteFrame = spriteFrame;
        //     node.zIndex = cc.macro.MAX_ZINDEX;
        //     node.parent = cc.director.getScene();
        //     // set position
        //     let width = cc.winSize.width;
        //     let height = cc.winSize.height;
        //     node.x = width / 2;
        //     node.y = height / 2;
        //     node.on(cc.Node.EventType.TOUCH_START, () => {
        //         node.parent = null;
        //         node.destroy();
        //     });
        //     // this.captureAction(node, width, height);
        // }
        // // sprite action
        // captureAction(capture, width, height) {
        //     let scaleAction = cc.scaleTo(1, 0.3);
        //     let targetPos = cc.v2(width - width / 6, height / 4);
        //     let moveAction = cc.moveTo(1, targetPos);
        //     let spawn = cc.spawn(scaleAction, moveAction);
        //     let finished = cc.callFunc(() => {
        //         capture.destroy();
        //     })
        //     let action = cc.sequence(spawn, finished);
        //     capture.runAction(action);
        // }
        // clearCanvas() {
        //     let ctx = this._canvas.getContext('2d');
        //     ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
        // }
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    TextureRender.prototype.start = function () {
    };
    TextureRender.prototype.init = function () {
        var texture = new cc.RenderTexture();
        texture.initWithSize(1000, 1000, cc.gfx.RB_FMT_S8);
        // this.camera.alignWithScreen = false;
        this.camera.targetTexture = texture;
        this.texture = texture;
    };
    TextureRender.prototype.createImg = function () {
        var dataURL = this._canvas.toDataURL("image/png");
        var img = document.createElement("img");
        img.src = dataURL;
        return img;
    };
    // create the canvas and context, filpY the image Data
    TextureRender.prototype.createCanvas = function () {
        var width = this.texture.width;
        var height = this.texture.height;
        if (!this._canvas) {
            this._canvas = document.createElement('canvas');
            this._canvas.width = width;
            this._canvas.height = height;
        }
        else {
            this.clearCanvas();
        }
        var ctx = this._canvas.getContext('2d');
        this.camera.render();
        var data = this.texture.readPixels();
        // write the render data
        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = height - 1 - row;
            var imageData = ctx.createImageData(width, 1);
            var start = srow * width * 4;
            for (var i = 0; i < rowBytes; i++) {
                imageData.data[i] = data[start + i];
            }
            ctx.putImageData(imageData, 0, row);
        }
        return this._canvas;
    };
    TextureRender.prototype.clearCanvas = function () {
        var ctx = this._canvas.getContext('2d');
        ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
    };
    // show on the canvas
    TextureRender.prototype.showImage = function (img) {
        var texture = new cc.Texture2D();
        texture.initWithElement(img);
        // let rect = new cc.Rect(0 , 0 , 600, 600)
        var spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture);
        var node = new cc.Node();
        var sprite = node.addComponent(cc.Sprite);
        sprite.spriteFrame = spriteFrame;
        // spriteFrame.setRect(rect);
        // this.shoeSpr.spriteFrame = spriteFrame;
        // this.shoeSpr.targetPos = cc.v2(0,0);
        node.zIndex = cc.macro.MAX_ZINDEX;
        node.parent = cc.director.getScene();
        var width = cc.winSize.width;
        var height = cc.winSize.height;
        node.x = width / 4;
        node.y = height / 2;
        node.on(cc.Node.EventType.TOUCH_START, function () {
            node.parent = null;
            node.destroy();
        });
        // this.captureAction(node, width, height);
        //9771,9000,09771
    };
    TextureRender.prototype.downloadImg = function () {
        this.createImg();
        var img = this.init();
        this.showImage(img);
        var dataURL = this._canvas.toDataURL("image/png");
        var a = document.createElement("a");
        a.href = dataURL;
        if (this.fileNum < 10) {
            this.fileName = "000" + this.fileNum;
        }
        else if (this.fileNum >= 10 && this.fileNum < 100) {
            this.fileName = "00" + this.fileNum;
        }
        else if (this.fileNum >= 100 && this.fileNum < 1000) {
            this.fileName = "0" + this.fileNum;
        }
        else if (this.fileNum >= 1000) {
            this.fileName = this.fileNum;
        }
        this.fileNum++;
        a.download = this.fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };
    TextureRender.catpureNodeForNative = function (node, imageType, imageName) {
        if (imageType === void 0) { imageType = ".png"; }
        if (imageName === void 0) { imageName = "Image"; }
        var camera = node.addComponent(cc.Camera);
        // 由于渲染问题，需要调整垂直翻转
        node.scaleY *= -1;
        // 设置你想要的截图内容的 cullingMask
        // camera.cullingMask = 0xffffffff;
        // 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
        var texture = new cc.RenderTexture();
        var gl = cc.game["_renderContext"];
        // 如果截图内容中不包含 Mask 组件，可以不用传递第三个参数
        var winSize = cc.winSize;
        texture.initWithSize.call(texture, 1000, 1000, imageType == ".png" ? gl.STENCIL_INDEX8 : null);
        // texture.setFlipY(true);
        camera.targetTexture = texture;
        // 渲染一次摄像机，即更新一次内容到 RenderTexture 中
        camera.render(node);
        // 这样我们就能从 RenderTexture 中获取到数据了
        // 获取指定像素的点信息(2.2.0以后改变了相机的渲染方式，需要调整)
        var size = node.getContentSize();
        var pixels = new Uint8Array(size.width * size.height * 4);
        var x = texture.width / 2 - size.width / 2;
        var y = texture.height / 2 - size.height / 2;
        var w = size.width;
        var h = size.height;
        var data = texture.readPixels(pixels, x, y, w, h);
        //存储所截图片
        console.log("路径：", jsb.fileUtils.getWritablePath());
        var filePath = jsb.fileUtils.getWritablePath() + imageName + imageType;
        var success = jsb['saveImageData'](data, size.width, size.height, filePath);
        if (success) {
            return filePath;
        }
        else
            return null;
    };
    __decorate([
        property(cc.Camera)
    ], TextureRender.prototype, "camera", void 0);
    TextureRender = __decorate([
        ccclass
    ], TextureRender);
    return TextureRender;
}(cc.Component));
exports.default = TextureRender;

cc._RF.pop();