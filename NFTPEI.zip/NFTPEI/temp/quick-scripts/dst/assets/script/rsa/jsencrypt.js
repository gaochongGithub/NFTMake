
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/rsa/jsencrypt.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b170adQ2rdN1oT7ikCtMxo8', 'jsencrypt');
// script/rsa/jsencrypt.js

"use strict";

(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) : typeof define === 'function' && define.amd ? define(['exports'], factory) : factory(global.JSEncrypt = {});
})(void 0, function (exports) {
  'use strict';

  var BI_RM = "0123456789abcdefghijklmnopqrstuvwxyz";

  function int2char(n) {
    return BI_RM.charAt(n);
  } //#region BIT_OPERATIONS
  // (public) this & a


  function op_and(x, y) {
    return x & y;
  } // (public) this | a


  function op_or(x, y) {
    return x | y;
  } // (public) this ^ a


  function op_xor(x, y) {
    return x ^ y;
  } // (public) this & ~a


  function op_andnot(x, y) {
    return x & ~y;
  } // return index of lowest 1-bit in x, x < 2^31


  function lbit(x) {
    if (x == 0) {
      return -1;
    }

    var r = 0;

    if ((x & 0xffff) == 0) {
      x >>= 16;
      r += 16;
    }

    if ((x & 0xff) == 0) {
      x >>= 8;
      r += 8;
    }

    if ((x & 0xf) == 0) {
      x >>= 4;
      r += 4;
    }

    if ((x & 3) == 0) {
      x >>= 2;
      r += 2;
    }

    if ((x & 1) == 0) {
      ++r;
    }

    return r;
  } // return number of 1 bits in x


  function cbit(x) {
    var r = 0;

    while (x != 0) {
      x &= x - 1;
      ++r;
    }

    return r;
  } //#endregion BIT_OPERATIONS


  var b64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var b64pad = "=";

  function hex2b64(h) {
    var i;
    var c;
    var ret = "";

    for (i = 0; i + 3 <= h.length; i += 3) {
      c = parseInt(h.substring(i, i + 3), 16);
      ret += b64map.charAt(c >> 6) + b64map.charAt(c & 63);
    }

    if (i + 1 == h.length) {
      c = parseInt(h.substring(i, i + 1), 16);
      ret += b64map.charAt(c << 2);
    } else if (i + 2 == h.length) {
      c = parseInt(h.substring(i, i + 2), 16);
      ret += b64map.charAt(c >> 2) + b64map.charAt((c & 3) << 4);
    }

    while ((ret.length & 3) > 0) {
      ret += b64pad;
    }

    return ret;
  } // convert a base64 string to hex


  function b64tohex(s) {
    var ret = "";
    var i;
    var k = 0; // b64 state, 0-3

    var slop = 0;

    for (i = 0; i < s.length; ++i) {
      if (s.charAt(i) == b64pad) {
        break;
      }

      var v = b64map.indexOf(s.charAt(i));

      if (v < 0) {
        continue;
      }

      if (k == 0) {
        ret += int2char(v >> 2);
        slop = v & 3;
        k = 1;
      } else if (k == 1) {
        ret += int2char(slop << 2 | v >> 4);
        slop = v & 0xf;
        k = 2;
      } else if (k == 2) {
        ret += int2char(slop);
        ret += int2char(v >> 2);
        slop = v & 3;
        k = 3;
      } else {
        ret += int2char(slop << 2 | v >> 4);
        ret += int2char(v & 0xf);
        k = 0;
      }
    }

    if (k == 1) {
      ret += int2char(slop << 2);
    }

    return ret;
  }
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0
  
  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.
  
  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */

  /* global Reflect, Promise */


  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  function __extends(d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  } // Hex JavaScript decoder
  // Copyright (c) 2008-2013 Lapo Luchini <lapo@lapo.it>
  // Permission to use, copy, modify, and/or distribute this software for any
  // purpose with or without fee is hereby granted, provided that the above
  // copyright notice and this permission notice appear in all copies.
  //
  // THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
  // WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
  // MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
  // ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
  // WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
  // ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
  // OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

  /*jshint browser: true, strict: true, immed: true, latedef: true, undef: true, regexdash: false */


  var decoder;
  var Hex = {
    decode: function decode(a) {
      var i;

      if (decoder === undefined) {
        var hex = "0123456789ABCDEF";
        var ignore = " \f\n\r\t\xA0\u2028\u2029";
        decoder = {};

        for (i = 0; i < 16; ++i) {
          decoder[hex.charAt(i)] = i;
        }

        hex = hex.toLowerCase();

        for (i = 10; i < 16; ++i) {
          decoder[hex.charAt(i)] = i;
        }

        for (i = 0; i < ignore.length; ++i) {
          decoder[ignore.charAt(i)] = -1;
        }
      }

      var out = [];
      var bits = 0;
      var char_count = 0;

      for (i = 0; i < a.length; ++i) {
        var c = a.charAt(i);

        if (c == "=") {
          break;
        }

        c = decoder[c];

        if (c == -1) {
          continue;
        }

        if (c === undefined) {
          throw new Error("Illegal character at offset " + i);
        }

        bits |= c;

        if (++char_count >= 2) {
          out[out.length] = bits;
          bits = 0;
          char_count = 0;
        } else {
          bits <<= 4;
        }
      }

      if (char_count) {
        throw new Error("Hex encoding incomplete: 4 bits missing");
      }

      return out;
    }
  }; // Base64 JavaScript decoder
  // Copyright (c) 2008-2013 Lapo Luchini <lapo@lapo.it>
  // Permission to use, copy, modify, and/or distribute this software for any
  // purpose with or without fee is hereby granted, provided that the above
  // copyright notice and this permission notice appear in all copies.
  //
  // THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
  // WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
  // MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
  // ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
  // WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
  // ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
  // OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

  /*jshint browser: true, strict: true, immed: true, latedef: true, undef: true, regexdash: false */

  var decoder$1;
  var Base64 = {
    decode: function decode(a) {
      var i;

      if (decoder$1 === undefined) {
        var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        var ignore = "= \f\n\r\t\xA0\u2028\u2029";
        decoder$1 = Object.create(null);

        for (i = 0; i < 64; ++i) {
          decoder$1[b64.charAt(i)] = i;
        }

        for (i = 0; i < ignore.length; ++i) {
          decoder$1[ignore.charAt(i)] = -1;
        }
      }

      var out = [];
      var bits = 0;
      var char_count = 0;

      for (i = 0; i < a.length; ++i) {
        var c = a.charAt(i);

        if (c == "=") {
          break;
        }

        c = decoder$1[c];

        if (c == -1) {
          continue;
        }

        if (c === undefined) {
          throw new Error("Illegal character at offset " + i);
        }

        bits |= c;

        if (++char_count >= 4) {
          out[out.length] = bits >> 16;
          out[out.length] = bits >> 8 & 0xFF;
          out[out.length] = bits & 0xFF;
          bits = 0;
          char_count = 0;
        } else {
          bits <<= 6;
        }
      }

      switch (char_count) {
        case 1:
          throw new Error("Base64 encoding incomplete: at least 2 bits missing");

        case 2:
          out[out.length] = bits >> 10;
          break;

        case 3:
          out[out.length] = bits >> 16;
          out[out.length] = bits >> 8 & 0xFF;
          break;
      }

      return out;
    },
    re: /-----BEGIN [^-]+-----([A-Za-z0-9+\/=\s]+)-----END [^-]+-----|begin-base64[^\n]+\n([A-Za-z0-9+\/=\s]+)====/,
    unarmor: function unarmor(a) {
      var m = Base64.re.exec(a);

      if (m) {
        if (m[1]) {
          a = m[1];
        } else if (m[2]) {
          a = m[2];
        } else {
          throw new Error("RegExp out of sync");
        }
      }

      return Base64.decode(a);
    }
  }; // Big integer base-10 printing library
  // Copyright (c) 2014 Lapo Luchini <lapo@lapo.it>
  // Permission to use, copy, modify, and/or distribute this software for any
  // purpose with or without fee is hereby granted, provided that the above
  // copyright notice and this permission notice appear in all copies.
  //
  // THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
  // WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
  // MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
  // ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
  // WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
  // ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
  // OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

  /*jshint browser: true, strict: true, immed: true, latedef: true, undef: true, regexdash: false */

  var max = 10000000000000; // biggest integer that can still fit 2^53 when multiplied by 256

  var Int10 =
  /** @class */
  function () {
    function Int10(value) {
      this.buf = [+value || 0];
    }

    Int10.prototype.mulAdd = function (m, c) {
      // assert(m <= 256)
      var b = this.buf;
      var l = b.length;
      var i;
      var t;

      for (i = 0; i < l; ++i) {
        t = b[i] * m + c;

        if (t < max) {
          c = 0;
        } else {
          c = 0 | t / max;
          t -= c * max;
        }

        b[i] = t;
      }

      if (c > 0) {
        b[i] = c;
      }
    };

    Int10.prototype.sub = function (c) {
      // assert(m <= 256)
      var b = this.buf;
      var l = b.length;
      var i;
      var t;

      for (i = 0; i < l; ++i) {
        t = b[i] - c;

        if (t < 0) {
          t += max;
          c = 1;
        } else {
          c = 0;
        }

        b[i] = t;
      }

      while (b[b.length - 1] === 0) {
        b.pop();
      }
    };

    Int10.prototype.toString = function (base) {
      if ((base || 10) != 10) {
        throw new Error("only base 10 is supported");
      }

      var b = this.buf;
      var s = b[b.length - 1].toString();

      for (var i = b.length - 2; i >= 0; --i) {
        s += (max + b[i]).toString().substring(1);
      }

      return s;
    };

    Int10.prototype.valueOf = function () {
      var b = this.buf;
      var v = 0;

      for (var i = b.length - 1; i >= 0; --i) {
        v = v * max + b[i];
      }

      return v;
    };

    Int10.prototype.simplify = function () {
      var b = this.buf;
      return b.length == 1 ? b[0] : this;
    };

    return Int10;
  }(); // ASN.1 JavaScript decoder


  var ellipsis = "\u2026";
  var reTimeS = /^(\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/;
  var reTimeL = /^(\d\d\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/;

  function stringCut(str, len) {
    if (str.length > len) {
      str = str.substring(0, len) + ellipsis;
    }

    return str;
  }

  var Stream =
  /** @class */
  function () {
    function Stream(enc, pos) {
      this.hexDigits = "0123456789ABCDEF";

      if (enc instanceof Stream) {
        this.enc = enc.enc;
        this.pos = enc.pos;
      } else {
        // enc should be an array or a binary string
        this.enc = enc;
        this.pos = pos;
      }
    }

    Stream.prototype.get = function (pos) {
      if (pos === undefined) {
        pos = this.pos++;
      }

      if (pos >= this.enc.length) {
        throw new Error("Requesting byte offset " + pos + " on a stream of length " + this.enc.length);
      }

      return "string" === typeof this.enc ? this.enc.charCodeAt(pos) : this.enc[pos];
    };

    Stream.prototype.hexByte = function (b) {
      return this.hexDigits.charAt(b >> 4 & 0xF) + this.hexDigits.charAt(b & 0xF);
    };

    Stream.prototype.hexDump = function (start, end, raw) {
      var s = "";

      for (var i = start; i < end; ++i) {
        s += this.hexByte(this.get(i));

        if (raw !== true) {
          switch (i & 0xF) {
            case 0x7:
              s += "  ";
              break;

            case 0xF:
              s += "\n";
              break;

            default:
              s += " ";
          }
        }
      }

      return s;
    };

    Stream.prototype.isASCII = function (start, end) {
      for (var i = start; i < end; ++i) {
        var c = this.get(i);

        if (c < 32 || c > 176) {
          return false;
        }
      }

      return true;
    };

    Stream.prototype.parseStringISO = function (start, end) {
      var s = "";

      for (var i = start; i < end; ++i) {
        s += String.fromCharCode(this.get(i));
      }

      return s;
    };

    Stream.prototype.parseStringUTF = function (start, end) {
      var s = "";

      for (var i = start; i < end;) {
        var c = this.get(i++);

        if (c < 128) {
          s += String.fromCharCode(c);
        } else if (c > 191 && c < 224) {
          s += String.fromCharCode((c & 0x1F) << 6 | this.get(i++) & 0x3F);
        } else {
          s += String.fromCharCode((c & 0x0F) << 12 | (this.get(i++) & 0x3F) << 6 | this.get(i++) & 0x3F);
        }
      }

      return s;
    };

    Stream.prototype.parseStringBMP = function (start, end) {
      var str = "";
      var hi;
      var lo;

      for (var i = start; i < end;) {
        hi = this.get(i++);
        lo = this.get(i++);
        str += String.fromCharCode(hi << 8 | lo);
      }

      return str;
    };

    Stream.prototype.parseTime = function (start, end, shortYear) {
      var s = this.parseStringISO(start, end);
      var m = (shortYear ? reTimeS : reTimeL).exec(s);

      if (!m) {
        return "Unrecognized time: " + s;
      }

      if (shortYear) {
        // to avoid querying the timer, use the fixed range [1970, 2069]
        // it will conform with ITU X.400 [-10, +40] sliding window until 2030
        m[1] = +m[1];
        m[1] += +m[1] < 70 ? 2000 : 1900;
      }

      s = m[1] + "-" + m[2] + "-" + m[3] + " " + m[4];

      if (m[5]) {
        s += ":" + m[5];

        if (m[6]) {
          s += ":" + m[6];

          if (m[7]) {
            s += "." + m[7];
          }
        }
      }

      if (m[8]) {
        s += " UTC";

        if (m[8] != "Z") {
          s += m[8];

          if (m[9]) {
            s += ":" + m[9];
          }
        }
      }

      return s;
    };

    Stream.prototype.parseInteger = function (start, end) {
      var v = this.get(start);
      var neg = v > 127;
      var pad = neg ? 255 : 0;
      var len;
      var s = ""; // skip unuseful bits (not allowed in DER)

      while (v == pad && ++start < end) {
        v = this.get(start);
      }

      len = end - start;

      if (len === 0) {
        return neg ? -1 : 0;
      } // show bit length of huge integers


      if (len > 4) {
        s = v;
        len <<= 3;

        while (((+s ^ pad) & 0x80) == 0) {
          s = +s << 1;
          --len;
        }

        s = "(" + len + " bit)\n";
      } // decode the integer


      if (neg) {
        v = v - 256;
      }

      var n = new Int10(v);

      for (var i = start + 1; i < end; ++i) {
        n.mulAdd(256, this.get(i));
      }

      return s + n.toString();
    };

    Stream.prototype.parseBitString = function (start, end, maxLength) {
      var unusedBit = this.get(start);
      var lenBit = (end - start - 1 << 3) - unusedBit;
      var intro = "(" + lenBit + " bit)\n";
      var s = "";

      for (var i = start + 1; i < end; ++i) {
        var b = this.get(i);
        var skip = i == end - 1 ? unusedBit : 0;

        for (var j = 7; j >= skip; --j) {
          s += b >> j & 1 ? "1" : "0";
        }

        if (s.length > maxLength) {
          return intro + stringCut(s, maxLength);
        }
      }

      return intro + s;
    };

    Stream.prototype.parseOctetString = function (start, end, maxLength) {
      if (this.isASCII(start, end)) {
        return stringCut(this.parseStringISO(start, end), maxLength);
      }

      var len = end - start;
      var s = "(" + len + " byte)\n";
      maxLength /= 2; // we work in bytes

      if (len > maxLength) {
        end = start + maxLength;
      }

      for (var i = start; i < end; ++i) {
        s += this.hexByte(this.get(i));
      }

      if (len > maxLength) {
        s += ellipsis;
      }

      return s;
    };

    Stream.prototype.parseOID = function (start, end, maxLength) {
      var s = "";
      var n = new Int10();
      var bits = 0;

      for (var i = start; i < end; ++i) {
        var v = this.get(i);
        n.mulAdd(128, v & 0x7F);
        bits += 7;

        if (!(v & 0x80)) {
          // finished
          if (s === "") {
            n = n.simplify();

            if (n instanceof Int10) {
              n.sub(80);
              s = "2." + n.toString();
            } else {
              var m = n < 80 ? n < 40 ? 0 : 1 : 2;
              s = m + "." + (n - m * 40);
            }
          } else {
            s += "." + n.toString();
          }

          if (s.length > maxLength) {
            return stringCut(s, maxLength);
          }

          n = new Int10();
          bits = 0;
        }
      }

      if (bits > 0) {
        s += ".incomplete";
      }

      return s;
    };

    return Stream;
  }();

  var ASN1 =
  /** @class */
  function () {
    function ASN1(stream, header, length, tag, sub) {
      if (!(tag instanceof ASN1Tag)) {
        throw new Error("Invalid tag value.");
      }

      this.stream = stream;
      this.header = header;
      this.length = length;
      this.tag = tag;
      this.sub = sub;
    }

    ASN1.prototype.typeName = function () {
      switch (this.tag.tagClass) {
        case 0:
          // universal
          switch (this.tag.tagNumber) {
            case 0x00:
              return "EOC";

            case 0x01:
              return "BOOLEAN";

            case 0x02:
              return "INTEGER";

            case 0x03:
              return "BIT_STRING";

            case 0x04:
              return "OCTET_STRING";

            case 0x05:
              return "NULL";

            case 0x06:
              return "OBJECT_IDENTIFIER";

            case 0x07:
              return "ObjectDescriptor";

            case 0x08:
              return "EXTERNAL";

            case 0x09:
              return "REAL";

            case 0x0A:
              return "ENUMERATED";

            case 0x0B:
              return "EMBEDDED_PDV";

            case 0x0C:
              return "UTF8String";

            case 0x10:
              return "SEQUENCE";

            case 0x11:
              return "SET";

            case 0x12:
              return "NumericString";

            case 0x13:
              return "PrintableString";
            // ASCII subset

            case 0x14:
              return "TeletexString";
            // aka T61String

            case 0x15:
              return "VideotexString";

            case 0x16:
              return "IA5String";
            // ASCII

            case 0x17:
              return "UTCTime";

            case 0x18:
              return "GeneralizedTime";

            case 0x19:
              return "GraphicString";

            case 0x1A:
              return "VisibleString";
            // ASCII subset

            case 0x1B:
              return "GeneralString";

            case 0x1C:
              return "UniversalString";

            case 0x1E:
              return "BMPString";
          }

          return "Universal_" + this.tag.tagNumber.toString();

        case 1:
          return "Application_" + this.tag.tagNumber.toString();

        case 2:
          return "[" + this.tag.tagNumber.toString() + "]";
        // Context

        case 3:
          return "Private_" + this.tag.tagNumber.toString();
      }
    };

    ASN1.prototype.content = function (maxLength) {
      if (this.tag === undefined) {
        return null;
      }

      if (maxLength === undefined) {
        maxLength = Infinity;
      }

      var content = this.posContent();
      var len = Math.abs(this.length);

      if (!this.tag.isUniversal()) {
        if (this.sub !== null) {
          return "(" + this.sub.length + " elem)";
        }

        return this.stream.parseOctetString(content, content + len, maxLength);
      }

      switch (this.tag.tagNumber) {
        case 0x01:
          // BOOLEAN
          return this.stream.get(content) === 0 ? "false" : "true";

        case 0x02:
          // INTEGER
          return this.stream.parseInteger(content, content + len);

        case 0x03:
          // BIT_STRING
          return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseBitString(content, content + len, maxLength);

        case 0x04:
          // OCTET_STRING
          return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseOctetString(content, content + len, maxLength);
        // case 0x05: // NULL

        case 0x06:
          // OBJECT_IDENTIFIER
          return this.stream.parseOID(content, content + len, maxLength);
        // case 0x07: // ObjectDescriptor
        // case 0x08: // EXTERNAL
        // case 0x09: // REAL
        // case 0x0A: // ENUMERATED
        // case 0x0B: // EMBEDDED_PDV

        case 0x10: // SEQUENCE

        case 0x11:
          // SET
          if (this.sub !== null) {
            return "(" + this.sub.length + " elem)";
          } else {
            return "(no elem)";
          }

        case 0x0C:
          // UTF8String
          return stringCut(this.stream.parseStringUTF(content, content + len), maxLength);

        case 0x12: // NumericString

        case 0x13: // PrintableString

        case 0x14: // TeletexString

        case 0x15: // VideotexString

        case 0x16: // IA5String
        // case 0x19: // GraphicString

        case 0x1A:
          // VisibleString
          // case 0x1B: // GeneralString
          // case 0x1C: // UniversalString
          return stringCut(this.stream.parseStringISO(content, content + len), maxLength);

        case 0x1E:
          // BMPString
          return stringCut(this.stream.parseStringBMP(content, content + len), maxLength);

        case 0x17: // UTCTime

        case 0x18:
          // GeneralizedTime
          return this.stream.parseTime(content, content + len, this.tag.tagNumber == 0x17);
      }

      return null;
    };

    ASN1.prototype.toString = function () {
      return this.typeName() + "@" + this.stream.pos + "[header:" + this.header + ",length:" + this.length + ",sub:" + (this.sub === null ? "null" : this.sub.length) + "]";
    };

    ASN1.prototype.toPrettyString = function (indent) {
      if (indent === undefined) {
        indent = "";
      }

      var s = indent + this.typeName() + " @" + this.stream.pos;

      if (this.length >= 0) {
        s += "+";
      }

      s += this.length;

      if (this.tag.tagConstructed) {
        s += " (constructed)";
      } else if (this.tag.isUniversal() && (this.tag.tagNumber == 0x03 || this.tag.tagNumber == 0x04) && this.sub !== null) {
        s += " (encapsulates)";
      }

      s += "\n";

      if (this.sub !== null) {
        indent += "  ";

        for (var i = 0, max = this.sub.length; i < max; ++i) {
          s += this.sub[i].toPrettyString(indent);
        }
      }

      return s;
    };

    ASN1.prototype.posStart = function () {
      return this.stream.pos;
    };

    ASN1.prototype.posContent = function () {
      return this.stream.pos + this.header;
    };

    ASN1.prototype.posEnd = function () {
      return this.stream.pos + this.header + Math.abs(this.length);
    };

    ASN1.prototype.toHexString = function () {
      return this.stream.hexDump(this.posStart(), this.posEnd(), true);
    };

    ASN1.decodeLength = function (stream) {
      var buf = stream.get();
      var len = buf & 0x7F;

      if (len == buf) {
        return len;
      } // no reason to use Int10, as it would be a huge buffer anyways


      if (len > 6) {
        throw new Error("Length over 48 bits not supported at position " + (stream.pos - 1));
      }

      if (len === 0) {
        return null;
      } // undefined


      buf = 0;

      for (var i = 0; i < len; ++i) {
        buf = buf * 256 + stream.get();
      }

      return buf;
    };
    /**
     * Retrieve the hexadecimal value (as a string) of the current ASN.1 element
     * @returns {string}
     * @public
     */


    ASN1.prototype.getHexStringValue = function () {
      var hexString = this.toHexString();
      var offset = this.header * 2;
      var length = this.length * 2;
      return hexString.substr(offset, length);
    };

    ASN1.decode = function (str) {
      var stream;

      if (!(str instanceof Stream)) {
        stream = new Stream(str, 0);
      } else {
        stream = str;
      }

      var streamStart = new Stream(stream);
      var tag = new ASN1Tag(stream);
      var len = ASN1.decodeLength(stream);
      var start = stream.pos;
      var header = start - streamStart.pos;
      var sub = null;

      var getSub = function getSub() {
        var ret = [];

        if (len !== null) {
          // definite length
          var end = start + len;

          while (stream.pos < end) {
            ret[ret.length] = ASN1.decode(stream);
          }

          if (stream.pos != end) {
            throw new Error("Content size is not correct for container starting at offset " + start);
          }
        } else {
          // undefined length
          try {
            for (;;) {
              var s = ASN1.decode(stream);

              if (s.tag.isEOC()) {
                break;
              }

              ret[ret.length] = s;
            }

            len = start - stream.pos; // undefined lengths are represented as negative values
          } catch (e) {
            throw new Error("Exception while decoding undefined length content: " + e);
          }
        }

        return ret;
      };

      if (tag.tagConstructed) {
        // must have valid content
        sub = getSub();
      } else if (tag.isUniversal() && (tag.tagNumber == 0x03 || tag.tagNumber == 0x04)) {
        // sometimes BitString and OctetString are used to encapsulate ASN.1
        try {
          if (tag.tagNumber == 0x03) {
            if (stream.get() != 0) {
              throw new Error("BIT STRINGs with unused bits cannot encapsulate.");
            }
          }

          sub = getSub();

          for (var i = 0; i < sub.length; ++i) {
            if (sub[i].tag.isEOC()) {
              throw new Error("EOC is not supposed to be actual content.");
            }
          }
        } catch (e) {
          // but silently ignore when they don't
          sub = null;
        }
      }

      if (sub === null) {
        if (len === null) {
          throw new Error("We can't skip over an invalid tag with undefined length at offset " + start);
        }

        stream.pos = start + Math.abs(len);
      }

      return new ASN1(streamStart, header, len, tag, sub);
    };

    return ASN1;
  }();

  var ASN1Tag =
  /** @class */
  function () {
    function ASN1Tag(stream) {
      var buf = stream.get();
      this.tagClass = buf >> 6;
      this.tagConstructed = (buf & 0x20) !== 0;
      this.tagNumber = buf & 0x1F;

      if (this.tagNumber == 0x1F) {
        // long tag
        var n = new Int10();

        do {
          buf = stream.get();
          n.mulAdd(128, buf & 0x7F);
        } while (buf & 0x80);

        this.tagNumber = n.simplify();
      }
    }

    ASN1Tag.prototype.isUniversal = function () {
      return this.tagClass === 0x00;
    };

    ASN1Tag.prototype.isEOC = function () {
      return this.tagClass === 0x00 && this.tagNumber === 0x00;
    };

    return ASN1Tag;
  }(); // Copyright (c) 2005  Tom Wu
  // Bits per digit


  var dbits; // JavaScript engine analysis

  var canary = 0xdeadbeefcafe;
  var j_lm = (canary & 0xffffff) == 0xefcafe; //#region

  var lowprimes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997];
  var lplim = (1 << 26) / lowprimes[lowprimes.length - 1]; //#endregion
  // (public) Constructor

  var BigInteger =
  /** @class */
  function () {
    function BigInteger(a, b, c) {
      if (a != null) {
        if ("number" == typeof a) {
          this.fromNumber(a, b, c);
        } else if (b == null && "string" != typeof a) {
          this.fromString(a, 256);
        } else {
          this.fromString(a, b);
        }
      }
    } //#region PUBLIC
    // BigInteger.prototype.toString = bnToString;
    // (public) return string representation in given radix


    BigInteger.prototype.toString = function (b) {
      if (this.s < 0) {
        return "-" + this.negate().toString(b);
      }

      var k;

      if (b == 16) {
        k = 4;
      } else if (b == 8) {
        k = 3;
      } else if (b == 2) {
        k = 1;
      } else if (b == 32) {
        k = 5;
      } else if (b == 4) {
        k = 2;
      } else {
        return this.toRadix(b);
      }

      var km = (1 << k) - 1;
      var d;
      var m = false;
      var r = "";
      var i = this.t;
      var p = this.DB - i * this.DB % k;

      if (i-- > 0) {
        if (p < this.DB && (d = this[i] >> p) > 0) {
          m = true;
          r = int2char(d);
        }

        while (i >= 0) {
          if (p < k) {
            d = (this[i] & (1 << p) - 1) << k - p;
            d |= this[--i] >> (p += this.DB - k);
          } else {
            d = this[i] >> (p -= k) & km;

            if (p <= 0) {
              p += this.DB;
              --i;
            }
          }

          if (d > 0) {
            m = true;
          }

          if (m) {
            r += int2char(d);
          }
        }
      }

      return m ? r : "0";
    }; // BigInteger.prototype.negate = bnNegate;
    // (public) -this


    BigInteger.prototype.negate = function () {
      var r = nbi();
      BigInteger.ZERO.subTo(this, r);
      return r;
    }; // BigInteger.prototype.abs = bnAbs;
    // (public) |this|


    BigInteger.prototype.abs = function () {
      return this.s < 0 ? this.negate() : this;
    }; // BigInteger.prototype.compareTo = bnCompareTo;
    // (public) return + if this > a, - if this < a, 0 if equal


    BigInteger.prototype.compareTo = function (a) {
      var r = this.s - a.s;

      if (r != 0) {
        return r;
      }

      var i = this.t;
      r = i - a.t;

      if (r != 0) {
        return this.s < 0 ? -r : r;
      }

      while (--i >= 0) {
        if ((r = this[i] - a[i]) != 0) {
          return r;
        }
      }

      return 0;
    }; // BigInteger.prototype.bitLength = bnBitLength;
    // (public) return the number of bits in "this"


    BigInteger.prototype.bitLength = function () {
      if (this.t <= 0) {
        return 0;
      }

      return this.DB * (this.t - 1) + nbits(this[this.t - 1] ^ this.s & this.DM);
    }; // BigInteger.prototype.mod = bnMod;
    // (public) this mod a


    BigInteger.prototype.mod = function (a) {
      var r = nbi();
      this.abs().divRemTo(a, null, r);

      if (this.s < 0 && r.compareTo(BigInteger.ZERO) > 0) {
        a.subTo(r, r);
      }

      return r;
    }; // BigInteger.prototype.modPowInt = bnModPowInt;
    // (public) this^e % m, 0 <= e < 2^32


    BigInteger.prototype.modPowInt = function (e, m) {
      var z;

      if (e < 256 || m.isEven()) {
        z = new Classic(m);
      } else {
        z = new Montgomery(m);
      }

      return this.exp(e, z);
    }; // BigInteger.prototype.clone = bnClone;
    // (public)


    BigInteger.prototype.clone = function () {
      var r = nbi();
      this.copyTo(r);
      return r;
    }; // BigInteger.prototype.intValue = bnIntValue;
    // (public) return value as integer


    BigInteger.prototype.intValue = function () {
      if (this.s < 0) {
        if (this.t == 1) {
          return this[0] - this.DV;
        } else if (this.t == 0) {
          return -1;
        }
      } else if (this.t == 1) {
        return this[0];
      } else if (this.t == 0) {
        return 0;
      } // assumes 16 < DB < 32


      return (this[1] & (1 << 32 - this.DB) - 1) << this.DB | this[0];
    }; // BigInteger.prototype.byteValue = bnByteValue;
    // (public) return value as byte


    BigInteger.prototype.byteValue = function () {
      return this.t == 0 ? this.s : this[0] << 24 >> 24;
    }; // BigInteger.prototype.shortValue = bnShortValue;
    // (public) return value as short (assumes DB>=16)


    BigInteger.prototype.shortValue = function () {
      return this.t == 0 ? this.s : this[0] << 16 >> 16;
    }; // BigInteger.prototype.signum = bnSigNum;
    // (public) 0 if this == 0, 1 if this > 0


    BigInteger.prototype.signum = function () {
      if (this.s < 0) {
        return -1;
      } else if (this.t <= 0 || this.t == 1 && this[0] <= 0) {
        return 0;
      } else {
        return 1;
      }
    }; // BigInteger.prototype.toByteArray = bnToByteArray;
    // (public) convert to bigendian byte array


    BigInteger.prototype.toByteArray = function () {
      var i = this.t;
      var r = [];
      r[0] = this.s;
      var p = this.DB - i * this.DB % 8;
      var d;
      var k = 0;

      if (i-- > 0) {
        if (p < this.DB && (d = this[i] >> p) != (this.s & this.DM) >> p) {
          r[k++] = d | this.s << this.DB - p;
        }

        while (i >= 0) {
          if (p < 8) {
            d = (this[i] & (1 << p) - 1) << 8 - p;
            d |= this[--i] >> (p += this.DB - 8);
          } else {
            d = this[i] >> (p -= 8) & 0xff;

            if (p <= 0) {
              p += this.DB;
              --i;
            }
          }

          if ((d & 0x80) != 0) {
            d |= -256;
          }

          if (k == 0 && (this.s & 0x80) != (d & 0x80)) {
            ++k;
          }

          if (k > 0 || d != this.s) {
            r[k++] = d;
          }
        }
      }

      return r;
    }; // BigInteger.prototype.equals = bnEquals;


    BigInteger.prototype.equals = function (a) {
      return this.compareTo(a) == 0;
    }; // BigInteger.prototype.min = bnMin;


    BigInteger.prototype.min = function (a) {
      return this.compareTo(a) < 0 ? this : a;
    }; // BigInteger.prototype.max = bnMax;


    BigInteger.prototype.max = function (a) {
      return this.compareTo(a) > 0 ? this : a;
    }; // BigInteger.prototype.and = bnAnd;


    BigInteger.prototype.and = function (a) {
      var r = nbi();
      this.bitwiseTo(a, op_and, r);
      return r;
    }; // BigInteger.prototype.or = bnOr;


    BigInteger.prototype.or = function (a) {
      var r = nbi();
      this.bitwiseTo(a, op_or, r);
      return r;
    }; // BigInteger.prototype.xor = bnXor;


    BigInteger.prototype.xor = function (a) {
      var r = nbi();
      this.bitwiseTo(a, op_xor, r);
      return r;
    }; // BigInteger.prototype.andNot = bnAndNot;


    BigInteger.prototype.andNot = function (a) {
      var r = nbi();
      this.bitwiseTo(a, op_andnot, r);
      return r;
    }; // BigInteger.prototype.not = bnNot;
    // (public) ~this


    BigInteger.prototype.not = function () {
      var r = nbi();

      for (var i = 0; i < this.t; ++i) {
        r[i] = this.DM & ~this[i];
      }

      r.t = this.t;
      r.s = ~this.s;
      return r;
    }; // BigInteger.prototype.shiftLeft = bnShiftLeft;
    // (public) this << n


    BigInteger.prototype.shiftLeft = function (n) {
      var r = nbi();

      if (n < 0) {
        this.rShiftTo(-n, r);
      } else {
        this.lShiftTo(n, r);
      }

      return r;
    }; // BigInteger.prototype.shiftRight = bnShiftRight;
    // (public) this >> n


    BigInteger.prototype.shiftRight = function (n) {
      var r = nbi();

      if (n < 0) {
        this.lShiftTo(-n, r);
      } else {
        this.rShiftTo(n, r);
      }

      return r;
    }; // BigInteger.prototype.getLowestSetBit = bnGetLowestSetBit;
    // (public) returns index of lowest 1-bit (or -1 if none)


    BigInteger.prototype.getLowestSetBit = function () {
      for (var i = 0; i < this.t; ++i) {
        if (this[i] != 0) {
          return i * this.DB + lbit(this[i]);
        }
      }

      if (this.s < 0) {
        return this.t * this.DB;
      }

      return -1;
    }; // BigInteger.prototype.bitCount = bnBitCount;
    // (public) return number of set bits


    BigInteger.prototype.bitCount = function () {
      var r = 0;
      var x = this.s & this.DM;

      for (var i = 0; i < this.t; ++i) {
        r += cbit(this[i] ^ x);
      }

      return r;
    }; // BigInteger.prototype.testBit = bnTestBit;
    // (public) true iff nth bit is set


    BigInteger.prototype.testBit = function (n) {
      var j = Math.floor(n / this.DB);

      if (j >= this.t) {
        return this.s != 0;
      }

      return (this[j] & 1 << n % this.DB) != 0;
    }; // BigInteger.prototype.setBit = bnSetBit;
    // (public) this | (1<<n)


    BigInteger.prototype.setBit = function (n) {
      return this.changeBit(n, op_or);
    }; // BigInteger.prototype.clearBit = bnClearBit;
    // (public) this & ~(1<<n)


    BigInteger.prototype.clearBit = function (n) {
      return this.changeBit(n, op_andnot);
    }; // BigInteger.prototype.flipBit = bnFlipBit;
    // (public) this ^ (1<<n)


    BigInteger.prototype.flipBit = function (n) {
      return this.changeBit(n, op_xor);
    }; // BigInteger.prototype.add = bnAdd;
    // (public) this + a


    BigInteger.prototype.add = function (a) {
      var r = nbi();
      this.addTo(a, r);
      return r;
    }; // BigInteger.prototype.subtract = bnSubtract;
    // (public) this - a


    BigInteger.prototype.subtract = function (a) {
      var r = nbi();
      this.subTo(a, r);
      return r;
    }; // BigInteger.prototype.multiply = bnMultiply;
    // (public) this * a


    BigInteger.prototype.multiply = function (a) {
      var r = nbi();
      this.multiplyTo(a, r);
      return r;
    }; // BigInteger.prototype.divide = bnDivide;
    // (public) this / a


    BigInteger.prototype.divide = function (a) {
      var r = nbi();
      this.divRemTo(a, r, null);
      return r;
    }; // BigInteger.prototype.remainder = bnRemainder;
    // (public) this % a


    BigInteger.prototype.remainder = function (a) {
      var r = nbi();
      this.divRemTo(a, null, r);
      return r;
    }; // BigInteger.prototype.divideAndRemainder = bnDivideAndRemainder;
    // (public) [this/a,this%a]


    BigInteger.prototype.divideAndRemainder = function (a) {
      var q = nbi();
      var r = nbi();
      this.divRemTo(a, q, r);
      return [q, r];
    }; // BigInteger.prototype.modPow = bnModPow;
    // (public) this^e % m (HAC 14.85)


    BigInteger.prototype.modPow = function (e, m) {
      var i = e.bitLength();
      var k;
      var r = nbv(1);
      var z;

      if (i <= 0) {
        return r;
      } else if (i < 18) {
        k = 1;
      } else if (i < 48) {
        k = 3;
      } else if (i < 144) {
        k = 4;
      } else if (i < 768) {
        k = 5;
      } else {
        k = 6;
      }

      if (i < 8) {
        z = new Classic(m);
      } else if (m.isEven()) {
        z = new Barrett(m);
      } else {
        z = new Montgomery(m);
      } // precomputation


      var g = [];
      var n = 3;
      var k1 = k - 1;
      var km = (1 << k) - 1;
      g[1] = z.convert(this);

      if (k > 1) {
        var g2 = nbi();
        z.sqrTo(g[1], g2);

        while (n <= km) {
          g[n] = nbi();
          z.mulTo(g2, g[n - 2], g[n]);
          n += 2;
        }
      }

      var j = e.t - 1;
      var w;
      var is1 = true;
      var r2 = nbi();
      var t;
      i = nbits(e[j]) - 1;

      while (j >= 0) {
        if (i >= k1) {
          w = e[j] >> i - k1 & km;
        } else {
          w = (e[j] & (1 << i + 1) - 1) << k1 - i;

          if (j > 0) {
            w |= e[j - 1] >> this.DB + i - k1;
          }
        }

        n = k;

        while ((w & 1) == 0) {
          w >>= 1;
          --n;
        }

        if ((i -= n) < 0) {
          i += this.DB;
          --j;
        }

        if (is1) {
          // ret == 1, don't bother squaring or multiplying it
          g[w].copyTo(r);
          is1 = false;
        } else {
          while (n > 1) {
            z.sqrTo(r, r2);
            z.sqrTo(r2, r);
            n -= 2;
          }

          if (n > 0) {
            z.sqrTo(r, r2);
          } else {
            t = r;
            r = r2;
            r2 = t;
          }

          z.mulTo(r2, g[w], r);
        }

        while (j >= 0 && (e[j] & 1 << i) == 0) {
          z.sqrTo(r, r2);
          t = r;
          r = r2;
          r2 = t;

          if (--i < 0) {
            i = this.DB - 1;
            --j;
          }
        }
      }

      return z.revert(r);
    }; // BigInteger.prototype.modInverse = bnModInverse;
    // (public) 1/this % m (HAC 14.61)


    BigInteger.prototype.modInverse = function (m) {
      var ac = m.isEven();

      if (this.isEven() && ac || m.signum() == 0) {
        return BigInteger.ZERO;
      }

      var u = m.clone();
      var v = this.clone();
      var a = nbv(1);
      var b = nbv(0);
      var c = nbv(0);
      var d = nbv(1);

      while (u.signum() != 0) {
        while (u.isEven()) {
          u.rShiftTo(1, u);

          if (ac) {
            if (!a.isEven() || !b.isEven()) {
              a.addTo(this, a);
              b.subTo(m, b);
            }

            a.rShiftTo(1, a);
          } else if (!b.isEven()) {
            b.subTo(m, b);
          }

          b.rShiftTo(1, b);
        }

        while (v.isEven()) {
          v.rShiftTo(1, v);

          if (ac) {
            if (!c.isEven() || !d.isEven()) {
              c.addTo(this, c);
              d.subTo(m, d);
            }

            c.rShiftTo(1, c);
          } else if (!d.isEven()) {
            d.subTo(m, d);
          }

          d.rShiftTo(1, d);
        }

        if (u.compareTo(v) >= 0) {
          u.subTo(v, u);

          if (ac) {
            a.subTo(c, a);
          }

          b.subTo(d, b);
        } else {
          v.subTo(u, v);

          if (ac) {
            c.subTo(a, c);
          }

          d.subTo(b, d);
        }
      }

      if (v.compareTo(BigInteger.ONE) != 0) {
        return BigInteger.ZERO;
      }

      if (d.compareTo(m) >= 0) {
        return d.subtract(m);
      }

      if (d.signum() < 0) {
        d.addTo(m, d);
      } else {
        return d;
      }

      if (d.signum() < 0) {
        return d.add(m);
      } else {
        return d;
      }
    }; // BigInteger.prototype.pow = bnPow;
    // (public) this^e


    BigInteger.prototype.pow = function (e) {
      return this.exp(e, new NullExp());
    }; // BigInteger.prototype.gcd = bnGCD;
    // (public) gcd(this,a) (HAC 14.54)


    BigInteger.prototype.gcd = function (a) {
      var x = this.s < 0 ? this.negate() : this.clone();
      var y = a.s < 0 ? a.negate() : a.clone();

      if (x.compareTo(y) < 0) {
        var t = x;
        x = y;
        y = t;
      }

      var i = x.getLowestSetBit();
      var g = y.getLowestSetBit();

      if (g < 0) {
        return x;
      }

      if (i < g) {
        g = i;
      }

      if (g > 0) {
        x.rShiftTo(g, x);
        y.rShiftTo(g, y);
      }

      while (x.signum() > 0) {
        if ((i = x.getLowestSetBit()) > 0) {
          x.rShiftTo(i, x);
        }

        if ((i = y.getLowestSetBit()) > 0) {
          y.rShiftTo(i, y);
        }

        if (x.compareTo(y) >= 0) {
          x.subTo(y, x);
          x.rShiftTo(1, x);
        } else {
          y.subTo(x, y);
          y.rShiftTo(1, y);
        }
      }

      if (g > 0) {
        y.lShiftTo(g, y);
      }

      return y;
    }; // BigInteger.prototype.isProbablePrime = bnIsProbablePrime;
    // (public) test primality with certainty >= 1-.5^t


    BigInteger.prototype.isProbablePrime = function (t) {
      var i;
      var x = this.abs();

      if (x.t == 1 && x[0] <= lowprimes[lowprimes.length - 1]) {
        for (i = 0; i < lowprimes.length; ++i) {
          if (x[0] == lowprimes[i]) {
            return true;
          }
        }

        return false;
      }

      if (x.isEven()) {
        return false;
      }

      i = 1;

      while (i < lowprimes.length) {
        var m = lowprimes[i];
        var j = i + 1;

        while (j < lowprimes.length && m < lplim) {
          m *= lowprimes[j++];
        }

        m = x.modInt(m);

        while (i < j) {
          if (m % lowprimes[i++] == 0) {
            return false;
          }
        }
      }

      return x.millerRabin(t);
    }; //#endregion PUBLIC
    //#region PROTECTED
    // BigInteger.prototype.copyTo = bnpCopyTo;
    // (protected) copy this to r


    BigInteger.prototype.copyTo = function (r) {
      for (var i = this.t - 1; i >= 0; --i) {
        r[i] = this[i];
      }

      r.t = this.t;
      r.s = this.s;
    }; // BigInteger.prototype.fromInt = bnpFromInt;
    // (protected) set from integer value x, -DV <= x < DV


    BigInteger.prototype.fromInt = function (x) {
      this.t = 1;
      this.s = x < 0 ? -1 : 0;

      if (x > 0) {
        this[0] = x;
      } else if (x < -1) {
        this[0] = x + this.DV;
      } else {
        this.t = 0;
      }
    }; // BigInteger.prototype.fromString = bnpFromString;
    // (protected) set from string and radix


    BigInteger.prototype.fromString = function (s, b) {
      var k;

      if (b == 16) {
        k = 4;
      } else if (b == 8) {
        k = 3;
      } else if (b == 256) {
        k = 8;
        /* byte array */
      } else if (b == 2) {
        k = 1;
      } else if (b == 32) {
        k = 5;
      } else if (b == 4) {
        k = 2;
      } else {
        this.fromRadix(s, b);
        return;
      }

      this.t = 0;
      this.s = 0;
      var i = s.length;
      var mi = false;
      var sh = 0;

      while (--i >= 0) {
        var x = k == 8 ? +s[i] & 0xff : intAt(s, i);

        if (x < 0) {
          if (s.charAt(i) == "-") {
            mi = true;
          }

          continue;
        }

        mi = false;

        if (sh == 0) {
          this[this.t++] = x;
        } else if (sh + k > this.DB) {
          this[this.t - 1] |= (x & (1 << this.DB - sh) - 1) << sh;
          this[this.t++] = x >> this.DB - sh;
        } else {
          this[this.t - 1] |= x << sh;
        }

        sh += k;

        if (sh >= this.DB) {
          sh -= this.DB;
        }
      }

      if (k == 8 && (+s[0] & 0x80) != 0) {
        this.s = -1;

        if (sh > 0) {
          this[this.t - 1] |= (1 << this.DB - sh) - 1 << sh;
        }
      }

      this.clamp();

      if (mi) {
        BigInteger.ZERO.subTo(this, this);
      }
    }; // BigInteger.prototype.clamp = bnpClamp;
    // (protected) clamp off excess high words


    BigInteger.prototype.clamp = function () {
      var c = this.s & this.DM;

      while (this.t > 0 && this[this.t - 1] == c) {
        --this.t;
      }
    }; // BigInteger.prototype.dlShiftTo = bnpDLShiftTo;
    // (protected) r = this << n*DB


    BigInteger.prototype.dlShiftTo = function (n, r) {
      var i;

      for (i = this.t - 1; i >= 0; --i) {
        r[i + n] = this[i];
      }

      for (i = n - 1; i >= 0; --i) {
        r[i] = 0;
      }

      r.t = this.t + n;
      r.s = this.s;
    }; // BigInteger.prototype.drShiftTo = bnpDRShiftTo;
    // (protected) r = this >> n*DB


    BigInteger.prototype.drShiftTo = function (n, r) {
      for (var i = n; i < this.t; ++i) {
        r[i - n] = this[i];
      }

      r.t = Math.max(this.t - n, 0);
      r.s = this.s;
    }; // BigInteger.prototype.lShiftTo = bnpLShiftTo;
    // (protected) r = this << n


    BigInteger.prototype.lShiftTo = function (n, r) {
      var bs = n % this.DB;
      var cbs = this.DB - bs;
      var bm = (1 << cbs) - 1;
      var ds = Math.floor(n / this.DB);
      var c = this.s << bs & this.DM;

      for (var i = this.t - 1; i >= 0; --i) {
        r[i + ds + 1] = this[i] >> cbs | c;
        c = (this[i] & bm) << bs;
      }

      for (var i = ds - 1; i >= 0; --i) {
        r[i] = 0;
      }

      r[ds] = c;
      r.t = this.t + ds + 1;
      r.s = this.s;
      r.clamp();
    }; // BigInteger.prototype.rShiftTo = bnpRShiftTo;
    // (protected) r = this >> n


    BigInteger.prototype.rShiftTo = function (n, r) {
      r.s = this.s;
      var ds = Math.floor(n / this.DB);

      if (ds >= this.t) {
        r.t = 0;
        return;
      }

      var bs = n % this.DB;
      var cbs = this.DB - bs;
      var bm = (1 << bs) - 1;
      r[0] = this[ds] >> bs;

      for (var i = ds + 1; i < this.t; ++i) {
        r[i - ds - 1] |= (this[i] & bm) << cbs;
        r[i - ds] = this[i] >> bs;
      }

      if (bs > 0) {
        r[this.t - ds - 1] |= (this.s & bm) << cbs;
      }

      r.t = this.t - ds;
      r.clamp();
    }; // BigInteger.prototype.subTo = bnpSubTo;
    // (protected) r = this - a


    BigInteger.prototype.subTo = function (a, r) {
      var i = 0;
      var c = 0;
      var m = Math.min(a.t, this.t);

      while (i < m) {
        c += this[i] - a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }

      if (a.t < this.t) {
        c -= a.s;

        while (i < this.t) {
          c += this[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }

        c += this.s;
      } else {
        c += this.s;

        while (i < a.t) {
          c -= a[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }

        c -= a.s;
      }

      r.s = c < 0 ? -1 : 0;

      if (c < -1) {
        r[i++] = this.DV + c;
      } else if (c > 0) {
        r[i++] = c;
      }

      r.t = i;
      r.clamp();
    }; // BigInteger.prototype.multiplyTo = bnpMultiplyTo;
    // (protected) r = this * a, r != this,a (HAC 14.12)
    // "this" should be the larger one if appropriate.


    BigInteger.prototype.multiplyTo = function (a, r) {
      var x = this.abs();
      var y = a.abs();
      var i = x.t;
      r.t = i + y.t;

      while (--i >= 0) {
        r[i] = 0;
      }

      for (i = 0; i < y.t; ++i) {
        r[i + x.t] = x.am(0, y[i], r, i, 0, x.t);
      }

      r.s = 0;
      r.clamp();

      if (this.s != a.s) {
        BigInteger.ZERO.subTo(r, r);
      }
    }; // BigInteger.prototype.squareTo = bnpSquareTo;
    // (protected) r = this^2, r != this (HAC 14.16)


    BigInteger.prototype.squareTo = function (r) {
      var x = this.abs();
      var i = r.t = 2 * x.t;

      while (--i >= 0) {
        r[i] = 0;
      }

      for (i = 0; i < x.t - 1; ++i) {
        var c = x.am(i, x[i], r, 2 * i, 0, 1);

        if ((r[i + x.t] += x.am(i + 1, 2 * x[i], r, 2 * i + 1, c, x.t - i - 1)) >= x.DV) {
          r[i + x.t] -= x.DV;
          r[i + x.t + 1] = 1;
        }
      }

      if (r.t > 0) {
        r[r.t - 1] += x.am(i, x[i], r, 2 * i, 0, 1);
      }

      r.s = 0;
      r.clamp();
    }; // BigInteger.prototype.divRemTo = bnpDivRemTo;
    // (protected) divide this by m, quotient and remainder to q, r (HAC 14.20)
    // r != q, this != m.  q or r may be null.


    BigInteger.prototype.divRemTo = function (m, q, r) {
      var pm = m.abs();

      if (pm.t <= 0) {
        return;
      }

      var pt = this.abs();

      if (pt.t < pm.t) {
        if (q != null) {
          q.fromInt(0);
        }

        if (r != null) {
          this.copyTo(r);
        }

        return;
      }

      if (r == null) {
        r = nbi();
      }

      var y = nbi();
      var ts = this.s;
      var ms = m.s;
      var nsh = this.DB - nbits(pm[pm.t - 1]); // normalize modulus

      if (nsh > 0) {
        pm.lShiftTo(nsh, y);
        pt.lShiftTo(nsh, r);
      } else {
        pm.copyTo(y);
        pt.copyTo(r);
      }

      var ys = y.t;
      var y0 = y[ys - 1];

      if (y0 == 0) {
        return;
      }

      var yt = y0 * (1 << this.F1) + (ys > 1 ? y[ys - 2] >> this.F2 : 0);
      var d1 = this.FV / yt;
      var d2 = (1 << this.F1) / yt;
      var e = 1 << this.F2;
      var i = r.t;
      var j = i - ys;
      var t = q == null ? nbi() : q;
      y.dlShiftTo(j, t);

      if (r.compareTo(t) >= 0) {
        r[r.t++] = 1;
        r.subTo(t, r);
      }

      BigInteger.ONE.dlShiftTo(ys, t);
      t.subTo(y, y); // "negative" y so we can replace sub with am later

      while (y.t < ys) {
        y[y.t++] = 0;
      }

      while (--j >= 0) {
        // Estimate quotient digit
        var qd = r[--i] == y0 ? this.DM : Math.floor(r[i] * d1 + (r[i - 1] + e) * d2);

        if ((r[i] += y.am(0, qd, r, j, 0, ys)) < qd) {
          // Try it out
          y.dlShiftTo(j, t);
          r.subTo(t, r);

          while (r[i] < --qd) {
            r.subTo(t, r);
          }
        }
      }

      if (q != null) {
        r.drShiftTo(ys, q);

        if (ts != ms) {
          BigInteger.ZERO.subTo(q, q);
        }
      }

      r.t = ys;
      r.clamp();

      if (nsh > 0) {
        r.rShiftTo(nsh, r);
      } // Denormalize remainder


      if (ts < 0) {
        BigInteger.ZERO.subTo(r, r);
      }
    }; // BigInteger.prototype.invDigit = bnpInvDigit;
    // (protected) return "-1/this % 2^DB"; useful for Mont. reduction
    // justification:
    //         xy == 1 (mod m)
    //         xy =  1+km
    //   xy(2-xy) = (1+km)(1-km)
    // x[y(2-xy)] = 1-k^2m^2
    // x[y(2-xy)] == 1 (mod m^2)
    // if y is 1/x mod m, then y(2-xy) is 1/x mod m^2
    // should reduce x and y(2-xy) by m^2 at each step to keep size bounded.
    // JS multiply "overflows" differently from C/C++, so care is needed here.


    BigInteger.prototype.invDigit = function () {
      if (this.t < 1) {
        return 0;
      }

      var x = this[0];

      if ((x & 1) == 0) {
        return 0;
      }

      var y = x & 3; // y == 1/x mod 2^2

      y = y * (2 - (x & 0xf) * y) & 0xf; // y == 1/x mod 2^4

      y = y * (2 - (x & 0xff) * y) & 0xff; // y == 1/x mod 2^8

      y = y * (2 - ((x & 0xffff) * y & 0xffff)) & 0xffff; // y == 1/x mod 2^16
      // last step - calculate inverse mod DV directly;
      // assumes 16 < DB <= 32 and assumes ability to handle 48-bit ints

      y = y * (2 - x * y % this.DV) % this.DV; // y == 1/x mod 2^dbits
      // we really want the negative inverse, and -DV < y < DV

      return y > 0 ? this.DV - y : -y;
    }; // BigInteger.prototype.isEven = bnpIsEven;
    // (protected) true iff this is even


    BigInteger.prototype.isEven = function () {
      return (this.t > 0 ? this[0] & 1 : this.s) == 0;
    }; // BigInteger.prototype.exp = bnpExp;
    // (protected) this^e, e < 2^32, doing sqr and mul with "r" (HAC 14.79)


    BigInteger.prototype.exp = function (e, z) {
      if (e > 0xffffffff || e < 1) {
        return BigInteger.ONE;
      }

      var r = nbi();
      var r2 = nbi();
      var g = z.convert(this);
      var i = nbits(e) - 1;
      g.copyTo(r);

      while (--i >= 0) {
        z.sqrTo(r, r2);

        if ((e & 1 << i) > 0) {
          z.mulTo(r2, g, r);
        } else {
          var t = r;
          r = r2;
          r2 = t;
        }
      }

      return z.revert(r);
    }; // BigInteger.prototype.chunkSize = bnpChunkSize;
    // (protected) return x s.t. r^x < DV


    BigInteger.prototype.chunkSize = function (r) {
      return Math.floor(Math.LN2 * this.DB / Math.log(r));
    }; // BigInteger.prototype.toRadix = bnpToRadix;
    // (protected) convert to radix string


    BigInteger.prototype.toRadix = function (b) {
      if (b == null) {
        b = 10;
      }

      if (this.signum() == 0 || b < 2 || b > 36) {
        return "0";
      }

      var cs = this.chunkSize(b);
      var a = Math.pow(b, cs);
      var d = nbv(a);
      var y = nbi();
      var z = nbi();
      var r = "";
      this.divRemTo(d, y, z);

      while (y.signum() > 0) {
        r = (a + z.intValue()).toString(b).substr(1) + r;
        y.divRemTo(d, y, z);
      }

      return z.intValue().toString(b) + r;
    }; // BigInteger.prototype.fromRadix = bnpFromRadix;
    // (protected) convert from radix string


    BigInteger.prototype.fromRadix = function (s, b) {
      this.fromInt(0);

      if (b == null) {
        b = 10;
      }

      var cs = this.chunkSize(b);
      var d = Math.pow(b, cs);
      var mi = false;
      var j = 0;
      var w = 0;

      for (var i = 0; i < s.length; ++i) {
        var x = intAt(s, i);

        if (x < 0) {
          if (s.charAt(i) == "-" && this.signum() == 0) {
            mi = true;
          }

          continue;
        }

        w = b * w + x;

        if (++j >= cs) {
          this.dMultiply(d);
          this.dAddOffset(w, 0);
          j = 0;
          w = 0;
        }
      }

      if (j > 0) {
        this.dMultiply(Math.pow(b, j));
        this.dAddOffset(w, 0);
      }

      if (mi) {
        BigInteger.ZERO.subTo(this, this);
      }
    }; // BigInteger.prototype.fromNumber = bnpFromNumber;
    // (protected) alternate constructor


    BigInteger.prototype.fromNumber = function (a, b, c) {
      if ("number" == typeof b) {
        // new BigInteger(int,int,RNG)
        if (a < 2) {
          this.fromInt(1);
        } else {
          this.fromNumber(a, c);

          if (!this.testBit(a - 1)) {
            // force MSB set
            this.bitwiseTo(BigInteger.ONE.shiftLeft(a - 1), op_or, this);
          }

          if (this.isEven()) {
            this.dAddOffset(1, 0);
          } // force odd


          while (!this.isProbablePrime(b)) {
            this.dAddOffset(2, 0);

            if (this.bitLength() > a) {
              this.subTo(BigInteger.ONE.shiftLeft(a - 1), this);
            }
          }
        }
      } else {
        // new BigInteger(int,RNG)
        var x = [];
        var t = a & 7;
        x.length = (a >> 3) + 1;
        b.nextBytes(x);

        if (t > 0) {
          x[0] &= (1 << t) - 1;
        } else {
          x[0] = 0;
        }

        this.fromString(x, 256);
      }
    }; // BigInteger.prototype.bitwiseTo = bnpBitwiseTo;
    // (protected) r = this op a (bitwise)


    BigInteger.prototype.bitwiseTo = function (a, op, r) {
      var i;
      var f;
      var m = Math.min(a.t, this.t);

      for (i = 0; i < m; ++i) {
        r[i] = op(this[i], a[i]);
      }

      if (a.t < this.t) {
        f = a.s & this.DM;

        for (i = m; i < this.t; ++i) {
          r[i] = op(this[i], f);
        }

        r.t = this.t;
      } else {
        f = this.s & this.DM;

        for (i = m; i < a.t; ++i) {
          r[i] = op(f, a[i]);
        }

        r.t = a.t;
      }

      r.s = op(this.s, a.s);
      r.clamp();
    }; // BigInteger.prototype.changeBit = bnpChangeBit;
    // (protected) this op (1<<n)


    BigInteger.prototype.changeBit = function (n, op) {
      var r = BigInteger.ONE.shiftLeft(n);
      this.bitwiseTo(r, op, r);
      return r;
    }; // BigInteger.prototype.addTo = bnpAddTo;
    // (protected) r = this + a


    BigInteger.prototype.addTo = function (a, r) {
      var i = 0;
      var c = 0;
      var m = Math.min(a.t, this.t);

      while (i < m) {
        c += this[i] + a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }

      if (a.t < this.t) {
        c += a.s;

        while (i < this.t) {
          c += this[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }

        c += this.s;
      } else {
        c += this.s;

        while (i < a.t) {
          c += a[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }

        c += a.s;
      }

      r.s = c < 0 ? -1 : 0;

      if (c > 0) {
        r[i++] = c;
      } else if (c < -1) {
        r[i++] = this.DV + c;
      }

      r.t = i;
      r.clamp();
    }; // BigInteger.prototype.dMultiply = bnpDMultiply;
    // (protected) this *= n, this >= 0, 1 < n < DV


    BigInteger.prototype.dMultiply = function (n) {
      this[this.t] = this.am(0, n - 1, this, 0, 0, this.t);
      ++this.t;
      this.clamp();
    }; // BigInteger.prototype.dAddOffset = bnpDAddOffset;
    // (protected) this += n << w words, this >= 0


    BigInteger.prototype.dAddOffset = function (n, w) {
      if (n == 0) {
        return;
      }

      while (this.t <= w) {
        this[this.t++] = 0;
      }

      this[w] += n;

      while (this[w] >= this.DV) {
        this[w] -= this.DV;

        if (++w >= this.t) {
          this[this.t++] = 0;
        }

        ++this[w];
      }
    }; // BigInteger.prototype.multiplyLowerTo = bnpMultiplyLowerTo;
    // (protected) r = lower n words of "this * a", a.t <= n
    // "this" should be the larger one if appropriate.


    BigInteger.prototype.multiplyLowerTo = function (a, n, r) {
      var i = Math.min(this.t + a.t, n);
      r.s = 0; // assumes a,this >= 0

      r.t = i;

      while (i > 0) {
        r[--i] = 0;
      }

      for (var j = r.t - this.t; i < j; ++i) {
        r[i + this.t] = this.am(0, a[i], r, i, 0, this.t);
      }

      for (var j = Math.min(a.t, n); i < j; ++i) {
        this.am(0, a[i], r, i, 0, n - i);
      }

      r.clamp();
    }; // BigInteger.prototype.multiplyUpperTo = bnpMultiplyUpperTo;
    // (protected) r = "this * a" without lower n words, n > 0
    // "this" should be the larger one if appropriate.


    BigInteger.prototype.multiplyUpperTo = function (a, n, r) {
      --n;
      var i = r.t = this.t + a.t - n;
      r.s = 0; // assumes a,this >= 0

      while (--i >= 0) {
        r[i] = 0;
      }

      for (i = Math.max(n - this.t, 0); i < a.t; ++i) {
        r[this.t + i - n] = this.am(n - i, a[i], r, 0, 0, this.t + i - n);
      }

      r.clamp();
      r.drShiftTo(1, r);
    }; // BigInteger.prototype.modInt = bnpModInt;
    // (protected) this % n, n < 2^26


    BigInteger.prototype.modInt = function (n) {
      if (n <= 0) {
        return 0;
      }

      var d = this.DV % n;
      var r = this.s < 0 ? n - 1 : 0;

      if (this.t > 0) {
        if (d == 0) {
          r = this[0] % n;
        } else {
          for (var i = this.t - 1; i >= 0; --i) {
            r = (d * r + this[i]) % n;
          }
        }
      }

      return r;
    }; // BigInteger.prototype.millerRabin = bnpMillerRabin;
    // (protected) true if probably prime (HAC 4.24, Miller-Rabin)


    BigInteger.prototype.millerRabin = function (t) {
      var n1 = this.subtract(BigInteger.ONE);
      var k = n1.getLowestSetBit();

      if (k <= 0) {
        return false;
      }

      var r = n1.shiftRight(k);
      t = t + 1 >> 1;

      if (t > lowprimes.length) {
        t = lowprimes.length;
      }

      var a = nbi();

      for (var i = 0; i < t; ++i) {
        // Pick bases at random, instead of starting at 2
        a.fromInt(lowprimes[Math.floor(Math.random() * lowprimes.length)]);
        var y = a.modPow(r, this);

        if (y.compareTo(BigInteger.ONE) != 0 && y.compareTo(n1) != 0) {
          var j = 1;

          while (j++ < k && y.compareTo(n1) != 0) {
            y = y.modPowInt(2, this);

            if (y.compareTo(BigInteger.ONE) == 0) {
              return false;
            }
          }

          if (y.compareTo(n1) != 0) {
            return false;
          }
        }
      }

      return true;
    }; // BigInteger.prototype.square = bnSquare;
    // (public) this^2


    BigInteger.prototype.square = function () {
      var r = nbi();
      this.squareTo(r);
      return r;
    }; //#region ASYNC
    // Public API method


    BigInteger.prototype.gcda = function (a, callback) {
      var x = this.s < 0 ? this.negate() : this.clone();
      var y = a.s < 0 ? a.negate() : a.clone();

      if (x.compareTo(y) < 0) {
        var t = x;
        x = y;
        y = t;
      }

      var i = x.getLowestSetBit();
      var g = y.getLowestSetBit();

      if (g < 0) {
        callback(x);
        return;
      }

      if (i < g) {
        g = i;
      }

      if (g > 0) {
        x.rShiftTo(g, x);
        y.rShiftTo(g, y);
      } // Workhorse of the algorithm, gets called 200 - 800 times per 512 bit keygen.


      var gcda1 = function gcda1() {
        if ((i = x.getLowestSetBit()) > 0) {
          x.rShiftTo(i, x);
        }

        if ((i = y.getLowestSetBit()) > 0) {
          y.rShiftTo(i, y);
        }

        if (x.compareTo(y) >= 0) {
          x.subTo(y, x);
          x.rShiftTo(1, x);
        } else {
          y.subTo(x, y);
          y.rShiftTo(1, y);
        }

        if (!(x.signum() > 0)) {
          if (g > 0) {
            y.lShiftTo(g, y);
          }

          setTimeout(function () {
            callback(y);
          }, 0); // escape
        } else {
          setTimeout(gcda1, 0);
        }
      };

      setTimeout(gcda1, 10);
    }; // (protected) alternate constructor


    BigInteger.prototype.fromNumberAsync = function (a, b, c, callback) {
      if ("number" == typeof b) {
        if (a < 2) {
          this.fromInt(1);
        } else {
          this.fromNumber(a, c);

          if (!this.testBit(a - 1)) {
            this.bitwiseTo(BigInteger.ONE.shiftLeft(a - 1), op_or, this);
          }

          if (this.isEven()) {
            this.dAddOffset(1, 0);
          }

          var bnp_1 = this;

          var bnpfn1_1 = function bnpfn1_1() {
            bnp_1.dAddOffset(2, 0);

            if (bnp_1.bitLength() > a) {
              bnp_1.subTo(BigInteger.ONE.shiftLeft(a - 1), bnp_1);
            }

            if (bnp_1.isProbablePrime(b)) {
              setTimeout(function () {
                callback();
              }, 0); // escape
            } else {
              setTimeout(bnpfn1_1, 0);
            }
          };

          setTimeout(bnpfn1_1, 0);
        }
      } else {
        var x = [];
        var t = a & 7;
        x.length = (a >> 3) + 1;
        b.nextBytes(x);

        if (t > 0) {
          x[0] &= (1 << t) - 1;
        } else {
          x[0] = 0;
        }

        this.fromString(x, 256);
      }
    };

    return BigInteger;
  }(); //#region REDUCERS
  //#region NullExp


  var NullExp =
  /** @class */
  function () {
    function NullExp() {} // NullExp.prototype.convert = nNop;


    NullExp.prototype.convert = function (x) {
      return x;
    }; // NullExp.prototype.revert = nNop;


    NullExp.prototype.revert = function (x) {
      return x;
    }; // NullExp.prototype.mulTo = nMulTo;


    NullExp.prototype.mulTo = function (x, y, r) {
      x.multiplyTo(y, r);
    }; // NullExp.prototype.sqrTo = nSqrTo;


    NullExp.prototype.sqrTo = function (x, r) {
      x.squareTo(r);
    };

    return NullExp;
  }(); // Modular reduction using "classic" algorithm


  var Classic =
  /** @class */
  function () {
    function Classic(m) {
      this.m = m;
    } // Classic.prototype.convert = cConvert;


    Classic.prototype.convert = function (x) {
      if (x.s < 0 || x.compareTo(this.m) >= 0) {
        return x.mod(this.m);
      } else {
        return x;
      }
    }; // Classic.prototype.revert = cRevert;


    Classic.prototype.revert = function (x) {
      return x;
    }; // Classic.prototype.reduce = cReduce;


    Classic.prototype.reduce = function (x) {
      x.divRemTo(this.m, null, x);
    }; // Classic.prototype.mulTo = cMulTo;


    Classic.prototype.mulTo = function (x, y, r) {
      x.multiplyTo(y, r);
      this.reduce(r);
    }; // Classic.prototype.sqrTo = cSqrTo;


    Classic.prototype.sqrTo = function (x, r) {
      x.squareTo(r);
      this.reduce(r);
    };

    return Classic;
  }(); //#endregion
  //#region Montgomery
  // Montgomery reduction


  var Montgomery =
  /** @class */
  function () {
    function Montgomery(m) {
      this.m = m;
      this.mp = m.invDigit();
      this.mpl = this.mp & 0x7fff;
      this.mph = this.mp >> 15;
      this.um = (1 << m.DB - 15) - 1;
      this.mt2 = 2 * m.t;
    } // Montgomery.prototype.convert = montConvert;
    // xR mod m


    Montgomery.prototype.convert = function (x) {
      var r = nbi();
      x.abs().dlShiftTo(this.m.t, r);
      r.divRemTo(this.m, null, r);

      if (x.s < 0 && r.compareTo(BigInteger.ZERO) > 0) {
        this.m.subTo(r, r);
      }

      return r;
    }; // Montgomery.prototype.revert = montRevert;
    // x/R mod m


    Montgomery.prototype.revert = function (x) {
      var r = nbi();
      x.copyTo(r);
      this.reduce(r);
      return r;
    }; // Montgomery.prototype.reduce = montReduce;
    // x = x/R mod m (HAC 14.32)


    Montgomery.prototype.reduce = function (x) {
      while (x.t <= this.mt2) {
        // pad x so am has enough room later
        x[x.t++] = 0;
      }

      for (var i = 0; i < this.m.t; ++i) {
        // faster way of calculating u0 = x[i]*mp mod DV
        var j = x[i] & 0x7fff;
        var u0 = j * this.mpl + ((j * this.mph + (x[i] >> 15) * this.mpl & this.um) << 15) & x.DM; // use am to combine the multiply-shift-add into one call

        j = i + this.m.t;
        x[j] += this.m.am(0, u0, x, i, 0, this.m.t); // propagate carry

        while (x[j] >= x.DV) {
          x[j] -= x.DV;
          x[++j]++;
        }
      }

      x.clamp();
      x.drShiftTo(this.m.t, x);

      if (x.compareTo(this.m) >= 0) {
        x.subTo(this.m, x);
      }
    }; // Montgomery.prototype.mulTo = montMulTo;
    // r = "xy/R mod m"; x,y != r


    Montgomery.prototype.mulTo = function (x, y, r) {
      x.multiplyTo(y, r);
      this.reduce(r);
    }; // Montgomery.prototype.sqrTo = montSqrTo;
    // r = "x^2/R mod m"; x != r


    Montgomery.prototype.sqrTo = function (x, r) {
      x.squareTo(r);
      this.reduce(r);
    };

    return Montgomery;
  }(); //#endregion Montgomery
  //#region Barrett
  // Barrett modular reduction


  var Barrett =
  /** @class */
  function () {
    function Barrett(m) {
      this.m = m; // setup Barrett

      this.r2 = nbi();
      this.q3 = nbi();
      BigInteger.ONE.dlShiftTo(2 * m.t, this.r2);
      this.mu = this.r2.divide(m);
    } // Barrett.prototype.convert = barrettConvert;


    Barrett.prototype.convert = function (x) {
      if (x.s < 0 || x.t > 2 * this.m.t) {
        return x.mod(this.m);
      } else if (x.compareTo(this.m) < 0) {
        return x;
      } else {
        var r = nbi();
        x.copyTo(r);
        this.reduce(r);
        return r;
      }
    }; // Barrett.prototype.revert = barrettRevert;


    Barrett.prototype.revert = function (x) {
      return x;
    }; // Barrett.prototype.reduce = barrettReduce;
    // x = x mod m (HAC 14.42)


    Barrett.prototype.reduce = function (x) {
      x.drShiftTo(this.m.t - 1, this.r2);

      if (x.t > this.m.t + 1) {
        x.t = this.m.t + 1;
        x.clamp();
      }

      this.mu.multiplyUpperTo(this.r2, this.m.t + 1, this.q3);
      this.m.multiplyLowerTo(this.q3, this.m.t + 1, this.r2);

      while (x.compareTo(this.r2) < 0) {
        x.dAddOffset(1, this.m.t + 1);
      }

      x.subTo(this.r2, x);

      while (x.compareTo(this.m) >= 0) {
        x.subTo(this.m, x);
      }
    }; // Barrett.prototype.mulTo = barrettMulTo;
    // r = x*y mod m; x,y != r


    Barrett.prototype.mulTo = function (x, y, r) {
      x.multiplyTo(y, r);
      this.reduce(r);
    }; // Barrett.prototype.sqrTo = barrettSqrTo;
    // r = x^2 mod m; x != r


    Barrett.prototype.sqrTo = function (x, r) {
      x.squareTo(r);
      this.reduce(r);
    };

    return Barrett;
  }(); //#endregion
  //#endregion REDUCERS
  // return new, unset BigInteger


  function nbi() {
    return new BigInteger(null);
  }

  function parseBigInt(str, r) {
    return new BigInteger(str, r);
  } // am: Compute w_j += (x*this_i), propagate carries,
  // c is initial carry, returns final carry.
  // c < 3*dvalue, x < 2*dvalue, this_i < dvalue
  // We need to select the fastest one that works in this environment.
  // am1: use a single mult and divide to get the high bits,
  // max digit bits should be 26 because
  // max internal value = 2*dvalue^2-2*dvalue (< 2^53)


  function am1(i, x, w, j, c, n) {
    while (--n >= 0) {
      var v = x * this[i++] + w[j] + c;
      c = Math.floor(v / 0x4000000);
      w[j++] = v & 0x3ffffff;
    }

    return c;
  } // am2 avoids a big mult-and-extract completely.
  // Max digit bits should be <= 30 because we do bitwise ops
  // on values up to 2*hdvalue^2-hdvalue-1 (< 2^31)


  function am2(i, x, w, j, c, n) {
    var xl = x & 0x7fff;
    var xh = x >> 15;

    while (--n >= 0) {
      var l = this[i] & 0x7fff;
      var h = this[i++] >> 15;
      var m = xh * l + h * xl;
      l = xl * l + ((m & 0x7fff) << 15) + w[j] + (c & 0x3fffffff);
      c = (l >>> 30) + (m >>> 15) + xh * h + (c >>> 30);
      w[j++] = l & 0x3fffffff;
    }

    return c;
  } // Alternately, set max digit bits to 28 since some
  // browsers slow down when dealing with 32-bit numbers.


  function am3(i, x, w, j, c, n) {
    var xl = x & 0x3fff;
    var xh = x >> 14;

    while (--n >= 0) {
      var l = this[i] & 0x3fff;
      var h = this[i++] >> 14;
      var m = xh * l + h * xl;
      l = xl * l + ((m & 0x3fff) << 14) + w[j] + c;
      c = (l >> 28) + (m >> 14) + xh * h;
      w[j++] = l & 0xfffffff;
    }

    return c;
  }

  if (j_lm && navigator.appName == "Microsoft Internet Explorer") {
    BigInteger.prototype.am = am2;
    dbits = 30;
  } else if (j_lm && navigator.appName != "Netscape") {
    BigInteger.prototype.am = am1;
    dbits = 26;
  } else {
    // Mozilla/Netscape seems to prefer am3
    BigInteger.prototype.am = am3;
    dbits = 28;
  }

  BigInteger.prototype.DB = dbits;
  BigInteger.prototype.DM = (1 << dbits) - 1;
  BigInteger.prototype.DV = 1 << dbits;
  var BI_FP = 52;
  BigInteger.prototype.FV = Math.pow(2, BI_FP);
  BigInteger.prototype.F1 = BI_FP - dbits;
  BigInteger.prototype.F2 = 2 * dbits - BI_FP; // Digit conversions

  var BI_RC = [];
  var rr;
  var vv;
  rr = "0".charCodeAt(0);

  for (vv = 0; vv <= 9; ++vv) {
    BI_RC[rr++] = vv;
  }

  rr = "a".charCodeAt(0);

  for (vv = 10; vv < 36; ++vv) {
    BI_RC[rr++] = vv;
  }

  rr = "A".charCodeAt(0);

  for (vv = 10; vv < 36; ++vv) {
    BI_RC[rr++] = vv;
  }

  function intAt(s, i) {
    var c = BI_RC[s.charCodeAt(i)];
    return c == null ? -1 : c;
  } // return bigint initialized to value


  function nbv(i) {
    var r = nbi();
    r.fromInt(i);
    return r;
  } // returns bit length of the integer x


  function nbits(x) {
    var r = 1;
    var t;

    if ((t = x >>> 16) != 0) {
      x = t;
      r += 16;
    }

    if ((t = x >> 8) != 0) {
      x = t;
      r += 8;
    }

    if ((t = x >> 4) != 0) {
      x = t;
      r += 4;
    }

    if ((t = x >> 2) != 0) {
      x = t;
      r += 2;
    }

    if ((t = x >> 1) != 0) {
      x = t;
      r += 1;
    }

    return r;
  } // "constants"


  BigInteger.ZERO = nbv(0);
  BigInteger.ONE = nbv(1); // prng4.js - uses Arcfour as a PRNG

  var Arcfour =
  /** @class */
  function () {
    function Arcfour() {
      this.i = 0;
      this.j = 0;
      this.S = [];
    } // Arcfour.prototype.init = ARC4init;
    // Initialize arcfour context from key, an array of ints, each from [0..255]


    Arcfour.prototype.init = function (key) {
      var i;
      var j;
      var t;

      for (i = 0; i < 256; ++i) {
        this.S[i] = i;
      }

      j = 0;

      for (i = 0; i < 256; ++i) {
        j = j + this.S[i] + key[i % key.length] & 255;
        t = this.S[i];
        this.S[i] = this.S[j];
        this.S[j] = t;
      }

      this.i = 0;
      this.j = 0;
    }; // Arcfour.prototype.next = ARC4next;


    Arcfour.prototype.next = function () {
      var t;
      this.i = this.i + 1 & 255;
      this.j = this.j + this.S[this.i] & 255;
      t = this.S[this.i];
      this.S[this.i] = this.S[this.j];
      this.S[this.j] = t;
      return this.S[t + this.S[this.i] & 255];
    };

    return Arcfour;
  }(); // Plug in your RNG constructor here


  function prng_newstate() {
    return new Arcfour();
  } // Pool size must be a multiple of 4 and greater than 32.
  // An array of bytes the size of the pool will be passed to init()


  var rng_psize = 256; // Random number generator - requires a PRNG backend, e.g. prng4.js

  var rng_state;
  var rng_pool = null;
  var rng_pptr; // Initialize the pool with junk if needed.

  if (rng_pool == null) {
    rng_pool = [];
    rng_pptr = 0;
    var t = void 0;

    if (window.crypto && window.crypto.getRandomValues) {
      // Extract entropy (2048 bits) from RNG if available
      var z = new Uint32Array(256);
      window.crypto.getRandomValues(z);

      for (t = 0; t < z.length; ++t) {
        rng_pool[rng_pptr++] = z[t] & 255;
      }
    } // Use mouse events for entropy, if we do not have enough entropy by the time
    // we need it, entropy will be generated by Math.random.


    var onMouseMoveListener_1 = function onMouseMoveListener_1(ev) {
      this.count = this.count || 0;

      if (this.count >= 256 || rng_pptr >= rng_psize) {
        if (window.removeEventListener) {
          window.removeEventListener("mousemove", onMouseMoveListener_1, false);
        } else if (window.detachEvent) {
          window.detachEvent("onmousemove", onMouseMoveListener_1);
        }

        return;
      }

      try {
        var mouseCoordinates = ev.x + ev.y;
        rng_pool[rng_pptr++] = mouseCoordinates & 255;
        this.count += 1;
      } catch (e) {// Sometimes Firefox will deny permission to access event properties for some reason. Ignore.
      }
    };

    if (window.addEventListener) {
      window.addEventListener("mousemove", onMouseMoveListener_1, false);
    } else if (window.attachEvent) {
      window.attachEvent("onmousemove", onMouseMoveListener_1);
    }
  }

  function rng_get_byte() {
    if (rng_state == null) {
      rng_state = prng_newstate(); // At this point, we may not have collected enough entropy.  If not, fall back to Math.random

      while (rng_pptr < rng_psize) {
        var random = Math.floor(65536 * Math.random());
        rng_pool[rng_pptr++] = random & 255;
      }

      rng_state.init(rng_pool);

      for (rng_pptr = 0; rng_pptr < rng_pool.length; ++rng_pptr) {
        rng_pool[rng_pptr] = 0;
      }

      rng_pptr = 0;
    } // TODO: allow reseeding after first request


    return rng_state.next();
  }

  var SecureRandom =
  /** @class */
  function () {
    function SecureRandom() {}

    SecureRandom.prototype.nextBytes = function (ba) {
      for (var i = 0; i < ba.length; ++i) {
        ba[i] = rng_get_byte();
      }
    };

    return SecureRandom;
  }(); // Depends on jsbn.js and rng.js
  // function linebrk(s,n) {
  //   var ret = "";
  //   var i = 0;
  //   while(i + n < s.length) {
  //     ret += s.substring(i,i+n) + "\n";
  //     i += n;
  //   }
  //   return ret + s.substring(i,s.length);
  // }
  // function byte2Hex(b) {
  //   if(b < 0x10)
  //     return "0" + b.toString(16);
  //   else
  //     return b.toString(16);
  // }


  function pkcs1pad1(s, n) {
    if (n < s.length + 22) {
      console.error("Message too long for RSA");
      return null;
    }

    var len = n - s.length - 6;
    var filler = "";

    for (var f = 0; f < len; f += 2) {
      filler += "ff";
    }

    var m = "0001" + filler + "00" + s;
    return parseBigInt(m, 16);
  } // PKCS#1 (type 2, random) pad input string s to n bytes, and return a bigint


  function pkcs1pad2(s, n) {
    if (n < s.length + 11) {
      // TODO: fix for utf-8
      console.error("Message too long for RSA");
      return null;
    }

    var ba = [];
    var i = s.length - 1;

    while (i >= 0 && n > 0) {
      var c = s.charCodeAt(i--);

      if (c < 128) {
        // encode using utf-8
        ba[--n] = c;
      } else if (c > 127 && c < 2048) {
        ba[--n] = c & 63 | 128;
        ba[--n] = c >> 6 | 192;
      } else {
        ba[--n] = c & 63 | 128;
        ba[--n] = c >> 6 & 63 | 128;
        ba[--n] = c >> 12 | 224;
      }
    }

    ba[--n] = 0;
    var rng = new SecureRandom();
    var x = [];

    while (n > 2) {
      // random non-zero pad
      x[0] = 0;

      while (x[0] == 0) {
        rng.nextBytes(x);
      }

      ba[--n] = x[0];
    }

    ba[--n] = 2;
    ba[--n] = 0;
    return new BigInteger(ba);
  } // "empty" RSA key constructor


  var RSAKey =
  /** @class */
  function () {
    function RSAKey() {
      this.n = null;
      this.e = 0;
      this.d = null;
      this.p = null;
      this.q = null;
      this.dmp1 = null;
      this.dmq1 = null;
      this.coeff = null;
    } //#region PROTECTED
    // protected
    // RSAKey.prototype.doPublic = RSADoPublic;
    // Perform raw public operation on "x": return x^e (mod n)


    RSAKey.prototype.doPublic = function (x) {
      return x.modPowInt(this.e, this.n);
    }; // RSAKey.prototype.doPrivate = RSADoPrivate;
    // Perform raw private operation on "x": return x^d (mod n)


    RSAKey.prototype.doPrivate = function (x) {
      if (this.p == null || this.q == null) {
        return x.modPow(this.d, this.n);
      } // TODO: re-calculate any missing CRT params


      var xp = x.mod(this.p).modPow(this.dmp1, this.p);
      var xq = x.mod(this.q).modPow(this.dmq1, this.q);

      while (xp.compareTo(xq) < 0) {
        xp = xp.add(this.p);
      }

      return xp.subtract(xq).multiply(this.coeff).mod(this.p).multiply(this.q).add(xq);
    }; //#endregion PROTECTED
    //#region PUBLIC
    // RSAKey.prototype.setPublic = RSASetPublic;
    // Set the public key fields N and e from hex strings


    RSAKey.prototype.setPublic = function (N, E) {
      if (N != null && E != null && N.length > 0 && E.length > 0) {
        this.n = parseBigInt(N, 16);
        this.e = parseInt(E, 16);
      } else {
        console.error("Invalid RSA public key");
      }
    }; // RSAKey.prototype.encrypt = RSAEncrypt;
    // Return the PKCS#1 RSA encryption of "text" as an even-length hex string


    RSAKey.prototype.encrypt = function (text) {
      var m = pkcs1pad2(text, this.n.bitLength() + 7 >> 3);

      if (m == null) {
        return null;
      }

      var c = this.doPublic(m);

      if (c == null) {
        return null;
      }

      var h = c.toString(16);

      if ((h.length & 1) == 0) {
        return h;
      } else {
        return "0" + h;
      }
    };
    /**
     * 长文本加密
     * @param {string} string 待加密长文本
     * @returns {string} 加密后的base64编码
     */


    RSAKey.prototype.encryptLong = function (text) {
      var _this = this;

      var maxLength = (this.n.bitLength() + 7 >> 3) - 11;

      try {
        var ct_1 = "";

        if (text.length > maxLength) {
          var lt = text.match(/.{1,117}/g);
          lt.forEach(function (entry) {
            var t1 = _this.encrypt(entry);

            ct_1 += t1;
          });
          return hex2b64(ct_1);
        }

        var t = this.encrypt(text);
        var y = hex2b64(t);
        return y;
      } catch (ex) {
        return false;
      }
    };
    /**
     * 长文本解密
     * @param {string} string 加密后的base64编码
     * @returns {string} 解密后的原文
     */


    RSAKey.prototype.decryptLong = function (text) {
      var _this = this;

      var maxLength = this.n.bitLength() + 7 >> 3;
      text = b64tohex(text);

      try {
        if (text.length > maxLength) {
          var ct_2 = "";
          var lt = text.match(/.{1,256}/g); // 128位解密。取256位

          lt.forEach(function (entry) {
            var t1 = _this.decrypt(entry);

            ct_2 += t1;
          });
          return ct_2;
        }

        var y = this.decrypt(text);
        return y;
      } catch (ex) {
        return false;
      }
    }; // RSAKey.prototype.setPrivate = RSASetPrivate;
    // Set the private key fields N, e, and d from hex strings


    RSAKey.prototype.setPrivate = function (N, E, D) {
      if (N != null && E != null && N.length > 0 && E.length > 0) {
        this.n = parseBigInt(N, 16);
        this.e = parseInt(E, 16);
        this.d = parseBigInt(D, 16);
      } else {
        console.error("Invalid RSA private key");
      }
    }; // RSAKey.prototype.setPrivateEx = RSASetPrivateEx;
    // Set the private key fields N, e, d and CRT params from hex strings


    RSAKey.prototype.setPrivateEx = function (N, E, D, P, Q, DP, DQ, C) {
      if (N != null && E != null && N.length > 0 && E.length > 0) {
        this.n = parseBigInt(N, 16);
        this.e = parseInt(E, 16);
        this.d = parseBigInt(D, 16);
        this.p = parseBigInt(P, 16);
        this.q = parseBigInt(Q, 16);
        this.dmp1 = parseBigInt(DP, 16);
        this.dmq1 = parseBigInt(DQ, 16);
        this.coeff = parseBigInt(C, 16);
      } else {
        console.error("Invalid RSA private key");
      }
    }; // RSAKey.prototype.generate = RSAGenerate;
    // Generate a new random private key B bits long, using public expt E


    RSAKey.prototype.generate = function (B, E) {
      var rng = new SecureRandom();
      var qs = B >> 1;
      this.e = parseInt(E, 16);
      var ee = new BigInteger(E, 16);

      for (;;) {
        for (;;) {
          this.p = new BigInteger(B - qs, 1, rng);

          if (this.p.subtract(BigInteger.ONE).gcd(ee).compareTo(BigInteger.ONE) == 0 && this.p.isProbablePrime(10)) {
            break;
          }
        }

        for (;;) {
          this.q = new BigInteger(qs, 1, rng);

          if (this.q.subtract(BigInteger.ONE).gcd(ee).compareTo(BigInteger.ONE) == 0 && this.q.isProbablePrime(10)) {
            break;
          }
        }

        if (this.p.compareTo(this.q) <= 0) {
          var t = this.p;
          this.p = this.q;
          this.q = t;
        }

        var p1 = this.p.subtract(BigInteger.ONE);
        var q1 = this.q.subtract(BigInteger.ONE);
        var phi = p1.multiply(q1);

        if (phi.gcd(ee).compareTo(BigInteger.ONE) == 0) {
          this.n = this.p.multiply(this.q);
          this.d = ee.modInverse(phi);
          this.dmp1 = this.d.mod(p1);
          this.dmq1 = this.d.mod(q1);
          this.coeff = this.q.modInverse(this.p);
          break;
        }
      }
    }; // RSAKey.prototype.decrypt = RSADecrypt;
    // Return the PKCS#1 RSA decryption of "ctext".
    // "ctext" is an even-length hex string and the output is a plain string.


    RSAKey.prototype.decrypt = function (ctext) {
      var c = parseBigInt(ctext, 16);
      var m = this.doPrivate(c);

      if (m == null) {
        return null;
      }

      return pkcs1unpad2(m, this.n.bitLength() + 7 >> 3);
    }; // Generate a new random private key B bits long, using public expt E


    RSAKey.prototype.generateAsync = function (B, E, callback) {
      var rng = new SecureRandom();
      var qs = B >> 1;
      this.e = parseInt(E, 16);
      var ee = new BigInteger(E, 16);
      var rsa = this; // These functions have non-descript names because they were originally for(;;) loops.
      // I don't know about cryptography to give them better names than loop1-4.

      var loop1 = function loop1() {
        var loop4 = function loop4() {
          if (rsa.p.compareTo(rsa.q) <= 0) {
            var t = rsa.p;
            rsa.p = rsa.q;
            rsa.q = t;
          }

          var p1 = rsa.p.subtract(BigInteger.ONE);
          var q1 = rsa.q.subtract(BigInteger.ONE);
          var phi = p1.multiply(q1);

          if (phi.gcd(ee).compareTo(BigInteger.ONE) == 0) {
            rsa.n = rsa.p.multiply(rsa.q);
            rsa.d = ee.modInverse(phi);
            rsa.dmp1 = rsa.d.mod(p1);
            rsa.dmq1 = rsa.d.mod(q1);
            rsa.coeff = rsa.q.modInverse(rsa.p);
            setTimeout(function () {
              callback();
            }, 0); // escape
          } else {
            setTimeout(loop1, 0);
          }
        };

        var loop3 = function loop3() {
          rsa.q = nbi();
          rsa.q.fromNumberAsync(qs, 1, rng, function () {
            rsa.q.subtract(BigInteger.ONE).gcda(ee, function (r) {
              if (r.compareTo(BigInteger.ONE) == 0 && rsa.q.isProbablePrime(10)) {
                setTimeout(loop4, 0);
              } else {
                setTimeout(loop3, 0);
              }
            });
          });
        };

        var loop2 = function loop2() {
          rsa.p = nbi();
          rsa.p.fromNumberAsync(B - qs, 1, rng, function () {
            rsa.p.subtract(BigInteger.ONE).gcda(ee, function (r) {
              if (r.compareTo(BigInteger.ONE) == 0 && rsa.p.isProbablePrime(10)) {
                setTimeout(loop3, 0);
              } else {
                setTimeout(loop2, 0);
              }
            });
          });
        };

        setTimeout(loop2, 0);
      };

      setTimeout(loop1, 0);
    };

    RSAKey.prototype.sign = function (text, digestMethod, digestName) {
      var header = getDigestHeader(digestName);
      var digest = header + digestMethod(text).toString();
      var m = pkcs1pad1(digest, this.n.bitLength() / 4);

      if (m == null) {
        return null;
      }

      var c = this.doPrivate(m);

      if (c == null) {
        return null;
      }

      var h = c.toString(16);

      if ((h.length & 1) == 0) {
        return h;
      } else {
        return "0" + h;
      }
    };

    RSAKey.prototype.verify = function (text, signature, digestMethod) {
      var c = parseBigInt(signature, 16);
      var m = this.doPublic(c);

      if (m == null) {
        return null;
      }

      var unpadded = m.toString(16).replace(/^1f+00/, "");
      var digest = removeDigestHeader(unpadded);
      return digest == digestMethod(text).toString();
    };

    return RSAKey;
  }(); // Undo PKCS#1 (type 2, random) padding and, if valid, return the plaintext


  function pkcs1unpad2(d, n) {
    var b = d.toByteArray();
    var i = 0;

    while (i < b.length && b[i] == 0) {
      ++i;
    }

    if (b.length - i != n - 1 || b[i] != 2) {
      return null;
    }

    ++i;

    while (b[i] != 0) {
      if (++i >= b.length) {
        return null;
      }
    }

    var ret = "";

    while (++i < b.length) {
      var c = b[i] & 255;

      if (c < 128) {
        // utf-8 decode
        ret += String.fromCharCode(c);
      } else if (c > 191 && c < 224) {
        ret += String.fromCharCode((c & 31) << 6 | b[i + 1] & 63);
        ++i;
      } else {
        ret += String.fromCharCode((c & 15) << 12 | (b[i + 1] & 63) << 6 | b[i + 2] & 63);
        i += 2;
      }
    }

    return ret;
  } // https://tools.ietf.org/html/rfc3447#page-43


  var DIGEST_HEADERS = {
    md2: "3020300c06082a864886f70d020205000410",
    md5: "3020300c06082a864886f70d020505000410",
    sha1: "3021300906052b0e03021a05000414",
    sha224: "302d300d06096086480165030402040500041c",
    sha256: "3031300d060960864801650304020105000420",
    sha384: "3041300d060960864801650304020205000430",
    sha512: "3051300d060960864801650304020305000440",
    ripemd160: "3021300906052b2403020105000414"
  };

  function getDigestHeader(name) {
    return DIGEST_HEADERS[name] || "";
  }

  function removeDigestHeader(str) {
    for (var name_1 in DIGEST_HEADERS) {
      if (DIGEST_HEADERS.hasOwnProperty(name_1)) {
        var header = DIGEST_HEADERS[name_1];
        var len = header.length;

        if (str.substr(0, len) == header) {
          return str.substr(len);
        }
      }
    }

    return str;
  } // Return the PKCS#1 RSA encryption of "text" as a Base64-encoded string
  // function RSAEncryptB64(text) {
  //  var h = this.encrypt(text);
  //  if(h) return hex2b64(h); else return null;
  // }
  // public
  // RSAKey.prototype.encrypt_b64 = RSAEncryptB64;

  /*!
  Copyright (c) 2011, Yahoo! Inc. All rights reserved.
  Code licensed under the BSD License:
  http://developer.yahoo.com/yui/license.html
  version: 2.9.0
  */


  var YAHOO = {};
  YAHOO.lang = {
    /**
     * Utility to set up the prototype, constructor and superclass properties to
     * support an inheritance strategy that can chain constructors and methods.
     * Static members will not be inherited.
     *
     * @method extend
     * @static
     * @param {Function} subc   the object to modify
     * @param {Function} superc the object to inherit
     * @param {Object} overrides  additional properties/methods to add to the
     *                              subclass prototype.  These will override the
     *                              matching items obtained from the superclass
     *                              if present.
     */
    extend: function extend(subc, superc, overrides) {
      if (!superc || !subc) {
        throw new Error("YAHOO.lang.extend failed, please check that " + "all dependencies are included.");
      }

      var F = function F() {};

      F.prototype = superc.prototype;
      subc.prototype = new F();
      subc.prototype.constructor = subc;
      subc.superclass = superc.prototype;

      if (superc.prototype.constructor == Object.prototype.constructor) {
        superc.prototype.constructor = superc;
      }

      if (overrides) {
        var i;

        for (i in overrides) {
          subc.prototype[i] = overrides[i];
        }
        /*
         * IE will not enumerate native functions in a derived object even if the
         * function was overridden.  This is a workaround for specific functions
         * we care about on the Object prototype.
         * @property _IEEnumFix
         * @param {Function} r  the object to receive the augmentation
         * @param {Function} s  the object that supplies the properties to augment
         * @static
         * @private
         */


        var _IEEnumFix = function _IEEnumFix() {},
            ADD = ["toString", "valueOf"];

        try {
          if (/MSIE/.test(navigator.userAgent)) {
            _IEEnumFix = function _IEEnumFix(r, s) {
              for (i = 0; i < ADD.length; i = i + 1) {
                var fname = ADD[i],
                    f = s[fname];

                if (typeof f === 'function' && f != Object.prototype[fname]) {
                  r[fname] = f;
                }
              }
            };
          }
        } catch (ex) {}

        _IEEnumFix(subc.prototype, overrides);
      }
    }
  };
  /* asn1-1.0.13.js (c) 2013-2017 Kenji Urushima | kjur.github.com/jsrsasign/license
   */

  /**
   * @fileOverview
   * @name asn1-1.0.js
   * @author Kenji Urushima kenji.urushima@gmail.com
   * @version asn1 1.0.13 (2017-Jun-02)
   * @since jsrsasign 2.1
   * @license <a href="https://kjur.github.io/jsrsasign/license/">MIT License</a>
   */

  /**
   * kjur's class library name space
   * <p>
   * This name space provides following name spaces:
   * <ul>
   * <li>{@link KJUR.asn1} - ASN.1 primitive hexadecimal encoder</li>
   * <li>{@link KJUR.asn1.x509} - ASN.1 structure for X.509 certificate and CRL</li>
   * <li>{@link KJUR.crypto} - Java Cryptographic Extension(JCE) style MessageDigest/Signature
   * class and utilities</li>
   * </ul>
   * </p>
   * NOTE: Please ignore method summary and document of this namespace. This caused by a bug of jsdoc2.
   * @name KJUR
   * @namespace kjur's class library name space
   */

  var KJUR = {};
  /**
   * kjur's ASN.1 class library name space
   * <p>
   * This is ITU-T X.690 ASN.1 DER encoder class library and
   * class structure and methods is very similar to
   * org.bouncycastle.asn1 package of
   * well known BouncyCaslte Cryptography Library.
   * <h4>PROVIDING ASN.1 PRIMITIVES</h4>
   * Here are ASN.1 DER primitive classes.
   * <ul>
   * <li>0x01 {@link KJUR.asn1.DERBoolean}</li>
   * <li>0x02 {@link KJUR.asn1.DERInteger}</li>
   * <li>0x03 {@link KJUR.asn1.DERBitString}</li>
   * <li>0x04 {@link KJUR.asn1.DEROctetString}</li>
   * <li>0x05 {@link KJUR.asn1.DERNull}</li>
   * <li>0x06 {@link KJUR.asn1.DERObjectIdentifier}</li>
   * <li>0x0a {@link KJUR.asn1.DEREnumerated}</li>
   * <li>0x0c {@link KJUR.asn1.DERUTF8String}</li>
   * <li>0x12 {@link KJUR.asn1.DERNumericString}</li>
   * <li>0x13 {@link KJUR.asn1.DERPrintableString}</li>
   * <li>0x14 {@link KJUR.asn1.DERTeletexString}</li>
   * <li>0x16 {@link KJUR.asn1.DERIA5String}</li>
   * <li>0x17 {@link KJUR.asn1.DERUTCTime}</li>
   * <li>0x18 {@link KJUR.asn1.DERGeneralizedTime}</li>
   * <li>0x30 {@link KJUR.asn1.DERSequence}</li>
   * <li>0x31 {@link KJUR.asn1.DERSet}</li>
   * </ul>
   * <h4>OTHER ASN.1 CLASSES</h4>
   * <ul>
   * <li>{@link KJUR.asn1.ASN1Object}</li>
   * <li>{@link KJUR.asn1.DERAbstractString}</li>
   * <li>{@link KJUR.asn1.DERAbstractTime}</li>
   * <li>{@link KJUR.asn1.DERAbstractStructured}</li>
   * <li>{@link KJUR.asn1.DERTaggedObject}</li>
   * </ul>
   * <h4>SUB NAME SPACES</h4>
   * <ul>
   * <li>{@link KJUR.asn1.cades} - CAdES long term signature format</li>
   * <li>{@link KJUR.asn1.cms} - Cryptographic Message Syntax</li>
   * <li>{@link KJUR.asn1.csr} - Certificate Signing Request (CSR/PKCS#10)</li>
   * <li>{@link KJUR.asn1.tsp} - RFC 3161 Timestamping Protocol Format</li>
   * <li>{@link KJUR.asn1.x509} - RFC 5280 X.509 certificate and CRL</li>
   * </ul>
   * </p>
   * NOTE: Please ignore method summary and document of this namespace.
   * This caused by a bug of jsdoc2.
   * @name KJUR.asn1
   * @namespace
   */

  if (typeof KJUR.asn1 == "undefined" || !KJUR.asn1) KJUR.asn1 = {};
  /**
   * ASN1 utilities class
   * @name KJUR.asn1.ASN1Util
   * @class ASN1 utilities class
   * @since asn1 1.0.2
   */

  KJUR.asn1.ASN1Util = new function () {
    this.integerToByteHex = function (i) {
      var h = i.toString(16);
      if (h.length % 2 == 1) h = '0' + h;
      return h;
    };

    this.bigIntToMinTwosComplementsHex = function (bigIntegerValue) {
      var h = bigIntegerValue.toString(16);

      if (h.substr(0, 1) != '-') {
        if (h.length % 2 == 1) {
          h = '0' + h;
        } else {
          if (!h.match(/^[0-7]/)) {
            h = '00' + h;
          }
        }
      } else {
        var hPos = h.substr(1);
        var xorLen = hPos.length;

        if (xorLen % 2 == 1) {
          xorLen += 1;
        } else {
          if (!h.match(/^[0-7]/)) {
            xorLen += 2;
          }
        }

        var hMask = '';

        for (var i = 0; i < xorLen; i++) {
          hMask += 'f';
        }

        var biMask = new BigInteger(hMask, 16);
        var biNeg = biMask.xor(bigIntegerValue).add(BigInteger.ONE);
        h = biNeg.toString(16).replace(/^-/, '');
      }

      return h;
    };
    /**
     * get PEM string from hexadecimal data and header string
     * @name getPEMStringFromHex
     * @memberOf KJUR.asn1.ASN1Util
     * @function
     * @param {String} dataHex hexadecimal string of PEM body
     * @param {String} pemHeader PEM header string (ex. 'RSA PRIVATE KEY')
     * @return {String} PEM formatted string of input data
     * @description
     * This method converts a hexadecimal string to a PEM string with
     * a specified header. Its line break will be CRLF("\r\n").
     * @example
     * var pem  = KJUR.asn1.ASN1Util.getPEMStringFromHex('616161', 'RSA PRIVATE KEY');
     * // value of pem will be:
     * -----BEGIN PRIVATE KEY-----
     * YWFh
     * -----END PRIVATE KEY-----
     */


    this.getPEMStringFromHex = function (dataHex, pemHeader) {
      return hextopem(dataHex, pemHeader);
    };
    /**
     * generate ASN1Object specifed by JSON parameters
     * @name newObject
     * @memberOf KJUR.asn1.ASN1Util
     * @function
     * @param {Array} param JSON parameter to generate ASN1Object
     * @return {KJUR.asn1.ASN1Object} generated object
     * @since asn1 1.0.3
     * @description
     * generate any ASN1Object specified by JSON param
     * including ASN.1 primitive or structured.
     * Generally 'param' can be described as follows:
     * <blockquote>
     * {TYPE-OF-ASNOBJ: ASN1OBJ-PARAMETER}
     * </blockquote>
     * 'TYPE-OF-ASN1OBJ' can be one of following symbols:
     * <ul>
     * <li>'bool' - DERBoolean</li>
     * <li>'int' - DERInteger</li>
     * <li>'bitstr' - DERBitString</li>
     * <li>'octstr' - DEROctetString</li>
     * <li>'null' - DERNull</li>
     * <li>'oid' - DERObjectIdentifier</li>
     * <li>'enum' - DEREnumerated</li>
     * <li>'utf8str' - DERUTF8String</li>
     * <li>'numstr' - DERNumericString</li>
     * <li>'prnstr' - DERPrintableString</li>
     * <li>'telstr' - DERTeletexString</li>
     * <li>'ia5str' - DERIA5String</li>
     * <li>'utctime' - DERUTCTime</li>
     * <li>'gentime' - DERGeneralizedTime</li>
     * <li>'seq' - DERSequence</li>
     * <li>'set' - DERSet</li>
     * <li>'tag' - DERTaggedObject</li>
     * </ul>
     * @example
     * newObject({'prnstr': 'aaa'});
     * newObject({'seq': [{'int': 3}, {'prnstr': 'aaa'}]})
     * // ASN.1 Tagged Object
     * newObject({'tag': {'tag': 'a1',
     *                    'explicit': true,
     *                    'obj': {'seq': [{'int': 3}, {'prnstr': 'aaa'}]}}});
     * // more simple representation of ASN.1 Tagged Object
     * newObject({'tag': ['a1',
     *                    true,
     *                    {'seq': [
     *                      {'int': 3},
     *                      {'prnstr': 'aaa'}]}
     *                   ]});
     */


    this.newObject = function (param) {
      var _KJUR = KJUR,
          _KJUR_asn1 = _KJUR.asn1,
          _DERBoolean = _KJUR_asn1.DERBoolean,
          _DERInteger = _KJUR_asn1.DERInteger,
          _DERBitString = _KJUR_asn1.DERBitString,
          _DEROctetString = _KJUR_asn1.DEROctetString,
          _DERNull = _KJUR_asn1.DERNull,
          _DERObjectIdentifier = _KJUR_asn1.DERObjectIdentifier,
          _DEREnumerated = _KJUR_asn1.DEREnumerated,
          _DERUTF8String = _KJUR_asn1.DERUTF8String,
          _DERNumericString = _KJUR_asn1.DERNumericString,
          _DERPrintableString = _KJUR_asn1.DERPrintableString,
          _DERTeletexString = _KJUR_asn1.DERTeletexString,
          _DERIA5String = _KJUR_asn1.DERIA5String,
          _DERUTCTime = _KJUR_asn1.DERUTCTime,
          _DERGeneralizedTime = _KJUR_asn1.DERGeneralizedTime,
          _DERSequence = _KJUR_asn1.DERSequence,
          _DERSet = _KJUR_asn1.DERSet,
          _DERTaggedObject = _KJUR_asn1.DERTaggedObject,
          _newObject = _KJUR_asn1.ASN1Util.newObject;
      var keys = Object.keys(param);
      if (keys.length != 1) throw "key of param shall be only one.";
      var key = keys[0];
      if (":bool:int:bitstr:octstr:null:oid:enum:utf8str:numstr:prnstr:telstr:ia5str:utctime:gentime:seq:set:tag:".indexOf(":" + key + ":") == -1) throw "undefined key: " + key;
      if (key == "bool") return new _DERBoolean(param[key]);
      if (key == "int") return new _DERInteger(param[key]);
      if (key == "bitstr") return new _DERBitString(param[key]);
      if (key == "octstr") return new _DEROctetString(param[key]);
      if (key == "null") return new _DERNull(param[key]);
      if (key == "oid") return new _DERObjectIdentifier(param[key]);
      if (key == "enum") return new _DEREnumerated(param[key]);
      if (key == "utf8str") return new _DERUTF8String(param[key]);
      if (key == "numstr") return new _DERNumericString(param[key]);
      if (key == "prnstr") return new _DERPrintableString(param[key]);
      if (key == "telstr") return new _DERTeletexString(param[key]);
      if (key == "ia5str") return new _DERIA5String(param[key]);
      if (key == "utctime") return new _DERUTCTime(param[key]);
      if (key == "gentime") return new _DERGeneralizedTime(param[key]);

      if (key == "seq") {
        var paramList = param[key];
        var a = [];

        for (var i = 0; i < paramList.length; i++) {
          var asn1Obj = _newObject(paramList[i]);

          a.push(asn1Obj);
        }

        return new _DERSequence({
          'array': a
        });
      }

      if (key == "set") {
        var paramList = param[key];
        var a = [];

        for (var i = 0; i < paramList.length; i++) {
          var asn1Obj = _newObject(paramList[i]);

          a.push(asn1Obj);
        }

        return new _DERSet({
          'array': a
        });
      }

      if (key == "tag") {
        var tagParam = param[key];

        if (Object.prototype.toString.call(tagParam) === '[object Array]' && tagParam.length == 3) {
          var obj = _newObject(tagParam[2]);

          return new _DERTaggedObject({
            tag: tagParam[0],
            explicit: tagParam[1],
            obj: obj
          });
        } else {
          var newParam = {};
          if (tagParam.explicit !== undefined) newParam.explicit = tagParam.explicit;
          if (tagParam.tag !== undefined) newParam.tag = tagParam.tag;
          if (tagParam.obj === undefined) throw "obj shall be specified for 'tag'.";
          newParam.obj = _newObject(tagParam.obj);
          return new _DERTaggedObject(newParam);
        }
      }
    };
    /**
     * get encoded hexadecimal string of ASN1Object specifed by JSON parameters
     * @name jsonToASN1HEX
     * @memberOf KJUR.asn1.ASN1Util
     * @function
     * @param {Array} param JSON parameter to generate ASN1Object
     * @return hexadecimal string of ASN1Object
     * @since asn1 1.0.4
     * @description
     * As for ASN.1 object representation of JSON object,
     * please see {@link newObject}.
     * @example
     * jsonToASN1HEX({'prnstr': 'aaa'});
     */


    this.jsonToASN1HEX = function (param) {
      var asn1Obj = this.newObject(param);
      return asn1Obj.getEncodedHex();
    };
  }();
  /**
   * get dot noted oid number string from hexadecimal value of OID
   * @name oidHexToInt
   * @memberOf KJUR.asn1.ASN1Util
   * @function
   * @param {String} hex hexadecimal value of object identifier
   * @return {String} dot noted string of object identifier
   * @since jsrsasign 4.8.3 asn1 1.0.7
   * @description
   * This static method converts from hexadecimal string representation of
   * ASN.1 value of object identifier to oid number string.
   * @example
   * KJUR.asn1.ASN1Util.oidHexToInt('550406') &rarr; "2.5.4.6"
   */

  KJUR.asn1.ASN1Util.oidHexToInt = function (hex) {
    var s = "";
    var i01 = parseInt(hex.substr(0, 2), 16);
    var i0 = Math.floor(i01 / 40);
    var i1 = i01 % 40;
    var s = i0 + "." + i1;
    var binbuf = "";

    for (var i = 2; i < hex.length; i += 2) {
      var value = parseInt(hex.substr(i, 2), 16);
      var bin = ("00000000" + value.toString(2)).slice(-8);
      binbuf = binbuf + bin.substr(1, 7);

      if (bin.substr(0, 1) == "0") {
        var bi = new BigInteger(binbuf, 2);
        s = s + "." + bi.toString(10);
        binbuf = "";
      }
    }

    return s;
  };
  /**
   * get hexadecimal value of object identifier from dot noted oid value
   * @name oidIntToHex
   * @memberOf KJUR.asn1.ASN1Util
   * @function
   * @param {String} oidString dot noted string of object identifier
   * @return {String} hexadecimal value of object identifier
   * @since jsrsasign 4.8.3 asn1 1.0.7
   * @description
   * This static method converts from object identifier value string.
   * to hexadecimal string representation of it.
   * @example
   * KJUR.asn1.ASN1Util.oidIntToHex("2.5.4.6") &rarr; "550406"
   */


  KJUR.asn1.ASN1Util.oidIntToHex = function (oidString) {
    var itox = function itox(i) {
      var h = i.toString(16);
      if (h.length == 1) h = '0' + h;
      return h;
    };

    var roidtox = function roidtox(roid) {
      var h = '';
      var bi = new BigInteger(roid, 10);
      var b = bi.toString(2);
      var padLen = 7 - b.length % 7;
      if (padLen == 7) padLen = 0;
      var bPad = '';

      for (var i = 0; i < padLen; i++) {
        bPad += '0';
      }

      b = bPad + b;

      for (var i = 0; i < b.length - 1; i += 7) {
        var b8 = b.substr(i, 7);
        if (i != b.length - 7) b8 = '1' + b8;
        h += itox(parseInt(b8, 2));
      }

      return h;
    };

    if (!oidString.match(/^[0-9.]+$/)) {
      throw "malformed oid string: " + oidString;
    }

    var h = '';
    var a = oidString.split('.');
    var i0 = parseInt(a[0]) * 40 + parseInt(a[1]);
    h += itox(i0);
    a.splice(0, 2);

    for (var i = 0; i < a.length; i++) {
      h += roidtox(a[i]);
    }

    return h;
  }; // ********************************************************************
  //  Abstract ASN.1 Classes
  // ********************************************************************
  // ********************************************************************

  /**
   * base class for ASN.1 DER encoder object
   * @name KJUR.asn1.ASN1Object
   * @class base class for ASN.1 DER encoder object
   * @property {Boolean} isModified flag whether internal data was changed
   * @property {String} hTLV hexadecimal string of ASN.1 TLV
   * @property {String} hT hexadecimal string of ASN.1 TLV tag(T)
   * @property {String} hL hexadecimal string of ASN.1 TLV length(L)
   * @property {String} hV hexadecimal string of ASN.1 TLV value(V)
   * @description
   */


  KJUR.asn1.ASN1Object = function () {
    var hV = '';
    /**
     * get hexadecimal ASN.1 TLV length(L) bytes from TLV value(V)
     * @name getLengthHexFromValue
     * @memberOf KJUR.asn1.ASN1Object#
     * @function
     * @return {String} hexadecimal string of ASN.1 TLV length(L)
     */

    this.getLengthHexFromValue = function () {
      if (typeof this.hV == "undefined" || this.hV == null) {
        throw "this.hV is null or undefined.";
      }

      if (this.hV.length % 2 == 1) {
        throw "value hex must be even length: n=" + hV.length + ",v=" + this.hV;
      }

      var n = this.hV.length / 2;
      var hN = n.toString(16);

      if (hN.length % 2 == 1) {
        hN = "0" + hN;
      }

      if (n < 128) {
        return hN;
      } else {
        var hNlen = hN.length / 2;

        if (hNlen > 15) {
          throw "ASN.1 length too long to represent by 8x: n = " + n.toString(16);
        }

        var head = 128 + hNlen;
        return head.toString(16) + hN;
      }
    };
    /**
     * get hexadecimal string of ASN.1 TLV bytes
     * @name getEncodedHex
     * @memberOf KJUR.asn1.ASN1Object#
     * @function
     * @return {String} hexadecimal string of ASN.1 TLV
     */


    this.getEncodedHex = function () {
      if (this.hTLV == null || this.isModified) {
        this.hV = this.getFreshValueHex();
        this.hL = this.getLengthHexFromValue();
        this.hTLV = this.hT + this.hL + this.hV;
        this.isModified = false; //alert("first time: " + this.hTLV);
      }

      return this.hTLV;
    };
    /**
     * get hexadecimal string of ASN.1 TLV value(V) bytes
     * @name getValueHex
     * @memberOf KJUR.asn1.ASN1Object#
     * @function
     * @return {String} hexadecimal string of ASN.1 TLV value(V) bytes
     */


    this.getValueHex = function () {
      this.getEncodedHex();
      return this.hV;
    };

    this.getFreshValueHex = function () {
      return '';
    };
  }; // == BEGIN DERAbstractString ================================================

  /**
   * base class for ASN.1 DER string classes
   * @name KJUR.asn1.DERAbstractString
   * @class base class for ASN.1 DER string classes
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @property {String} s internal string of value
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>str - specify initial ASN.1 value(V) by a string</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   */


  KJUR.asn1.DERAbstractString = function (params) {
    KJUR.asn1.DERAbstractString.superclass.constructor.call(this);
    /**
     * get string value of this string object
     * @name getString
     * @memberOf KJUR.asn1.DERAbstractString#
     * @function
     * @return {String} string value of this string object
     */

    this.getString = function () {
      return this.s;
    };
    /**
     * set value by a string
     * @name setString
     * @memberOf KJUR.asn1.DERAbstractString#
     * @function
     * @param {String} newS value by a string to set
     */


    this.setString = function (newS) {
      this.hTLV = null;
      this.isModified = true;
      this.s = newS;
      this.hV = stohex(this.s);
    };
    /**
     * set value by a hexadecimal string
     * @name setStringHex
     * @memberOf KJUR.asn1.DERAbstractString#
     * @function
     * @param {String} newHexString value by a hexadecimal string to set
     */


    this.setStringHex = function (newHexString) {
      this.hTLV = null;
      this.isModified = true;
      this.s = null;
      this.hV = newHexString;
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params == "string") {
        this.setString(params);
      } else if (typeof params['str'] != "undefined") {
        this.setString(params['str']);
      } else if (typeof params['hex'] != "undefined") {
        this.setStringHex(params['hex']);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERAbstractString, KJUR.asn1.ASN1Object); // == END   DERAbstractString ================================================
  // == BEGIN DERAbstractTime ==================================================

  /**
   * base class for ASN.1 DER Generalized/UTCTime class
   * @name KJUR.asn1.DERAbstractTime
   * @class base class for ASN.1 DER Generalized/UTCTime class
   * @param {Array} params associative array of parameters (ex. {'str': '130430235959Z'})
   * @extends KJUR.asn1.ASN1Object
   * @description
   * @see KJUR.asn1.ASN1Object - superclass
   */

  KJUR.asn1.DERAbstractTime = function (params) {
    KJUR.asn1.DERAbstractTime.superclass.constructor.call(this); // --- PRIVATE METHODS --------------------

    this.localDateToUTC = function (d) {
      utc = d.getTime() + d.getTimezoneOffset() * 60000;
      var utcDate = new Date(utc);
      return utcDate;
    };
    /*
     * format date string by Data object
     * @name formatDate
     * @memberOf KJUR.asn1.AbstractTime;
     * @param {Date} dateObject
     * @param {string} type 'utc' or 'gen'
     * @param {boolean} withMillis flag for with millisections or not
     * @description
     * 'withMillis' flag is supported from asn1 1.0.6.
     */


    this.formatDate = function (dateObject, type, withMillis) {
      var pad = this.zeroPadding;
      var d = this.localDateToUTC(dateObject);
      var year = String(d.getFullYear());
      if (type == 'utc') year = year.substr(2, 2);
      var month = pad(String(d.getMonth() + 1), 2);
      var day = pad(String(d.getDate()), 2);
      var hour = pad(String(d.getHours()), 2);
      var min = pad(String(d.getMinutes()), 2);
      var sec = pad(String(d.getSeconds()), 2);
      var s = year + month + day + hour + min + sec;

      if (withMillis === true) {
        var millis = d.getMilliseconds();

        if (millis != 0) {
          var sMillis = pad(String(millis), 3);
          sMillis = sMillis.replace(/[0]+$/, "");
          s = s + "." + sMillis;
        }
      }

      return s + "Z";
    };

    this.zeroPadding = function (s, len) {
      if (s.length >= len) return s;
      return new Array(len - s.length + 1).join('0') + s;
    }; // --- PUBLIC METHODS --------------------

    /**
     * get string value of this string object
     * @name getString
     * @memberOf KJUR.asn1.DERAbstractTime#
     * @function
     * @return {String} string value of this time object
     */


    this.getString = function () {
      return this.s;
    };
    /**
     * set value by a string
     * @name setString
     * @memberOf KJUR.asn1.DERAbstractTime#
     * @function
     * @param {String} newS value by a string to set such like "130430235959Z"
     */


    this.setString = function (newS) {
      this.hTLV = null;
      this.isModified = true;
      this.s = newS;
      this.hV = stohex(newS);
    };
    /**
     * set value by a Date object
     * @name setByDateValue
     * @memberOf KJUR.asn1.DERAbstractTime#
     * @function
     * @param {Integer} year year of date (ex. 2013)
     * @param {Integer} month month of date between 1 and 12 (ex. 12)
     * @param {Integer} day day of month
     * @param {Integer} hour hours of date
     * @param {Integer} min minutes of date
     * @param {Integer} sec seconds of date
     */


    this.setByDateValue = function (year, month, day, hour, min, sec) {
      var dateObject = new Date(Date.UTC(year, month - 1, day, hour, min, sec, 0));
      this.setByDate(dateObject);
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };
  };

  YAHOO.lang.extend(KJUR.asn1.DERAbstractTime, KJUR.asn1.ASN1Object); // == END   DERAbstractTime ==================================================
  // == BEGIN DERAbstractStructured ============================================

  /**
   * base class for ASN.1 DER structured class
   * @name KJUR.asn1.DERAbstractStructured
   * @class base class for ASN.1 DER structured class
   * @property {Array} asn1Array internal array of ASN1Object
   * @extends KJUR.asn1.ASN1Object
   * @description
   * @see KJUR.asn1.ASN1Object - superclass
   */

  KJUR.asn1.DERAbstractStructured = function (params) {
    KJUR.asn1.DERAbstractString.superclass.constructor.call(this);
    /**
     * set value by array of ASN1Object
     * @name setByASN1ObjectArray
     * @memberOf KJUR.asn1.DERAbstractStructured#
     * @function
     * @param {array} asn1ObjectArray array of ASN1Object to set
     */

    this.setByASN1ObjectArray = function (asn1ObjectArray) {
      this.hTLV = null;
      this.isModified = true;
      this.asn1Array = asn1ObjectArray;
    };
    /**
     * append an ASN1Object to internal array
     * @name appendASN1Object
     * @memberOf KJUR.asn1.DERAbstractStructured#
     * @function
     * @param {ASN1Object} asn1Object to add
     */


    this.appendASN1Object = function (asn1Object) {
      this.hTLV = null;
      this.isModified = true;
      this.asn1Array.push(asn1Object);
    };

    this.asn1Array = new Array();

    if (typeof params != "undefined") {
      if (typeof params['array'] != "undefined") {
        this.asn1Array = params['array'];
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERAbstractStructured, KJUR.asn1.ASN1Object); // ********************************************************************
  //  ASN.1 Object Classes
  // ********************************************************************
  // ********************************************************************

  /**
   * class for ASN.1 DER Boolean
   * @name KJUR.asn1.DERBoolean
   * @class class for ASN.1 DER Boolean
   * @extends KJUR.asn1.ASN1Object
   * @description
   * @see KJUR.asn1.ASN1Object - superclass
   */

  KJUR.asn1.DERBoolean = function () {
    KJUR.asn1.DERBoolean.superclass.constructor.call(this);
    this.hT = "01";
    this.hTLV = "0101ff";
  };

  YAHOO.lang.extend(KJUR.asn1.DERBoolean, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER Integer
   * @name KJUR.asn1.DERInteger
   * @class class for ASN.1 DER Integer
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>int - specify initial ASN.1 value(V) by integer value</li>
   * <li>bigint - specify initial ASN.1 value(V) by BigInteger object</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   */

  KJUR.asn1.DERInteger = function (params) {
    KJUR.asn1.DERInteger.superclass.constructor.call(this);
    this.hT = "02";
    /**
     * set value by Tom Wu's BigInteger object
     * @name setByBigInteger
     * @memberOf KJUR.asn1.DERInteger#
     * @function
     * @param {BigInteger} bigIntegerValue to set
     */

    this.setByBigInteger = function (bigIntegerValue) {
      this.hTLV = null;
      this.isModified = true;
      this.hV = KJUR.asn1.ASN1Util.bigIntToMinTwosComplementsHex(bigIntegerValue);
    };
    /**
     * set value by integer value
     * @name setByInteger
     * @memberOf KJUR.asn1.DERInteger
     * @function
     * @param {Integer} integer value to set
     */


    this.setByInteger = function (intValue) {
      var bi = new BigInteger(String(intValue), 10);
      this.setByBigInteger(bi);
    };
    /**
     * set value by integer value
     * @name setValueHex
     * @memberOf KJUR.asn1.DERInteger#
     * @function
     * @param {String} hexadecimal string of integer value
     * @description
     * <br/>
     * NOTE: Value shall be represented by minimum octet length of
     * two's complement representation.
     * @example
     * new KJUR.asn1.DERInteger(123);
     * new KJUR.asn1.DERInteger({'int': 123});
     * new KJUR.asn1.DERInteger({'hex': '1fad'});
     */


    this.setValueHex = function (newHexString) {
      this.hV = newHexString;
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params['bigint'] != "undefined") {
        this.setByBigInteger(params['bigint']);
      } else if (typeof params['int'] != "undefined") {
        this.setByInteger(params['int']);
      } else if (typeof params == "number") {
        this.setByInteger(params);
      } else if (typeof params['hex'] != "undefined") {
        this.setValueHex(params['hex']);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERInteger, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER encoded BitString primitive
   * @name KJUR.asn1.DERBitString
   * @class class for ASN.1 DER encoded BitString primitive
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>bin - specify binary string (ex. '10111')</li>
   * <li>array - specify array of boolean (ex. [true,false,true,true])</li>
   * <li>hex - specify hexadecimal string of ASN.1 value(V) including unused bits</li>
   * <li>obj - specify {@link KJUR.asn1.ASN1Util.newObject}
   * argument for "BitString encapsulates" structure.</li>
   * </ul>
   * NOTE1: 'params' can be omitted.<br/>
   * NOTE2: 'obj' parameter have been supported since
   * asn1 1.0.11, jsrsasign 6.1.1 (2016-Sep-25).<br/>
   * @example
   * // default constructor
   * o = new KJUR.asn1.DERBitString();
   * // initialize with binary string
   * o = new KJUR.asn1.DERBitString({bin: "1011"});
   * // initialize with boolean array
   * o = new KJUR.asn1.DERBitString({array: [true,false,true,true]});
   * // initialize with hexadecimal string (04 is unused bits)
   * o = new KJUR.asn1.DEROctetString({hex: "04bac0"});
   * // initialize with ASN1Util.newObject argument for encapsulated
   * o = new KJUR.asn1.DERBitString({obj: {seq: [{int: 3}, {prnstr: 'aaa'}]}});
   * // above generates a ASN.1 data like this:
   * // BIT STRING, encapsulates {
   * //   SEQUENCE {
   * //     INTEGER 3
   * //     PrintableString 'aaa'
   * //     }
   * //   }
   */

  KJUR.asn1.DERBitString = function (params) {
    if (params !== undefined && typeof params.obj !== "undefined") {
      var o = KJUR.asn1.ASN1Util.newObject(params.obj);
      params.hex = "00" + o.getEncodedHex();
    }

    KJUR.asn1.DERBitString.superclass.constructor.call(this);
    this.hT = "03";
    /**
     * set ASN.1 value(V) by a hexadecimal string including unused bits
     * @name setHexValueIncludingUnusedBits
     * @memberOf KJUR.asn1.DERBitString#
     * @function
     * @param {String} newHexStringIncludingUnusedBits
     */

    this.setHexValueIncludingUnusedBits = function (newHexStringIncludingUnusedBits) {
      this.hTLV = null;
      this.isModified = true;
      this.hV = newHexStringIncludingUnusedBits;
    };
    /**
     * set ASN.1 value(V) by unused bit and hexadecimal string of value
     * @name setUnusedBitsAndHexValue
     * @memberOf KJUR.asn1.DERBitString#
     * @function
     * @param {Integer} unusedBits
     * @param {String} hValue
     */


    this.setUnusedBitsAndHexValue = function (unusedBits, hValue) {
      if (unusedBits < 0 || 7 < unusedBits) {
        throw "unused bits shall be from 0 to 7: u = " + unusedBits;
      }

      var hUnusedBits = "0" + unusedBits;
      this.hTLV = null;
      this.isModified = true;
      this.hV = hUnusedBits + hValue;
    };
    /**
     * set ASN.1 DER BitString by binary string<br/>
     * @name setByBinaryString
     * @memberOf KJUR.asn1.DERBitString#
     * @function
     * @param {String} binaryString binary value string (i.e. '10111')
     * @description
     * Its unused bits will be calculated automatically by length of
     * 'binaryValue'. <br/>
     * NOTE: Trailing zeros '0' will be ignored.
     * @example
     * o = new KJUR.asn1.DERBitString();
     * o.setByBooleanArray("01011");
     */


    this.setByBinaryString = function (binaryString) {
      binaryString = binaryString.replace(/0+$/, '');
      var unusedBits = 8 - binaryString.length % 8;
      if (unusedBits == 8) unusedBits = 0;

      for (var i = 0; i <= unusedBits; i++) {
        binaryString += '0';
      }

      var h = '';

      for (var i = 0; i < binaryString.length - 1; i += 8) {
        var b = binaryString.substr(i, 8);
        var x = parseInt(b, 2).toString(16);
        if (x.length == 1) x = '0' + x;
        h += x;
      }

      this.hTLV = null;
      this.isModified = true;
      this.hV = '0' + unusedBits + h;
    };
    /**
     * set ASN.1 TLV value(V) by an array of boolean<br/>
     * @name setByBooleanArray
     * @memberOf KJUR.asn1.DERBitString#
     * @function
     * @param {array} booleanArray array of boolean (ex. [true, false, true])
     * @description
     * NOTE: Trailing falses will be ignored in the ASN.1 DER Object.
     * @example
     * o = new KJUR.asn1.DERBitString();
     * o.setByBooleanArray([false, true, false, true, true]);
     */


    this.setByBooleanArray = function (booleanArray) {
      var s = '';

      for (var i = 0; i < booleanArray.length; i++) {
        if (booleanArray[i] == true) {
          s += '1';
        } else {
          s += '0';
        }
      }

      this.setByBinaryString(s);
    };
    /**
     * generate an array of falses with specified length<br/>
     * @name newFalseArray
     * @memberOf KJUR.asn1.DERBitString
     * @function
     * @param {Integer} nLength length of array to generate
     * @return {array} array of boolean falses
     * @description
     * This static method may be useful to initialize boolean array.
     * @example
     * o = new KJUR.asn1.DERBitString();
     * o.newFalseArray(3) &rarr; [false, false, false]
     */


    this.newFalseArray = function (nLength) {
      var a = new Array(nLength);

      for (var i = 0; i < nLength; i++) {
        a[i] = false;
      }

      return a;
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params == "string" && params.toLowerCase().match(/^[0-9a-f]+$/)) {
        this.setHexValueIncludingUnusedBits(params);
      } else if (typeof params['hex'] != "undefined") {
        this.setHexValueIncludingUnusedBits(params['hex']);
      } else if (typeof params['bin'] != "undefined") {
        this.setByBinaryString(params['bin']);
      } else if (typeof params['array'] != "undefined") {
        this.setByBooleanArray(params['array']);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERBitString, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER OctetString<br/>
   * @name KJUR.asn1.DEROctetString
   * @class class for ASN.1 DER OctetString
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * This class provides ASN.1 OctetString simple type.<br/>
   * Supported "params" attributes are:
   * <ul>
   * <li>str - to set a string as a value</li>
   * <li>hex - to set a hexadecimal string as a value</li>
   * <li>obj - to set a encapsulated ASN.1 value by JSON object
   * which is defined in {@link KJUR.asn1.ASN1Util.newObject}</li>
   * </ul>
   * NOTE: A parameter 'obj' have been supported
   * for "OCTET STRING, encapsulates" structure.
   * since asn1 1.0.11, jsrsasign 6.1.1 (2016-Sep-25).
   * @see KJUR.asn1.DERAbstractString - superclass
   * @example
   * // default constructor
   * o = new KJUR.asn1.DEROctetString();
   * // initialize with string
   * o = new KJUR.asn1.DEROctetString({str: "aaa"});
   * // initialize with hexadecimal string
   * o = new KJUR.asn1.DEROctetString({hex: "616161"});
   * // initialize with ASN1Util.newObject argument
   * o = new KJUR.asn1.DEROctetString({obj: {seq: [{int: 3}, {prnstr: 'aaa'}]}});
   * // above generates a ASN.1 data like this:
   * // OCTET STRING, encapsulates {
   * //   SEQUENCE {
   * //     INTEGER 3
   * //     PrintableString 'aaa'
   * //     }
   * //   }
   */

  KJUR.asn1.DEROctetString = function (params) {
    if (params !== undefined && typeof params.obj !== "undefined") {
      var o = KJUR.asn1.ASN1Util.newObject(params.obj);
      params.hex = o.getEncodedHex();
    }

    KJUR.asn1.DEROctetString.superclass.constructor.call(this, params);
    this.hT = "04";
  };

  YAHOO.lang.extend(KJUR.asn1.DEROctetString, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER Null
   * @name KJUR.asn1.DERNull
   * @class class for ASN.1 DER Null
   * @extends KJUR.asn1.ASN1Object
   * @description
   * @see KJUR.asn1.ASN1Object - superclass
   */

  KJUR.asn1.DERNull = function () {
    KJUR.asn1.DERNull.superclass.constructor.call(this);
    this.hT = "05";
    this.hTLV = "0500";
  };

  YAHOO.lang.extend(KJUR.asn1.DERNull, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER ObjectIdentifier
   * @name KJUR.asn1.DERObjectIdentifier
   * @class class for ASN.1 DER ObjectIdentifier
   * @param {Array} params associative array of parameters (ex. {'oid': '2.5.4.5'})
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>oid - specify initial ASN.1 value(V) by a oid string (ex. 2.5.4.13)</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   */

  KJUR.asn1.DERObjectIdentifier = function (params) {
    var itox = function itox(i) {
      var h = i.toString(16);
      if (h.length == 1) h = '0' + h;
      return h;
    };

    var roidtox = function roidtox(roid) {
      var h = '';
      var bi = new BigInteger(roid, 10);
      var b = bi.toString(2);
      var padLen = 7 - b.length % 7;
      if (padLen == 7) padLen = 0;
      var bPad = '';

      for (var i = 0; i < padLen; i++) {
        bPad += '0';
      }

      b = bPad + b;

      for (var i = 0; i < b.length - 1; i += 7) {
        var b8 = b.substr(i, 7);
        if (i != b.length - 7) b8 = '1' + b8;
        h += itox(parseInt(b8, 2));
      }

      return h;
    };

    KJUR.asn1.DERObjectIdentifier.superclass.constructor.call(this);
    this.hT = "06";
    /**
     * set value by a hexadecimal string
     * @name setValueHex
     * @memberOf KJUR.asn1.DERObjectIdentifier#
     * @function
     * @param {String} newHexString hexadecimal value of OID bytes
     */

    this.setValueHex = function (newHexString) {
      this.hTLV = null;
      this.isModified = true;
      this.s = null;
      this.hV = newHexString;
    };
    /**
     * set value by a OID string<br/>
     * @name setValueOidString
     * @memberOf KJUR.asn1.DERObjectIdentifier#
     * @function
     * @param {String} oidString OID string (ex. 2.5.4.13)
     * @example
     * o = new KJUR.asn1.DERObjectIdentifier();
     * o.setValueOidString("2.5.4.13");
     */


    this.setValueOidString = function (oidString) {
      if (!oidString.match(/^[0-9.]+$/)) {
        throw "malformed oid string: " + oidString;
      }

      var h = '';
      var a = oidString.split('.');
      var i0 = parseInt(a[0]) * 40 + parseInt(a[1]);
      h += itox(i0);
      a.splice(0, 2);

      for (var i = 0; i < a.length; i++) {
        h += roidtox(a[i]);
      }

      this.hTLV = null;
      this.isModified = true;
      this.s = null;
      this.hV = h;
    };
    /**
     * set value by a OID name
     * @name setValueName
     * @memberOf KJUR.asn1.DERObjectIdentifier#
     * @function
     * @param {String} oidName OID name (ex. 'serverAuth')
     * @since 1.0.1
     * @description
     * OID name shall be defined in 'KJUR.asn1.x509.OID.name2oidList'.
     * Otherwise raise error.
     * @example
     * o = new KJUR.asn1.DERObjectIdentifier();
     * o.setValueName("serverAuth");
     */


    this.setValueName = function (oidName) {
      var oid = KJUR.asn1.x509.OID.name2oid(oidName);

      if (oid !== '') {
        this.setValueOidString(oid);
      } else {
        throw "DERObjectIdentifier oidName undefined: " + oidName;
      }
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (params !== undefined) {
      if (typeof params === "string") {
        if (params.match(/^[0-2].[0-9.]+$/)) {
          this.setValueOidString(params);
        } else {
          this.setValueName(params);
        }
      } else if (params.oid !== undefined) {
        this.setValueOidString(params.oid);
      } else if (params.hex !== undefined) {
        this.setValueHex(params.hex);
      } else if (params.name !== undefined) {
        this.setValueName(params.name);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERObjectIdentifier, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER Enumerated
   * @name KJUR.asn1.DEREnumerated
   * @class class for ASN.1 DER Enumerated
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>int - specify initial ASN.1 value(V) by integer value</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   * @example
   * new KJUR.asn1.DEREnumerated(123);
   * new KJUR.asn1.DEREnumerated({int: 123});
   * new KJUR.asn1.DEREnumerated({hex: '1fad'});
   */

  KJUR.asn1.DEREnumerated = function (params) {
    KJUR.asn1.DEREnumerated.superclass.constructor.call(this);
    this.hT = "0a";
    /**
     * set value by Tom Wu's BigInteger object
     * @name setByBigInteger
     * @memberOf KJUR.asn1.DEREnumerated#
     * @function
     * @param {BigInteger} bigIntegerValue to set
     */

    this.setByBigInteger = function (bigIntegerValue) {
      this.hTLV = null;
      this.isModified = true;
      this.hV = KJUR.asn1.ASN1Util.bigIntToMinTwosComplementsHex(bigIntegerValue);
    };
    /**
     * set value by integer value
     * @name setByInteger
     * @memberOf KJUR.asn1.DEREnumerated#
     * @function
     * @param {Integer} integer value to set
     */


    this.setByInteger = function (intValue) {
      var bi = new BigInteger(String(intValue), 10);
      this.setByBigInteger(bi);
    };
    /**
     * set value by integer value
     * @name setValueHex
     * @memberOf KJUR.asn1.DEREnumerated#
     * @function
     * @param {String} hexadecimal string of integer value
     * @description
     * <br/>
     * NOTE: Value shall be represented by minimum octet length of
     * two's complement representation.
     */


    this.setValueHex = function (newHexString) {
      this.hV = newHexString;
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params['int'] != "undefined") {
        this.setByInteger(params['int']);
      } else if (typeof params == "number") {
        this.setByInteger(params);
      } else if (typeof params['hex'] != "undefined") {
        this.setValueHex(params['hex']);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DEREnumerated, KJUR.asn1.ASN1Object); // ********************************************************************

  /**
   * class for ASN.1 DER UTF8String
   * @name KJUR.asn1.DERUTF8String
   * @class class for ASN.1 DER UTF8String
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * @see KJUR.asn1.DERAbstractString - superclass
   */

  KJUR.asn1.DERUTF8String = function (params) {
    KJUR.asn1.DERUTF8String.superclass.constructor.call(this, params);
    this.hT = "0c";
  };

  YAHOO.lang.extend(KJUR.asn1.DERUTF8String, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER NumericString
   * @name KJUR.asn1.DERNumericString
   * @class class for ASN.1 DER NumericString
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * @see KJUR.asn1.DERAbstractString - superclass
   */

  KJUR.asn1.DERNumericString = function (params) {
    KJUR.asn1.DERNumericString.superclass.constructor.call(this, params);
    this.hT = "12";
  };

  YAHOO.lang.extend(KJUR.asn1.DERNumericString, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER PrintableString
   * @name KJUR.asn1.DERPrintableString
   * @class class for ASN.1 DER PrintableString
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * @see KJUR.asn1.DERAbstractString - superclass
   */

  KJUR.asn1.DERPrintableString = function (params) {
    KJUR.asn1.DERPrintableString.superclass.constructor.call(this, params);
    this.hT = "13";
  };

  YAHOO.lang.extend(KJUR.asn1.DERPrintableString, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER TeletexString
   * @name KJUR.asn1.DERTeletexString
   * @class class for ASN.1 DER TeletexString
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * @see KJUR.asn1.DERAbstractString - superclass
   */

  KJUR.asn1.DERTeletexString = function (params) {
    KJUR.asn1.DERTeletexString.superclass.constructor.call(this, params);
    this.hT = "14";
  };

  YAHOO.lang.extend(KJUR.asn1.DERTeletexString, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER IA5String
   * @name KJUR.asn1.DERIA5String
   * @class class for ASN.1 DER IA5String
   * @param {Array} params associative array of parameters (ex. {'str': 'aaa'})
   * @extends KJUR.asn1.DERAbstractString
   * @description
   * @see KJUR.asn1.DERAbstractString - superclass
   */

  KJUR.asn1.DERIA5String = function (params) {
    KJUR.asn1.DERIA5String.superclass.constructor.call(this, params);
    this.hT = "16";
  };

  YAHOO.lang.extend(KJUR.asn1.DERIA5String, KJUR.asn1.DERAbstractString); // ********************************************************************

  /**
   * class for ASN.1 DER UTCTime
   * @name KJUR.asn1.DERUTCTime
   * @class class for ASN.1 DER UTCTime
   * @param {Array} params associative array of parameters (ex. {'str': '130430235959Z'})
   * @extends KJUR.asn1.DERAbstractTime
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>str - specify initial ASN.1 value(V) by a string (ex.'130430235959Z')</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * <li>date - specify Date object.</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   * <h4>EXAMPLES</h4>
   * @example
   * d1 = new KJUR.asn1.DERUTCTime();
   * d1.setString('130430125959Z');
   *
   * d2 = new KJUR.asn1.DERUTCTime({'str': '130430125959Z'});
   * d3 = new KJUR.asn1.DERUTCTime({'date': new Date(Date.UTC(2015, 0, 31, 0, 0, 0, 0))});
   * d4 = new KJUR.asn1.DERUTCTime('130430125959Z');
   */

  KJUR.asn1.DERUTCTime = function (params) {
    KJUR.asn1.DERUTCTime.superclass.constructor.call(this, params);
    this.hT = "17";
    /**
     * set value by a Date object<br/>
     * @name setByDate
     * @memberOf KJUR.asn1.DERUTCTime#
     * @function
     * @param {Date} dateObject Date object to set ASN.1 value(V)
     * @example
     * o = new KJUR.asn1.DERUTCTime();
     * o.setByDate(new Date("2016/12/31"));
     */

    this.setByDate = function (dateObject) {
      this.hTLV = null;
      this.isModified = true;
      this.date = dateObject;
      this.s = this.formatDate(this.date, 'utc');
      this.hV = stohex(this.s);
    };

    this.getFreshValueHex = function () {
      if (typeof this.date == "undefined" && typeof this.s == "undefined") {
        this.date = new Date();
        this.s = this.formatDate(this.date, 'utc');
        this.hV = stohex(this.s);
      }

      return this.hV;
    };

    if (params !== undefined) {
      if (params.str !== undefined) {
        this.setString(params.str);
      } else if (typeof params == "string" && params.match(/^[0-9]{12}Z$/)) {
        this.setString(params);
      } else if (params.hex !== undefined) {
        this.setStringHex(params.hex);
      } else if (params.date !== undefined) {
        this.setByDate(params.date);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERUTCTime, KJUR.asn1.DERAbstractTime); // ********************************************************************

  /**
   * class for ASN.1 DER GeneralizedTime
   * @name KJUR.asn1.DERGeneralizedTime
   * @class class for ASN.1 DER GeneralizedTime
   * @param {Array} params associative array of parameters (ex. {'str': '20130430235959Z'})
   * @property {Boolean} withMillis flag to show milliseconds or not
   * @extends KJUR.asn1.DERAbstractTime
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>str - specify initial ASN.1 value(V) by a string (ex.'20130430235959Z')</li>
   * <li>hex - specify initial ASN.1 value(V) by a hexadecimal string</li>
   * <li>date - specify Date object.</li>
   * <li>millis - specify flag to show milliseconds (from 1.0.6)</li>
   * </ul>
   * NOTE1: 'params' can be omitted.
   * NOTE2: 'withMillis' property is supported from asn1 1.0.6.
   */

  KJUR.asn1.DERGeneralizedTime = function (params) {
    KJUR.asn1.DERGeneralizedTime.superclass.constructor.call(this, params);
    this.hT = "18";
    this.withMillis = false;
    /**
     * set value by a Date object
     * @name setByDate
     * @memberOf KJUR.asn1.DERGeneralizedTime#
     * @function
     * @param {Date} dateObject Date object to set ASN.1 value(V)
     * @example
     * When you specify UTC time, use 'Date.UTC' method like this:<br/>
     * o1 = new DERUTCTime();
     * o1.setByDate(date);
     *
     * date = new Date(Date.UTC(2015, 0, 31, 23, 59, 59, 0)); #2015JAN31 23:59:59
     */

    this.setByDate = function (dateObject) {
      this.hTLV = null;
      this.isModified = true;
      this.date = dateObject;
      this.s = this.formatDate(this.date, 'gen', this.withMillis);
      this.hV = stohex(this.s);
    };

    this.getFreshValueHex = function () {
      if (this.date === undefined && this.s === undefined) {
        this.date = new Date();
        this.s = this.formatDate(this.date, 'gen', this.withMillis);
        this.hV = stohex(this.s);
      }

      return this.hV;
    };

    if (params !== undefined) {
      if (params.str !== undefined) {
        this.setString(params.str);
      } else if (typeof params == "string" && params.match(/^[0-9]{14}Z$/)) {
        this.setString(params);
      } else if (params.hex !== undefined) {
        this.setStringHex(params.hex);
      } else if (params.date !== undefined) {
        this.setByDate(params.date);
      }

      if (params.millis === true) {
        this.withMillis = true;
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERGeneralizedTime, KJUR.asn1.DERAbstractTime); // ********************************************************************

  /**
   * class for ASN.1 DER Sequence
   * @name KJUR.asn1.DERSequence
   * @class class for ASN.1 DER Sequence
   * @extends KJUR.asn1.DERAbstractStructured
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>array - specify array of ASN1Object to set elements of content</li>
   * </ul>
   * NOTE: 'params' can be omitted.
   */

  KJUR.asn1.DERSequence = function (params) {
    KJUR.asn1.DERSequence.superclass.constructor.call(this, params);
    this.hT = "30";

    this.getFreshValueHex = function () {
      var h = '';

      for (var i = 0; i < this.asn1Array.length; i++) {
        var asn1Obj = this.asn1Array[i];
        h += asn1Obj.getEncodedHex();
      }

      this.hV = h;
      return this.hV;
    };
  };

  YAHOO.lang.extend(KJUR.asn1.DERSequence, KJUR.asn1.DERAbstractStructured); // ********************************************************************

  /**
   * class for ASN.1 DER Set
   * @name KJUR.asn1.DERSet
   * @class class for ASN.1 DER Set
   * @extends KJUR.asn1.DERAbstractStructured
   * @description
   * <br/>
   * As for argument 'params' for constructor, you can specify one of
   * following properties:
   * <ul>
   * <li>array - specify array of ASN1Object to set elements of content</li>
   * <li>sortflag - flag for sort (default: true). ASN.1 BER is not sorted in 'SET OF'.</li>
   * </ul>
   * NOTE1: 'params' can be omitted.<br/>
   * NOTE2: sortflag is supported since 1.0.5.
   */

  KJUR.asn1.DERSet = function (params) {
    KJUR.asn1.DERSet.superclass.constructor.call(this, params);
    this.hT = "31";
    this.sortFlag = true; // item shall be sorted only in ASN.1 DER

    this.getFreshValueHex = function () {
      var a = new Array();

      for (var i = 0; i < this.asn1Array.length; i++) {
        var asn1Obj = this.asn1Array[i];
        a.push(asn1Obj.getEncodedHex());
      }

      if (this.sortFlag == true) a.sort();
      this.hV = a.join('');
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params.sortflag != "undefined" && params.sortflag == false) this.sortFlag = false;
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERSet, KJUR.asn1.DERAbstractStructured); // ********************************************************************

  /**
   * class for ASN.1 DER TaggedObject
   * @name KJUR.asn1.DERTaggedObject
   * @class class for ASN.1 DER TaggedObject
   * @extends KJUR.asn1.ASN1Object
   * @description
   * <br/>
   * Parameter 'tagNoNex' is ASN.1 tag(T) value for this object.
   * For example, if you find '[1]' tag in a ASN.1 dump,
   * 'tagNoHex' will be 'a1'.
   * <br/>
   * As for optional argument 'params' for constructor, you can specify *ANY* of
   * following properties:
   * <ul>
   * <li>explicit - specify true if this is explicit tag otherwise false
   *     (default is 'true').</li>
   * <li>tag - specify tag (default is 'a0' which means [0])</li>
   * <li>obj - specify ASN1Object which is tagged</li>
   * </ul>
   * @example
   * d1 = new KJUR.asn1.DERUTF8String({'str':'a'});
   * d2 = new KJUR.asn1.DERTaggedObject({'obj': d1});
   * hex = d2.getEncodedHex();
   */

  KJUR.asn1.DERTaggedObject = function (params) {
    KJUR.asn1.DERTaggedObject.superclass.constructor.call(this);
    this.hT = "a0";
    this.hV = '';
    this.isExplicit = true;
    this.asn1Object = null;
    /**
     * set value by an ASN1Object
     * @name setString
     * @memberOf KJUR.asn1.DERTaggedObject#
     * @function
     * @param {Boolean} isExplicitFlag flag for explicit/implicit tag
     * @param {Integer} tagNoHex hexadecimal string of ASN.1 tag
     * @param {ASN1Object} asn1Object ASN.1 to encapsulate
     */

    this.setASN1Object = function (isExplicitFlag, tagNoHex, asn1Object) {
      this.hT = tagNoHex;
      this.isExplicit = isExplicitFlag;
      this.asn1Object = asn1Object;

      if (this.isExplicit) {
        this.hV = this.asn1Object.getEncodedHex();
        this.hTLV = null;
        this.isModified = true;
      } else {
        this.hV = null;
        this.hTLV = asn1Object.getEncodedHex();
        this.hTLV = this.hTLV.replace(/^../, tagNoHex);
        this.isModified = false;
      }
    };

    this.getFreshValueHex = function () {
      return this.hV;
    };

    if (typeof params != "undefined") {
      if (typeof params['tag'] != "undefined") {
        this.hT = params['tag'];
      }

      if (typeof params['explicit'] != "undefined") {
        this.isExplicit = params['explicit'];
      }

      if (typeof params['obj'] != "undefined") {
        this.asn1Object = params['obj'];
        this.setASN1Object(this.isExplicit, this.hT, this.asn1Object);
      }
    }
  };

  YAHOO.lang.extend(KJUR.asn1.DERTaggedObject, KJUR.asn1.ASN1Object);
  /**
   * Create a new JSEncryptRSAKey that extends Tom Wu's RSA key object.
   * This object is just a decorator for parsing the key parameter
   * @param {string|Object} key - The key in string format, or an object containing
   * the parameters needed to build a RSAKey object.
   * @constructor
   */

  var JSEncryptRSAKey =
  /** @class */
  function (_super) {
    __extends(JSEncryptRSAKey, _super);

    function JSEncryptRSAKey(key) {
      var _this = _super.call(this) || this; // Call the super constructor.
      //  RSAKey.call(this);
      // If a key key was provided.


      if (key) {
        // If this is a string...
        if (typeof key === "string") {
          _this.parseKey(key);
        } else if (JSEncryptRSAKey.hasPrivateKeyProperty(key) || JSEncryptRSAKey.hasPublicKeyProperty(key)) {
          // Set the values for the key.
          _this.parsePropertiesFrom(key);
        }
      }

      return _this;
    }
    /**
     * Method to parse a pem encoded string containing both a public or private key.
     * The method will translate the pem encoded string in a der encoded string and
     * will parse private key and public key parameters. This method accepts public key
     * in the rsaencryption pkcs #1 format (oid: 1.2.840.113549.1.1.1).
     *
     * @todo Check how many rsa formats use the same format of pkcs #1.
     *
     * The format is defined as:
     * PublicKeyInfo ::= SEQUENCE {
     *   algorithm       AlgorithmIdentifier,
     *   PublicKey       BIT STRING
     * }
     * Where AlgorithmIdentifier is:
     * AlgorithmIdentifier ::= SEQUENCE {
     *   algorithm       OBJECT IDENTIFIER,     the OID of the enc algorithm
     *   parameters      ANY DEFINED BY algorithm OPTIONAL (NULL for PKCS #1)
     * }
     * and PublicKey is a SEQUENCE encapsulated in a BIT STRING
     * RSAPublicKey ::= SEQUENCE {
     *   modulus           INTEGER,  -- n
     *   publicExponent    INTEGER   -- e
     * }
     * it's possible to examine the structure of the keys obtained from openssl using
     * an asn.1 dumper as the one used here to parse the components: http://lapo.it/asn1js/
     * @argument {string} pem the pem encoded string, can include the BEGIN/END header/footer
     * @private
     */


    JSEncryptRSAKey.prototype.parseKey = function (pem) {
      try {
        var modulus = 0;
        var public_exponent = 0;
        var reHex = /^\s*(?:[0-9A-Fa-f][0-9A-Fa-f]\s*)+$/;
        var der = reHex.test(pem) ? Hex.decode(pem) : Base64.unarmor(pem);
        var asn1 = ASN1.decode(der); // Fixes a bug with OpenSSL 1.0+ private keys

        if (asn1.sub.length === 3) {
          asn1 = asn1.sub[2].sub[0];
        }

        if (asn1.sub.length === 9) {
          // Parse the private key.
          modulus = asn1.sub[1].getHexStringValue(); // bigint

          this.n = parseBigInt(modulus, 16);
          public_exponent = asn1.sub[2].getHexStringValue(); // int

          this.e = parseInt(public_exponent, 16);
          var private_exponent = asn1.sub[3].getHexStringValue(); // bigint

          this.d = parseBigInt(private_exponent, 16);
          var prime1 = asn1.sub[4].getHexStringValue(); // bigint

          this.p = parseBigInt(prime1, 16);
          var prime2 = asn1.sub[5].getHexStringValue(); // bigint

          this.q = parseBigInt(prime2, 16);
          var exponent1 = asn1.sub[6].getHexStringValue(); // bigint

          this.dmp1 = parseBigInt(exponent1, 16);
          var exponent2 = asn1.sub[7].getHexStringValue(); // bigint

          this.dmq1 = parseBigInt(exponent2, 16);
          var coefficient = asn1.sub[8].getHexStringValue(); // bigint

          this.coeff = parseBigInt(coefficient, 16);
        } else if (asn1.sub.length === 2) {
          // Parse the public key.
          var bit_string = asn1.sub[1];
          var sequence = bit_string.sub[0];
          modulus = sequence.sub[0].getHexStringValue();
          this.n = parseBigInt(modulus, 16);
          public_exponent = sequence.sub[1].getHexStringValue();
          this.e = parseInt(public_exponent, 16);
        } else {
          return false;
        }

        return true;
      } catch (ex) {
        return false;
      }
    };
    /**
     * Translate rsa parameters in a hex encoded string representing the rsa key.
     *
     * The translation follow the ASN.1 notation :
     * RSAPrivateKey ::= SEQUENCE {
     *   version           Version,
     *   modulus           INTEGER,  -- n
     *   publicExponent    INTEGER,  -- e
     *   privateExponent   INTEGER,  -- d
     *   prime1            INTEGER,  -- p
     *   prime2            INTEGER,  -- q
     *   exponent1         INTEGER,  -- d mod (p1)
     *   exponent2         INTEGER,  -- d mod (q-1)
     *   coefficient       INTEGER,  -- (inverse of q) mod p
     * }
     * @returns {string}  DER Encoded String representing the rsa private key
     * @private
     */


    JSEncryptRSAKey.prototype.getPrivateBaseKey = function () {
      var options = {
        array: [new KJUR.asn1.DERInteger({
          "int": 0
        }), new KJUR.asn1.DERInteger({
          bigint: this.n
        }), new KJUR.asn1.DERInteger({
          "int": this.e
        }), new KJUR.asn1.DERInteger({
          bigint: this.d
        }), new KJUR.asn1.DERInteger({
          bigint: this.p
        }), new KJUR.asn1.DERInteger({
          bigint: this.q
        }), new KJUR.asn1.DERInteger({
          bigint: this.dmp1
        }), new KJUR.asn1.DERInteger({
          bigint: this.dmq1
        }), new KJUR.asn1.DERInteger({
          bigint: this.coeff
        })]
      };
      var seq = new KJUR.asn1.DERSequence(options);
      return seq.getEncodedHex();
    };
    /**
     * base64 (pem) encoded version of the DER encoded representation
     * @returns {string} pem encoded representation without header and footer
     * @public
     */


    JSEncryptRSAKey.prototype.getPrivateBaseKeyB64 = function () {
      return hex2b64(this.getPrivateBaseKey());
    };
    /**
     * Translate rsa parameters in a hex encoded string representing the rsa public key.
     * The representation follow the ASN.1 notation :
     * PublicKeyInfo ::= SEQUENCE {
     *   algorithm       AlgorithmIdentifier,
     *   PublicKey       BIT STRING
     * }
     * Where AlgorithmIdentifier is:
     * AlgorithmIdentifier ::= SEQUENCE {
     *   algorithm       OBJECT IDENTIFIER,     the OID of the enc algorithm
     *   parameters      ANY DEFINED BY algorithm OPTIONAL (NULL for PKCS #1)
     * }
     * and PublicKey is a SEQUENCE encapsulated in a BIT STRING
     * RSAPublicKey ::= SEQUENCE {
     *   modulus           INTEGER,  -- n
     *   publicExponent    INTEGER   -- e
     * }
     * @returns {string} DER Encoded String representing the rsa public key
     * @private
     */


    JSEncryptRSAKey.prototype.getPublicBaseKey = function () {
      var first_sequence = new KJUR.asn1.DERSequence({
        array: [new KJUR.asn1.DERObjectIdentifier({
          oid: "1.2.840.113549.1.1.1"
        }), new KJUR.asn1.DERNull()]
      });
      var second_sequence = new KJUR.asn1.DERSequence({
        array: [new KJUR.asn1.DERInteger({
          bigint: this.n
        }), new KJUR.asn1.DERInteger({
          "int": this.e
        })]
      });
      var bit_string = new KJUR.asn1.DERBitString({
        hex: "00" + second_sequence.getEncodedHex()
      });
      var seq = new KJUR.asn1.DERSequence({
        array: [first_sequence, bit_string]
      });
      return seq.getEncodedHex();
    };
    /**
     * base64 (pem) encoded version of the DER encoded representation
     * @returns {string} pem encoded representation without header and footer
     * @public
     */


    JSEncryptRSAKey.prototype.getPublicBaseKeyB64 = function () {
      return hex2b64(this.getPublicBaseKey());
    };
    /**
     * wrap the string in block of width chars. The default value for rsa keys is 64
     * characters.
     * @param {string} str the pem encoded string without header and footer
     * @param {Number} [width=64] - the length the string has to be wrapped at
     * @returns {string}
     * @private
     */


    JSEncryptRSAKey.wordwrap = function (str, width) {
      width = width || 64;

      if (!str) {
        return str;
      }

      var regex = "(.{1," + width + "})( +|$\n?)|(.{1," + width + "})";
      return str.match(RegExp(regex, "g")).join("\n");
    };
    /**
     * Retrieve the pem encoded private key
     * @returns {string} the pem encoded private key with header/footer
     * @public
     */


    JSEncryptRSAKey.prototype.getPrivateKey = function () {
      var key = "-----BEGIN RSA PRIVATE KEY-----\n";
      key += JSEncryptRSAKey.wordwrap(this.getPrivateBaseKeyB64()) + "\n";
      key += "-----END RSA PRIVATE KEY-----";
      return key;
    };
    /**
     * Retrieve the pem encoded public key
     * @returns {string} the pem encoded public key with header/footer
     * @public
     */


    JSEncryptRSAKey.prototype.getPublicKey = function () {
      var key = "-----BEGIN PUBLIC KEY-----\n";
      key += JSEncryptRSAKey.wordwrap(this.getPublicBaseKeyB64()) + "\n";
      key += "-----END PUBLIC KEY-----";
      return key;
    };
    /**
     * Check if the object contains the necessary parameters to populate the rsa modulus
     * and public exponent parameters.
     * @param {Object} [obj={}] - An object that may contain the two public key
     * parameters
     * @returns {boolean} true if the object contains both the modulus and the public exponent
     * properties (n and e)
     * @todo check for types of n and e. N should be a parseable bigInt object, E should
     * be a parseable integer number
     * @private
     */


    JSEncryptRSAKey.hasPublicKeyProperty = function (obj) {
      obj = obj || {};
      return obj.hasOwnProperty("n") && obj.hasOwnProperty("e");
    };
    /**
     * Check if the object contains ALL the parameters of an RSA key.
     * @param {Object} [obj={}] - An object that may contain nine rsa key
     * parameters
     * @returns {boolean} true if the object contains all the parameters needed
     * @todo check for types of the parameters all the parameters but the public exponent
     * should be parseable bigint objects, the public exponent should be a parseable integer number
     * @private
     */


    JSEncryptRSAKey.hasPrivateKeyProperty = function (obj) {
      obj = obj || {};
      return obj.hasOwnProperty("n") && obj.hasOwnProperty("e") && obj.hasOwnProperty("d") && obj.hasOwnProperty("p") && obj.hasOwnProperty("q") && obj.hasOwnProperty("dmp1") && obj.hasOwnProperty("dmq1") && obj.hasOwnProperty("coeff");
    };
    /**
     * Parse the properties of obj in the current rsa object. Obj should AT LEAST
     * include the modulus and public exponent (n, e) parameters.
     * @param {Object} obj - the object containing rsa parameters
     * @private
     */


    JSEncryptRSAKey.prototype.parsePropertiesFrom = function (obj) {
      this.n = obj.n;
      this.e = obj.e;

      if (obj.hasOwnProperty("d")) {
        this.d = obj.d;
        this.p = obj.p;
        this.q = obj.q;
        this.dmp1 = obj.dmp1;
        this.dmq1 = obj.dmq1;
        this.coeff = obj.coeff;
      }
    };

    return JSEncryptRSAKey;
  }(RSAKey);
  /**
   *
   * @param {Object} [options = {}] - An object to customize JSEncrypt behaviour
   * possible parameters are:
   * - default_key_size        {number}  default: 1024 the key size in bit
   * - default_public_exponent {string}  default: '010001' the hexadecimal representation of the public exponent
   * - log                     {boolean} default: false whether log warn/error or not
   * @constructor
   */


  var JSEncrypt =
  /** @class */
  function () {
    function JSEncrypt(options) {
      options = options || {};
      this.default_key_size = parseInt(options.default_key_size, 10) || 1024;
      this.default_public_exponent = options.default_public_exponent || "010001"; // 65537 default openssl public exponent for rsa key type

      this.log = options.log || false; // The private and public key.

      this.key = null;
    }
    /**
     * Method to set the rsa key parameter (one method is enough to set both the public
     * and the private key, since the private key contains the public key paramenters)
     * Log a warning if logs are enabled
     * @param {Object|string} key the pem encoded string or an object (with or without header/footer)
     * @public
     */


    JSEncrypt.prototype.setKey = function (key) {
      if (this.log && this.key) {
        console.warn("A key was already set, overriding existing.");
      }

      this.key = new JSEncryptRSAKey(key);
    };
    /**
     * Proxy method for setKey, for api compatibility
     * @see setKey
     * @public
     */


    JSEncrypt.prototype.setPrivateKey = function (privkey) {
      // Create the key.
      this.setKey(privkey);
    };
    /**
     * Proxy method for setKey, for api compatibility
     * @see setKey
     * @public
     */


    JSEncrypt.prototype.setPublicKey = function (pubkey) {
      // Sets the public key.
      this.setKey(pubkey);
    };
    /**
     * Proxy method for RSAKey object's decrypt, decrypt the string using the private
     * components of the rsa key object. Note that if the object was not set will be created
     * on the fly (by the getKey method) using the parameters passed in the JSEncrypt constructor
     * @param {string} str base64 encoded crypted string to decrypt
     * @return {string} the decrypted string
     * @public
     */


    JSEncrypt.prototype.decrypt = function (str) {
      // Return the decrypted string.
      try {
        return this.getKey().decrypt(b64tohex(str));
      } catch (ex) {
        return false;
      }
    };
    /**
     * Proxy method for RSAKey object's encrypt, encrypt the string using the public
     * components of the rsa key object. Note that if the object was not set will be created
     * on the fly (by the getKey method) using the parameters passed in the JSEncrypt constructor
     * @param {string} str the string to encrypt
     * @return {string} the encrypted string encoded in base64
     * @public
     */


    JSEncrypt.prototype.encrypt = function (str) {
      // Return the encrypted string.
      try {
        return hex2b64(this.getKey().encrypt(str));
      } catch (ex) {
        return false;
      }
    };
    /**
     * 分段加密长字符串
     * @param {string} str the string to encrypt
     * @return {string} the encrypted string encoded in base64
     * @public
     */


    JSEncrypt.prototype.encryptLong = function (str) {
      try {
        var encrypted = this.getKey().encryptLong(str) || "";
        var uncrypted = this.getKey().decryptLong(encrypted) || "";
        var count = 0;
        var reg = /null$/g;

        while (reg.test(uncrypted)) {
          // 如果加密出错，重新加密
          count++;
          encrypted = this.getKey().encryptLong(str) || "";
          uncrypted = this.getKey().decryptLong(encrypted) || ""; // console.log('加密出错次数', count)

          if (count > 10) {
            // 重复加密不能大于10次
            // console.log('加密次数过多')
            break;
          }
        }

        return encrypted;
      } catch (ex) {
        return false;
      }
    };
    /**
     * 分段解密长字符串
     * @param {string} str base64 encoded crypted string to decrypt
     * @return {string} the decrypted string
     * @public
     */


    JSEncrypt.prototype.decryptLong = function (str) {
      try {
        return this.getKey().decryptLong(str);
      } catch (ex) {
        return false;
      }
    };
    /**
     * Proxy method for RSAKey object's sign.
     * @param {string} str the string to sign
     * @param {function} digestMethod hash method
     * @param {string} digestName the name of the hash algorithm
     * @return {string} the signature encoded in base64
     * @public
     */


    JSEncrypt.prototype.sign = function (str, digestMethod, digestName) {
      // return the RSA signature of 'str' in 'hex' format.
      try {
        return hex2b64(this.getKey().sign(str, digestMethod, digestName));
      } catch (ex) {
        return false;
      }
    };
    /**
     * Proxy method for RSAKey object's verify.
     * @param {string} str the string to verify
     * @param {string} signature the signature encoded in base64 to compare the string to
     * @param {function} digestMethod hash method
     * @return {boolean} whether the data and signature match
     * @public
     */


    JSEncrypt.prototype.verify = function (str, signature, digestMethod) {
      // Return the decrypted 'digest' of the signature.
      try {
        return this.getKey().verify(str, b64tohex(signature), digestMethod);
      } catch (ex) {
        return false;
      }
    };
    /**
     * Getter for the current JSEncryptRSAKey object. If it doesn't exists a new object
     * will be created and returned
     * @param {callback} [cb] the callback to be called if we want the key to be generated
     * in an async fashion
     * @returns {JSEncryptRSAKey} the JSEncryptRSAKey object
     * @public
     */


    JSEncrypt.prototype.getKey = function (cb) {
      // Only create new if it does not exist.
      if (!this.key) {
        // Get a new private key.
        this.key = new JSEncryptRSAKey();

        if (cb && {}.toString.call(cb) === "[object Function]") {
          this.key.generateAsync(this.default_key_size, this.default_public_exponent, cb);
          return;
        } // Generate the key.


        this.key.generate(this.default_key_size, this.default_public_exponent);
      }

      return this.key;
    };
    /**
     * Returns the pem encoded representation of the private key
     * If the key doesn't exists a new key will be created
     * @returns {string} pem encoded representation of the private key WITH header and footer
     * @public
     */


    JSEncrypt.prototype.getPrivateKey = function () {
      // Return the private representation of this key.
      return this.getKey().getPrivateKey();
    };
    /**
     * Returns the pem encoded representation of the private key
     * If the key doesn't exists a new key will be created
     * @returns {string} pem encoded representation of the private key WITHOUT header and footer
     * @public
     */


    JSEncrypt.prototype.getPrivateKeyB64 = function () {
      // Return the private representation of this key.
      return this.getKey().getPrivateBaseKeyB64();
    };
    /**
     * Returns the pem encoded representation of the public key
     * If the key doesn't exists a new key will be created
     * @returns {string} pem encoded representation of the public key WITH header and footer
     * @public
     */


    JSEncrypt.prototype.getPublicKey = function () {
      // Return the private representation of this key.
      return this.getKey().getPublicKey();
    };
    /**
     * Returns the pem encoded representation of the public key
     * If the key doesn't exists a new key will be created
     * @returns {string} pem encoded representation of the public key WITHOUT header and footer
     * @public
     */


    JSEncrypt.prototype.getPublicKeyB64 = function () {
      // Return the private representation of this key.
      return this.getKey().getPublicBaseKeyB64();
    };

    JSEncrypt.version = "3.1.4";
    return JSEncrypt;
  }();

  window.JSEncrypt = JSEncrypt;
  exports.JSEncrypt = JSEncrypt;
  exports["default"] = JSEncrypt;
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxyc2FcXGpzZW5jcnlwdC5qcyJdLCJuYW1lcyI6WyJnbG9iYWwiLCJmYWN0b3J5IiwiZXhwb3J0cyIsIm1vZHVsZSIsImRlZmluZSIsImFtZCIsIkpTRW5jcnlwdCIsIkJJX1JNIiwiaW50MmNoYXIiLCJuIiwiY2hhckF0Iiwib3BfYW5kIiwieCIsInkiLCJvcF9vciIsIm9wX3hvciIsIm9wX2FuZG5vdCIsImxiaXQiLCJyIiwiY2JpdCIsImI2NG1hcCIsImI2NHBhZCIsImhleDJiNjQiLCJoIiwiaSIsImMiLCJyZXQiLCJsZW5ndGgiLCJwYXJzZUludCIsInN1YnN0cmluZyIsImI2NHRvaGV4IiwicyIsImsiLCJzbG9wIiwidiIsImluZGV4T2YiLCJleHRlbmRTdGF0aWNzIiwiZCIsImIiLCJPYmplY3QiLCJzZXRQcm90b3R5cGVPZiIsIl9fcHJvdG9fXyIsIkFycmF5IiwicCIsImhhc093blByb3BlcnR5IiwiX19leHRlbmRzIiwiX18iLCJjb25zdHJ1Y3RvciIsInByb3RvdHlwZSIsImNyZWF0ZSIsImRlY29kZXIiLCJIZXgiLCJkZWNvZGUiLCJhIiwidW5kZWZpbmVkIiwiaGV4IiwiaWdub3JlIiwidG9Mb3dlckNhc2UiLCJvdXQiLCJiaXRzIiwiY2hhcl9jb3VudCIsIkVycm9yIiwiZGVjb2RlciQxIiwiQmFzZTY0IiwiYjY0IiwicmUiLCJ1bmFybW9yIiwibSIsImV4ZWMiLCJtYXgiLCJJbnQxMCIsInZhbHVlIiwiYnVmIiwibXVsQWRkIiwibCIsInQiLCJzdWIiLCJwb3AiLCJ0b1N0cmluZyIsImJhc2UiLCJ2YWx1ZU9mIiwic2ltcGxpZnkiLCJlbGxpcHNpcyIsInJlVGltZVMiLCJyZVRpbWVMIiwic3RyaW5nQ3V0Iiwic3RyIiwibGVuIiwiU3RyZWFtIiwiZW5jIiwicG9zIiwiaGV4RGlnaXRzIiwiZ2V0IiwiY2hhckNvZGVBdCIsImhleEJ5dGUiLCJoZXhEdW1wIiwic3RhcnQiLCJlbmQiLCJyYXciLCJpc0FTQ0lJIiwicGFyc2VTdHJpbmdJU08iLCJTdHJpbmciLCJmcm9tQ2hhckNvZGUiLCJwYXJzZVN0cmluZ1VURiIsInBhcnNlU3RyaW5nQk1QIiwiaGkiLCJsbyIsInBhcnNlVGltZSIsInNob3J0WWVhciIsInBhcnNlSW50ZWdlciIsIm5lZyIsInBhZCIsInBhcnNlQml0U3RyaW5nIiwibWF4TGVuZ3RoIiwidW51c2VkQml0IiwibGVuQml0IiwiaW50cm8iLCJza2lwIiwiaiIsInBhcnNlT2N0ZXRTdHJpbmciLCJwYXJzZU9JRCIsIkFTTjEiLCJzdHJlYW0iLCJoZWFkZXIiLCJ0YWciLCJBU04xVGFnIiwidHlwZU5hbWUiLCJ0YWdDbGFzcyIsInRhZ051bWJlciIsImNvbnRlbnQiLCJJbmZpbml0eSIsInBvc0NvbnRlbnQiLCJNYXRoIiwiYWJzIiwiaXNVbml2ZXJzYWwiLCJ0b1ByZXR0eVN0cmluZyIsImluZGVudCIsInRhZ0NvbnN0cnVjdGVkIiwicG9zU3RhcnQiLCJwb3NFbmQiLCJ0b0hleFN0cmluZyIsImRlY29kZUxlbmd0aCIsImdldEhleFN0cmluZ1ZhbHVlIiwiaGV4U3RyaW5nIiwib2Zmc2V0Iiwic3Vic3RyIiwic3RyZWFtU3RhcnQiLCJnZXRTdWIiLCJpc0VPQyIsImUiLCJkYml0cyIsImNhbmFyeSIsImpfbG0iLCJsb3dwcmltZXMiLCJscGxpbSIsIkJpZ0ludGVnZXIiLCJmcm9tTnVtYmVyIiwiZnJvbVN0cmluZyIsIm5lZ2F0ZSIsInRvUmFkaXgiLCJrbSIsIkRCIiwibmJpIiwiWkVSTyIsInN1YlRvIiwiY29tcGFyZVRvIiwiYml0TGVuZ3RoIiwibmJpdHMiLCJETSIsIm1vZCIsImRpdlJlbVRvIiwibW9kUG93SW50IiwieiIsImlzRXZlbiIsIkNsYXNzaWMiLCJNb250Z29tZXJ5IiwiZXhwIiwiY2xvbmUiLCJjb3B5VG8iLCJpbnRWYWx1ZSIsIkRWIiwiYnl0ZVZhbHVlIiwic2hvcnRWYWx1ZSIsInNpZ251bSIsInRvQnl0ZUFycmF5IiwiZXF1YWxzIiwibWluIiwiYW5kIiwiYml0d2lzZVRvIiwib3IiLCJ4b3IiLCJhbmROb3QiLCJub3QiLCJzaGlmdExlZnQiLCJyU2hpZnRUbyIsImxTaGlmdFRvIiwic2hpZnRSaWdodCIsImdldExvd2VzdFNldEJpdCIsImJpdENvdW50IiwidGVzdEJpdCIsImZsb29yIiwic2V0Qml0IiwiY2hhbmdlQml0IiwiY2xlYXJCaXQiLCJmbGlwQml0IiwiYWRkIiwiYWRkVG8iLCJzdWJ0cmFjdCIsIm11bHRpcGx5IiwibXVsdGlwbHlUbyIsImRpdmlkZSIsInJlbWFpbmRlciIsImRpdmlkZUFuZFJlbWFpbmRlciIsInEiLCJtb2RQb3ciLCJuYnYiLCJCYXJyZXR0IiwiZyIsImsxIiwiY29udmVydCIsImcyIiwic3FyVG8iLCJtdWxUbyIsInciLCJpczEiLCJyMiIsInJldmVydCIsIm1vZEludmVyc2UiLCJhYyIsInUiLCJPTkUiLCJwb3ciLCJOdWxsRXhwIiwiZ2NkIiwiaXNQcm9iYWJsZVByaW1lIiwibW9kSW50IiwibWlsbGVyUmFiaW4iLCJmcm9tSW50IiwiZnJvbVJhZGl4IiwibWkiLCJzaCIsImludEF0IiwiY2xhbXAiLCJkbFNoaWZ0VG8iLCJkclNoaWZ0VG8iLCJicyIsImNicyIsImJtIiwiZHMiLCJhbSIsInNxdWFyZVRvIiwicG0iLCJwdCIsInRzIiwibXMiLCJuc2giLCJ5cyIsInkwIiwieXQiLCJGMSIsIkYyIiwiZDEiLCJGViIsImQyIiwicWQiLCJpbnZEaWdpdCIsImNodW5rU2l6ZSIsIkxOMiIsImxvZyIsImNzIiwiZE11bHRpcGx5IiwiZEFkZE9mZnNldCIsIm5leHRCeXRlcyIsIm9wIiwiZiIsIm11bHRpcGx5TG93ZXJUbyIsIm11bHRpcGx5VXBwZXJUbyIsIm4xIiwicmFuZG9tIiwic3F1YXJlIiwiZ2NkYSIsImNhbGxiYWNrIiwiZ2NkYTEiLCJzZXRUaW1lb3V0IiwiZnJvbU51bWJlckFzeW5jIiwiYm5wXzEiLCJibnBmbjFfMSIsInJlZHVjZSIsIm1wIiwibXBsIiwibXBoIiwidW0iLCJtdDIiLCJ1MCIsInEzIiwibXUiLCJwYXJzZUJpZ0ludCIsImFtMSIsImFtMiIsInhsIiwieGgiLCJhbTMiLCJuYXZpZ2F0b3IiLCJhcHBOYW1lIiwiQklfRlAiLCJCSV9SQyIsInJyIiwidnYiLCJBcmNmb3VyIiwiUyIsImluaXQiLCJrZXkiLCJuZXh0IiwicHJuZ19uZXdzdGF0ZSIsInJuZ19wc2l6ZSIsInJuZ19zdGF0ZSIsInJuZ19wb29sIiwicm5nX3BwdHIiLCJ3aW5kb3ciLCJjcnlwdG8iLCJnZXRSYW5kb21WYWx1ZXMiLCJVaW50MzJBcnJheSIsIm9uTW91c2VNb3ZlTGlzdGVuZXJfMSIsImV2IiwiY291bnQiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZGV0YWNoRXZlbnQiLCJtb3VzZUNvb3JkaW5hdGVzIiwiYWRkRXZlbnRMaXN0ZW5lciIsImF0dGFjaEV2ZW50Iiwicm5nX2dldF9ieXRlIiwiU2VjdXJlUmFuZG9tIiwiYmEiLCJwa2NzMXBhZDEiLCJjb25zb2xlIiwiZXJyb3IiLCJmaWxsZXIiLCJwa2NzMXBhZDIiLCJybmciLCJSU0FLZXkiLCJkbXAxIiwiZG1xMSIsImNvZWZmIiwiZG9QdWJsaWMiLCJkb1ByaXZhdGUiLCJ4cCIsInhxIiwic2V0UHVibGljIiwiTiIsIkUiLCJlbmNyeXB0IiwidGV4dCIsImVuY3J5cHRMb25nIiwiX3RoaXMiLCJjdF8xIiwibHQiLCJtYXRjaCIsImZvckVhY2giLCJlbnRyeSIsInQxIiwiZXgiLCJkZWNyeXB0TG9uZyIsImN0XzIiLCJkZWNyeXB0Iiwic2V0UHJpdmF0ZSIsIkQiLCJzZXRQcml2YXRlRXgiLCJQIiwiUSIsIkRQIiwiRFEiLCJDIiwiZ2VuZXJhdGUiLCJCIiwicXMiLCJlZSIsInAxIiwicTEiLCJwaGkiLCJjdGV4dCIsInBrY3MxdW5wYWQyIiwiZ2VuZXJhdGVBc3luYyIsInJzYSIsImxvb3AxIiwibG9vcDQiLCJsb29wMyIsImxvb3AyIiwic2lnbiIsImRpZ2VzdE1ldGhvZCIsImRpZ2VzdE5hbWUiLCJnZXREaWdlc3RIZWFkZXIiLCJkaWdlc3QiLCJ2ZXJpZnkiLCJzaWduYXR1cmUiLCJ1bnBhZGRlZCIsInJlcGxhY2UiLCJyZW1vdmVEaWdlc3RIZWFkZXIiLCJESUdFU1RfSEVBREVSUyIsIm1kMiIsIm1kNSIsInNoYTEiLCJzaGEyMjQiLCJzaGEyNTYiLCJzaGEzODQiLCJzaGE1MTIiLCJyaXBlbWQxNjAiLCJuYW1lIiwibmFtZV8xIiwiWUFIT08iLCJsYW5nIiwiZXh0ZW5kIiwic3ViYyIsInN1cGVyYyIsIm92ZXJyaWRlcyIsIkYiLCJzdXBlcmNsYXNzIiwiX0lFRW51bUZpeCIsIkFERCIsInRlc3QiLCJ1c2VyQWdlbnQiLCJmbmFtZSIsIktKVVIiLCJhc24xIiwiQVNOMVV0aWwiLCJpbnRlZ2VyVG9CeXRlSGV4IiwiYmlnSW50VG9NaW5Ud29zQ29tcGxlbWVudHNIZXgiLCJiaWdJbnRlZ2VyVmFsdWUiLCJoUG9zIiwieG9yTGVuIiwiaE1hc2siLCJiaU1hc2siLCJiaU5lZyIsImdldFBFTVN0cmluZ0Zyb21IZXgiLCJkYXRhSGV4IiwicGVtSGVhZGVyIiwiaGV4dG9wZW0iLCJuZXdPYmplY3QiLCJwYXJhbSIsIl9LSlVSIiwiX0tKVVJfYXNuMSIsIl9ERVJCb29sZWFuIiwiREVSQm9vbGVhbiIsIl9ERVJJbnRlZ2VyIiwiREVSSW50ZWdlciIsIl9ERVJCaXRTdHJpbmciLCJERVJCaXRTdHJpbmciLCJfREVST2N0ZXRTdHJpbmciLCJERVJPY3RldFN0cmluZyIsIl9ERVJOdWxsIiwiREVSTnVsbCIsIl9ERVJPYmplY3RJZGVudGlmaWVyIiwiREVST2JqZWN0SWRlbnRpZmllciIsIl9ERVJFbnVtZXJhdGVkIiwiREVSRW51bWVyYXRlZCIsIl9ERVJVVEY4U3RyaW5nIiwiREVSVVRGOFN0cmluZyIsIl9ERVJOdW1lcmljU3RyaW5nIiwiREVSTnVtZXJpY1N0cmluZyIsIl9ERVJQcmludGFibGVTdHJpbmciLCJERVJQcmludGFibGVTdHJpbmciLCJfREVSVGVsZXRleFN0cmluZyIsIkRFUlRlbGV0ZXhTdHJpbmciLCJfREVSSUE1U3RyaW5nIiwiREVSSUE1U3RyaW5nIiwiX0RFUlVUQ1RpbWUiLCJERVJVVENUaW1lIiwiX0RFUkdlbmVyYWxpemVkVGltZSIsIkRFUkdlbmVyYWxpemVkVGltZSIsIl9ERVJTZXF1ZW5jZSIsIkRFUlNlcXVlbmNlIiwiX0RFUlNldCIsIkRFUlNldCIsIl9ERVJUYWdnZWRPYmplY3QiLCJERVJUYWdnZWRPYmplY3QiLCJfbmV3T2JqZWN0Iiwia2V5cyIsInBhcmFtTGlzdCIsImFzbjFPYmoiLCJwdXNoIiwidGFnUGFyYW0iLCJjYWxsIiwib2JqIiwiZXhwbGljaXQiLCJuZXdQYXJhbSIsImpzb25Ub0FTTjFIRVgiLCJnZXRFbmNvZGVkSGV4Iiwib2lkSGV4VG9JbnQiLCJpMDEiLCJpMCIsImkxIiwiYmluYnVmIiwiYmluIiwic2xpY2UiLCJiaSIsIm9pZEludFRvSGV4Iiwib2lkU3RyaW5nIiwiaXRveCIsInJvaWR0b3giLCJyb2lkIiwicGFkTGVuIiwiYlBhZCIsImI4Iiwic3BsaXQiLCJzcGxpY2UiLCJBU04xT2JqZWN0IiwiaFYiLCJnZXRMZW5ndGhIZXhGcm9tVmFsdWUiLCJoTiIsImhObGVuIiwiaGVhZCIsImhUTFYiLCJpc01vZGlmaWVkIiwiZ2V0RnJlc2hWYWx1ZUhleCIsImhMIiwiaFQiLCJnZXRWYWx1ZUhleCIsIkRFUkFic3RyYWN0U3RyaW5nIiwicGFyYW1zIiwiZ2V0U3RyaW5nIiwic2V0U3RyaW5nIiwibmV3UyIsInN0b2hleCIsInNldFN0cmluZ0hleCIsIm5ld0hleFN0cmluZyIsIkRFUkFic3RyYWN0VGltZSIsImxvY2FsRGF0ZVRvVVRDIiwidXRjIiwiZ2V0VGltZSIsImdldFRpbWV6b25lT2Zmc2V0IiwidXRjRGF0ZSIsIkRhdGUiLCJmb3JtYXREYXRlIiwiZGF0ZU9iamVjdCIsInR5cGUiLCJ3aXRoTWlsbGlzIiwiemVyb1BhZGRpbmciLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJtb250aCIsImdldE1vbnRoIiwiZGF5IiwiZ2V0RGF0ZSIsImhvdXIiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJzZWMiLCJnZXRTZWNvbmRzIiwibWlsbGlzIiwiZ2V0TWlsbGlzZWNvbmRzIiwic01pbGxpcyIsImpvaW4iLCJzZXRCeURhdGVWYWx1ZSIsIlVUQyIsInNldEJ5RGF0ZSIsIkRFUkFic3RyYWN0U3RydWN0dXJlZCIsInNldEJ5QVNOMU9iamVjdEFycmF5IiwiYXNuMU9iamVjdEFycmF5IiwiYXNuMUFycmF5IiwiYXBwZW5kQVNOMU9iamVjdCIsImFzbjFPYmplY3QiLCJzZXRCeUJpZ0ludGVnZXIiLCJzZXRCeUludGVnZXIiLCJzZXRWYWx1ZUhleCIsIm8iLCJzZXRIZXhWYWx1ZUluY2x1ZGluZ1VudXNlZEJpdHMiLCJuZXdIZXhTdHJpbmdJbmNsdWRpbmdVbnVzZWRCaXRzIiwic2V0VW51c2VkQml0c0FuZEhleFZhbHVlIiwidW51c2VkQml0cyIsImhWYWx1ZSIsImhVbnVzZWRCaXRzIiwic2V0QnlCaW5hcnlTdHJpbmciLCJiaW5hcnlTdHJpbmciLCJzZXRCeUJvb2xlYW5BcnJheSIsImJvb2xlYW5BcnJheSIsIm5ld0ZhbHNlQXJyYXkiLCJuTGVuZ3RoIiwic2V0VmFsdWVPaWRTdHJpbmciLCJzZXRWYWx1ZU5hbWUiLCJvaWROYW1lIiwib2lkIiwieDUwOSIsIk9JRCIsIm5hbWUyb2lkIiwiZGF0ZSIsInNvcnRGbGFnIiwic29ydCIsInNvcnRmbGFnIiwiaXNFeHBsaWNpdCIsInNldEFTTjFPYmplY3QiLCJpc0V4cGxpY2l0RmxhZyIsInRhZ05vSGV4IiwiSlNFbmNyeXB0UlNBS2V5IiwiX3N1cGVyIiwicGFyc2VLZXkiLCJoYXNQcml2YXRlS2V5UHJvcGVydHkiLCJoYXNQdWJsaWNLZXlQcm9wZXJ0eSIsInBhcnNlUHJvcGVydGllc0Zyb20iLCJwZW0iLCJtb2R1bHVzIiwicHVibGljX2V4cG9uZW50IiwicmVIZXgiLCJkZXIiLCJwcml2YXRlX2V4cG9uZW50IiwicHJpbWUxIiwicHJpbWUyIiwiZXhwb25lbnQxIiwiZXhwb25lbnQyIiwiY29lZmZpY2llbnQiLCJiaXRfc3RyaW5nIiwic2VxdWVuY2UiLCJnZXRQcml2YXRlQmFzZUtleSIsIm9wdGlvbnMiLCJhcnJheSIsImJpZ2ludCIsInNlcSIsImdldFByaXZhdGVCYXNlS2V5QjY0IiwiZ2V0UHVibGljQmFzZUtleSIsImZpcnN0X3NlcXVlbmNlIiwic2Vjb25kX3NlcXVlbmNlIiwiZ2V0UHVibGljQmFzZUtleUI2NCIsIndvcmR3cmFwIiwid2lkdGgiLCJyZWdleCIsIlJlZ0V4cCIsImdldFByaXZhdGVLZXkiLCJnZXRQdWJsaWNLZXkiLCJkZWZhdWx0X2tleV9zaXplIiwiZGVmYXVsdF9wdWJsaWNfZXhwb25lbnQiLCJzZXRLZXkiLCJ3YXJuIiwic2V0UHJpdmF0ZUtleSIsInByaXZrZXkiLCJzZXRQdWJsaWNLZXkiLCJwdWJrZXkiLCJnZXRLZXkiLCJlbmNyeXB0ZWQiLCJ1bmNyeXB0ZWQiLCJyZWciLCJjYiIsImdldFByaXZhdGVLZXlCNjQiLCJnZXRQdWJsaWNLZXlCNjQiLCJ2ZXJzaW9uIiwiZGVmaW5lUHJvcGVydHkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUMsV0FBVUEsTUFBVixFQUFrQkMsT0FBbEIsRUFBMkI7QUFDM0IsU0FBT0MsT0FBUCxLQUFtQixRQUFuQixJQUErQixPQUFPQyxNQUFQLEtBQWtCLFdBQWpELEdBQStERixPQUFPLENBQUNDLE9BQUQsQ0FBdEUsR0FDQSxPQUFPRSxNQUFQLEtBQWtCLFVBQWxCLElBQWdDQSxNQUFNLENBQUNDLEdBQXZDLEdBQTZDRCxNQUFNLENBQUMsQ0FBQyxTQUFELENBQUQsRUFBY0gsT0FBZCxDQUFuRCxHQUNDQSxPQUFPLENBQUVELE1BQU0sQ0FBQ00sU0FBUCxHQUFtQixFQUFyQixDQUZSO0FBR0EsQ0FKQSxVQUlRLFVBQVVKLE9BQVYsRUFBbUI7QUFBRTs7QUFFOUIsTUFBSUssS0FBSyxHQUFHLHNDQUFaOztBQUNBLFdBQVNDLFFBQVQsQ0FBa0JDLENBQWxCLEVBQXFCO0FBQ2pCLFdBQU9GLEtBQUssQ0FBQ0csTUFBTixDQUFhRCxDQUFiLENBQVA7QUFDSCxHQUwyQixDQU01QjtBQUNBOzs7QUFDQSxXQUFTRSxNQUFULENBQWdCQyxDQUFoQixFQUFtQkMsQ0FBbkIsRUFBc0I7QUFDbEIsV0FBT0QsQ0FBQyxHQUFHQyxDQUFYO0FBQ0gsR0FWMkIsQ0FXNUI7OztBQUNBLFdBQVNDLEtBQVQsQ0FBZUYsQ0FBZixFQUFrQkMsQ0FBbEIsRUFBcUI7QUFDakIsV0FBT0QsQ0FBQyxHQUFHQyxDQUFYO0FBQ0gsR0FkMkIsQ0FlNUI7OztBQUNBLFdBQVNFLE1BQVQsQ0FBZ0JILENBQWhCLEVBQW1CQyxDQUFuQixFQUFzQjtBQUNsQixXQUFPRCxDQUFDLEdBQUdDLENBQVg7QUFDSCxHQWxCMkIsQ0FtQjVCOzs7QUFDQSxXQUFTRyxTQUFULENBQW1CSixDQUFuQixFQUFzQkMsQ0FBdEIsRUFBeUI7QUFDckIsV0FBT0QsQ0FBQyxHQUFHLENBQUNDLENBQVo7QUFDSCxHQXRCMkIsQ0F1QjVCOzs7QUFDQSxXQUFTSSxJQUFULENBQWNMLENBQWQsRUFBaUI7QUFDYixRQUFJQSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ1IsYUFBTyxDQUFDLENBQVI7QUFDSDs7QUFDRCxRQUFJTSxDQUFDLEdBQUcsQ0FBUjs7QUFDQSxRQUFJLENBQUNOLENBQUMsR0FBRyxNQUFMLEtBQWdCLENBQXBCLEVBQXVCO0FBQ25CQSxNQUFBQSxDQUFDLEtBQUssRUFBTjtBQUNBTSxNQUFBQSxDQUFDLElBQUksRUFBTDtBQUNIOztBQUNELFFBQUksQ0FBQ04sQ0FBQyxHQUFHLElBQUwsS0FBYyxDQUFsQixFQUFxQjtBQUNqQkEsTUFBQUEsQ0FBQyxLQUFLLENBQU47QUFDQU0sTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUNOLENBQUMsR0FBRyxHQUFMLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEJBLE1BQUFBLENBQUMsS0FBSyxDQUFOO0FBQ0FNLE1BQUFBLENBQUMsSUFBSSxDQUFMO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDTixDQUFDLEdBQUcsQ0FBTCxLQUFXLENBQWYsRUFBa0I7QUFDZEEsTUFBQUEsQ0FBQyxLQUFLLENBQU47QUFDQU0sTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUNOLENBQUMsR0FBRyxDQUFMLEtBQVcsQ0FBZixFQUFrQjtBQUNkLFFBQUVNLENBQUY7QUFDSDs7QUFDRCxXQUFPQSxDQUFQO0FBQ0gsR0FqRDJCLENBa0Q1Qjs7O0FBQ0EsV0FBU0MsSUFBVCxDQUFjUCxDQUFkLEVBQWlCO0FBQ2IsUUFBSU0sQ0FBQyxHQUFHLENBQVI7O0FBQ0EsV0FBT04sQ0FBQyxJQUFJLENBQVosRUFBZTtBQUNYQSxNQUFBQSxDQUFDLElBQUlBLENBQUMsR0FBRyxDQUFUO0FBQ0EsUUFBRU0sQ0FBRjtBQUNIOztBQUNELFdBQU9BLENBQVA7QUFDSCxHQTFEMkIsQ0EyRDVCOzs7QUFFQSxNQUFJRSxNQUFNLEdBQUcsa0VBQWI7QUFDQSxNQUFJQyxNQUFNLEdBQUcsR0FBYjs7QUFDQSxXQUFTQyxPQUFULENBQWlCQyxDQUFqQixFQUFvQjtBQUNoQixRQUFJQyxDQUFKO0FBQ0EsUUFBSUMsQ0FBSjtBQUNBLFFBQUlDLEdBQUcsR0FBRyxFQUFWOztBQUNBLFNBQUtGLENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBRyxDQUFKLElBQVNELENBQUMsQ0FBQ0ksTUFBdkIsRUFBK0JILENBQUMsSUFBSSxDQUFwQyxFQUF1QztBQUNuQ0MsTUFBQUEsQ0FBQyxHQUFHRyxRQUFRLENBQUNMLENBQUMsQ0FBQ00sU0FBRixDQUFZTCxDQUFaLEVBQWVBLENBQUMsR0FBRyxDQUFuQixDQUFELEVBQXdCLEVBQXhCLENBQVo7QUFDQUUsTUFBQUEsR0FBRyxJQUFJTixNQUFNLENBQUNWLE1BQVAsQ0FBY2UsQ0FBQyxJQUFJLENBQW5CLElBQXdCTCxNQUFNLENBQUNWLE1BQVAsQ0FBY2UsQ0FBQyxHQUFHLEVBQWxCLENBQS9CO0FBQ0g7O0FBQ0QsUUFBSUQsQ0FBQyxHQUFHLENBQUosSUFBU0QsQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ25CRixNQUFBQSxDQUFDLEdBQUdHLFFBQVEsQ0FBQ0wsQ0FBQyxDQUFDTSxTQUFGLENBQVlMLENBQVosRUFBZUEsQ0FBQyxHQUFHLENBQW5CLENBQUQsRUFBd0IsRUFBeEIsQ0FBWjtBQUNBRSxNQUFBQSxHQUFHLElBQUlOLE1BQU0sQ0FBQ1YsTUFBUCxDQUFjZSxDQUFDLElBQUksQ0FBbkIsQ0FBUDtBQUNILEtBSEQsTUFJSyxJQUFJRCxDQUFDLEdBQUcsQ0FBSixJQUFTRCxDQUFDLENBQUNJLE1BQWYsRUFBdUI7QUFDeEJGLE1BQUFBLENBQUMsR0FBR0csUUFBUSxDQUFDTCxDQUFDLENBQUNNLFNBQUYsQ0FBWUwsQ0FBWixFQUFlQSxDQUFDLEdBQUcsQ0FBbkIsQ0FBRCxFQUF3QixFQUF4QixDQUFaO0FBQ0FFLE1BQUFBLEdBQUcsSUFBSU4sTUFBTSxDQUFDVixNQUFQLENBQWNlLENBQUMsSUFBSSxDQUFuQixJQUF3QkwsTUFBTSxDQUFDVixNQUFQLENBQWMsQ0FBQ2UsQ0FBQyxHQUFHLENBQUwsS0FBVyxDQUF6QixDQUEvQjtBQUNIOztBQUNELFdBQU8sQ0FBQ0MsR0FBRyxDQUFDQyxNQUFKLEdBQWEsQ0FBZCxJQUFtQixDQUExQixFQUE2QjtBQUN6QkQsTUFBQUEsR0FBRyxJQUFJTCxNQUFQO0FBQ0g7O0FBQ0QsV0FBT0ssR0FBUDtBQUNILEdBbkYyQixDQW9GNUI7OztBQUNBLFdBQVNJLFFBQVQsQ0FBa0JDLENBQWxCLEVBQXFCO0FBQ2pCLFFBQUlMLEdBQUcsR0FBRyxFQUFWO0FBQ0EsUUFBSUYsQ0FBSjtBQUNBLFFBQUlRLENBQUMsR0FBRyxDQUFSLENBSGlCLENBR047O0FBQ1gsUUFBSUMsSUFBSSxHQUFHLENBQVg7O0FBQ0EsU0FBS1QsQ0FBQyxHQUFHLENBQVQsRUFBWUEsQ0FBQyxHQUFHTyxDQUFDLENBQUNKLE1BQWxCLEVBQTBCLEVBQUVILENBQTVCLEVBQStCO0FBQzNCLFVBQUlPLENBQUMsQ0FBQ3JCLE1BQUYsQ0FBU2MsQ0FBVCxLQUFlSCxNQUFuQixFQUEyQjtBQUN2QjtBQUNIOztBQUNELFVBQUlhLENBQUMsR0FBR2QsTUFBTSxDQUFDZSxPQUFQLENBQWVKLENBQUMsQ0FBQ3JCLE1BQUYsQ0FBU2MsQ0FBVCxDQUFmLENBQVI7O0FBQ0EsVUFBSVUsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQO0FBQ0g7O0FBQ0QsVUFBSUYsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNSTixRQUFBQSxHQUFHLElBQUlsQixRQUFRLENBQUMwQixDQUFDLElBQUksQ0FBTixDQUFmO0FBQ0FELFFBQUFBLElBQUksR0FBR0MsQ0FBQyxHQUFHLENBQVg7QUFDQUYsUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUpELE1BS0ssSUFBSUEsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNiTixRQUFBQSxHQUFHLElBQUlsQixRQUFRLENBQUV5QixJQUFJLElBQUksQ0FBVCxHQUFlQyxDQUFDLElBQUksQ0FBckIsQ0FBZjtBQUNBRCxRQUFBQSxJQUFJLEdBQUdDLENBQUMsR0FBRyxHQUFYO0FBQ0FGLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FKSSxNQUtBLElBQUlBLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDYk4sUUFBQUEsR0FBRyxJQUFJbEIsUUFBUSxDQUFDeUIsSUFBRCxDQUFmO0FBQ0FQLFFBQUFBLEdBQUcsSUFBSWxCLFFBQVEsQ0FBQzBCLENBQUMsSUFBSSxDQUFOLENBQWY7QUFDQUQsUUFBQUEsSUFBSSxHQUFHQyxDQUFDLEdBQUcsQ0FBWDtBQUNBRixRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILE9BTEksTUFNQTtBQUNETixRQUFBQSxHQUFHLElBQUlsQixRQUFRLENBQUV5QixJQUFJLElBQUksQ0FBVCxHQUFlQyxDQUFDLElBQUksQ0FBckIsQ0FBZjtBQUNBUixRQUFBQSxHQUFHLElBQUlsQixRQUFRLENBQUMwQixDQUFDLEdBQUcsR0FBTCxDQUFmO0FBQ0FGLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0g7QUFDSjs7QUFDRCxRQUFJQSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ1JOLE1BQUFBLEdBQUcsSUFBSWxCLFFBQVEsQ0FBQ3lCLElBQUksSUFBSSxDQUFULENBQWY7QUFDSDs7QUFDRCxXQUFPUCxHQUFQO0FBQ0g7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBOzs7QUFFQSxNQUFJVSxjQUFhLEdBQUcsdUJBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlO0FBQy9CRixJQUFBQSxjQUFhLEdBQUdHLE1BQU0sQ0FBQ0MsY0FBUCxJQUNYO0FBQUVDLE1BQUFBLFNBQVMsRUFBRTtBQUFiLGlCQUE2QkMsS0FBN0IsSUFBc0MsVUFBVUwsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUVELE1BQUFBLENBQUMsQ0FBQ0ksU0FBRixHQUFjSCxDQUFkO0FBQWtCLEtBRC9ELElBRVosVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUUsV0FBSyxJQUFJSyxDQUFULElBQWNMLENBQWQ7QUFBaUIsWUFBSUEsQ0FBQyxDQUFDTSxjQUFGLENBQWlCRCxDQUFqQixDQUFKLEVBQXlCTixDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPTCxDQUFDLENBQUNLLENBQUQsQ0FBUjtBQUExQztBQUF3RCxLQUY5RTs7QUFHQSxXQUFPUCxjQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFwQjtBQUNILEdBTEQ7O0FBT0EsV0FBU08sU0FBVCxDQUFtQlIsQ0FBbkIsRUFBc0JDLENBQXRCLEVBQXlCO0FBQ3JCRixJQUFBQSxjQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFiOztBQUNBLGFBQVNRLEVBQVQsR0FBYztBQUFFLFdBQUtDLFdBQUwsR0FBbUJWLENBQW5CO0FBQXVCOztBQUN2Q0EsSUFBQUEsQ0FBQyxDQUFDVyxTQUFGLEdBQWNWLENBQUMsS0FBSyxJQUFOLEdBQWFDLE1BQU0sQ0FBQ1UsTUFBUCxDQUFjWCxDQUFkLENBQWIsSUFBaUNRLEVBQUUsQ0FBQ0UsU0FBSCxHQUFlVixDQUFDLENBQUNVLFNBQWpCLEVBQTRCLElBQUlGLEVBQUosRUFBN0QsQ0FBZDtBQUNILEdBekoyQixDQTJKNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7OztBQUNBLE1BQUlJLE9BQUo7QUFDQSxNQUFJQyxHQUFHLEdBQUc7QUFDTkMsSUFBQUEsTUFBTSxFQUFFLGdCQUFVQyxDQUFWLEVBQWE7QUFDakIsVUFBSTdCLENBQUo7O0FBQ0EsVUFBSTBCLE9BQU8sS0FBS0ksU0FBaEIsRUFBMkI7QUFDdkIsWUFBSUMsR0FBRyxHQUFHLGtCQUFWO0FBQ0EsWUFBSUMsTUFBTSxHQUFHLDJCQUFiO0FBQ0FOLFFBQUFBLE9BQU8sR0FBRyxFQUFWOztBQUNBLGFBQUsxQixDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUcsRUFBaEIsRUFBb0IsRUFBRUEsQ0FBdEIsRUFBeUI7QUFDckIwQixVQUFBQSxPQUFPLENBQUNLLEdBQUcsQ0FBQzdDLE1BQUosQ0FBV2MsQ0FBWCxDQUFELENBQVAsR0FBeUJBLENBQXpCO0FBQ0g7O0FBQ0QrQixRQUFBQSxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0UsV0FBSixFQUFOOztBQUNBLGFBQUtqQyxDQUFDLEdBQUcsRUFBVCxFQUFhQSxDQUFDLEdBQUcsRUFBakIsRUFBcUIsRUFBRUEsQ0FBdkIsRUFBMEI7QUFDdEIwQixVQUFBQSxPQUFPLENBQUNLLEdBQUcsQ0FBQzdDLE1BQUosQ0FBV2MsQ0FBWCxDQUFELENBQVAsR0FBeUJBLENBQXpCO0FBQ0g7O0FBQ0QsYUFBS0EsQ0FBQyxHQUFHLENBQVQsRUFBWUEsQ0FBQyxHQUFHZ0MsTUFBTSxDQUFDN0IsTUFBdkIsRUFBK0IsRUFBRUgsQ0FBakMsRUFBb0M7QUFDaEMwQixVQUFBQSxPQUFPLENBQUNNLE1BQU0sQ0FBQzlDLE1BQVAsQ0FBY2MsQ0FBZCxDQUFELENBQVAsR0FBNEIsQ0FBQyxDQUE3QjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSWtDLEdBQUcsR0FBRyxFQUFWO0FBQ0EsVUFBSUMsSUFBSSxHQUFHLENBQVg7QUFDQSxVQUFJQyxVQUFVLEdBQUcsQ0FBakI7O0FBQ0EsV0FBS3BDLENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBRzZCLENBQUMsQ0FBQzFCLE1BQWxCLEVBQTBCLEVBQUVILENBQTVCLEVBQStCO0FBQzNCLFlBQUlDLENBQUMsR0FBRzRCLENBQUMsQ0FBQzNDLE1BQUYsQ0FBU2MsQ0FBVCxDQUFSOztBQUNBLFlBQUlDLENBQUMsSUFBSSxHQUFULEVBQWM7QUFDVjtBQUNIOztBQUNEQSxRQUFBQSxDQUFDLEdBQUd5QixPQUFPLENBQUN6QixDQUFELENBQVg7O0FBQ0EsWUFBSUEsQ0FBQyxJQUFJLENBQUMsQ0FBVixFQUFhO0FBQ1Q7QUFDSDs7QUFDRCxZQUFJQSxDQUFDLEtBQUs2QixTQUFWLEVBQXFCO0FBQ2pCLGdCQUFNLElBQUlPLEtBQUosQ0FBVSxpQ0FBaUNyQyxDQUEzQyxDQUFOO0FBQ0g7O0FBQ0RtQyxRQUFBQSxJQUFJLElBQUlsQyxDQUFSOztBQUNBLFlBQUksRUFBRW1DLFVBQUYsSUFBZ0IsQ0FBcEIsRUFBdUI7QUFDbkJGLFVBQUFBLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDL0IsTUFBTCxDQUFILEdBQWtCZ0MsSUFBbEI7QUFDQUEsVUFBQUEsSUFBSSxHQUFHLENBQVA7QUFDQUMsVUFBQUEsVUFBVSxHQUFHLENBQWI7QUFDSCxTQUpELE1BS0s7QUFDREQsVUFBQUEsSUFBSSxLQUFLLENBQVQ7QUFDSDtBQUNKOztBQUNELFVBQUlDLFVBQUosRUFBZ0I7QUFDWixjQUFNLElBQUlDLEtBQUosQ0FBVSx5Q0FBVixDQUFOO0FBQ0g7O0FBQ0QsYUFBT0gsR0FBUDtBQUNIO0FBL0NLLEdBQVYsQ0ExSzRCLENBNE41QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQSxNQUFJSSxTQUFKO0FBQ0EsTUFBSUMsTUFBTSxHQUFHO0FBQ1RYLElBQUFBLE1BQU0sRUFBRSxnQkFBVUMsQ0FBVixFQUFhO0FBQ2pCLFVBQUk3QixDQUFKOztBQUNBLFVBQUlzQyxTQUFTLEtBQUtSLFNBQWxCLEVBQTZCO0FBQ3pCLFlBQUlVLEdBQUcsR0FBRyxrRUFBVjtBQUNBLFlBQUlSLE1BQU0sR0FBRyw0QkFBYjtBQUNBTSxRQUFBQSxTQUFTLEdBQUd2QixNQUFNLENBQUNVLE1BQVAsQ0FBYyxJQUFkLENBQVo7O0FBQ0EsYUFBS3pCLENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBRyxFQUFoQixFQUFvQixFQUFFQSxDQUF0QixFQUF5QjtBQUNyQnNDLFVBQUFBLFNBQVMsQ0FBQ0UsR0FBRyxDQUFDdEQsTUFBSixDQUFXYyxDQUFYLENBQUQsQ0FBVCxHQUEyQkEsQ0FBM0I7QUFDSDs7QUFDRCxhQUFLQSxDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUdnQyxNQUFNLENBQUM3QixNQUF2QixFQUErQixFQUFFSCxDQUFqQyxFQUFvQztBQUNoQ3NDLFVBQUFBLFNBQVMsQ0FBQ04sTUFBTSxDQUFDOUMsTUFBUCxDQUFjYyxDQUFkLENBQUQsQ0FBVCxHQUE4QixDQUFDLENBQS9CO0FBQ0g7QUFDSjs7QUFDRCxVQUFJa0MsR0FBRyxHQUFHLEVBQVY7QUFDQSxVQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUNBLFVBQUlDLFVBQVUsR0FBRyxDQUFqQjs7QUFDQSxXQUFLcEMsQ0FBQyxHQUFHLENBQVQsRUFBWUEsQ0FBQyxHQUFHNkIsQ0FBQyxDQUFDMUIsTUFBbEIsRUFBMEIsRUFBRUgsQ0FBNUIsRUFBK0I7QUFDM0IsWUFBSUMsQ0FBQyxHQUFHNEIsQ0FBQyxDQUFDM0MsTUFBRixDQUFTYyxDQUFULENBQVI7O0FBQ0EsWUFBSUMsQ0FBQyxJQUFJLEdBQVQsRUFBYztBQUNWO0FBQ0g7O0FBQ0RBLFFBQUFBLENBQUMsR0FBR3FDLFNBQVMsQ0FBQ3JDLENBQUQsQ0FBYjs7QUFDQSxZQUFJQSxDQUFDLElBQUksQ0FBQyxDQUFWLEVBQWE7QUFDVDtBQUNIOztBQUNELFlBQUlBLENBQUMsS0FBSzZCLFNBQVYsRUFBcUI7QUFDakIsZ0JBQU0sSUFBSU8sS0FBSixDQUFVLGlDQUFpQ3JDLENBQTNDLENBQU47QUFDSDs7QUFDRG1DLFFBQUFBLElBQUksSUFBSWxDLENBQVI7O0FBQ0EsWUFBSSxFQUFFbUMsVUFBRixJQUFnQixDQUFwQixFQUF1QjtBQUNuQkYsVUFBQUEsR0FBRyxDQUFDQSxHQUFHLENBQUMvQixNQUFMLENBQUgsR0FBbUJnQyxJQUFJLElBQUksRUFBM0I7QUFDQUQsVUFBQUEsR0FBRyxDQUFDQSxHQUFHLENBQUMvQixNQUFMLENBQUgsR0FBbUJnQyxJQUFJLElBQUksQ0FBVCxHQUFjLElBQWhDO0FBQ0FELFVBQUFBLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDL0IsTUFBTCxDQUFILEdBQWtCZ0MsSUFBSSxHQUFHLElBQXpCO0FBQ0FBLFVBQUFBLElBQUksR0FBRyxDQUFQO0FBQ0FDLFVBQUFBLFVBQVUsR0FBRyxDQUFiO0FBQ0gsU0FORCxNQU9LO0FBQ0RELFVBQUFBLElBQUksS0FBSyxDQUFUO0FBQ0g7QUFDSjs7QUFDRCxjQUFRQyxVQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQ0ksZ0JBQU0sSUFBSUMsS0FBSixDQUFVLHFEQUFWLENBQU47O0FBQ0osYUFBSyxDQUFMO0FBQ0lILFVBQUFBLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDL0IsTUFBTCxDQUFILEdBQW1CZ0MsSUFBSSxJQUFJLEVBQTNCO0FBQ0E7O0FBQ0osYUFBSyxDQUFMO0FBQ0lELFVBQUFBLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDL0IsTUFBTCxDQUFILEdBQW1CZ0MsSUFBSSxJQUFJLEVBQTNCO0FBQ0FELFVBQUFBLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDL0IsTUFBTCxDQUFILEdBQW1CZ0MsSUFBSSxJQUFJLENBQVQsR0FBYyxJQUFoQztBQUNBO0FBVFI7O0FBV0EsYUFBT0QsR0FBUDtBQUNILEtBckRRO0FBc0RUTyxJQUFBQSxFQUFFLEVBQUUsMkdBdERLO0FBdURUQyxJQUFBQSxPQUFPLEVBQUUsaUJBQVViLENBQVYsRUFBYTtBQUNsQixVQUFJYyxDQUFDLEdBQUdKLE1BQU0sQ0FBQ0UsRUFBUCxDQUFVRyxJQUFWLENBQWVmLENBQWYsQ0FBUjs7QUFDQSxVQUFJYyxDQUFKLEVBQU87QUFDSCxZQUFJQSxDQUFDLENBQUMsQ0FBRCxDQUFMLEVBQVU7QUFDTmQsVUFBQUEsQ0FBQyxHQUFHYyxDQUFDLENBQUMsQ0FBRCxDQUFMO0FBQ0gsU0FGRCxNQUdLLElBQUlBLENBQUMsQ0FBQyxDQUFELENBQUwsRUFBVTtBQUNYZCxVQUFBQSxDQUFDLEdBQUdjLENBQUMsQ0FBQyxDQUFELENBQUw7QUFDSCxTQUZJLE1BR0E7QUFDRCxnQkFBTSxJQUFJTixLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsYUFBT0UsTUFBTSxDQUFDWCxNQUFQLENBQWNDLENBQWQsQ0FBUDtBQUNIO0FBckVRLEdBQWIsQ0EzTzRCLENBbVQ1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQSxNQUFJZ0IsR0FBRyxHQUFHLGNBQVYsQ0FqVTRCLENBaVVGOztBQUMxQixNQUFJQyxLQUFLO0FBQUc7QUFBZSxjQUFZO0FBQ25DLGFBQVNBLEtBQVQsQ0FBZUMsS0FBZixFQUFzQjtBQUNsQixXQUFLQyxHQUFMLEdBQVcsQ0FBQyxDQUFDRCxLQUFELElBQVUsQ0FBWCxDQUFYO0FBQ0g7O0FBQ0RELElBQUFBLEtBQUssQ0FBQ3RCLFNBQU4sQ0FBZ0J5QixNQUFoQixHQUF5QixVQUFVTixDQUFWLEVBQWExQyxDQUFiLEVBQWdCO0FBQ3JDO0FBQ0EsVUFBSWEsQ0FBQyxHQUFHLEtBQUtrQyxHQUFiO0FBQ0EsVUFBSUUsQ0FBQyxHQUFHcEMsQ0FBQyxDQUFDWCxNQUFWO0FBQ0EsVUFBSUgsQ0FBSjtBQUNBLFVBQUltRCxDQUFKOztBQUNBLFdBQUtuRCxDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUdrRCxDQUFoQixFQUFtQixFQUFFbEQsQ0FBckIsRUFBd0I7QUFDcEJtRCxRQUFBQSxDQUFDLEdBQUdyQyxDQUFDLENBQUNkLENBQUQsQ0FBRCxHQUFPMkMsQ0FBUCxHQUFXMUMsQ0FBZjs7QUFDQSxZQUFJa0QsQ0FBQyxHQUFHTixHQUFSLEVBQWE7QUFDVDVDLFVBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsU0FGRCxNQUdLO0FBQ0RBLFVBQUFBLENBQUMsR0FBRyxJQUFLa0QsQ0FBQyxHQUFHTixHQUFiO0FBQ0FNLFVBQUFBLENBQUMsSUFBSWxELENBQUMsR0FBRzRDLEdBQVQ7QUFDSDs7QUFDRC9CLFFBQUFBLENBQUMsQ0FBQ2QsQ0FBRCxDQUFELEdBQU9tRCxDQUFQO0FBQ0g7O0FBQ0QsVUFBSWxELENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUGEsUUFBQUEsQ0FBQyxDQUFDZCxDQUFELENBQUQsR0FBT0MsQ0FBUDtBQUNIO0FBQ0osS0FwQkQ7O0FBcUJBNkMsSUFBQUEsS0FBSyxDQUFDdEIsU0FBTixDQUFnQjRCLEdBQWhCLEdBQXNCLFVBQVVuRCxDQUFWLEVBQWE7QUFDL0I7QUFDQSxVQUFJYSxDQUFDLEdBQUcsS0FBS2tDLEdBQWI7QUFDQSxVQUFJRSxDQUFDLEdBQUdwQyxDQUFDLENBQUNYLE1BQVY7QUFDQSxVQUFJSCxDQUFKO0FBQ0EsVUFBSW1ELENBQUo7O0FBQ0EsV0FBS25ELENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBR2tELENBQWhCLEVBQW1CLEVBQUVsRCxDQUFyQixFQUF3QjtBQUNwQm1ELFFBQUFBLENBQUMsR0FBR3JDLENBQUMsQ0FBQ2QsQ0FBRCxDQUFELEdBQU9DLENBQVg7O0FBQ0EsWUFBSWtELENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUEEsVUFBQUEsQ0FBQyxJQUFJTixHQUFMO0FBQ0E1QyxVQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILFNBSEQsTUFJSztBQUNEQSxVQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNIOztBQUNEYSxRQUFBQSxDQUFDLENBQUNkLENBQUQsQ0FBRCxHQUFPbUQsQ0FBUDtBQUNIOztBQUNELGFBQU9yQyxDQUFDLENBQUNBLENBQUMsQ0FBQ1gsTUFBRixHQUFXLENBQVosQ0FBRCxLQUFvQixDQUEzQixFQUE4QjtBQUMxQlcsUUFBQUEsQ0FBQyxDQUFDdUMsR0FBRjtBQUNIO0FBQ0osS0FwQkQ7O0FBcUJBUCxJQUFBQSxLQUFLLENBQUN0QixTQUFOLENBQWdCOEIsUUFBaEIsR0FBMkIsVUFBVUMsSUFBVixFQUFnQjtBQUN2QyxVQUFJLENBQUNBLElBQUksSUFBSSxFQUFULEtBQWdCLEVBQXBCLEVBQXdCO0FBQ3BCLGNBQU0sSUFBSWxCLEtBQUosQ0FBVSwyQkFBVixDQUFOO0FBQ0g7O0FBQ0QsVUFBSXZCLENBQUMsR0FBRyxLQUFLa0MsR0FBYjtBQUNBLFVBQUl6QyxDQUFDLEdBQUdPLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDWCxNQUFGLEdBQVcsQ0FBWixDQUFELENBQWdCbUQsUUFBaEIsRUFBUjs7QUFDQSxXQUFLLElBQUl0RCxDQUFDLEdBQUdjLENBQUMsQ0FBQ1gsTUFBRixHQUFXLENBQXhCLEVBQTJCSCxDQUFDLElBQUksQ0FBaEMsRUFBbUMsRUFBRUEsQ0FBckMsRUFBd0M7QUFDcENPLFFBQUFBLENBQUMsSUFBSSxDQUFDc0MsR0FBRyxHQUFHL0IsQ0FBQyxDQUFDZCxDQUFELENBQVIsRUFBYXNELFFBQWIsR0FBd0JqRCxTQUF4QixDQUFrQyxDQUFsQyxDQUFMO0FBQ0g7O0FBQ0QsYUFBT0UsQ0FBUDtBQUNILEtBVkQ7O0FBV0F1QyxJQUFBQSxLQUFLLENBQUN0QixTQUFOLENBQWdCZ0MsT0FBaEIsR0FBMEIsWUFBWTtBQUNsQyxVQUFJMUMsQ0FBQyxHQUFHLEtBQUtrQyxHQUFiO0FBQ0EsVUFBSXRDLENBQUMsR0FBRyxDQUFSOztBQUNBLFdBQUssSUFBSVYsQ0FBQyxHQUFHYyxDQUFDLENBQUNYLE1BQUYsR0FBVyxDQUF4QixFQUEyQkgsQ0FBQyxJQUFJLENBQWhDLEVBQW1DLEVBQUVBLENBQXJDLEVBQXdDO0FBQ3BDVSxRQUFBQSxDQUFDLEdBQUdBLENBQUMsR0FBR21DLEdBQUosR0FBVS9CLENBQUMsQ0FBQ2QsQ0FBRCxDQUFmO0FBQ0g7O0FBQ0QsYUFBT1UsQ0FBUDtBQUNILEtBUEQ7O0FBUUFvQyxJQUFBQSxLQUFLLENBQUN0QixTQUFOLENBQWdCaUMsUUFBaEIsR0FBMkIsWUFBWTtBQUNuQyxVQUFJM0MsQ0FBQyxHQUFHLEtBQUtrQyxHQUFiO0FBQ0EsYUFBUWxDLENBQUMsQ0FBQ1gsTUFBRixJQUFZLENBQWIsR0FBa0JXLENBQUMsQ0FBQyxDQUFELENBQW5CLEdBQXlCLElBQWhDO0FBQ0gsS0FIRDs7QUFJQSxXQUFPZ0MsS0FBUDtBQUNILEdBdEUwQixFQUEzQixDQWxVNEIsQ0EwWTVCOzs7QUFDQSxNQUFJWSxRQUFRLEdBQUcsUUFBZjtBQUNBLE1BQUlDLE9BQU8sR0FBRyw4SUFBZDtBQUNBLE1BQUlDLE9BQU8sR0FBRyxrSkFBZDs7QUFDQSxXQUFTQyxTQUFULENBQW1CQyxHQUFuQixFQUF3QkMsR0FBeEIsRUFBNkI7QUFDekIsUUFBSUQsR0FBRyxDQUFDM0QsTUFBSixHQUFhNEQsR0FBakIsRUFBc0I7QUFDbEJELE1BQUFBLEdBQUcsR0FBR0EsR0FBRyxDQUFDekQsU0FBSixDQUFjLENBQWQsRUFBaUIwRCxHQUFqQixJQUF3QkwsUUFBOUI7QUFDSDs7QUFDRCxXQUFPSSxHQUFQO0FBQ0g7O0FBQ0QsTUFBSUUsTUFBTTtBQUFHO0FBQWUsY0FBWTtBQUNwQyxhQUFTQSxNQUFULENBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsRUFBMEI7QUFDdEIsV0FBS0MsU0FBTCxHQUFpQixrQkFBakI7O0FBQ0EsVUFBSUYsR0FBRyxZQUFZRCxNQUFuQixFQUEyQjtBQUN2QixhQUFLQyxHQUFMLEdBQVdBLEdBQUcsQ0FBQ0EsR0FBZjtBQUNBLGFBQUtDLEdBQUwsR0FBV0QsR0FBRyxDQUFDQyxHQUFmO0FBQ0gsT0FIRCxNQUlLO0FBQ0Q7QUFDQSxhQUFLRCxHQUFMLEdBQVdBLEdBQVg7QUFDQSxhQUFLQyxHQUFMLEdBQVdBLEdBQVg7QUFDSDtBQUNKOztBQUNERixJQUFBQSxNQUFNLENBQUN4QyxTQUFQLENBQWlCNEMsR0FBakIsR0FBdUIsVUFBVUYsR0FBVixFQUFlO0FBQ2xDLFVBQUlBLEdBQUcsS0FBS3BDLFNBQVosRUFBdUI7QUFDbkJvQyxRQUFBQSxHQUFHLEdBQUcsS0FBS0EsR0FBTCxFQUFOO0FBQ0g7O0FBQ0QsVUFBSUEsR0FBRyxJQUFJLEtBQUtELEdBQUwsQ0FBUzlELE1BQXBCLEVBQTRCO0FBQ3hCLGNBQU0sSUFBSWtDLEtBQUosQ0FBVSw0QkFBNEI2QixHQUE1QixHQUFrQyx5QkFBbEMsR0FBOEQsS0FBS0QsR0FBTCxDQUFTOUQsTUFBakYsQ0FBTjtBQUNIOztBQUNELGFBQVEsYUFBYSxPQUFPLEtBQUs4RCxHQUExQixHQUFpQyxLQUFLQSxHQUFMLENBQVNJLFVBQVQsQ0FBb0JILEdBQXBCLENBQWpDLEdBQTRELEtBQUtELEdBQUwsQ0FBU0MsR0FBVCxDQUFuRTtBQUNILEtBUkQ7O0FBU0FGLElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUI4QyxPQUFqQixHQUEyQixVQUFVeEQsQ0FBVixFQUFhO0FBQ3BDLGFBQU8sS0FBS3FELFNBQUwsQ0FBZWpGLE1BQWYsQ0FBdUI0QixDQUFDLElBQUksQ0FBTixHQUFXLEdBQWpDLElBQXdDLEtBQUtxRCxTQUFMLENBQWVqRixNQUFmLENBQXNCNEIsQ0FBQyxHQUFHLEdBQTFCLENBQS9DO0FBQ0gsS0FGRDs7QUFHQWtELElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUIrQyxPQUFqQixHQUEyQixVQUFVQyxLQUFWLEVBQWlCQyxHQUFqQixFQUFzQkMsR0FBdEIsRUFBMkI7QUFDbEQsVUFBSW5FLENBQUMsR0FBRyxFQUFSOztBQUNBLFdBQUssSUFBSVAsQ0FBQyxHQUFHd0UsS0FBYixFQUFvQnhFLENBQUMsR0FBR3lFLEdBQXhCLEVBQTZCLEVBQUV6RSxDQUEvQixFQUFrQztBQUM5Qk8sUUFBQUEsQ0FBQyxJQUFJLEtBQUsrRCxPQUFMLENBQWEsS0FBS0YsR0FBTCxDQUFTcEUsQ0FBVCxDQUFiLENBQUw7O0FBQ0EsWUFBSTBFLEdBQUcsS0FBSyxJQUFaLEVBQWtCO0FBQ2Qsa0JBQVExRSxDQUFDLEdBQUcsR0FBWjtBQUNJLGlCQUFLLEdBQUw7QUFDSU8sY0FBQUEsQ0FBQyxJQUFJLElBQUw7QUFDQTs7QUFDSixpQkFBSyxHQUFMO0FBQ0lBLGNBQUFBLENBQUMsSUFBSSxJQUFMO0FBQ0E7O0FBQ0o7QUFDSUEsY0FBQUEsQ0FBQyxJQUFJLEdBQUw7QUFSUjtBQVVIO0FBQ0o7O0FBQ0QsYUFBT0EsQ0FBUDtBQUNILEtBbEJEOztBQW1CQXlELElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUJtRCxPQUFqQixHQUEyQixVQUFVSCxLQUFWLEVBQWlCQyxHQUFqQixFQUFzQjtBQUM3QyxXQUFLLElBQUl6RSxDQUFDLEdBQUd3RSxLQUFiLEVBQW9CeEUsQ0FBQyxHQUFHeUUsR0FBeEIsRUFBNkIsRUFBRXpFLENBQS9CLEVBQWtDO0FBQzlCLFlBQUlDLENBQUMsR0FBRyxLQUFLbUUsR0FBTCxDQUFTcEUsQ0FBVCxDQUFSOztBQUNBLFlBQUlDLENBQUMsR0FBRyxFQUFKLElBQVVBLENBQUMsR0FBRyxHQUFsQixFQUF1QjtBQUNuQixpQkFBTyxLQUFQO0FBQ0g7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQVJEOztBQVNBK0QsSUFBQUEsTUFBTSxDQUFDeEMsU0FBUCxDQUFpQm9ELGNBQWpCLEdBQWtDLFVBQVVKLEtBQVYsRUFBaUJDLEdBQWpCLEVBQXNCO0FBQ3BELFVBQUlsRSxDQUFDLEdBQUcsRUFBUjs7QUFDQSxXQUFLLElBQUlQLENBQUMsR0FBR3dFLEtBQWIsRUFBb0J4RSxDQUFDLEdBQUd5RSxHQUF4QixFQUE2QixFQUFFekUsQ0FBL0IsRUFBa0M7QUFDOUJPLFFBQUFBLENBQUMsSUFBSXNFLE1BQU0sQ0FBQ0MsWUFBUCxDQUFvQixLQUFLVixHQUFMLENBQVNwRSxDQUFULENBQXBCLENBQUw7QUFDSDs7QUFDRCxhQUFPTyxDQUFQO0FBQ0gsS0FORDs7QUFPQXlELElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUJ1RCxjQUFqQixHQUFrQyxVQUFVUCxLQUFWLEVBQWlCQyxHQUFqQixFQUFzQjtBQUNwRCxVQUFJbEUsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsV0FBSyxJQUFJUCxDQUFDLEdBQUd3RSxLQUFiLEVBQW9CeEUsQ0FBQyxHQUFHeUUsR0FBeEIsR0FBOEI7QUFDMUIsWUFBSXhFLENBQUMsR0FBRyxLQUFLbUUsR0FBTCxDQUFTcEUsQ0FBQyxFQUFWLENBQVI7O0FBQ0EsWUFBSUMsQ0FBQyxHQUFHLEdBQVIsRUFBYTtBQUNUTSxVQUFBQSxDQUFDLElBQUlzRSxNQUFNLENBQUNDLFlBQVAsQ0FBb0I3RSxDQUFwQixDQUFMO0FBQ0gsU0FGRCxNQUdLLElBQUtBLENBQUMsR0FBRyxHQUFMLElBQWNBLENBQUMsR0FBRyxHQUF0QixFQUE0QjtBQUM3Qk0sVUFBQUEsQ0FBQyxJQUFJc0UsTUFBTSxDQUFDQyxZQUFQLENBQXFCLENBQUM3RSxDQUFDLEdBQUcsSUFBTCxLQUFjLENBQWYsR0FBcUIsS0FBS21FLEdBQUwsQ0FBU3BFLENBQUMsRUFBVixJQUFnQixJQUF6RCxDQUFMO0FBQ0gsU0FGSSxNQUdBO0FBQ0RPLFVBQUFBLENBQUMsSUFBSXNFLE1BQU0sQ0FBQ0MsWUFBUCxDQUFxQixDQUFDN0UsQ0FBQyxHQUFHLElBQUwsS0FBYyxFQUFmLEdBQXNCLENBQUMsS0FBS21FLEdBQUwsQ0FBU3BFLENBQUMsRUFBVixJQUFnQixJQUFqQixLQUEwQixDQUFoRCxHQUFzRCxLQUFLb0UsR0FBTCxDQUFTcEUsQ0FBQyxFQUFWLElBQWdCLElBQTFGLENBQUw7QUFDSDtBQUNKOztBQUNELGFBQU9PLENBQVA7QUFDSCxLQWZEOztBQWdCQXlELElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUJ3RCxjQUFqQixHQUFrQyxVQUFVUixLQUFWLEVBQWlCQyxHQUFqQixFQUFzQjtBQUNwRCxVQUFJWCxHQUFHLEdBQUcsRUFBVjtBQUNBLFVBQUltQixFQUFKO0FBQ0EsVUFBSUMsRUFBSjs7QUFDQSxXQUFLLElBQUlsRixDQUFDLEdBQUd3RSxLQUFiLEVBQW9CeEUsQ0FBQyxHQUFHeUUsR0FBeEIsR0FBOEI7QUFDMUJRLFFBQUFBLEVBQUUsR0FBRyxLQUFLYixHQUFMLENBQVNwRSxDQUFDLEVBQVYsQ0FBTDtBQUNBa0YsUUFBQUEsRUFBRSxHQUFHLEtBQUtkLEdBQUwsQ0FBU3BFLENBQUMsRUFBVixDQUFMO0FBQ0E4RCxRQUFBQSxHQUFHLElBQUllLE1BQU0sQ0FBQ0MsWUFBUCxDQUFxQkcsRUFBRSxJQUFJLENBQVAsR0FBWUMsRUFBaEMsQ0FBUDtBQUNIOztBQUNELGFBQU9wQixHQUFQO0FBQ0gsS0FWRDs7QUFXQUUsSUFBQUEsTUFBTSxDQUFDeEMsU0FBUCxDQUFpQjJELFNBQWpCLEdBQTZCLFVBQVVYLEtBQVYsRUFBaUJDLEdBQWpCLEVBQXNCVyxTQUF0QixFQUFpQztBQUMxRCxVQUFJN0UsQ0FBQyxHQUFHLEtBQUtxRSxjQUFMLENBQW9CSixLQUFwQixFQUEyQkMsR0FBM0IsQ0FBUjtBQUNBLFVBQUk5QixDQUFDLEdBQUcsQ0FBQ3lDLFNBQVMsR0FBR3pCLE9BQUgsR0FBYUMsT0FBdkIsRUFBZ0NoQixJQUFoQyxDQUFxQ3JDLENBQXJDLENBQVI7O0FBQ0EsVUFBSSxDQUFDb0MsQ0FBTCxFQUFRO0FBQ0osZUFBTyx3QkFBd0JwQyxDQUEvQjtBQUNIOztBQUNELFVBQUk2RSxTQUFKLEVBQWU7QUFDWDtBQUNBO0FBQ0F6QyxRQUFBQSxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sQ0FBQ0EsQ0FBQyxDQUFDLENBQUQsQ0FBVDtBQUNBQSxRQUFBQSxDQUFDLENBQUMsQ0FBRCxDQUFELElBQVMsQ0FBQ0EsQ0FBQyxDQUFDLENBQUQsQ0FBRixHQUFRLEVBQVQsR0FBZSxJQUFmLEdBQXNCLElBQTlCO0FBQ0g7O0FBQ0RwQyxNQUFBQSxDQUFDLEdBQUdvQyxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sR0FBUCxHQUFhQSxDQUFDLENBQUMsQ0FBRCxDQUFkLEdBQW9CLEdBQXBCLEdBQTBCQSxDQUFDLENBQUMsQ0FBRCxDQUEzQixHQUFpQyxHQUFqQyxHQUF1Q0EsQ0FBQyxDQUFDLENBQUQsQ0FBNUM7O0FBQ0EsVUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVO0FBQ05wQyxRQUFBQSxDQUFDLElBQUksTUFBTW9DLENBQUMsQ0FBQyxDQUFELENBQVo7O0FBQ0EsWUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVO0FBQ05wQyxVQUFBQSxDQUFDLElBQUksTUFBTW9DLENBQUMsQ0FBQyxDQUFELENBQVo7O0FBQ0EsY0FBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVO0FBQ05wQyxZQUFBQSxDQUFDLElBQUksTUFBTW9DLENBQUMsQ0FBQyxDQUFELENBQVo7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsVUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVO0FBQ05wQyxRQUFBQSxDQUFDLElBQUksTUFBTDs7QUFDQSxZQUFJb0MsQ0FBQyxDQUFDLENBQUQsQ0FBRCxJQUFRLEdBQVosRUFBaUI7QUFDYnBDLFVBQUFBLENBQUMsSUFBSW9DLENBQUMsQ0FBQyxDQUFELENBQU47O0FBQ0EsY0FBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVO0FBQ05wQyxZQUFBQSxDQUFDLElBQUksTUFBTW9DLENBQUMsQ0FBQyxDQUFELENBQVo7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsYUFBT3BDLENBQVA7QUFDSCxLQWhDRDs7QUFpQ0F5RCxJQUFBQSxNQUFNLENBQUN4QyxTQUFQLENBQWlCNkQsWUFBakIsR0FBZ0MsVUFBVWIsS0FBVixFQUFpQkMsR0FBakIsRUFBc0I7QUFDbEQsVUFBSS9ELENBQUMsR0FBRyxLQUFLMEQsR0FBTCxDQUFTSSxLQUFULENBQVI7QUFDQSxVQUFJYyxHQUFHLEdBQUk1RSxDQUFDLEdBQUcsR0FBZjtBQUNBLFVBQUk2RSxHQUFHLEdBQUdELEdBQUcsR0FBRyxHQUFILEdBQVMsQ0FBdEI7QUFDQSxVQUFJdkIsR0FBSjtBQUNBLFVBQUl4RCxDQUFDLEdBQUcsRUFBUixDQUxrRCxDQU1sRDs7QUFDQSxhQUFPRyxDQUFDLElBQUk2RSxHQUFMLElBQVksRUFBRWYsS0FBRixHQUFVQyxHQUE3QixFQUFrQztBQUM5Qi9ELFFBQUFBLENBQUMsR0FBRyxLQUFLMEQsR0FBTCxDQUFTSSxLQUFULENBQUo7QUFDSDs7QUFDRFQsTUFBQUEsR0FBRyxHQUFHVSxHQUFHLEdBQUdELEtBQVo7O0FBQ0EsVUFBSVQsR0FBRyxLQUFLLENBQVosRUFBZTtBQUNYLGVBQU91QixHQUFHLEdBQUcsQ0FBQyxDQUFKLEdBQVEsQ0FBbEI7QUFDSCxPQWJpRCxDQWNsRDs7O0FBQ0EsVUFBSXZCLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDVHhELFFBQUFBLENBQUMsR0FBR0csQ0FBSjtBQUNBcUQsUUFBQUEsR0FBRyxLQUFLLENBQVI7O0FBQ0EsZUFBTyxDQUFDLENBQUMsQ0FBQ3hELENBQUQsR0FBS2dGLEdBQU4sSUFBYSxJQUFkLEtBQXVCLENBQTlCLEVBQWlDO0FBQzdCaEYsVUFBQUEsQ0FBQyxHQUFHLENBQUNBLENBQUQsSUFBTSxDQUFWO0FBQ0EsWUFBRXdELEdBQUY7QUFDSDs7QUFDRHhELFFBQUFBLENBQUMsR0FBRyxNQUFNd0QsR0FBTixHQUFZLFNBQWhCO0FBQ0gsT0F2QmlELENBd0JsRDs7O0FBQ0EsVUFBSXVCLEdBQUosRUFBUztBQUNMNUUsUUFBQUEsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsR0FBUjtBQUNIOztBQUNELFVBQUl6QixDQUFDLEdBQUcsSUFBSTZELEtBQUosQ0FBVXBDLENBQVYsQ0FBUjs7QUFDQSxXQUFLLElBQUlWLENBQUMsR0FBR3dFLEtBQUssR0FBRyxDQUFyQixFQUF3QnhFLENBQUMsR0FBR3lFLEdBQTVCLEVBQWlDLEVBQUV6RSxDQUFuQyxFQUFzQztBQUNsQ2YsUUFBQUEsQ0FBQyxDQUFDZ0UsTUFBRixDQUFTLEdBQVQsRUFBYyxLQUFLbUIsR0FBTCxDQUFTcEUsQ0FBVCxDQUFkO0FBQ0g7O0FBQ0QsYUFBT08sQ0FBQyxHQUFHdEIsQ0FBQyxDQUFDcUUsUUFBRixFQUFYO0FBQ0gsS0FqQ0Q7O0FBa0NBVSxJQUFBQSxNQUFNLENBQUN4QyxTQUFQLENBQWlCZ0UsY0FBakIsR0FBa0MsVUFBVWhCLEtBQVYsRUFBaUJDLEdBQWpCLEVBQXNCZ0IsU0FBdEIsRUFBaUM7QUFDL0QsVUFBSUMsU0FBUyxHQUFHLEtBQUt0QixHQUFMLENBQVNJLEtBQVQsQ0FBaEI7QUFDQSxVQUFJbUIsTUFBTSxHQUFHLENBQUVsQixHQUFHLEdBQUdELEtBQU4sR0FBYyxDQUFmLElBQXFCLENBQXRCLElBQTJCa0IsU0FBeEM7QUFDQSxVQUFJRSxLQUFLLEdBQUcsTUFBTUQsTUFBTixHQUFlLFNBQTNCO0FBQ0EsVUFBSXBGLENBQUMsR0FBRyxFQUFSOztBQUNBLFdBQUssSUFBSVAsQ0FBQyxHQUFHd0UsS0FBSyxHQUFHLENBQXJCLEVBQXdCeEUsQ0FBQyxHQUFHeUUsR0FBNUIsRUFBaUMsRUFBRXpFLENBQW5DLEVBQXNDO0FBQ2xDLFlBQUljLENBQUMsR0FBRyxLQUFLc0QsR0FBTCxDQUFTcEUsQ0FBVCxDQUFSO0FBQ0EsWUFBSTZGLElBQUksR0FBSTdGLENBQUMsSUFBSXlFLEdBQUcsR0FBRyxDQUFaLEdBQWlCaUIsU0FBakIsR0FBNkIsQ0FBeEM7O0FBQ0EsYUFBSyxJQUFJSSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxJQUFJRCxJQUFyQixFQUEyQixFQUFFQyxDQUE3QixFQUFnQztBQUM1QnZGLFVBQUFBLENBQUMsSUFBS08sQ0FBQyxJQUFJZ0YsQ0FBTixHQUFXLENBQVgsR0FBZSxHQUFmLEdBQXFCLEdBQTFCO0FBQ0g7O0FBQ0QsWUFBSXZGLENBQUMsQ0FBQ0osTUFBRixHQUFXc0YsU0FBZixFQUEwQjtBQUN0QixpQkFBT0csS0FBSyxHQUFHL0IsU0FBUyxDQUFDdEQsQ0FBRCxFQUFJa0YsU0FBSixDQUF4QjtBQUNIO0FBQ0o7O0FBQ0QsYUFBT0csS0FBSyxHQUFHckYsQ0FBZjtBQUNILEtBaEJEOztBQWlCQXlELElBQUFBLE1BQU0sQ0FBQ3hDLFNBQVAsQ0FBaUJ1RSxnQkFBakIsR0FBb0MsVUFBVXZCLEtBQVYsRUFBaUJDLEdBQWpCLEVBQXNCZ0IsU0FBdEIsRUFBaUM7QUFDakUsVUFBSSxLQUFLZCxPQUFMLENBQWFILEtBQWIsRUFBb0JDLEdBQXBCLENBQUosRUFBOEI7QUFDMUIsZUFBT1osU0FBUyxDQUFDLEtBQUtlLGNBQUwsQ0FBb0JKLEtBQXBCLEVBQTJCQyxHQUEzQixDQUFELEVBQWtDZ0IsU0FBbEMsQ0FBaEI7QUFDSDs7QUFDRCxVQUFJMUIsR0FBRyxHQUFHVSxHQUFHLEdBQUdELEtBQWhCO0FBQ0EsVUFBSWpFLENBQUMsR0FBRyxNQUFNd0QsR0FBTixHQUFZLFVBQXBCO0FBQ0EwQixNQUFBQSxTQUFTLElBQUksQ0FBYixDQU5pRSxDQU1qRDs7QUFDaEIsVUFBSTFCLEdBQUcsR0FBRzBCLFNBQVYsRUFBcUI7QUFDakJoQixRQUFBQSxHQUFHLEdBQUdELEtBQUssR0FBR2lCLFNBQWQ7QUFDSDs7QUFDRCxXQUFLLElBQUl6RixDQUFDLEdBQUd3RSxLQUFiLEVBQW9CeEUsQ0FBQyxHQUFHeUUsR0FBeEIsRUFBNkIsRUFBRXpFLENBQS9CLEVBQWtDO0FBQzlCTyxRQUFBQSxDQUFDLElBQUksS0FBSytELE9BQUwsQ0FBYSxLQUFLRixHQUFMLENBQVNwRSxDQUFULENBQWIsQ0FBTDtBQUNIOztBQUNELFVBQUkrRCxHQUFHLEdBQUcwQixTQUFWLEVBQXFCO0FBQ2pCbEYsUUFBQUEsQ0FBQyxJQUFJbUQsUUFBTDtBQUNIOztBQUNELGFBQU9uRCxDQUFQO0FBQ0gsS0FqQkQ7O0FBa0JBeUQsSUFBQUEsTUFBTSxDQUFDeEMsU0FBUCxDQUFpQndFLFFBQWpCLEdBQTRCLFVBQVV4QixLQUFWLEVBQWlCQyxHQUFqQixFQUFzQmdCLFNBQXRCLEVBQWlDO0FBQ3pELFVBQUlsRixDQUFDLEdBQUcsRUFBUjtBQUNBLFVBQUl0QixDQUFDLEdBQUcsSUFBSTZELEtBQUosRUFBUjtBQUNBLFVBQUlYLElBQUksR0FBRyxDQUFYOztBQUNBLFdBQUssSUFBSW5DLENBQUMsR0FBR3dFLEtBQWIsRUFBb0J4RSxDQUFDLEdBQUd5RSxHQUF4QixFQUE2QixFQUFFekUsQ0FBL0IsRUFBa0M7QUFDOUIsWUFBSVUsQ0FBQyxHQUFHLEtBQUswRCxHQUFMLENBQVNwRSxDQUFULENBQVI7QUFDQWYsUUFBQUEsQ0FBQyxDQUFDZ0UsTUFBRixDQUFTLEdBQVQsRUFBY3ZDLENBQUMsR0FBRyxJQUFsQjtBQUNBeUIsUUFBQUEsSUFBSSxJQUFJLENBQVI7O0FBQ0EsWUFBSSxFQUFFekIsQ0FBQyxHQUFHLElBQU4sQ0FBSixFQUFpQjtBQUFFO0FBQ2YsY0FBSUgsQ0FBQyxLQUFLLEVBQVYsRUFBYztBQUNWdEIsWUFBQUEsQ0FBQyxHQUFHQSxDQUFDLENBQUN3RSxRQUFGLEVBQUo7O0FBQ0EsZ0JBQUl4RSxDQUFDLFlBQVk2RCxLQUFqQixFQUF3QjtBQUNwQjdELGNBQUFBLENBQUMsQ0FBQ21FLEdBQUYsQ0FBTSxFQUFOO0FBQ0E3QyxjQUFBQSxDQUFDLEdBQUcsT0FBT3RCLENBQUMsQ0FBQ3FFLFFBQUYsRUFBWDtBQUNILGFBSEQsTUFJSztBQUNELGtCQUFJWCxDQUFDLEdBQUcxRCxDQUFDLEdBQUcsRUFBSixHQUFTQSxDQUFDLEdBQUcsRUFBSixHQUFTLENBQVQsR0FBYSxDQUF0QixHQUEwQixDQUFsQztBQUNBc0IsY0FBQUEsQ0FBQyxHQUFHb0MsQ0FBQyxHQUFHLEdBQUosSUFBVzFELENBQUMsR0FBRzBELENBQUMsR0FBRyxFQUFuQixDQUFKO0FBQ0g7QUFDSixXQVZELE1BV0s7QUFDRHBDLFlBQUFBLENBQUMsSUFBSSxNQUFNdEIsQ0FBQyxDQUFDcUUsUUFBRixFQUFYO0FBQ0g7O0FBQ0QsY0FBSS9DLENBQUMsQ0FBQ0osTUFBRixHQUFXc0YsU0FBZixFQUEwQjtBQUN0QixtQkFBTzVCLFNBQVMsQ0FBQ3RELENBQUQsRUFBSWtGLFNBQUosQ0FBaEI7QUFDSDs7QUFDRHhHLFVBQUFBLENBQUMsR0FBRyxJQUFJNkQsS0FBSixFQUFKO0FBQ0FYLFVBQUFBLElBQUksR0FBRyxDQUFQO0FBQ0g7QUFDSjs7QUFDRCxVQUFJQSxJQUFJLEdBQUcsQ0FBWCxFQUFjO0FBQ1Y1QixRQUFBQSxDQUFDLElBQUksYUFBTDtBQUNIOztBQUNELGFBQU9BLENBQVA7QUFDSCxLQWxDRDs7QUFtQ0EsV0FBT3lELE1BQVA7QUFDSCxHQWpPMkIsRUFBNUI7O0FBa09BLE1BQUlpQyxJQUFJO0FBQUc7QUFBZSxjQUFZO0FBQ2xDLGFBQVNBLElBQVQsQ0FBY0MsTUFBZCxFQUFzQkMsTUFBdEIsRUFBOEJoRyxNQUE5QixFQUFzQ2lHLEdBQXRDLEVBQTJDaEQsR0FBM0MsRUFBZ0Q7QUFDNUMsVUFBSSxFQUFFZ0QsR0FBRyxZQUFZQyxPQUFqQixDQUFKLEVBQStCO0FBQzNCLGNBQU0sSUFBSWhFLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0g7O0FBQ0QsV0FBSzZELE1BQUwsR0FBY0EsTUFBZDtBQUNBLFdBQUtDLE1BQUwsR0FBY0EsTUFBZDtBQUNBLFdBQUtoRyxNQUFMLEdBQWNBLE1BQWQ7QUFDQSxXQUFLaUcsR0FBTCxHQUFXQSxHQUFYO0FBQ0EsV0FBS2hELEdBQUwsR0FBV0EsR0FBWDtBQUNIOztBQUNENkMsSUFBQUEsSUFBSSxDQUFDekUsU0FBTCxDQUFlOEUsUUFBZixHQUEwQixZQUFZO0FBQ2xDLGNBQVEsS0FBS0YsR0FBTCxDQUFTRyxRQUFqQjtBQUNJLGFBQUssQ0FBTDtBQUFRO0FBQ0osa0JBQVEsS0FBS0gsR0FBTCxDQUFTSSxTQUFqQjtBQUNJLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxLQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxTQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxTQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxZQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxjQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxNQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxtQkFBUDs7QUFDSixpQkFBSyxJQUFMO0FBQ0kscUJBQU8sa0JBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLFVBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLE1BQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLFlBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLGNBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLFlBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLFVBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLEtBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLGVBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLGlCQUFQO0FBQTBCOztBQUM5QixpQkFBSyxJQUFMO0FBQ0kscUJBQU8sZUFBUDtBQUF3Qjs7QUFDNUIsaUJBQUssSUFBTDtBQUNJLHFCQUFPLGdCQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxXQUFQO0FBQW9COztBQUN4QixpQkFBSyxJQUFMO0FBQ0kscUJBQU8sU0FBUDs7QUFDSixpQkFBSyxJQUFMO0FBQ0kscUJBQU8saUJBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLGVBQVA7O0FBQ0osaUJBQUssSUFBTDtBQUNJLHFCQUFPLGVBQVA7QUFBd0I7O0FBQzVCLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxlQUFQOztBQUNKLGlCQUFLLElBQUw7QUFDSSxxQkFBTyxpQkFBUDs7QUFDSixpQkFBSyxJQUFMO0FBQ0kscUJBQU8sV0FBUDtBQXREUjs7QUF3REEsaUJBQU8sZUFBZSxLQUFLSixHQUFMLENBQVNJLFNBQVQsQ0FBbUJsRCxRQUFuQixFQUF0Qjs7QUFDSixhQUFLLENBQUw7QUFDSSxpQkFBTyxpQkFBaUIsS0FBSzhDLEdBQUwsQ0FBU0ksU0FBVCxDQUFtQmxELFFBQW5CLEVBQXhCOztBQUNKLGFBQUssQ0FBTDtBQUNJLGlCQUFPLE1BQU0sS0FBSzhDLEdBQUwsQ0FBU0ksU0FBVCxDQUFtQmxELFFBQW5CLEVBQU4sR0FBc0MsR0FBN0M7QUFBa0Q7O0FBQ3RELGFBQUssQ0FBTDtBQUNJLGlCQUFPLGFBQWEsS0FBSzhDLEdBQUwsQ0FBU0ksU0FBVCxDQUFtQmxELFFBQW5CLEVBQXBCO0FBaEVSO0FBa0VILEtBbkVEOztBQW9FQTJDLElBQUFBLElBQUksQ0FBQ3pFLFNBQUwsQ0FBZWlGLE9BQWYsR0FBeUIsVUFBVWhCLFNBQVYsRUFBcUI7QUFDMUMsVUFBSSxLQUFLVyxHQUFMLEtBQWF0RSxTQUFqQixFQUE0QjtBQUN4QixlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJMkQsU0FBUyxLQUFLM0QsU0FBbEIsRUFBNkI7QUFDekIyRCxRQUFBQSxTQUFTLEdBQUdpQixRQUFaO0FBQ0g7O0FBQ0QsVUFBSUQsT0FBTyxHQUFHLEtBQUtFLFVBQUwsRUFBZDtBQUNBLFVBQUk1QyxHQUFHLEdBQUc2QyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLMUcsTUFBZCxDQUFWOztBQUNBLFVBQUksQ0FBQyxLQUFLaUcsR0FBTCxDQUFTVSxXQUFULEVBQUwsRUFBNkI7QUFDekIsWUFBSSxLQUFLMUQsR0FBTCxLQUFhLElBQWpCLEVBQXVCO0FBQ25CLGlCQUFPLE1BQU0sS0FBS0EsR0FBTCxDQUFTakQsTUFBZixHQUF3QixRQUEvQjtBQUNIOztBQUNELGVBQU8sS0FBSytGLE1BQUwsQ0FBWUgsZ0JBQVosQ0FBNkJVLE9BQTdCLEVBQXNDQSxPQUFPLEdBQUcxQyxHQUFoRCxFQUFxRDBCLFNBQXJELENBQVA7QUFDSDs7QUFDRCxjQUFRLEtBQUtXLEdBQUwsQ0FBU0ksU0FBakI7QUFDSSxhQUFLLElBQUw7QUFBVztBQUNQLGlCQUFRLEtBQUtOLE1BQUwsQ0FBWTlCLEdBQVosQ0FBZ0JxQyxPQUFoQixNQUE2QixDQUE5QixHQUFtQyxPQUFuQyxHQUE2QyxNQUFwRDs7QUFDSixhQUFLLElBQUw7QUFBVztBQUNQLGlCQUFPLEtBQUtQLE1BQUwsQ0FBWWIsWUFBWixDQUF5Qm9CLE9BQXpCLEVBQWtDQSxPQUFPLEdBQUcxQyxHQUE1QyxDQUFQOztBQUNKLGFBQUssSUFBTDtBQUFXO0FBQ1AsaUJBQU8sS0FBS1gsR0FBTCxHQUFXLE1BQU0sS0FBS0EsR0FBTCxDQUFTakQsTUFBZixHQUF3QixRQUFuQyxHQUNILEtBQUsrRixNQUFMLENBQVlWLGNBQVosQ0FBMkJpQixPQUEzQixFQUFvQ0EsT0FBTyxHQUFHMUMsR0FBOUMsRUFBbUQwQixTQUFuRCxDQURKOztBQUVKLGFBQUssSUFBTDtBQUFXO0FBQ1AsaUJBQU8sS0FBS3JDLEdBQUwsR0FBVyxNQUFNLEtBQUtBLEdBQUwsQ0FBU2pELE1BQWYsR0FBd0IsUUFBbkMsR0FDSCxLQUFLK0YsTUFBTCxDQUFZSCxnQkFBWixDQUE2QlUsT0FBN0IsRUFBc0NBLE9BQU8sR0FBRzFDLEdBQWhELEVBQXFEMEIsU0FBckQsQ0FESjtBQUVKOztBQUNBLGFBQUssSUFBTDtBQUFXO0FBQ1AsaUJBQU8sS0FBS1MsTUFBTCxDQUFZRixRQUFaLENBQXFCUyxPQUFyQixFQUE4QkEsT0FBTyxHQUFHMUMsR0FBeEMsRUFBNkMwQixTQUE3QyxDQUFQO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxhQUFLLElBQUwsQ0FuQkosQ0FtQmU7O0FBQ1gsYUFBSyxJQUFMO0FBQVc7QUFDUCxjQUFJLEtBQUtyQyxHQUFMLEtBQWEsSUFBakIsRUFBdUI7QUFDbkIsbUJBQU8sTUFBTSxLQUFLQSxHQUFMLENBQVNqRCxNQUFmLEdBQXdCLFFBQS9CO0FBQ0gsV0FGRCxNQUdLO0FBQ0QsbUJBQU8sV0FBUDtBQUNIOztBQUNMLGFBQUssSUFBTDtBQUFXO0FBQ1AsaUJBQU8wRCxTQUFTLENBQUMsS0FBS3FDLE1BQUwsQ0FBWW5CLGNBQVosQ0FBMkIwQixPQUEzQixFQUFvQ0EsT0FBTyxHQUFHMUMsR0FBOUMsQ0FBRCxFQUFxRDBCLFNBQXJELENBQWhCOztBQUNKLGFBQUssSUFBTCxDQTdCSixDQTZCZTs7QUFDWCxhQUFLLElBQUwsQ0E5QkosQ0E4QmU7O0FBQ1gsYUFBSyxJQUFMLENBL0JKLENBK0JlOztBQUNYLGFBQUssSUFBTCxDQWhDSixDQWdDZTs7QUFDWCxhQUFLLElBQUwsQ0FqQ0osQ0FpQ2U7QUFDWDs7QUFDQSxhQUFLLElBQUw7QUFBVztBQUNQO0FBQ0E7QUFDQSxpQkFBTzVCLFNBQVMsQ0FBQyxLQUFLcUMsTUFBTCxDQUFZdEIsY0FBWixDQUEyQjZCLE9BQTNCLEVBQW9DQSxPQUFPLEdBQUcxQyxHQUE5QyxDQUFELEVBQXFEMEIsU0FBckQsQ0FBaEI7O0FBQ0osYUFBSyxJQUFMO0FBQVc7QUFDUCxpQkFBTzVCLFNBQVMsQ0FBQyxLQUFLcUMsTUFBTCxDQUFZbEIsY0FBWixDQUEyQnlCLE9BQTNCLEVBQW9DQSxPQUFPLEdBQUcxQyxHQUE5QyxDQUFELEVBQXFEMEIsU0FBckQsQ0FBaEI7O0FBQ0osYUFBSyxJQUFMLENBekNKLENBeUNlOztBQUNYLGFBQUssSUFBTDtBQUFXO0FBQ1AsaUJBQU8sS0FBS1MsTUFBTCxDQUFZZixTQUFaLENBQXNCc0IsT0FBdEIsRUFBK0JBLE9BQU8sR0FBRzFDLEdBQXpDLEVBQStDLEtBQUtxQyxHQUFMLENBQVNJLFNBQVQsSUFBc0IsSUFBckUsQ0FBUDtBQTNDUjs7QUE2Q0EsYUFBTyxJQUFQO0FBQ0gsS0E3REQ7O0FBOERBUCxJQUFBQSxJQUFJLENBQUN6RSxTQUFMLENBQWU4QixRQUFmLEdBQTBCLFlBQVk7QUFDbEMsYUFBTyxLQUFLZ0QsUUFBTCxLQUFrQixHQUFsQixHQUF3QixLQUFLSixNQUFMLENBQVloQyxHQUFwQyxHQUEwQyxVQUExQyxHQUF1RCxLQUFLaUMsTUFBNUQsR0FBcUUsVUFBckUsR0FBa0YsS0FBS2hHLE1BQXZGLEdBQWdHLE9BQWhHLElBQTRHLEtBQUtpRCxHQUFMLEtBQWEsSUFBZCxHQUFzQixNQUF0QixHQUErQixLQUFLQSxHQUFMLENBQVNqRCxNQUFuSixJQUE2SixHQUFwSztBQUNILEtBRkQ7O0FBR0E4RixJQUFBQSxJQUFJLENBQUN6RSxTQUFMLENBQWV1RixjQUFmLEdBQWdDLFVBQVVDLE1BQVYsRUFBa0I7QUFDOUMsVUFBSUEsTUFBTSxLQUFLbEYsU0FBZixFQUEwQjtBQUN0QmtGLFFBQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0g7O0FBQ0QsVUFBSXpHLENBQUMsR0FBR3lHLE1BQU0sR0FBRyxLQUFLVixRQUFMLEVBQVQsR0FBMkIsSUFBM0IsR0FBa0MsS0FBS0osTUFBTCxDQUFZaEMsR0FBdEQ7O0FBQ0EsVUFBSSxLQUFLL0QsTUFBTCxJQUFlLENBQW5CLEVBQXNCO0FBQ2xCSSxRQUFBQSxDQUFDLElBQUksR0FBTDtBQUNIOztBQUNEQSxNQUFBQSxDQUFDLElBQUksS0FBS0osTUFBVjs7QUFDQSxVQUFJLEtBQUtpRyxHQUFMLENBQVNhLGNBQWIsRUFBNkI7QUFDekIxRyxRQUFBQSxDQUFDLElBQUksZ0JBQUw7QUFDSCxPQUZELE1BR0ssSUFBSyxLQUFLNkYsR0FBTCxDQUFTVSxXQUFULE9BQTRCLEtBQUtWLEdBQUwsQ0FBU0ksU0FBVCxJQUFzQixJQUF2QixJQUFpQyxLQUFLSixHQUFMLENBQVNJLFNBQVQsSUFBc0IsSUFBbEYsQ0FBRCxJQUErRixLQUFLcEQsR0FBTCxLQUFhLElBQWhILEVBQXVIO0FBQ3hIN0MsUUFBQUEsQ0FBQyxJQUFJLGlCQUFMO0FBQ0g7O0FBQ0RBLE1BQUFBLENBQUMsSUFBSSxJQUFMOztBQUNBLFVBQUksS0FBSzZDLEdBQUwsS0FBYSxJQUFqQixFQUF1QjtBQUNuQjRELFFBQUFBLE1BQU0sSUFBSSxJQUFWOztBQUNBLGFBQUssSUFBSWhILENBQUMsR0FBRyxDQUFSLEVBQVc2QyxHQUFHLEdBQUcsS0FBS08sR0FBTCxDQUFTakQsTUFBL0IsRUFBdUNILENBQUMsR0FBRzZDLEdBQTNDLEVBQWdELEVBQUU3QyxDQUFsRCxFQUFxRDtBQUNqRE8sVUFBQUEsQ0FBQyxJQUFJLEtBQUs2QyxHQUFMLENBQVNwRCxDQUFULEVBQVkrRyxjQUFaLENBQTJCQyxNQUEzQixDQUFMO0FBQ0g7QUFDSjs7QUFDRCxhQUFPekcsQ0FBUDtBQUNILEtBdkJEOztBQXdCQTBGLElBQUFBLElBQUksQ0FBQ3pFLFNBQUwsQ0FBZTBGLFFBQWYsR0FBMEIsWUFBWTtBQUNsQyxhQUFPLEtBQUtoQixNQUFMLENBQVloQyxHQUFuQjtBQUNILEtBRkQ7O0FBR0ErQixJQUFBQSxJQUFJLENBQUN6RSxTQUFMLENBQWVtRixVQUFmLEdBQTRCLFlBQVk7QUFDcEMsYUFBTyxLQUFLVCxNQUFMLENBQVloQyxHQUFaLEdBQWtCLEtBQUtpQyxNQUE5QjtBQUNILEtBRkQ7O0FBR0FGLElBQUFBLElBQUksQ0FBQ3pFLFNBQUwsQ0FBZTJGLE1BQWYsR0FBd0IsWUFBWTtBQUNoQyxhQUFPLEtBQUtqQixNQUFMLENBQVloQyxHQUFaLEdBQWtCLEtBQUtpQyxNQUF2QixHQUFnQ1MsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBSzFHLE1BQWQsQ0FBdkM7QUFDSCxLQUZEOztBQUdBOEYsSUFBQUEsSUFBSSxDQUFDekUsU0FBTCxDQUFlNEYsV0FBZixHQUE2QixZQUFZO0FBQ3JDLGFBQU8sS0FBS2xCLE1BQUwsQ0FBWTNCLE9BQVosQ0FBb0IsS0FBSzJDLFFBQUwsRUFBcEIsRUFBcUMsS0FBS0MsTUFBTCxFQUFyQyxFQUFvRCxJQUFwRCxDQUFQO0FBQ0gsS0FGRDs7QUFHQWxCLElBQUFBLElBQUksQ0FBQ29CLFlBQUwsR0FBb0IsVUFBVW5CLE1BQVYsRUFBa0I7QUFDbEMsVUFBSWxELEdBQUcsR0FBR2tELE1BQU0sQ0FBQzlCLEdBQVAsRUFBVjtBQUNBLFVBQUlMLEdBQUcsR0FBR2YsR0FBRyxHQUFHLElBQWhCOztBQUNBLFVBQUllLEdBQUcsSUFBSWYsR0FBWCxFQUFnQjtBQUNaLGVBQU9lLEdBQVA7QUFDSCxPQUxpQyxDQU1sQzs7O0FBQ0EsVUFBSUEsR0FBRyxHQUFHLENBQVYsRUFBYTtBQUNULGNBQU0sSUFBSTFCLEtBQUosQ0FBVSxvREFBb0Q2RCxNQUFNLENBQUNoQyxHQUFQLEdBQWEsQ0FBakUsQ0FBVixDQUFOO0FBQ0g7O0FBQ0QsVUFBSUgsR0FBRyxLQUFLLENBQVosRUFBZTtBQUNYLGVBQU8sSUFBUDtBQUNILE9BWmlDLENBWWhDOzs7QUFDRmYsTUFBQUEsR0FBRyxHQUFHLENBQU47O0FBQ0EsV0FBSyxJQUFJaEQsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRytELEdBQXBCLEVBQXlCLEVBQUUvRCxDQUEzQixFQUE4QjtBQUMxQmdELFFBQUFBLEdBQUcsR0FBSUEsR0FBRyxHQUFHLEdBQVAsR0FBY2tELE1BQU0sQ0FBQzlCLEdBQVAsRUFBcEI7QUFDSDs7QUFDRCxhQUFPcEIsR0FBUDtBQUNILEtBbEJEO0FBbUJBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7OztBQUNJaUQsSUFBQUEsSUFBSSxDQUFDekUsU0FBTCxDQUFlOEYsaUJBQWYsR0FBbUMsWUFBWTtBQUMzQyxVQUFJQyxTQUFTLEdBQUcsS0FBS0gsV0FBTCxFQUFoQjtBQUNBLFVBQUlJLE1BQU0sR0FBRyxLQUFLckIsTUFBTCxHQUFjLENBQTNCO0FBQ0EsVUFBSWhHLE1BQU0sR0FBRyxLQUFLQSxNQUFMLEdBQWMsQ0FBM0I7QUFDQSxhQUFPb0gsU0FBUyxDQUFDRSxNQUFWLENBQWlCRCxNQUFqQixFQUF5QnJILE1BQXpCLENBQVA7QUFDSCxLQUxEOztBQU1BOEYsSUFBQUEsSUFBSSxDQUFDckUsTUFBTCxHQUFjLFVBQVVrQyxHQUFWLEVBQWU7QUFDekIsVUFBSW9DLE1BQUo7O0FBQ0EsVUFBSSxFQUFFcEMsR0FBRyxZQUFZRSxNQUFqQixDQUFKLEVBQThCO0FBQzFCa0MsUUFBQUEsTUFBTSxHQUFHLElBQUlsQyxNQUFKLENBQVdGLEdBQVgsRUFBZ0IsQ0FBaEIsQ0FBVDtBQUNILE9BRkQsTUFHSztBQUNEb0MsUUFBQUEsTUFBTSxHQUFHcEMsR0FBVDtBQUNIOztBQUNELFVBQUk0RCxXQUFXLEdBQUcsSUFBSTFELE1BQUosQ0FBV2tDLE1BQVgsQ0FBbEI7QUFDQSxVQUFJRSxHQUFHLEdBQUcsSUFBSUMsT0FBSixDQUFZSCxNQUFaLENBQVY7QUFDQSxVQUFJbkMsR0FBRyxHQUFHa0MsSUFBSSxDQUFDb0IsWUFBTCxDQUFrQm5CLE1BQWxCLENBQVY7QUFDQSxVQUFJMUIsS0FBSyxHQUFHMEIsTUFBTSxDQUFDaEMsR0FBbkI7QUFDQSxVQUFJaUMsTUFBTSxHQUFHM0IsS0FBSyxHQUFHa0QsV0FBVyxDQUFDeEQsR0FBakM7QUFDQSxVQUFJZCxHQUFHLEdBQUcsSUFBVjs7QUFDQSxVQUFJdUUsTUFBTSxHQUFHLFNBQVRBLE1BQVMsR0FBWTtBQUNyQixZQUFJekgsR0FBRyxHQUFHLEVBQVY7O0FBQ0EsWUFBSTZELEdBQUcsS0FBSyxJQUFaLEVBQWtCO0FBQ2Q7QUFDQSxjQUFJVSxHQUFHLEdBQUdELEtBQUssR0FBR1QsR0FBbEI7O0FBQ0EsaUJBQU9tQyxNQUFNLENBQUNoQyxHQUFQLEdBQWFPLEdBQXBCLEVBQXlCO0FBQ3JCdkUsWUFBQUEsR0FBRyxDQUFDQSxHQUFHLENBQUNDLE1BQUwsQ0FBSCxHQUFrQjhGLElBQUksQ0FBQ3JFLE1BQUwsQ0FBWXNFLE1BQVosQ0FBbEI7QUFDSDs7QUFDRCxjQUFJQSxNQUFNLENBQUNoQyxHQUFQLElBQWNPLEdBQWxCLEVBQXVCO0FBQ25CLGtCQUFNLElBQUlwQyxLQUFKLENBQVUsa0VBQWtFbUMsS0FBNUUsQ0FBTjtBQUNIO0FBQ0osU0FURCxNQVVLO0FBQ0Q7QUFDQSxjQUFJO0FBQ0EscUJBQVM7QUFDTCxrQkFBSWpFLENBQUMsR0FBRzBGLElBQUksQ0FBQ3JFLE1BQUwsQ0FBWXNFLE1BQVosQ0FBUjs7QUFDQSxrQkFBSTNGLENBQUMsQ0FBQzZGLEdBQUYsQ0FBTXdCLEtBQU4sRUFBSixFQUFtQjtBQUNmO0FBQ0g7O0FBQ0QxSCxjQUFBQSxHQUFHLENBQUNBLEdBQUcsQ0FBQ0MsTUFBTCxDQUFILEdBQWtCSSxDQUFsQjtBQUNIOztBQUNEd0QsWUFBQUEsR0FBRyxHQUFHUyxLQUFLLEdBQUcwQixNQUFNLENBQUNoQyxHQUFyQixDQVJBLENBUTBCO0FBQzdCLFdBVEQsQ0FVQSxPQUFPMkQsQ0FBUCxFQUFVO0FBQ04sa0JBQU0sSUFBSXhGLEtBQUosQ0FBVSx3REFBd0R3RixDQUFsRSxDQUFOO0FBQ0g7QUFDSjs7QUFDRCxlQUFPM0gsR0FBUDtBQUNILE9BN0JEOztBQThCQSxVQUFJa0csR0FBRyxDQUFDYSxjQUFSLEVBQXdCO0FBQ3BCO0FBQ0E3RCxRQUFBQSxHQUFHLEdBQUd1RSxNQUFNLEVBQVo7QUFDSCxPQUhELE1BSUssSUFBSXZCLEdBQUcsQ0FBQ1UsV0FBSixPQUF1QlYsR0FBRyxDQUFDSSxTQUFKLElBQWlCLElBQWxCLElBQTRCSixHQUFHLENBQUNJLFNBQUosSUFBaUIsSUFBbkUsQ0FBSixFQUErRTtBQUNoRjtBQUNBLFlBQUk7QUFDQSxjQUFJSixHQUFHLENBQUNJLFNBQUosSUFBaUIsSUFBckIsRUFBMkI7QUFDdkIsZ0JBQUlOLE1BQU0sQ0FBQzlCLEdBQVAsTUFBZ0IsQ0FBcEIsRUFBdUI7QUFDbkIsb0JBQU0sSUFBSS9CLEtBQUosQ0FBVSxrREFBVixDQUFOO0FBQ0g7QUFDSjs7QUFDRGUsVUFBQUEsR0FBRyxHQUFHdUUsTUFBTSxFQUFaOztBQUNBLGVBQUssSUFBSTNILENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdvRCxHQUFHLENBQUNqRCxNQUF4QixFQUFnQyxFQUFFSCxDQUFsQyxFQUFxQztBQUNqQyxnQkFBSW9ELEdBQUcsQ0FBQ3BELENBQUQsQ0FBSCxDQUFPb0csR0FBUCxDQUFXd0IsS0FBWCxFQUFKLEVBQXdCO0FBQ3BCLG9CQUFNLElBQUl2RixLQUFKLENBQVUsMkNBQVYsQ0FBTjtBQUNIO0FBQ0o7QUFDSixTQVpELENBYUEsT0FBT3dGLENBQVAsRUFBVTtBQUNOO0FBQ0F6RSxVQUFBQSxHQUFHLEdBQUcsSUFBTjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSUEsR0FBRyxLQUFLLElBQVosRUFBa0I7QUFDZCxZQUFJVyxHQUFHLEtBQUssSUFBWixFQUFrQjtBQUNkLGdCQUFNLElBQUkxQixLQUFKLENBQVUsdUVBQXVFbUMsS0FBakYsQ0FBTjtBQUNIOztBQUNEMEIsUUFBQUEsTUFBTSxDQUFDaEMsR0FBUCxHQUFhTSxLQUFLLEdBQUdvQyxJQUFJLENBQUNDLEdBQUwsQ0FBUzlDLEdBQVQsQ0FBckI7QUFDSDs7QUFDRCxhQUFPLElBQUlrQyxJQUFKLENBQVN5QixXQUFULEVBQXNCdkIsTUFBdEIsRUFBOEJwQyxHQUE5QixFQUFtQ3FDLEdBQW5DLEVBQXdDaEQsR0FBeEMsQ0FBUDtBQUNILEtBM0VEOztBQTRFQSxXQUFPNkMsSUFBUDtBQUNILEdBL1J5QixFQUExQjs7QUFnU0EsTUFBSUksT0FBTztBQUFHO0FBQWUsY0FBWTtBQUNyQyxhQUFTQSxPQUFULENBQWlCSCxNQUFqQixFQUF5QjtBQUNyQixVQUFJbEQsR0FBRyxHQUFHa0QsTUFBTSxDQUFDOUIsR0FBUCxFQUFWO0FBQ0EsV0FBS21DLFFBQUwsR0FBZ0J2RCxHQUFHLElBQUksQ0FBdkI7QUFDQSxXQUFLaUUsY0FBTCxHQUF1QixDQUFDakUsR0FBRyxHQUFHLElBQVAsTUFBaUIsQ0FBeEM7QUFDQSxXQUFLd0QsU0FBTCxHQUFpQnhELEdBQUcsR0FBRyxJQUF2Qjs7QUFDQSxVQUFJLEtBQUt3RCxTQUFMLElBQWtCLElBQXRCLEVBQTRCO0FBQUU7QUFDMUIsWUFBSXZILENBQUMsR0FBRyxJQUFJNkQsS0FBSixFQUFSOztBQUNBLFdBQUc7QUFDQ0UsVUFBQUEsR0FBRyxHQUFHa0QsTUFBTSxDQUFDOUIsR0FBUCxFQUFOO0FBQ0FuRixVQUFBQSxDQUFDLENBQUNnRSxNQUFGLENBQVMsR0FBVCxFQUFjRCxHQUFHLEdBQUcsSUFBcEI7QUFDSCxTQUhELFFBR1NBLEdBQUcsR0FBRyxJQUhmOztBQUlBLGFBQUt3RCxTQUFMLEdBQWlCdkgsQ0FBQyxDQUFDd0UsUUFBRixFQUFqQjtBQUNIO0FBQ0o7O0FBQ0Q0QyxJQUFBQSxPQUFPLENBQUM3RSxTQUFSLENBQWtCc0YsV0FBbEIsR0FBZ0MsWUFBWTtBQUN4QyxhQUFPLEtBQUtQLFFBQUwsS0FBa0IsSUFBekI7QUFDSCxLQUZEOztBQUdBRixJQUFBQSxPQUFPLENBQUM3RSxTQUFSLENBQWtCb0csS0FBbEIsR0FBMEIsWUFBWTtBQUNsQyxhQUFPLEtBQUtyQixRQUFMLEtBQWtCLElBQWxCLElBQTBCLEtBQUtDLFNBQUwsS0FBbUIsSUFBcEQ7QUFDSCxLQUZEOztBQUdBLFdBQU9ILE9BQVA7QUFDSCxHQXRCNEIsRUFBN0IsQ0F0NUI0QixDQTg2QjVCO0FBQ0E7OztBQUNBLE1BQUl5QixLQUFKLENBaDdCNEIsQ0FpN0I1Qjs7QUFDQSxNQUFJQyxNQUFNLEdBQUcsY0FBYjtBQUNBLE1BQUlDLElBQUksR0FBSSxDQUFDRCxNQUFNLEdBQUcsUUFBVixLQUF1QixRQUFuQyxDQW43QjRCLENBbzdCNUI7O0FBQ0EsTUFBSUUsU0FBUyxHQUFHLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLEVBQWIsRUFBaUIsRUFBakIsRUFBcUIsRUFBckIsRUFBeUIsRUFBekIsRUFBNkIsRUFBN0IsRUFBaUMsRUFBakMsRUFBcUMsRUFBckMsRUFBeUMsRUFBekMsRUFBNkMsRUFBN0MsRUFBaUQsRUFBakQsRUFBcUQsRUFBckQsRUFBeUQsRUFBekQsRUFBNkQsRUFBN0QsRUFBaUUsRUFBakUsRUFBcUUsRUFBckUsRUFBeUUsRUFBekUsRUFBNkUsRUFBN0UsRUFBaUYsRUFBakYsRUFBcUYsRUFBckYsRUFBeUYsRUFBekYsRUFBNkYsRUFBN0YsRUFBaUcsR0FBakcsRUFBc0csR0FBdEcsRUFBMkcsR0FBM0csRUFBZ0gsR0FBaEgsRUFBcUgsR0FBckgsRUFBMEgsR0FBMUgsRUFBK0gsR0FBL0gsRUFBb0ksR0FBcEksRUFBeUksR0FBekksRUFBOEksR0FBOUksRUFBbUosR0FBbkosRUFBd0osR0FBeEosRUFBNkosR0FBN0osRUFBa0ssR0FBbEssRUFBdUssR0FBdkssRUFBNEssR0FBNUssRUFBaUwsR0FBakwsRUFBc0wsR0FBdEwsRUFBMkwsR0FBM0wsRUFBZ00sR0FBaE0sRUFBcU0sR0FBck0sRUFBME0sR0FBMU0sRUFBK00sR0FBL00sRUFBb04sR0FBcE4sRUFBeU4sR0FBek4sRUFBOE4sR0FBOU4sRUFBbU8sR0FBbk8sRUFBd08sR0FBeE8sRUFBNk8sR0FBN08sRUFBa1AsR0FBbFAsRUFBdVAsR0FBdlAsRUFBNFAsR0FBNVAsRUFBaVEsR0FBalEsRUFBc1EsR0FBdFEsRUFBMlEsR0FBM1EsRUFBZ1IsR0FBaFIsRUFBcVIsR0FBclIsRUFBMFIsR0FBMVIsRUFBK1IsR0FBL1IsRUFBb1MsR0FBcFMsRUFBeVMsR0FBelMsRUFBOFMsR0FBOVMsRUFBbVQsR0FBblQsRUFBd1QsR0FBeFQsRUFBNlQsR0FBN1QsRUFBa1UsR0FBbFUsRUFBdVUsR0FBdlUsRUFBNFUsR0FBNVUsRUFBaVYsR0FBalYsRUFBc1YsR0FBdFYsRUFBMlYsR0FBM1YsRUFBZ1csR0FBaFcsRUFBcVcsR0FBclcsRUFBMFcsR0FBMVcsRUFBK1csR0FBL1csRUFBb1gsR0FBcFgsRUFBeVgsR0FBelgsRUFBOFgsR0FBOVgsRUFBbVksR0FBblksRUFBd1ksR0FBeFksRUFBNlksR0FBN1ksRUFBa1osR0FBbFosRUFBdVosR0FBdlosRUFBNFosR0FBNVosRUFBaWEsR0FBamEsRUFBc2EsR0FBdGEsRUFBMmEsR0FBM2EsRUFBZ2IsR0FBaGIsRUFBcWIsR0FBcmIsRUFBMGIsR0FBMWIsRUFBK2IsR0FBL2IsRUFBb2MsR0FBcGMsRUFBeWMsR0FBemMsRUFBOGMsR0FBOWMsRUFBbWQsR0FBbmQsRUFBd2QsR0FBeGQsRUFBNmQsR0FBN2QsRUFBa2UsR0FBbGUsRUFBdWUsR0FBdmUsRUFBNGUsR0FBNWUsRUFBaWYsR0FBamYsRUFBc2YsR0FBdGYsRUFBMmYsR0FBM2YsRUFBZ2dCLEdBQWhnQixFQUFxZ0IsR0FBcmdCLEVBQTBnQixHQUExZ0IsRUFBK2dCLEdBQS9nQixFQUFvaEIsR0FBcGhCLEVBQXloQixHQUF6aEIsRUFBOGhCLEdBQTloQixFQUFtaUIsR0FBbmlCLEVBQXdpQixHQUF4aUIsRUFBNmlCLEdBQTdpQixFQUFrakIsR0FBbGpCLEVBQXVqQixHQUF2akIsRUFBNGpCLEdBQTVqQixFQUFpa0IsR0FBamtCLEVBQXNrQixHQUF0a0IsRUFBMmtCLEdBQTNrQixFQUFnbEIsR0FBaGxCLEVBQXFsQixHQUFybEIsRUFBMGxCLEdBQTFsQixFQUErbEIsR0FBL2xCLEVBQW9tQixHQUFwbUIsRUFBeW1CLEdBQXptQixFQUE4bUIsR0FBOW1CLEVBQW1uQixHQUFubkIsRUFBd25CLEdBQXhuQixFQUE2bkIsR0FBN25CLEVBQWtvQixHQUFsb0IsRUFBdW9CLEdBQXZvQixFQUE0b0IsR0FBNW9CLEVBQWlwQixHQUFqcEIsRUFBc3BCLEdBQXRwQixFQUEycEIsR0FBM3BCLEVBQWdxQixHQUFocUIsRUFBcXFCLEdBQXJxQixFQUEwcUIsR0FBMXFCLEVBQStxQixHQUEvcUIsRUFBb3JCLEdBQXByQixFQUF5ckIsR0FBenJCLEVBQThyQixHQUE5ckIsRUFBbXNCLEdBQW5zQixFQUF3c0IsR0FBeHNCLEVBQTZzQixHQUE3c0IsRUFBa3RCLEdBQWx0QixFQUF1dEIsR0FBdnRCLEVBQTR0QixHQUE1dEIsRUFBaXVCLEdBQWp1QixFQUFzdUIsR0FBdHVCLEVBQTJ1QixHQUEzdUIsRUFBZ3ZCLEdBQWh2QixFQUFxdkIsR0FBcnZCLEVBQTB2QixHQUExdkIsRUFBK3ZCLEdBQS92QixFQUFvd0IsR0FBcHdCLEVBQXl3QixHQUF6d0IsRUFBOHdCLEdBQTl3QixFQUFteEIsR0FBbnhCLEVBQXd4QixHQUF4eEIsRUFBNnhCLEdBQTd4QixFQUFreUIsR0FBbHlCLEVBQXV5QixHQUF2eUIsQ0FBaEI7QUFDQSxNQUFJQyxLQUFLLEdBQUcsQ0FBQyxLQUFLLEVBQU4sSUFBWUQsU0FBUyxDQUFDQSxTQUFTLENBQUM5SCxNQUFWLEdBQW1CLENBQXBCLENBQWpDLENBdDdCNEIsQ0F1N0I1QjtBQUNBOztBQUNBLE1BQUlnSSxVQUFVO0FBQUc7QUFBZSxjQUFZO0FBQ3hDLGFBQVNBLFVBQVQsQ0FBb0J0RyxDQUFwQixFQUF1QmYsQ0FBdkIsRUFBMEJiLENBQTFCLEVBQTZCO0FBQ3pCLFVBQUk0QixDQUFDLElBQUksSUFBVCxFQUFlO0FBQ1gsWUFBSSxZQUFZLE9BQU9BLENBQXZCLEVBQTBCO0FBQ3RCLGVBQUt1RyxVQUFMLENBQWdCdkcsQ0FBaEIsRUFBbUJmLENBQW5CLEVBQXNCYixDQUF0QjtBQUNILFNBRkQsTUFHSyxJQUFJYSxDQUFDLElBQUksSUFBTCxJQUFhLFlBQVksT0FBT2UsQ0FBcEMsRUFBdUM7QUFDeEMsZUFBS3dHLFVBQUwsQ0FBZ0J4RyxDQUFoQixFQUFtQixHQUFuQjtBQUNILFNBRkksTUFHQTtBQUNELGVBQUt3RyxVQUFMLENBQWdCeEcsQ0FBaEIsRUFBbUJmLENBQW5CO0FBQ0g7QUFDSjtBQUNKLEtBYnVDLENBY3hDO0FBQ0E7QUFDQTs7O0FBQ0FxSCxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCOEIsUUFBckIsR0FBZ0MsVUFBVXhDLENBQVYsRUFBYTtBQUN6QyxVQUFJLEtBQUtQLENBQUwsR0FBUyxDQUFiLEVBQWdCO0FBQ1osZUFBTyxNQUFNLEtBQUsrSCxNQUFMLEdBQWNoRixRQUFkLENBQXVCeEMsQ0FBdkIsQ0FBYjtBQUNIOztBQUNELFVBQUlOLENBQUo7O0FBQ0EsVUFBSU0sQ0FBQyxJQUFJLEVBQVQsRUFBYTtBQUNUTixRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILE9BRkQsTUFHSyxJQUFJTSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ2JOLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FGSSxNQUdBLElBQUlNLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDYk4sUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUZJLE1BR0EsSUFBSU0sQ0FBQyxJQUFJLEVBQVQsRUFBYTtBQUNkTixRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILE9BRkksTUFHQSxJQUFJTSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ2JOLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FGSSxNQUdBO0FBQ0QsZUFBTyxLQUFLK0gsT0FBTCxDQUFhekgsQ0FBYixDQUFQO0FBQ0g7O0FBQ0QsVUFBSTBILEVBQUUsR0FBRyxDQUFDLEtBQUtoSSxDQUFOLElBQVcsQ0FBcEI7QUFDQSxVQUFJSyxDQUFKO0FBQ0EsVUFBSThCLENBQUMsR0FBRyxLQUFSO0FBQ0EsVUFBSWpELENBQUMsR0FBRyxFQUFSO0FBQ0EsVUFBSU0sQ0FBQyxHQUFHLEtBQUttRCxDQUFiO0FBQ0EsVUFBSWhDLENBQUMsR0FBRyxLQUFLc0gsRUFBTCxHQUFXekksQ0FBQyxHQUFHLEtBQUt5SSxFQUFWLEdBQWdCakksQ0FBbEM7O0FBQ0EsVUFBSVIsQ0FBQyxLQUFLLENBQVYsRUFBYTtBQUNULFlBQUltQixDQUFDLEdBQUcsS0FBS3NILEVBQVQsSUFBZSxDQUFDNUgsQ0FBQyxHQUFHLEtBQUtiLENBQUwsS0FBV21CLENBQWhCLElBQXFCLENBQXhDLEVBQTJDO0FBQ3ZDd0IsVUFBQUEsQ0FBQyxHQUFHLElBQUo7QUFDQWpELFVBQUFBLENBQUMsR0FBR1YsUUFBUSxDQUFDNkIsQ0FBRCxDQUFaO0FBQ0g7O0FBQ0QsZUFBT2IsQ0FBQyxJQUFJLENBQVosRUFBZTtBQUNYLGNBQUltQixDQUFDLEdBQUdYLENBQVIsRUFBVztBQUNQSyxZQUFBQSxDQUFDLEdBQUcsQ0FBQyxLQUFLYixDQUFMLElBQVcsQ0FBQyxLQUFLbUIsQ0FBTixJQUFXLENBQXZCLEtBQStCWCxDQUFDLEdBQUdXLENBQXZDO0FBQ0FOLFlBQUFBLENBQUMsSUFBSSxLQUFLLEVBQUViLENBQVAsTUFBY21CLENBQUMsSUFBSSxLQUFLc0gsRUFBTCxHQUFVakksQ0FBN0IsQ0FBTDtBQUNILFdBSEQsTUFJSztBQUNESyxZQUFBQSxDQUFDLEdBQUksS0FBS2IsQ0FBTCxNQUFZbUIsQ0FBQyxJQUFJWCxDQUFqQixDQUFELEdBQXdCZ0ksRUFBNUI7O0FBQ0EsZ0JBQUlySCxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ1JBLGNBQUFBLENBQUMsSUFBSSxLQUFLc0gsRUFBVjtBQUNBLGdCQUFFekksQ0FBRjtBQUNIO0FBQ0o7O0FBQ0QsY0FBSWEsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQOEIsWUFBQUEsQ0FBQyxHQUFHLElBQUo7QUFDSDs7QUFDRCxjQUFJQSxDQUFKLEVBQU87QUFDSGpELFlBQUFBLENBQUMsSUFBSVYsUUFBUSxDQUFDNkIsQ0FBRCxDQUFiO0FBQ0g7QUFDSjtBQUNKOztBQUNELGFBQU84QixDQUFDLEdBQUdqRCxDQUFILEdBQU8sR0FBZjtBQUNILEtBdkRELENBakJ3QyxDQXlFeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCOEcsTUFBckIsR0FBOEIsWUFBWTtBQUN0QyxVQUFJNUksQ0FBQyxHQUFHZ0osR0FBRyxFQUFYO0FBQ0FQLE1BQUFBLFVBQVUsQ0FBQ1EsSUFBWCxDQUFnQkMsS0FBaEIsQ0FBc0IsSUFBdEIsRUFBNEJsSixDQUE1QjtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBM0V3QyxDQWdGeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCcUYsR0FBckIsR0FBMkIsWUFBWTtBQUNuQyxhQUFRLEtBQUt0RyxDQUFMLEdBQVMsQ0FBVixHQUFlLEtBQUsrSCxNQUFMLEVBQWYsR0FBK0IsSUFBdEM7QUFDSCxLQUZELENBbEZ3QyxDQXFGeEM7QUFDQTs7O0FBQ0FILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJxSCxTQUFyQixHQUFpQyxVQUFVaEgsQ0FBVixFQUFhO0FBQzFDLFVBQUluQyxDQUFDLEdBQUcsS0FBS2EsQ0FBTCxHQUFTc0IsQ0FBQyxDQUFDdEIsQ0FBbkI7O0FBQ0EsVUFBSWIsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNSLGVBQU9BLENBQVA7QUFDSDs7QUFDRCxVQUFJTSxDQUFDLEdBQUcsS0FBS21ELENBQWI7QUFDQXpELE1BQUFBLENBQUMsR0FBR00sQ0FBQyxHQUFHNkIsQ0FBQyxDQUFDc0IsQ0FBVjs7QUFDQSxVQUFJekQsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNSLGVBQVEsS0FBS2EsQ0FBTCxHQUFTLENBQVYsR0FBZSxDQUFDYixDQUFoQixHQUFvQkEsQ0FBM0I7QUFDSDs7QUFDRCxhQUFPLEVBQUVNLENBQUYsSUFBTyxDQUFkLEVBQWlCO0FBQ2IsWUFBSSxDQUFDTixDQUFDLEdBQUcsS0FBS00sQ0FBTCxJQUFVNkIsQ0FBQyxDQUFDN0IsQ0FBRCxDQUFoQixLQUF3QixDQUE1QixFQUErQjtBQUMzQixpQkFBT04sQ0FBUDtBQUNIO0FBQ0o7O0FBQ0QsYUFBTyxDQUFQO0FBQ0gsS0FoQkQsQ0F2RndDLENBd0d4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJzSCxTQUFyQixHQUFpQyxZQUFZO0FBQ3pDLFVBQUksS0FBSzNGLENBQUwsSUFBVSxDQUFkLEVBQWlCO0FBQ2IsZUFBTyxDQUFQO0FBQ0g7O0FBQ0QsYUFBTyxLQUFLc0YsRUFBTCxJQUFXLEtBQUt0RixDQUFMLEdBQVMsQ0FBcEIsSUFBeUI0RixLQUFLLENBQUMsS0FBSyxLQUFLNUYsQ0FBTCxHQUFTLENBQWQsSUFBb0IsS0FBSzVDLENBQUwsR0FBUyxLQUFLeUksRUFBbkMsQ0FBckM7QUFDSCxLQUxELENBMUd3QyxDQWdIeEM7QUFDQTs7O0FBQ0FiLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ5SCxHQUFyQixHQUEyQixVQUFVcEgsQ0FBVixFQUFhO0FBQ3BDLFVBQUluQyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLN0IsR0FBTCxHQUFXcUMsUUFBWCxDQUFvQnJILENBQXBCLEVBQXVCLElBQXZCLEVBQTZCbkMsQ0FBN0I7O0FBQ0EsVUFBSSxLQUFLYSxDQUFMLEdBQVMsQ0FBVCxJQUFjYixDQUFDLENBQUNtSixTQUFGLENBQVlWLFVBQVUsQ0FBQ1EsSUFBdkIsSUFBK0IsQ0FBakQsRUFBb0Q7QUFDaEQ5RyxRQUFBQSxDQUFDLENBQUMrRyxLQUFGLENBQVFsSixDQUFSLEVBQVdBLENBQVg7QUFDSDs7QUFDRCxhQUFPQSxDQUFQO0FBQ0gsS0FQRCxDQWxId0MsQ0EwSHhDO0FBQ0E7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjJILFNBQXJCLEdBQWlDLFVBQVV0QixDQUFWLEVBQWFsRixDQUFiLEVBQWdCO0FBQzdDLFVBQUl5RyxDQUFKOztBQUNBLFVBQUl2QixDQUFDLEdBQUcsR0FBSixJQUFXbEYsQ0FBQyxDQUFDMEcsTUFBRixFQUFmLEVBQTJCO0FBQ3ZCRCxRQUFBQSxDQUFDLEdBQUcsSUFBSUUsT0FBSixDQUFZM0csQ0FBWixDQUFKO0FBQ0gsT0FGRCxNQUdLO0FBQ0R5RyxRQUFBQSxDQUFDLEdBQUcsSUFBSUcsVUFBSixDQUFlNUcsQ0FBZixDQUFKO0FBQ0g7O0FBQ0QsYUFBTyxLQUFLNkcsR0FBTCxDQUFTM0IsQ0FBVCxFQUFZdUIsQ0FBWixDQUFQO0FBQ0gsS0FURCxDQTVId0MsQ0FzSXhDO0FBQ0E7OztBQUNBakIsSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQmlJLEtBQXJCLEdBQTZCLFlBQVk7QUFDckMsVUFBSS9KLENBQUMsR0FBR2dKLEdBQUcsRUFBWDtBQUNBLFdBQUtnQixNQUFMLENBQVloSyxDQUFaO0FBQ0EsYUFBT0EsQ0FBUDtBQUNILEtBSkQsQ0F4SXdDLENBNkl4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJtSSxRQUFyQixHQUFnQyxZQUFZO0FBQ3hDLFVBQUksS0FBS3BKLENBQUwsR0FBUyxDQUFiLEVBQWdCO0FBQ1osWUFBSSxLQUFLNEMsQ0FBTCxJQUFVLENBQWQsRUFBaUI7QUFDYixpQkFBTyxLQUFLLENBQUwsSUFBVSxLQUFLeUcsRUFBdEI7QUFDSCxTQUZELE1BR0ssSUFBSSxLQUFLekcsQ0FBTCxJQUFVLENBQWQsRUFBaUI7QUFDbEIsaUJBQU8sQ0FBQyxDQUFSO0FBQ0g7QUFDSixPQVBELE1BUUssSUFBSSxLQUFLQSxDQUFMLElBQVUsQ0FBZCxFQUFpQjtBQUNsQixlQUFPLEtBQUssQ0FBTCxDQUFQO0FBQ0gsT0FGSSxNQUdBLElBQUksS0FBS0EsQ0FBTCxJQUFVLENBQWQsRUFBaUI7QUFDbEIsZUFBTyxDQUFQO0FBQ0gsT0FkdUMsQ0FleEM7OztBQUNBLGFBQVEsQ0FBQyxLQUFLLENBQUwsSUFBVyxDQUFDLEtBQU0sS0FBSyxLQUFLc0YsRUFBakIsSUFBd0IsQ0FBcEMsS0FBMkMsS0FBS0EsRUFBakQsR0FBdUQsS0FBSyxDQUFMLENBQTlEO0FBQ0gsS0FqQkQsQ0EvSXdDLENBaUt4QztBQUNBOzs7QUFDQU4sSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQnFJLFNBQXJCLEdBQWlDLFlBQVk7QUFDekMsYUFBUSxLQUFLMUcsQ0FBTCxJQUFVLENBQVgsR0FBZ0IsS0FBSzVDLENBQXJCLEdBQTBCLEtBQUssQ0FBTCxLQUFXLEVBQVosSUFBbUIsRUFBbkQ7QUFDSCxLQUZELENBbkt3QyxDQXNLeEM7QUFDQTs7O0FBQ0E0SCxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCc0ksVUFBckIsR0FBa0MsWUFBWTtBQUMxQyxhQUFRLEtBQUszRyxDQUFMLElBQVUsQ0FBWCxHQUFnQixLQUFLNUMsQ0FBckIsR0FBMEIsS0FBSyxDQUFMLEtBQVcsRUFBWixJQUFtQixFQUFuRDtBQUNILEtBRkQsQ0F4S3dDLENBMkt4QztBQUNBOzs7QUFDQTRILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ1SSxNQUFyQixHQUE4QixZQUFZO0FBQ3RDLFVBQUksS0FBS3hKLENBQUwsR0FBUyxDQUFiLEVBQWdCO0FBQ1osZUFBTyxDQUFDLENBQVI7QUFDSCxPQUZELE1BR0ssSUFBSSxLQUFLNEMsQ0FBTCxJQUFVLENBQVYsSUFBZ0IsS0FBS0EsQ0FBTCxJQUFVLENBQVYsSUFBZSxLQUFLLENBQUwsS0FBVyxDQUE5QyxFQUFrRDtBQUNuRCxlQUFPLENBQVA7QUFDSCxPQUZJLE1BR0E7QUFDRCxlQUFPLENBQVA7QUFDSDtBQUNKLEtBVkQsQ0E3S3dDLENBd0x4QztBQUNBOzs7QUFDQWdGLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ3SSxXQUFyQixHQUFtQyxZQUFZO0FBQzNDLFVBQUloSyxDQUFDLEdBQUcsS0FBS21ELENBQWI7QUFDQSxVQUFJekQsQ0FBQyxHQUFHLEVBQVI7QUFDQUEsTUFBQUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLEtBQUthLENBQVo7QUFDQSxVQUFJWSxDQUFDLEdBQUcsS0FBS3NILEVBQUwsR0FBV3pJLENBQUMsR0FBRyxLQUFLeUksRUFBVixHQUFnQixDQUFsQztBQUNBLFVBQUk1SCxDQUFKO0FBQ0EsVUFBSUwsQ0FBQyxHQUFHLENBQVI7O0FBQ0EsVUFBSVIsQ0FBQyxLQUFLLENBQVYsRUFBYTtBQUNULFlBQUltQixDQUFDLEdBQUcsS0FBS3NILEVBQVQsSUFBZSxDQUFDNUgsQ0FBQyxHQUFHLEtBQUtiLENBQUwsS0FBV21CLENBQWhCLEtBQXNCLENBQUMsS0FBS1osQ0FBTCxHQUFTLEtBQUt5SSxFQUFmLEtBQXNCN0gsQ0FBL0QsRUFBa0U7QUFDOUR6QixVQUFBQSxDQUFDLENBQUNjLENBQUMsRUFBRixDQUFELEdBQVNLLENBQUMsR0FBSSxLQUFLTixDQUFMLElBQVcsS0FBS2tJLEVBQUwsR0FBVXRILENBQW5DO0FBQ0g7O0FBQ0QsZUFBT25CLENBQUMsSUFBSSxDQUFaLEVBQWU7QUFDWCxjQUFJbUIsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQTixZQUFBQSxDQUFDLEdBQUcsQ0FBQyxLQUFLYixDQUFMLElBQVcsQ0FBQyxLQUFLbUIsQ0FBTixJQUFXLENBQXZCLEtBQStCLElBQUlBLENBQXZDO0FBQ0FOLFlBQUFBLENBQUMsSUFBSSxLQUFLLEVBQUViLENBQVAsTUFBY21CLENBQUMsSUFBSSxLQUFLc0gsRUFBTCxHQUFVLENBQTdCLENBQUw7QUFDSCxXQUhELE1BSUs7QUFDRDVILFlBQUFBLENBQUMsR0FBSSxLQUFLYixDQUFMLE1BQVltQixDQUFDLElBQUksQ0FBakIsQ0FBRCxHQUF3QixJQUE1Qjs7QUFDQSxnQkFBSUEsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNSQSxjQUFBQSxDQUFDLElBQUksS0FBS3NILEVBQVY7QUFDQSxnQkFBRXpJLENBQUY7QUFDSDtBQUNKOztBQUNELGNBQUksQ0FBQ2EsQ0FBQyxHQUFHLElBQUwsS0FBYyxDQUFsQixFQUFxQjtBQUNqQkEsWUFBQUEsQ0FBQyxJQUFJLENBQUMsR0FBTjtBQUNIOztBQUNELGNBQUlMLENBQUMsSUFBSSxDQUFMLElBQVUsQ0FBQyxLQUFLRCxDQUFMLEdBQVMsSUFBVixNQUFvQk0sQ0FBQyxHQUFHLElBQXhCLENBQWQsRUFBNkM7QUFDekMsY0FBRUwsQ0FBRjtBQUNIOztBQUNELGNBQUlBLENBQUMsR0FBRyxDQUFKLElBQVNLLENBQUMsSUFBSSxLQUFLTixDQUF2QixFQUEwQjtBQUN0QmIsWUFBQUEsQ0FBQyxDQUFDYyxDQUFDLEVBQUYsQ0FBRCxHQUFTSyxDQUFUO0FBQ0g7QUFDSjtBQUNKOztBQUNELGFBQU9uQixDQUFQO0FBQ0gsS0FuQ0QsQ0ExTHdDLENBOE54Qzs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCeUksTUFBckIsR0FBOEIsVUFBVXBJLENBQVYsRUFBYTtBQUN2QyxhQUFRLEtBQUtnSCxTQUFMLENBQWVoSCxDQUFmLEtBQXFCLENBQTdCO0FBQ0gsS0FGRCxDQS9Od0MsQ0FrT3hDOzs7QUFDQXNHLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIwSSxHQUFyQixHQUEyQixVQUFVckksQ0FBVixFQUFhO0FBQ3BDLGFBQVEsS0FBS2dILFNBQUwsQ0FBZWhILENBQWYsSUFBb0IsQ0FBckIsR0FBMEIsSUFBMUIsR0FBaUNBLENBQXhDO0FBQ0gsS0FGRCxDQW5Pd0MsQ0FzT3hDOzs7QUFDQXNHLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJxQixHQUFyQixHQUEyQixVQUFVaEIsQ0FBVixFQUFhO0FBQ3BDLGFBQVEsS0FBS2dILFNBQUwsQ0FBZWhILENBQWYsSUFBb0IsQ0FBckIsR0FBMEIsSUFBMUIsR0FBaUNBLENBQXhDO0FBQ0gsS0FGRCxDQXZPd0MsQ0EwT3hDOzs7QUFDQXNHLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIySSxHQUFyQixHQUEyQixVQUFVdEksQ0FBVixFQUFhO0FBQ3BDLFVBQUluQyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLMEIsU0FBTCxDQUFldkksQ0FBZixFQUFrQjFDLE1BQWxCLEVBQTBCTyxDQUExQjtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBM093QyxDQWdQeEM7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjZJLEVBQXJCLEdBQTBCLFVBQVV4SSxDQUFWLEVBQWE7QUFDbkMsVUFBSW5DLENBQUMsR0FBR2dKLEdBQUcsRUFBWDtBQUNBLFdBQUswQixTQUFMLENBQWV2SSxDQUFmLEVBQWtCdkMsS0FBbEIsRUFBeUJJLENBQXpCO0FBQ0EsYUFBT0EsQ0FBUDtBQUNILEtBSkQsQ0FqUHdDLENBc1B4Qzs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCOEksR0FBckIsR0FBMkIsVUFBVXpJLENBQVYsRUFBYTtBQUNwQyxVQUFJbkMsQ0FBQyxHQUFHZ0osR0FBRyxFQUFYO0FBQ0EsV0FBSzBCLFNBQUwsQ0FBZXZJLENBQWYsRUFBa0J0QyxNQUFsQixFQUEwQkcsQ0FBMUI7QUFDQSxhQUFPQSxDQUFQO0FBQ0gsS0FKRCxDQXZQd0MsQ0E0UHhDOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIrSSxNQUFyQixHQUE4QixVQUFVMUksQ0FBVixFQUFhO0FBQ3ZDLFVBQUluQyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLMEIsU0FBTCxDQUFldkksQ0FBZixFQUFrQnJDLFNBQWxCLEVBQTZCRSxDQUE3QjtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBN1B3QyxDQWtReEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCZ0osR0FBckIsR0FBMkIsWUFBWTtBQUNuQyxVQUFJOUssQ0FBQyxHQUFHZ0osR0FBRyxFQUFYOztBQUNBLFdBQUssSUFBSTFJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBS21ELENBQXpCLEVBQTRCLEVBQUVuRCxDQUE5QixFQUFpQztBQUM3Qk4sUUFBQUEsQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBTyxLQUFLZ0osRUFBTCxHQUFVLENBQUMsS0FBS2hKLENBQUwsQ0FBbEI7QUFDSDs7QUFDRE4sTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLEtBQUtBLENBQVg7QUFDQXpELE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFNLENBQUMsS0FBS0EsQ0FBWjtBQUNBLGFBQU9iLENBQVA7QUFDSCxLQVJELENBcFF3QyxDQTZReEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCaUosU0FBckIsR0FBaUMsVUFBVXhMLENBQVYsRUFBYTtBQUMxQyxVQUFJUyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7O0FBQ0EsVUFBSXpKLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxhQUFLeUwsUUFBTCxDQUFjLENBQUN6TCxDQUFmLEVBQWtCUyxDQUFsQjtBQUNILE9BRkQsTUFHSztBQUNELGFBQUtpTCxRQUFMLENBQWMxTCxDQUFkLEVBQWlCUyxDQUFqQjtBQUNIOztBQUNELGFBQU9BLENBQVA7QUFDSCxLQVRELENBL1F3QyxDQXlSeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCb0osVUFBckIsR0FBa0MsVUFBVTNMLENBQVYsRUFBYTtBQUMzQyxVQUFJUyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7O0FBQ0EsVUFBSXpKLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxhQUFLMEwsUUFBTCxDQUFjLENBQUMxTCxDQUFmLEVBQWtCUyxDQUFsQjtBQUNILE9BRkQsTUFHSztBQUNELGFBQUtnTCxRQUFMLENBQWN6TCxDQUFkLEVBQWlCUyxDQUFqQjtBQUNIOztBQUNELGFBQU9BLENBQVA7QUFDSCxLQVRELENBM1J3QyxDQXFTeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCcUosZUFBckIsR0FBdUMsWUFBWTtBQUMvQyxXQUFLLElBQUk3SyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEtBQUttRCxDQUF6QixFQUE0QixFQUFFbkQsQ0FBOUIsRUFBaUM7QUFDN0IsWUFBSSxLQUFLQSxDQUFMLEtBQVcsQ0FBZixFQUFrQjtBQUNkLGlCQUFPQSxDQUFDLEdBQUcsS0FBS3lJLEVBQVQsR0FBY2hKLElBQUksQ0FBQyxLQUFLTyxDQUFMLENBQUQsQ0FBekI7QUFDSDtBQUNKOztBQUNELFVBQUksS0FBS08sQ0FBTCxHQUFTLENBQWIsRUFBZ0I7QUFDWixlQUFPLEtBQUs0QyxDQUFMLEdBQVMsS0FBS3NGLEVBQXJCO0FBQ0g7O0FBQ0QsYUFBTyxDQUFDLENBQVI7QUFDSCxLQVZELENBdlN3QyxDQWtUeEM7QUFDQTs7O0FBQ0FOLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJzSixRQUFyQixHQUFnQyxZQUFZO0FBQ3hDLFVBQUlwTCxDQUFDLEdBQUcsQ0FBUjtBQUNBLFVBQUlOLENBQUMsR0FBRyxLQUFLbUIsQ0FBTCxHQUFTLEtBQUt5SSxFQUF0Qjs7QUFDQSxXQUFLLElBQUloSixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEtBQUttRCxDQUF6QixFQUE0QixFQUFFbkQsQ0FBOUIsRUFBaUM7QUFDN0JOLFFBQUFBLENBQUMsSUFBSUMsSUFBSSxDQUFDLEtBQUtLLENBQUwsSUFBVVosQ0FBWCxDQUFUO0FBQ0g7O0FBQ0QsYUFBT00sQ0FBUDtBQUNILEtBUEQsQ0FwVHdDLENBNFR4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ1SixPQUFyQixHQUErQixVQUFVOUwsQ0FBVixFQUFhO0FBQ3hDLFVBQUk2RyxDQUFDLEdBQUdjLElBQUksQ0FBQ29FLEtBQUwsQ0FBVy9MLENBQUMsR0FBRyxLQUFLd0osRUFBcEIsQ0FBUjs7QUFDQSxVQUFJM0MsQ0FBQyxJQUFJLEtBQUszQyxDQUFkLEVBQWlCO0FBQ2IsZUFBUSxLQUFLNUMsQ0FBTCxJQUFVLENBQWxCO0FBQ0g7O0FBQ0QsYUFBUSxDQUFDLEtBQUt1RixDQUFMLElBQVcsS0FBTTdHLENBQUMsR0FBRyxLQUFLd0osRUFBM0IsS0FBb0MsQ0FBNUM7QUFDSCxLQU5ELENBOVR3QyxDQXFVeEM7QUFDQTs7O0FBQ0FOLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ5SixNQUFyQixHQUE4QixVQUFVaE0sQ0FBVixFQUFhO0FBQ3ZDLGFBQU8sS0FBS2lNLFNBQUwsQ0FBZWpNLENBQWYsRUFBa0JLLEtBQWxCLENBQVA7QUFDSCxLQUZELENBdlV3QyxDQTBVeEM7QUFDQTs7O0FBQ0E2SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCMkosUUFBckIsR0FBZ0MsVUFBVWxNLENBQVYsRUFBYTtBQUN6QyxhQUFPLEtBQUtpTSxTQUFMLENBQWVqTSxDQUFmLEVBQWtCTyxTQUFsQixDQUFQO0FBQ0gsS0FGRCxDQTVVd0MsQ0ErVXhDO0FBQ0E7OztBQUNBMkksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjRKLE9BQXJCLEdBQStCLFVBQVVuTSxDQUFWLEVBQWE7QUFDeEMsYUFBTyxLQUFLaU0sU0FBTCxDQUFlak0sQ0FBZixFQUFrQk0sTUFBbEIsQ0FBUDtBQUNILEtBRkQsQ0FqVndDLENBb1Z4QztBQUNBOzs7QUFDQTRJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUI2SixHQUFyQixHQUEyQixVQUFVeEosQ0FBVixFQUFhO0FBQ3BDLFVBQUluQyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLNEMsS0FBTCxDQUFXekosQ0FBWCxFQUFjbkMsQ0FBZDtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBdFZ3QyxDQTJWeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCK0osUUFBckIsR0FBZ0MsVUFBVTFKLENBQVYsRUFBYTtBQUN6QyxVQUFJbkMsQ0FBQyxHQUFHZ0osR0FBRyxFQUFYO0FBQ0EsV0FBS0UsS0FBTCxDQUFXL0csQ0FBWCxFQUFjbkMsQ0FBZDtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBN1Z3QyxDQWtXeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCZ0ssUUFBckIsR0FBZ0MsVUFBVTNKLENBQVYsRUFBYTtBQUN6QyxVQUFJbkMsQ0FBQyxHQUFHZ0osR0FBRyxFQUFYO0FBQ0EsV0FBSytDLFVBQUwsQ0FBZ0I1SixDQUFoQixFQUFtQm5DLENBQW5CO0FBQ0EsYUFBT0EsQ0FBUDtBQUNILEtBSkQsQ0FwV3dDLENBeVd4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJrSyxNQUFyQixHQUE4QixVQUFVN0osQ0FBVixFQUFhO0FBQ3ZDLFVBQUluQyxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLUSxRQUFMLENBQWNySCxDQUFkLEVBQWlCbkMsQ0FBakIsRUFBb0IsSUFBcEI7QUFDQSxhQUFPQSxDQUFQO0FBQ0gsS0FKRCxDQTNXd0MsQ0FnWHhDO0FBQ0E7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQm1LLFNBQXJCLEdBQWlDLFVBQVU5SixDQUFWLEVBQWE7QUFDMUMsVUFBSW5DLENBQUMsR0FBR2dKLEdBQUcsRUFBWDtBQUNBLFdBQUtRLFFBQUwsQ0FBY3JILENBQWQsRUFBaUIsSUFBakIsRUFBdUJuQyxDQUF2QjtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBbFh3QyxDQXVYeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCb0ssa0JBQXJCLEdBQTBDLFVBQVUvSixDQUFWLEVBQWE7QUFDbkQsVUFBSWdLLENBQUMsR0FBR25ELEdBQUcsRUFBWDtBQUNBLFVBQUloSixDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLUSxRQUFMLENBQWNySCxDQUFkLEVBQWlCZ0ssQ0FBakIsRUFBb0JuTSxDQUFwQjtBQUNBLGFBQU8sQ0FBQ21NLENBQUQsRUFBSW5NLENBQUosQ0FBUDtBQUNILEtBTEQsQ0F6WHdDLENBK1h4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJzSyxNQUFyQixHQUE4QixVQUFVakUsQ0FBVixFQUFhbEYsQ0FBYixFQUFnQjtBQUMxQyxVQUFJM0MsQ0FBQyxHQUFHNkgsQ0FBQyxDQUFDaUIsU0FBRixFQUFSO0FBQ0EsVUFBSXRJLENBQUo7QUFDQSxVQUFJZCxDQUFDLEdBQUdxTSxHQUFHLENBQUMsQ0FBRCxDQUFYO0FBQ0EsVUFBSTNDLENBQUo7O0FBQ0EsVUFBSXBKLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDUixlQUFPTixDQUFQO0FBQ0gsT0FGRCxNQUdLLElBQUlNLENBQUMsR0FBRyxFQUFSLEVBQVk7QUFDYlEsUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUZJLE1BR0EsSUFBSVIsQ0FBQyxHQUFHLEVBQVIsRUFBWTtBQUNiUSxRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILE9BRkksTUFHQSxJQUFJUixDQUFDLEdBQUcsR0FBUixFQUFhO0FBQ2RRLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FGSSxNQUdBLElBQUlSLENBQUMsR0FBRyxHQUFSLEVBQWE7QUFDZFEsUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUZJLE1BR0E7QUFDREEsUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSDs7QUFDRCxVQUFJUixDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1BvSixRQUFBQSxDQUFDLEdBQUcsSUFBSUUsT0FBSixDQUFZM0csQ0FBWixDQUFKO0FBQ0gsT0FGRCxNQUdLLElBQUlBLENBQUMsQ0FBQzBHLE1BQUYsRUFBSixFQUFnQjtBQUNqQkQsUUFBQUEsQ0FBQyxHQUFHLElBQUk0QyxPQUFKLENBQVlySixDQUFaLENBQUo7QUFDSCxPQUZJLE1BR0E7QUFDRHlHLFFBQUFBLENBQUMsR0FBRyxJQUFJRyxVQUFKLENBQWU1RyxDQUFmLENBQUo7QUFDSCxPQS9CeUMsQ0FnQzFDOzs7QUFDQSxVQUFJc0osQ0FBQyxHQUFHLEVBQVI7QUFDQSxVQUFJaE4sQ0FBQyxHQUFHLENBQVI7QUFDQSxVQUFJaU4sRUFBRSxHQUFHMUwsQ0FBQyxHQUFHLENBQWI7QUFDQSxVQUFJZ0ksRUFBRSxHQUFHLENBQUMsS0FBS2hJLENBQU4sSUFBVyxDQUFwQjtBQUNBeUwsTUFBQUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPN0MsQ0FBQyxDQUFDK0MsT0FBRixDQUFVLElBQVYsQ0FBUDs7QUFDQSxVQUFJM0wsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQLFlBQUk0TCxFQUFFLEdBQUcxRCxHQUFHLEVBQVo7QUFDQVUsUUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRSixDQUFDLENBQUMsQ0FBRCxDQUFULEVBQWNHLEVBQWQ7O0FBQ0EsZUFBT25OLENBQUMsSUFBSXVKLEVBQVosRUFBZ0I7QUFDWnlELFVBQUFBLENBQUMsQ0FBQ2hOLENBQUQsQ0FBRCxHQUFPeUosR0FBRyxFQUFWO0FBQ0FVLFVBQUFBLENBQUMsQ0FBQ2tELEtBQUYsQ0FBUUYsRUFBUixFQUFZSCxDQUFDLENBQUNoTixDQUFDLEdBQUcsQ0FBTCxDQUFiLEVBQXNCZ04sQ0FBQyxDQUFDaE4sQ0FBRCxDQUF2QjtBQUNBQSxVQUFBQSxDQUFDLElBQUksQ0FBTDtBQUNIO0FBQ0o7O0FBQ0QsVUFBSTZHLENBQUMsR0FBRytCLENBQUMsQ0FBQzFFLENBQUYsR0FBTSxDQUFkO0FBQ0EsVUFBSW9KLENBQUo7QUFDQSxVQUFJQyxHQUFHLEdBQUcsSUFBVjtBQUNBLFVBQUlDLEVBQUUsR0FBRy9ELEdBQUcsRUFBWjtBQUNBLFVBQUl2RixDQUFKO0FBQ0FuRCxNQUFBQSxDQUFDLEdBQUcrSSxLQUFLLENBQUNsQixDQUFDLENBQUMvQixDQUFELENBQUYsQ0FBTCxHQUFjLENBQWxCOztBQUNBLGFBQU9BLENBQUMsSUFBSSxDQUFaLEVBQWU7QUFDWCxZQUFJOUYsQ0FBQyxJQUFJa00sRUFBVCxFQUFhO0FBQ1RLLFVBQUFBLENBQUMsR0FBSTFFLENBQUMsQ0FBQy9CLENBQUQsQ0FBRCxJQUFTOUYsQ0FBQyxHQUFHa00sRUFBZCxHQUFxQjFELEVBQXpCO0FBQ0gsU0FGRCxNQUdLO0FBQ0QrRCxVQUFBQSxDQUFDLEdBQUcsQ0FBQzFFLENBQUMsQ0FBQy9CLENBQUQsQ0FBRCxHQUFRLENBQUMsS0FBTTlGLENBQUMsR0FBRyxDQUFYLElBQWlCLENBQTFCLEtBQWtDa00sRUFBRSxHQUFHbE0sQ0FBM0M7O0FBQ0EsY0FBSThGLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUHlHLFlBQUFBLENBQUMsSUFBSTFFLENBQUMsQ0FBQy9CLENBQUMsR0FBRyxDQUFMLENBQUQsSUFBYSxLQUFLMkMsRUFBTCxHQUFVekksQ0FBVixHQUFja00sRUFBaEM7QUFDSDtBQUNKOztBQUNEak4sUUFBQUEsQ0FBQyxHQUFHdUIsQ0FBSjs7QUFDQSxlQUFPLENBQUMrTCxDQUFDLEdBQUcsQ0FBTCxLQUFXLENBQWxCLEVBQXFCO0FBQ2pCQSxVQUFBQSxDQUFDLEtBQUssQ0FBTjtBQUNBLFlBQUV0TixDQUFGO0FBQ0g7O0FBQ0QsWUFBSSxDQUFDZSxDQUFDLElBQUlmLENBQU4sSUFBVyxDQUFmLEVBQWtCO0FBQ2RlLFVBQUFBLENBQUMsSUFBSSxLQUFLeUksRUFBVjtBQUNBLFlBQUUzQyxDQUFGO0FBQ0g7O0FBQ0QsWUFBSTBHLEdBQUosRUFBUztBQUFFO0FBQ1BQLFVBQUFBLENBQUMsQ0FBQ00sQ0FBRCxDQUFELENBQUs3QyxNQUFMLENBQVloSyxDQUFaO0FBQ0E4TSxVQUFBQSxHQUFHLEdBQUcsS0FBTjtBQUNILFNBSEQsTUFJSztBQUNELGlCQUFPdk4sQ0FBQyxHQUFHLENBQVgsRUFBYztBQUNWbUssWUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRM00sQ0FBUixFQUFXK00sRUFBWDtBQUNBckQsWUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRSSxFQUFSLEVBQVkvTSxDQUFaO0FBQ0FULFlBQUFBLENBQUMsSUFBSSxDQUFMO0FBQ0g7O0FBQ0QsY0FBSUEsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQbUssWUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRM00sQ0FBUixFQUFXK00sRUFBWDtBQUNILFdBRkQsTUFHSztBQUNEdEosWUFBQUEsQ0FBQyxHQUFHekQsQ0FBSjtBQUNBQSxZQUFBQSxDQUFDLEdBQUcrTSxFQUFKO0FBQ0FBLFlBQUFBLEVBQUUsR0FBR3RKLENBQUw7QUFDSDs7QUFDRGlHLFVBQUFBLENBQUMsQ0FBQ2tELEtBQUYsQ0FBUUcsRUFBUixFQUFZUixDQUFDLENBQUNNLENBQUQsQ0FBYixFQUFrQjdNLENBQWxCO0FBQ0g7O0FBQ0QsZUFBT29HLENBQUMsSUFBSSxDQUFMLElBQVUsQ0FBQytCLENBQUMsQ0FBQy9CLENBQUQsQ0FBRCxHQUFRLEtBQUs5RixDQUFkLEtBQXFCLENBQXRDLEVBQXlDO0FBQ3JDb0osVUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRM00sQ0FBUixFQUFXK00sRUFBWDtBQUNBdEosVUFBQUEsQ0FBQyxHQUFHekQsQ0FBSjtBQUNBQSxVQUFBQSxDQUFDLEdBQUcrTSxFQUFKO0FBQ0FBLFVBQUFBLEVBQUUsR0FBR3RKLENBQUw7O0FBQ0EsY0FBSSxFQUFFbkQsQ0FBRixHQUFNLENBQVYsRUFBYTtBQUNUQSxZQUFBQSxDQUFDLEdBQUcsS0FBS3lJLEVBQUwsR0FBVSxDQUFkO0FBQ0EsY0FBRTNDLENBQUY7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsYUFBT3NELENBQUMsQ0FBQ3NELE1BQUYsQ0FBU2hOLENBQVQsQ0FBUDtBQUNILEtBeEdELENBall3QyxDQTBleEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCbUwsVUFBckIsR0FBa0MsVUFBVWhLLENBQVYsRUFBYTtBQUMzQyxVQUFJaUssRUFBRSxHQUFHakssQ0FBQyxDQUFDMEcsTUFBRixFQUFUOztBQUNBLFVBQUssS0FBS0EsTUFBTCxNQUFpQnVELEVBQWxCLElBQXlCakssQ0FBQyxDQUFDb0gsTUFBRixNQUFjLENBQTNDLEVBQThDO0FBQzFDLGVBQU81QixVQUFVLENBQUNRLElBQWxCO0FBQ0g7O0FBQ0QsVUFBSWtFLENBQUMsR0FBR2xLLENBQUMsQ0FBQzhHLEtBQUYsRUFBUjtBQUNBLFVBQUkvSSxDQUFDLEdBQUcsS0FBSytJLEtBQUwsRUFBUjtBQUNBLFVBQUk1SCxDQUFDLEdBQUdrSyxHQUFHLENBQUMsQ0FBRCxDQUFYO0FBQ0EsVUFBSWpMLENBQUMsR0FBR2lMLEdBQUcsQ0FBQyxDQUFELENBQVg7QUFDQSxVQUFJOUwsQ0FBQyxHQUFHOEwsR0FBRyxDQUFDLENBQUQsQ0FBWDtBQUNBLFVBQUlsTCxDQUFDLEdBQUdrTCxHQUFHLENBQUMsQ0FBRCxDQUFYOztBQUNBLGFBQU9jLENBQUMsQ0FBQzlDLE1BQUYsTUFBYyxDQUFyQixFQUF3QjtBQUNwQixlQUFPOEMsQ0FBQyxDQUFDeEQsTUFBRixFQUFQLEVBQW1CO0FBQ2Z3RCxVQUFBQSxDQUFDLENBQUNuQyxRQUFGLENBQVcsQ0FBWCxFQUFjbUMsQ0FBZDs7QUFDQSxjQUFJRCxFQUFKLEVBQVE7QUFDSixnQkFBSSxDQUFDL0ssQ0FBQyxDQUFDd0gsTUFBRixFQUFELElBQWUsQ0FBQ3ZJLENBQUMsQ0FBQ3VJLE1BQUYsRUFBcEIsRUFBZ0M7QUFDNUJ4SCxjQUFBQSxDQUFDLENBQUN5SixLQUFGLENBQVEsSUFBUixFQUFjekosQ0FBZDtBQUNBZixjQUFBQSxDQUFDLENBQUM4SCxLQUFGLENBQVFqRyxDQUFSLEVBQVc3QixDQUFYO0FBQ0g7O0FBQ0RlLFlBQUFBLENBQUMsQ0FBQzZJLFFBQUYsQ0FBVyxDQUFYLEVBQWM3SSxDQUFkO0FBQ0gsV0FORCxNQU9LLElBQUksQ0FBQ2YsQ0FBQyxDQUFDdUksTUFBRixFQUFMLEVBQWlCO0FBQ2xCdkksWUFBQUEsQ0FBQyxDQUFDOEgsS0FBRixDQUFRakcsQ0FBUixFQUFXN0IsQ0FBWDtBQUNIOztBQUNEQSxVQUFBQSxDQUFDLENBQUM0SixRQUFGLENBQVcsQ0FBWCxFQUFjNUosQ0FBZDtBQUNIOztBQUNELGVBQU9KLENBQUMsQ0FBQzJJLE1BQUYsRUFBUCxFQUFtQjtBQUNmM0ksVUFBQUEsQ0FBQyxDQUFDZ0ssUUFBRixDQUFXLENBQVgsRUFBY2hLLENBQWQ7O0FBQ0EsY0FBSWtNLEVBQUosRUFBUTtBQUNKLGdCQUFJLENBQUMzTSxDQUFDLENBQUNvSixNQUFGLEVBQUQsSUFBZSxDQUFDeEksQ0FBQyxDQUFDd0ksTUFBRixFQUFwQixFQUFnQztBQUM1QnBKLGNBQUFBLENBQUMsQ0FBQ3FMLEtBQUYsQ0FBUSxJQUFSLEVBQWNyTCxDQUFkO0FBQ0FZLGNBQUFBLENBQUMsQ0FBQytILEtBQUYsQ0FBUWpHLENBQVIsRUFBVzlCLENBQVg7QUFDSDs7QUFDRFosWUFBQUEsQ0FBQyxDQUFDeUssUUFBRixDQUFXLENBQVgsRUFBY3pLLENBQWQ7QUFDSCxXQU5ELE1BT0ssSUFBSSxDQUFDWSxDQUFDLENBQUN3SSxNQUFGLEVBQUwsRUFBaUI7QUFDbEJ4SSxZQUFBQSxDQUFDLENBQUMrSCxLQUFGLENBQVFqRyxDQUFSLEVBQVc5QixDQUFYO0FBQ0g7O0FBQ0RBLFVBQUFBLENBQUMsQ0FBQzZKLFFBQUYsQ0FBVyxDQUFYLEVBQWM3SixDQUFkO0FBQ0g7O0FBQ0QsWUFBSWdNLENBQUMsQ0FBQ2hFLFNBQUYsQ0FBWW5JLENBQVosS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJtTSxVQUFBQSxDQUFDLENBQUNqRSxLQUFGLENBQVFsSSxDQUFSLEVBQVdtTSxDQUFYOztBQUNBLGNBQUlELEVBQUosRUFBUTtBQUNKL0ssWUFBQUEsQ0FBQyxDQUFDK0csS0FBRixDQUFRM0ksQ0FBUixFQUFXNEIsQ0FBWDtBQUNIOztBQUNEZixVQUFBQSxDQUFDLENBQUM4SCxLQUFGLENBQVEvSCxDQUFSLEVBQVdDLENBQVg7QUFDSCxTQU5ELE1BT0s7QUFDREosVUFBQUEsQ0FBQyxDQUFDa0ksS0FBRixDQUFRaUUsQ0FBUixFQUFXbk0sQ0FBWDs7QUFDQSxjQUFJa00sRUFBSixFQUFRO0FBQ0ozTSxZQUFBQSxDQUFDLENBQUMySSxLQUFGLENBQVEvRyxDQUFSLEVBQVc1QixDQUFYO0FBQ0g7O0FBQ0RZLFVBQUFBLENBQUMsQ0FBQytILEtBQUYsQ0FBUTlILENBQVIsRUFBV0QsQ0FBWDtBQUNIO0FBQ0o7O0FBQ0QsVUFBSUgsQ0FBQyxDQUFDbUksU0FBRixDQUFZVixVQUFVLENBQUMyRSxHQUF2QixLQUErQixDQUFuQyxFQUFzQztBQUNsQyxlQUFPM0UsVUFBVSxDQUFDUSxJQUFsQjtBQUNIOztBQUNELFVBQUk5SCxDQUFDLENBQUNnSSxTQUFGLENBQVlsRyxDQUFaLEtBQWtCLENBQXRCLEVBQXlCO0FBQ3JCLGVBQU85QixDQUFDLENBQUMwSyxRQUFGLENBQVc1SSxDQUFYLENBQVA7QUFDSDs7QUFDRCxVQUFJOUIsQ0FBQyxDQUFDa0osTUFBRixLQUFhLENBQWpCLEVBQW9CO0FBQ2hCbEosUUFBQUEsQ0FBQyxDQUFDeUssS0FBRixDQUFRM0ksQ0FBUixFQUFXOUIsQ0FBWDtBQUNILE9BRkQsTUFHSztBQUNELGVBQU9BLENBQVA7QUFDSDs7QUFDRCxVQUFJQSxDQUFDLENBQUNrSixNQUFGLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEIsZUFBT2xKLENBQUMsQ0FBQ3dLLEdBQUYsQ0FBTTFJLENBQU4sQ0FBUDtBQUNILE9BRkQsTUFHSztBQUNELGVBQU85QixDQUFQO0FBQ0g7QUFDSixLQXpFRCxDQTVld0MsQ0FzakJ4QztBQUNBOzs7QUFDQXNILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ1TCxHQUFyQixHQUEyQixVQUFVbEYsQ0FBVixFQUFhO0FBQ3BDLGFBQU8sS0FBSzJCLEdBQUwsQ0FBUzNCLENBQVQsRUFBWSxJQUFJbUYsT0FBSixFQUFaLENBQVA7QUFDSCxLQUZELENBeGpCd0MsQ0EyakJ4QztBQUNBOzs7QUFDQTdFLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ5TCxHQUFyQixHQUEyQixVQUFVcEwsQ0FBVixFQUFhO0FBQ3BDLFVBQUl6QyxDQUFDLEdBQUksS0FBS21CLENBQUwsR0FBUyxDQUFWLEdBQWUsS0FBSytILE1BQUwsRUFBZixHQUErQixLQUFLbUIsS0FBTCxFQUF2QztBQUNBLFVBQUlwSyxDQUFDLEdBQUl3QyxDQUFDLENBQUN0QixDQUFGLEdBQU0sQ0FBUCxHQUFZc0IsQ0FBQyxDQUFDeUcsTUFBRixFQUFaLEdBQXlCekcsQ0FBQyxDQUFDNEgsS0FBRixFQUFqQzs7QUFDQSxVQUFJckssQ0FBQyxDQUFDeUosU0FBRixDQUFZeEosQ0FBWixJQUFpQixDQUFyQixFQUF3QjtBQUNwQixZQUFJOEQsQ0FBQyxHQUFHL0QsQ0FBUjtBQUNBQSxRQUFBQSxDQUFDLEdBQUdDLENBQUo7QUFDQUEsUUFBQUEsQ0FBQyxHQUFHOEQsQ0FBSjtBQUNIOztBQUNELFVBQUluRCxDQUFDLEdBQUdaLENBQUMsQ0FBQ3lMLGVBQUYsRUFBUjtBQUNBLFVBQUlvQixDQUFDLEdBQUc1TSxDQUFDLENBQUN3TCxlQUFGLEVBQVI7O0FBQ0EsVUFBSW9CLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxlQUFPN00sQ0FBUDtBQUNIOztBQUNELFVBQUlZLENBQUMsR0FBR2lNLENBQVIsRUFBVztBQUNQQSxRQUFBQSxDQUFDLEdBQUdqTSxDQUFKO0FBQ0g7O0FBQ0QsVUFBSWlNLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUDdNLFFBQUFBLENBQUMsQ0FBQ3NMLFFBQUYsQ0FBV3VCLENBQVgsRUFBYzdNLENBQWQ7QUFDQUMsUUFBQUEsQ0FBQyxDQUFDcUwsUUFBRixDQUFXdUIsQ0FBWCxFQUFjNU0sQ0FBZDtBQUNIOztBQUNELGFBQU9ELENBQUMsQ0FBQzJLLE1BQUYsS0FBYSxDQUFwQixFQUF1QjtBQUNuQixZQUFJLENBQUMvSixDQUFDLEdBQUdaLENBQUMsQ0FBQ3lMLGVBQUYsRUFBTCxJQUE0QixDQUFoQyxFQUFtQztBQUMvQnpMLFVBQUFBLENBQUMsQ0FBQ3NMLFFBQUYsQ0FBVzFLLENBQVgsRUFBY1osQ0FBZDtBQUNIOztBQUNELFlBQUksQ0FBQ1ksQ0FBQyxHQUFHWCxDQUFDLENBQUN3TCxlQUFGLEVBQUwsSUFBNEIsQ0FBaEMsRUFBbUM7QUFDL0J4TCxVQUFBQSxDQUFDLENBQUNxTCxRQUFGLENBQVcxSyxDQUFYLEVBQWNYLENBQWQ7QUFDSDs7QUFDRCxZQUFJRCxDQUFDLENBQUN5SixTQUFGLENBQVl4SixDQUFaLEtBQWtCLENBQXRCLEVBQXlCO0FBQ3JCRCxVQUFBQSxDQUFDLENBQUN3SixLQUFGLENBQVF2SixDQUFSLEVBQVdELENBQVg7QUFDQUEsVUFBQUEsQ0FBQyxDQUFDc0wsUUFBRixDQUFXLENBQVgsRUFBY3RMLENBQWQ7QUFDSCxTQUhELE1BSUs7QUFDREMsVUFBQUEsQ0FBQyxDQUFDdUosS0FBRixDQUFReEosQ0FBUixFQUFXQyxDQUFYO0FBQ0FBLFVBQUFBLENBQUMsQ0FBQ3FMLFFBQUYsQ0FBVyxDQUFYLEVBQWNyTCxDQUFkO0FBQ0g7QUFDSjs7QUFDRCxVQUFJNE0sQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQNU0sUUFBQUEsQ0FBQyxDQUFDc0wsUUFBRixDQUFXc0IsQ0FBWCxFQUFjNU0sQ0FBZDtBQUNIOztBQUNELGFBQU9BLENBQVA7QUFDSCxLQXhDRCxDQTdqQndDLENBc21CeEM7QUFDQTs7O0FBQ0E4SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCMEwsZUFBckIsR0FBdUMsVUFBVS9KLENBQVYsRUFBYTtBQUNoRCxVQUFJbkQsQ0FBSjtBQUNBLFVBQUlaLENBQUMsR0FBRyxLQUFLeUgsR0FBTCxFQUFSOztBQUNBLFVBQUl6SCxDQUFDLENBQUMrRCxDQUFGLElBQU8sQ0FBUCxJQUFZL0QsQ0FBQyxDQUFDLENBQUQsQ0FBRCxJQUFRNkksU0FBUyxDQUFDQSxTQUFTLENBQUM5SCxNQUFWLEdBQW1CLENBQXBCLENBQWpDLEVBQXlEO0FBQ3JELGFBQUtILENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBR2lJLFNBQVMsQ0FBQzlILE1BQTFCLEVBQWtDLEVBQUVILENBQXBDLEVBQXVDO0FBQ25DLGNBQUlaLENBQUMsQ0FBQyxDQUFELENBQUQsSUFBUTZJLFNBQVMsQ0FBQ2pJLENBQUQsQ0FBckIsRUFBMEI7QUFDdEIsbUJBQU8sSUFBUDtBQUNIO0FBQ0o7O0FBQ0QsZUFBTyxLQUFQO0FBQ0g7O0FBQ0QsVUFBSVosQ0FBQyxDQUFDaUssTUFBRixFQUFKLEVBQWdCO0FBQ1osZUFBTyxLQUFQO0FBQ0g7O0FBQ0RySixNQUFBQSxDQUFDLEdBQUcsQ0FBSjs7QUFDQSxhQUFPQSxDQUFDLEdBQUdpSSxTQUFTLENBQUM5SCxNQUFyQixFQUE2QjtBQUN6QixZQUFJd0MsQ0FBQyxHQUFHc0YsU0FBUyxDQUFDakksQ0FBRCxDQUFqQjtBQUNBLFlBQUk4RixDQUFDLEdBQUc5RixDQUFDLEdBQUcsQ0FBWjs7QUFDQSxlQUFPOEYsQ0FBQyxHQUFHbUMsU0FBUyxDQUFDOUgsTUFBZCxJQUF3QndDLENBQUMsR0FBR3VGLEtBQW5DLEVBQTBDO0FBQ3RDdkYsVUFBQUEsQ0FBQyxJQUFJc0YsU0FBUyxDQUFDbkMsQ0FBQyxFQUFGLENBQWQ7QUFDSDs7QUFDRG5ELFFBQUFBLENBQUMsR0FBR3ZELENBQUMsQ0FBQytOLE1BQUYsQ0FBU3hLLENBQVQsQ0FBSjs7QUFDQSxlQUFPM0MsQ0FBQyxHQUFHOEYsQ0FBWCxFQUFjO0FBQ1YsY0FBSW5ELENBQUMsR0FBR3NGLFNBQVMsQ0FBQ2pJLENBQUMsRUFBRixDQUFiLElBQXNCLENBQTFCLEVBQTZCO0FBQ3pCLG1CQUFPLEtBQVA7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsYUFBT1osQ0FBQyxDQUFDZ08sV0FBRixDQUFjakssQ0FBZCxDQUFQO0FBQ0gsS0E3QkQsQ0F4bUJ3QyxDQXNvQnhDO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQWdGLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJrSSxNQUFyQixHQUE4QixVQUFVaEssQ0FBVixFQUFhO0FBQ3ZDLFdBQUssSUFBSU0sQ0FBQyxHQUFHLEtBQUttRCxDQUFMLEdBQVMsQ0FBdEIsRUFBeUJuRCxDQUFDLElBQUksQ0FBOUIsRUFBaUMsRUFBRUEsQ0FBbkMsRUFBc0M7QUFDbENOLFFBQUFBLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU8sS0FBS0EsQ0FBTCxDQUFQO0FBQ0g7O0FBQ0ROLE1BQUFBLENBQUMsQ0FBQ3lELENBQUYsR0FBTSxLQUFLQSxDQUFYO0FBQ0F6RCxNQUFBQSxDQUFDLENBQUNhLENBQUYsR0FBTSxLQUFLQSxDQUFYO0FBQ0gsS0FORCxDQTFvQndDLENBaXBCeEM7QUFDQTs7O0FBQ0E0SCxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCNkwsT0FBckIsR0FBK0IsVUFBVWpPLENBQVYsRUFBYTtBQUN4QyxXQUFLK0QsQ0FBTCxHQUFTLENBQVQ7QUFDQSxXQUFLNUMsQ0FBTCxHQUFVbkIsQ0FBQyxHQUFHLENBQUwsR0FBVSxDQUFDLENBQVgsR0FBZSxDQUF4Qjs7QUFDQSxVQUFJQSxDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1AsYUFBSyxDQUFMLElBQVVBLENBQVY7QUFDSCxPQUZELE1BR0ssSUFBSUEsQ0FBQyxHQUFHLENBQUMsQ0FBVCxFQUFZO0FBQ2IsYUFBSyxDQUFMLElBQVVBLENBQUMsR0FBRyxLQUFLd0ssRUFBbkI7QUFDSCxPQUZJLE1BR0E7QUFDRCxhQUFLekcsQ0FBTCxHQUFTLENBQVQ7QUFDSDtBQUNKLEtBWkQsQ0FucEJ3QyxDQWdxQnhDO0FBQ0E7OztBQUNBZ0YsSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjZHLFVBQXJCLEdBQWtDLFVBQVU5SCxDQUFWLEVBQWFPLENBQWIsRUFBZ0I7QUFDOUMsVUFBSU4sQ0FBSjs7QUFDQSxVQUFJTSxDQUFDLElBQUksRUFBVCxFQUFhO0FBQ1ROLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FGRCxNQUdLLElBQUlNLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDYk4sUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUZJLE1BR0EsSUFBSU0sQ0FBQyxJQUFJLEdBQVQsRUFBYztBQUNmTixRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNBO0FBQ0gsT0FISSxNQUlBLElBQUlNLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDYk4sUUFBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSCxPQUZJLE1BR0EsSUFBSU0sQ0FBQyxJQUFJLEVBQVQsRUFBYTtBQUNkTixRQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILE9BRkksTUFHQSxJQUFJTSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ2JOLFFBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0gsT0FGSSxNQUdBO0FBQ0QsYUFBSzhNLFNBQUwsQ0FBZS9NLENBQWYsRUFBa0JPLENBQWxCO0FBQ0E7QUFDSDs7QUFDRCxXQUFLcUMsQ0FBTCxHQUFTLENBQVQ7QUFDQSxXQUFLNUMsQ0FBTCxHQUFTLENBQVQ7QUFDQSxVQUFJUCxDQUFDLEdBQUdPLENBQUMsQ0FBQ0osTUFBVjtBQUNBLFVBQUlvTixFQUFFLEdBQUcsS0FBVDtBQUNBLFVBQUlDLEVBQUUsR0FBRyxDQUFUOztBQUNBLGFBQU8sRUFBRXhOLENBQUYsSUFBTyxDQUFkLEVBQWlCO0FBQ2IsWUFBSVosQ0FBQyxHQUFJb0IsQ0FBQyxJQUFJLENBQU4sR0FBWSxDQUFDRCxDQUFDLENBQUNQLENBQUQsQ0FBSCxHQUFVLElBQXJCLEdBQTRCeU4sS0FBSyxDQUFDbE4sQ0FBRCxFQUFJUCxDQUFKLENBQXpDOztBQUNBLFlBQUlaLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxjQUFJbUIsQ0FBQyxDQUFDckIsTUFBRixDQUFTYyxDQUFULEtBQWUsR0FBbkIsRUFBd0I7QUFDcEJ1TixZQUFBQSxFQUFFLEdBQUcsSUFBTDtBQUNIOztBQUNEO0FBQ0g7O0FBQ0RBLFFBQUFBLEVBQUUsR0FBRyxLQUFMOztBQUNBLFlBQUlDLEVBQUUsSUFBSSxDQUFWLEVBQWE7QUFDVCxlQUFLLEtBQUtySyxDQUFMLEVBQUwsSUFBaUIvRCxDQUFqQjtBQUNILFNBRkQsTUFHSyxJQUFJb08sRUFBRSxHQUFHaE4sQ0FBTCxHQUFTLEtBQUtpSSxFQUFsQixFQUFzQjtBQUN2QixlQUFLLEtBQUt0RixDQUFMLEdBQVMsQ0FBZCxLQUFvQixDQUFDL0QsQ0FBQyxHQUFJLENBQUMsS0FBTSxLQUFLcUosRUFBTCxHQUFVK0UsRUFBakIsSUFBd0IsQ0FBOUIsS0FBcUNBLEVBQXpEO0FBQ0EsZUFBSyxLQUFLckssQ0FBTCxFQUFMLElBQWtCL0QsQ0FBQyxJQUFLLEtBQUtxSixFQUFMLEdBQVUrRSxFQUFsQztBQUNILFNBSEksTUFJQTtBQUNELGVBQUssS0FBS3JLLENBQUwsR0FBUyxDQUFkLEtBQW9CL0QsQ0FBQyxJQUFJb08sRUFBekI7QUFDSDs7QUFDREEsUUFBQUEsRUFBRSxJQUFJaE4sQ0FBTjs7QUFDQSxZQUFJZ04sRUFBRSxJQUFJLEtBQUsvRSxFQUFmLEVBQW1CO0FBQ2YrRSxVQUFBQSxFQUFFLElBQUksS0FBSy9FLEVBQVg7QUFDSDtBQUNKOztBQUNELFVBQUlqSSxDQUFDLElBQUksQ0FBTCxJQUFVLENBQUUsQ0FBQ0QsQ0FBQyxDQUFDLENBQUQsQ0FBSCxHQUFVLElBQVgsS0FBb0IsQ0FBbEMsRUFBcUM7QUFDakMsYUFBS0EsQ0FBTCxHQUFTLENBQUMsQ0FBVjs7QUFDQSxZQUFJaU4sRUFBRSxHQUFHLENBQVQsRUFBWTtBQUNSLGVBQUssS0FBS3JLLENBQUwsR0FBUyxDQUFkLEtBQXFCLENBQUMsS0FBTSxLQUFLc0YsRUFBTCxHQUFVK0UsRUFBakIsSUFBd0IsQ0FBekIsSUFBK0JBLEVBQW5EO0FBQ0g7QUFDSjs7QUFDRCxXQUFLRSxLQUFMOztBQUNBLFVBQUlILEVBQUosRUFBUTtBQUNKcEYsUUFBQUEsVUFBVSxDQUFDUSxJQUFYLENBQWdCQyxLQUFoQixDQUFzQixJQUF0QixFQUE0QixJQUE1QjtBQUNIO0FBQ0osS0FoRUQsQ0FscUJ3QyxDQW11QnhDO0FBQ0E7OztBQUNBVCxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCa00sS0FBckIsR0FBNkIsWUFBWTtBQUNyQyxVQUFJek4sQ0FBQyxHQUFHLEtBQUtNLENBQUwsR0FBUyxLQUFLeUksRUFBdEI7O0FBQ0EsYUFBTyxLQUFLN0YsQ0FBTCxHQUFTLENBQVQsSUFBYyxLQUFLLEtBQUtBLENBQUwsR0FBUyxDQUFkLEtBQW9CbEQsQ0FBekMsRUFBNEM7QUFDeEMsVUFBRSxLQUFLa0QsQ0FBUDtBQUNIO0FBQ0osS0FMRCxDQXJ1QndDLENBMnVCeEM7QUFDQTs7O0FBQ0FnRixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCbU0sU0FBckIsR0FBaUMsVUFBVTFPLENBQVYsRUFBYVMsQ0FBYixFQUFnQjtBQUM3QyxVQUFJTSxDQUFKOztBQUNBLFdBQUtBLENBQUMsR0FBRyxLQUFLbUQsQ0FBTCxHQUFTLENBQWxCLEVBQXFCbkQsQ0FBQyxJQUFJLENBQTFCLEVBQTZCLEVBQUVBLENBQS9CLEVBQWtDO0FBQzlCTixRQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR2YsQ0FBTCxDQUFELEdBQVcsS0FBS2UsQ0FBTCxDQUFYO0FBQ0g7O0FBQ0QsV0FBS0EsQ0FBQyxHQUFHZixDQUFDLEdBQUcsQ0FBYixFQUFnQmUsQ0FBQyxJQUFJLENBQXJCLEVBQXdCLEVBQUVBLENBQTFCLEVBQTZCO0FBQ3pCTixRQUFBQSxDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPLENBQVA7QUFDSDs7QUFDRE4sTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLEtBQUtBLENBQUwsR0FBU2xFLENBQWY7QUFDQVMsTUFBQUEsQ0FBQyxDQUFDYSxDQUFGLEdBQU0sS0FBS0EsQ0FBWDtBQUNILEtBVkQsQ0E3dUJ3QyxDQXd2QnhDO0FBQ0E7OztBQUNBNEgsSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQm9NLFNBQXJCLEdBQWlDLFVBQVUzTyxDQUFWLEVBQWFTLENBQWIsRUFBZ0I7QUFDN0MsV0FBSyxJQUFJTSxDQUFDLEdBQUdmLENBQWIsRUFBZ0JlLENBQUMsR0FBRyxLQUFLbUQsQ0FBekIsRUFBNEIsRUFBRW5ELENBQTlCLEVBQWlDO0FBQzdCTixRQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR2YsQ0FBTCxDQUFELEdBQVcsS0FBS2UsQ0FBTCxDQUFYO0FBQ0g7O0FBQ0ROLE1BQUFBLENBQUMsQ0FBQ3lELENBQUYsR0FBTXlELElBQUksQ0FBQy9ELEdBQUwsQ0FBUyxLQUFLTSxDQUFMLEdBQVNsRSxDQUFsQixFQUFxQixDQUFyQixDQUFOO0FBQ0FTLE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFNLEtBQUtBLENBQVg7QUFDSCxLQU5ELENBMXZCd0MsQ0Fpd0J4QztBQUNBOzs7QUFDQTRILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJtSixRQUFyQixHQUFnQyxVQUFVMUwsQ0FBVixFQUFhUyxDQUFiLEVBQWdCO0FBQzVDLFVBQUltTyxFQUFFLEdBQUc1TyxDQUFDLEdBQUcsS0FBS3dKLEVBQWxCO0FBQ0EsVUFBSXFGLEdBQUcsR0FBRyxLQUFLckYsRUFBTCxHQUFVb0YsRUFBcEI7QUFDQSxVQUFJRSxFQUFFLEdBQUcsQ0FBQyxLQUFLRCxHQUFOLElBQWEsQ0FBdEI7QUFDQSxVQUFJRSxFQUFFLEdBQUdwSCxJQUFJLENBQUNvRSxLQUFMLENBQVcvTCxDQUFDLEdBQUcsS0FBS3dKLEVBQXBCLENBQVQ7QUFDQSxVQUFJeEksQ0FBQyxHQUFJLEtBQUtNLENBQUwsSUFBVXNOLEVBQVgsR0FBaUIsS0FBSzdFLEVBQTlCOztBQUNBLFdBQUssSUFBSWhKLENBQUMsR0FBRyxLQUFLbUQsQ0FBTCxHQUFTLENBQXRCLEVBQXlCbkQsQ0FBQyxJQUFJLENBQTlCLEVBQWlDLEVBQUVBLENBQW5DLEVBQXNDO0FBQ2xDTixRQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR2dPLEVBQUosR0FBUyxDQUFWLENBQUQsR0FBaUIsS0FBS2hPLENBQUwsS0FBVzhOLEdBQVosR0FBbUI3TixDQUFuQztBQUNBQSxRQUFBQSxDQUFDLEdBQUcsQ0FBQyxLQUFLRCxDQUFMLElBQVUrTixFQUFYLEtBQWtCRixFQUF0QjtBQUNIOztBQUNELFdBQUssSUFBSTdOLENBQUMsR0FBR2dPLEVBQUUsR0FBRyxDQUFsQixFQUFxQmhPLENBQUMsSUFBSSxDQUExQixFQUE2QixFQUFFQSxDQUEvQixFQUFrQztBQUM5Qk4sUUFBQUEsQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBTyxDQUFQO0FBQ0g7O0FBQ0ROLE1BQUFBLENBQUMsQ0FBQ3NPLEVBQUQsQ0FBRCxHQUFRL04sQ0FBUjtBQUNBUCxNQUFBQSxDQUFDLENBQUN5RCxDQUFGLEdBQU0sS0FBS0EsQ0FBTCxHQUFTNkssRUFBVCxHQUFjLENBQXBCO0FBQ0F0TyxNQUFBQSxDQUFDLENBQUNhLENBQUYsR0FBTSxLQUFLQSxDQUFYO0FBQ0FiLE1BQUFBLENBQUMsQ0FBQ2dPLEtBQUY7QUFDSCxLQWpCRCxDQW53QndDLENBcXhCeEM7QUFDQTs7O0FBQ0F2RixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCa0osUUFBckIsR0FBZ0MsVUFBVXpMLENBQVYsRUFBYVMsQ0FBYixFQUFnQjtBQUM1Q0EsTUFBQUEsQ0FBQyxDQUFDYSxDQUFGLEdBQU0sS0FBS0EsQ0FBWDtBQUNBLFVBQUl5TixFQUFFLEdBQUdwSCxJQUFJLENBQUNvRSxLQUFMLENBQVcvTCxDQUFDLEdBQUcsS0FBS3dKLEVBQXBCLENBQVQ7O0FBQ0EsVUFBSXVGLEVBQUUsSUFBSSxLQUFLN0ssQ0FBZixFQUFrQjtBQUNkekQsUUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLENBQU47QUFDQTtBQUNIOztBQUNELFVBQUkwSyxFQUFFLEdBQUc1TyxDQUFDLEdBQUcsS0FBS3dKLEVBQWxCO0FBQ0EsVUFBSXFGLEdBQUcsR0FBRyxLQUFLckYsRUFBTCxHQUFVb0YsRUFBcEI7QUFDQSxVQUFJRSxFQUFFLEdBQUcsQ0FBQyxLQUFLRixFQUFOLElBQVksQ0FBckI7QUFDQW5PLE1BQUFBLENBQUMsQ0FBQyxDQUFELENBQUQsR0FBTyxLQUFLc08sRUFBTCxLQUFZSCxFQUFuQjs7QUFDQSxXQUFLLElBQUk3TixDQUFDLEdBQUdnTyxFQUFFLEdBQUcsQ0FBbEIsRUFBcUJoTyxDQUFDLEdBQUcsS0FBS21ELENBQTlCLEVBQWlDLEVBQUVuRCxDQUFuQyxFQUFzQztBQUNsQ04sUUFBQUEsQ0FBQyxDQUFDTSxDQUFDLEdBQUdnTyxFQUFKLEdBQVMsQ0FBVixDQUFELElBQWlCLENBQUMsS0FBS2hPLENBQUwsSUFBVStOLEVBQVgsS0FBa0JELEdBQW5DO0FBQ0FwTyxRQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR2dPLEVBQUwsQ0FBRCxHQUFZLEtBQUtoTyxDQUFMLEtBQVc2TixFQUF2QjtBQUNIOztBQUNELFVBQUlBLEVBQUUsR0FBRyxDQUFULEVBQVk7QUFDUm5PLFFBQUFBLENBQUMsQ0FBQyxLQUFLeUQsQ0FBTCxHQUFTNkssRUFBVCxHQUFjLENBQWYsQ0FBRCxJQUFzQixDQUFDLEtBQUt6TixDQUFMLEdBQVN3TixFQUFWLEtBQWlCRCxHQUF2QztBQUNIOztBQUNEcE8sTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLEtBQUtBLENBQUwsR0FBUzZLLEVBQWY7QUFDQXRPLE1BQUFBLENBQUMsQ0FBQ2dPLEtBQUY7QUFDSCxLQXBCRCxDQXZ4QndDLENBNHlCeEM7QUFDQTs7O0FBQ0F2RixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCb0gsS0FBckIsR0FBNkIsVUFBVS9HLENBQVYsRUFBYW5DLENBQWIsRUFBZ0I7QUFDekMsVUFBSU0sQ0FBQyxHQUFHLENBQVI7QUFDQSxVQUFJQyxDQUFDLEdBQUcsQ0FBUjtBQUNBLFVBQUkwQyxDQUFDLEdBQUdpRSxJQUFJLENBQUNzRCxHQUFMLENBQVNySSxDQUFDLENBQUNzQixDQUFYLEVBQWMsS0FBS0EsQ0FBbkIsQ0FBUjs7QUFDQSxhQUFPbkQsQ0FBQyxHQUFHMkMsQ0FBWCxFQUFjO0FBQ1YxQyxRQUFBQSxDQUFDLElBQUksS0FBS0QsQ0FBTCxJQUFVNkIsQ0FBQyxDQUFDN0IsQ0FBRCxDQUFoQjtBQUNBTixRQUFBQSxDQUFDLENBQUNNLENBQUMsRUFBRixDQUFELEdBQVNDLENBQUMsR0FBRyxLQUFLK0ksRUFBbEI7QUFDQS9JLFFBQUFBLENBQUMsS0FBSyxLQUFLd0ksRUFBWDtBQUNIOztBQUNELFVBQUk1RyxDQUFDLENBQUNzQixDQUFGLEdBQU0sS0FBS0EsQ0FBZixFQUFrQjtBQUNkbEQsUUFBQUEsQ0FBQyxJQUFJNEIsQ0FBQyxDQUFDdEIsQ0FBUDs7QUFDQSxlQUFPUCxDQUFDLEdBQUcsS0FBS21ELENBQWhCLEVBQW1CO0FBQ2ZsRCxVQUFBQSxDQUFDLElBQUksS0FBS0QsQ0FBTCxDQUFMO0FBQ0FOLFVBQUFBLENBQUMsQ0FBQ00sQ0FBQyxFQUFGLENBQUQsR0FBU0MsQ0FBQyxHQUFHLEtBQUsrSSxFQUFsQjtBQUNBL0ksVUFBQUEsQ0FBQyxLQUFLLEtBQUt3SSxFQUFYO0FBQ0g7O0FBQ0R4SSxRQUFBQSxDQUFDLElBQUksS0FBS00sQ0FBVjtBQUNILE9BUkQsTUFTSztBQUNETixRQUFBQSxDQUFDLElBQUksS0FBS00sQ0FBVjs7QUFDQSxlQUFPUCxDQUFDLEdBQUc2QixDQUFDLENBQUNzQixDQUFiLEVBQWdCO0FBQ1psRCxVQUFBQSxDQUFDLElBQUk0QixDQUFDLENBQUM3QixDQUFELENBQU47QUFDQU4sVUFBQUEsQ0FBQyxDQUFDTSxDQUFDLEVBQUYsQ0FBRCxHQUFTQyxDQUFDLEdBQUcsS0FBSytJLEVBQWxCO0FBQ0EvSSxVQUFBQSxDQUFDLEtBQUssS0FBS3dJLEVBQVg7QUFDSDs7QUFDRHhJLFFBQUFBLENBQUMsSUFBSTRCLENBQUMsQ0FBQ3RCLENBQVA7QUFDSDs7QUFDRGIsTUFBQUEsQ0FBQyxDQUFDYSxDQUFGLEdBQU9OLENBQUMsR0FBRyxDQUFMLEdBQVUsQ0FBQyxDQUFYLEdBQWUsQ0FBckI7O0FBQ0EsVUFBSUEsQ0FBQyxHQUFHLENBQUMsQ0FBVCxFQUFZO0FBQ1JQLFFBQUFBLENBQUMsQ0FBQ00sQ0FBQyxFQUFGLENBQUQsR0FBUyxLQUFLNEosRUFBTCxHQUFVM0osQ0FBbkI7QUFDSCxPQUZELE1BR0ssSUFBSUEsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNaUCxRQUFBQSxDQUFDLENBQUNNLENBQUMsRUFBRixDQUFELEdBQVNDLENBQVQ7QUFDSDs7QUFDRFAsTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNbkQsQ0FBTjtBQUNBTixNQUFBQSxDQUFDLENBQUNnTyxLQUFGO0FBQ0gsS0FwQ0QsQ0E5eUJ3QyxDQW0xQnhDO0FBQ0E7QUFDQTs7O0FBQ0F2RixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCaUssVUFBckIsR0FBa0MsVUFBVTVKLENBQVYsRUFBYW5DLENBQWIsRUFBZ0I7QUFDOUMsVUFBSU4sQ0FBQyxHQUFHLEtBQUt5SCxHQUFMLEVBQVI7QUFDQSxVQUFJeEgsQ0FBQyxHQUFHd0MsQ0FBQyxDQUFDZ0YsR0FBRixFQUFSO0FBQ0EsVUFBSTdHLENBQUMsR0FBR1osQ0FBQyxDQUFDK0QsQ0FBVjtBQUNBekQsTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNbkQsQ0FBQyxHQUFHWCxDQUFDLENBQUM4RCxDQUFaOztBQUNBLGFBQU8sRUFBRW5ELENBQUYsSUFBTyxDQUFkLEVBQWlCO0FBQ2JOLFFBQUFBLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU8sQ0FBUDtBQUNIOztBQUNELFdBQUtBLENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBR1gsQ0FBQyxDQUFDOEQsQ0FBbEIsRUFBcUIsRUFBRW5ELENBQXZCLEVBQTBCO0FBQ3RCTixRQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR1osQ0FBQyxDQUFDK0QsQ0FBUCxDQUFELEdBQWEvRCxDQUFDLENBQUM2TyxFQUFGLENBQUssQ0FBTCxFQUFRNU8sQ0FBQyxDQUFDVyxDQUFELENBQVQsRUFBY04sQ0FBZCxFQUFpQk0sQ0FBakIsRUFBb0IsQ0FBcEIsRUFBdUJaLENBQUMsQ0FBQytELENBQXpCLENBQWI7QUFDSDs7QUFDRHpELE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFNLENBQU47QUFDQWIsTUFBQUEsQ0FBQyxDQUFDZ08sS0FBRjs7QUFDQSxVQUFJLEtBQUtuTixDQUFMLElBQVVzQixDQUFDLENBQUN0QixDQUFoQixFQUFtQjtBQUNmNEgsUUFBQUEsVUFBVSxDQUFDUSxJQUFYLENBQWdCQyxLQUFoQixDQUFzQmxKLENBQXRCLEVBQXlCQSxDQUF6QjtBQUNIO0FBQ0osS0FoQkQsQ0F0MUJ3QyxDQXUyQnhDO0FBQ0E7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjBNLFFBQXJCLEdBQWdDLFVBQVV4TyxDQUFWLEVBQWE7QUFDekMsVUFBSU4sQ0FBQyxHQUFHLEtBQUt5SCxHQUFMLEVBQVI7QUFDQSxVQUFJN0csQ0FBQyxHQUFHTixDQUFDLENBQUN5RCxDQUFGLEdBQU0sSUFBSS9ELENBQUMsQ0FBQytELENBQXBCOztBQUNBLGFBQU8sRUFBRW5ELENBQUYsSUFBTyxDQUFkLEVBQWlCO0FBQ2JOLFFBQUFBLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU8sQ0FBUDtBQUNIOztBQUNELFdBQUtBLENBQUMsR0FBRyxDQUFULEVBQVlBLENBQUMsR0FBR1osQ0FBQyxDQUFDK0QsQ0FBRixHQUFNLENBQXRCLEVBQXlCLEVBQUVuRCxDQUEzQixFQUE4QjtBQUMxQixZQUFJQyxDQUFDLEdBQUdiLENBQUMsQ0FBQzZPLEVBQUYsQ0FBS2pPLENBQUwsRUFBUVosQ0FBQyxDQUFDWSxDQUFELENBQVQsRUFBY04sQ0FBZCxFQUFpQixJQUFJTSxDQUFyQixFQUF3QixDQUF4QixFQUEyQixDQUEzQixDQUFSOztBQUNBLFlBQUksQ0FBQ04sQ0FBQyxDQUFDTSxDQUFDLEdBQUdaLENBQUMsQ0FBQytELENBQVAsQ0FBRCxJQUFjL0QsQ0FBQyxDQUFDNk8sRUFBRixDQUFLak8sQ0FBQyxHQUFHLENBQVQsRUFBWSxJQUFJWixDQUFDLENBQUNZLENBQUQsQ0FBakIsRUFBc0JOLENBQXRCLEVBQXlCLElBQUlNLENBQUosR0FBUSxDQUFqQyxFQUFvQ0MsQ0FBcEMsRUFBdUNiLENBQUMsQ0FBQytELENBQUYsR0FBTW5ELENBQU4sR0FBVSxDQUFqRCxDQUFmLEtBQXVFWixDQUFDLENBQUN3SyxFQUE3RSxFQUFpRjtBQUM3RWxLLFVBQUFBLENBQUMsQ0FBQ00sQ0FBQyxHQUFHWixDQUFDLENBQUMrRCxDQUFQLENBQUQsSUFBYy9ELENBQUMsQ0FBQ3dLLEVBQWhCO0FBQ0FsSyxVQUFBQSxDQUFDLENBQUNNLENBQUMsR0FBR1osQ0FBQyxDQUFDK0QsQ0FBTixHQUFVLENBQVgsQ0FBRCxHQUFpQixDQUFqQjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSXpELENBQUMsQ0FBQ3lELENBQUYsR0FBTSxDQUFWLEVBQWE7QUFDVHpELFFBQUFBLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLENBQVAsQ0FBRCxJQUFjL0QsQ0FBQyxDQUFDNk8sRUFBRixDQUFLak8sQ0FBTCxFQUFRWixDQUFDLENBQUNZLENBQUQsQ0FBVCxFQUFjTixDQUFkLEVBQWlCLElBQUlNLENBQXJCLEVBQXdCLENBQXhCLEVBQTJCLENBQTNCLENBQWQ7QUFDSDs7QUFDRE4sTUFBQUEsQ0FBQyxDQUFDYSxDQUFGLEdBQU0sQ0FBTjtBQUNBYixNQUFBQSxDQUFDLENBQUNnTyxLQUFGO0FBQ0gsS0FsQkQsQ0F6MkJ3QyxDQTQzQnhDO0FBQ0E7QUFDQTs7O0FBQ0F2RixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCMEgsUUFBckIsR0FBZ0MsVUFBVXZHLENBQVYsRUFBYWtKLENBQWIsRUFBZ0JuTSxDQUFoQixFQUFtQjtBQUMvQyxVQUFJeU8sRUFBRSxHQUFHeEwsQ0FBQyxDQUFDa0UsR0FBRixFQUFUOztBQUNBLFVBQUlzSCxFQUFFLENBQUNoTCxDQUFILElBQVEsQ0FBWixFQUFlO0FBQ1g7QUFDSDs7QUFDRCxVQUFJaUwsRUFBRSxHQUFHLEtBQUt2SCxHQUFMLEVBQVQ7O0FBQ0EsVUFBSXVILEVBQUUsQ0FBQ2pMLENBQUgsR0FBT2dMLEVBQUUsQ0FBQ2hMLENBQWQsRUFBaUI7QUFDYixZQUFJMEksQ0FBQyxJQUFJLElBQVQsRUFBZTtBQUNYQSxVQUFBQSxDQUFDLENBQUN3QixPQUFGLENBQVUsQ0FBVjtBQUNIOztBQUNELFlBQUkzTixDQUFDLElBQUksSUFBVCxFQUFlO0FBQ1gsZUFBS2dLLE1BQUwsQ0FBWWhLLENBQVo7QUFDSDs7QUFDRDtBQUNIOztBQUNELFVBQUlBLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWEEsUUFBQUEsQ0FBQyxHQUFHZ0osR0FBRyxFQUFQO0FBQ0g7O0FBQ0QsVUFBSXJKLENBQUMsR0FBR3FKLEdBQUcsRUFBWDtBQUNBLFVBQUkyRixFQUFFLEdBQUcsS0FBSzlOLENBQWQ7QUFDQSxVQUFJK04sRUFBRSxHQUFHM0wsQ0FBQyxDQUFDcEMsQ0FBWDtBQUNBLFVBQUlnTyxHQUFHLEdBQUcsS0FBSzlGLEVBQUwsR0FBVU0sS0FBSyxDQUFDb0YsRUFBRSxDQUFDQSxFQUFFLENBQUNoTCxDQUFILEdBQU8sQ0FBUixDQUFILENBQXpCLENBckIrQyxDQXFCTjs7QUFDekMsVUFBSW9MLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDVEosUUFBQUEsRUFBRSxDQUFDeEQsUUFBSCxDQUFZNEQsR0FBWixFQUFpQmxQLENBQWpCO0FBQ0ErTyxRQUFBQSxFQUFFLENBQUN6RCxRQUFILENBQVk0RCxHQUFaLEVBQWlCN08sQ0FBakI7QUFDSCxPQUhELE1BSUs7QUFDRHlPLFFBQUFBLEVBQUUsQ0FBQ3pFLE1BQUgsQ0FBVXJLLENBQVY7QUFDQStPLFFBQUFBLEVBQUUsQ0FBQzFFLE1BQUgsQ0FBVWhLLENBQVY7QUFDSDs7QUFDRCxVQUFJOE8sRUFBRSxHQUFHblAsQ0FBQyxDQUFDOEQsQ0FBWDtBQUNBLFVBQUlzTCxFQUFFLEdBQUdwUCxDQUFDLENBQUNtUCxFQUFFLEdBQUcsQ0FBTixDQUFWOztBQUNBLFVBQUlDLEVBQUUsSUFBSSxDQUFWLEVBQWE7QUFDVDtBQUNIOztBQUNELFVBQUlDLEVBQUUsR0FBR0QsRUFBRSxJQUFJLEtBQUssS0FBS0UsRUFBZCxDQUFGLElBQXdCSCxFQUFFLEdBQUcsQ0FBTixHQUFXblAsQ0FBQyxDQUFDbVAsRUFBRSxHQUFHLENBQU4sQ0FBRCxJQUFhLEtBQUtJLEVBQTdCLEdBQWtDLENBQXpELENBQVQ7QUFDQSxVQUFJQyxFQUFFLEdBQUcsS0FBS0MsRUFBTCxHQUFVSixFQUFuQjtBQUNBLFVBQUlLLEVBQUUsR0FBRyxDQUFDLEtBQUssS0FBS0osRUFBWCxJQUFpQkQsRUFBMUI7QUFDQSxVQUFJN0csQ0FBQyxHQUFHLEtBQUssS0FBSytHLEVBQWxCO0FBQ0EsVUFBSTVPLENBQUMsR0FBR04sQ0FBQyxDQUFDeUQsQ0FBVjtBQUNBLFVBQUkyQyxDQUFDLEdBQUc5RixDQUFDLEdBQUd3TyxFQUFaO0FBQ0EsVUFBSXJMLENBQUMsR0FBSTBJLENBQUMsSUFBSSxJQUFOLEdBQWNuRCxHQUFHLEVBQWpCLEdBQXNCbUQsQ0FBOUI7QUFDQXhNLE1BQUFBLENBQUMsQ0FBQ3NPLFNBQUYsQ0FBWTdILENBQVosRUFBZTNDLENBQWY7O0FBQ0EsVUFBSXpELENBQUMsQ0FBQ21KLFNBQUYsQ0FBWTFGLENBQVosS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJ6RCxRQUFBQSxDQUFDLENBQUNBLENBQUMsQ0FBQ3lELENBQUYsRUFBRCxDQUFELEdBQVcsQ0FBWDtBQUNBekQsUUFBQUEsQ0FBQyxDQUFDa0osS0FBRixDQUFRekYsQ0FBUixFQUFXekQsQ0FBWDtBQUNIOztBQUNEeUksTUFBQUEsVUFBVSxDQUFDMkUsR0FBWCxDQUFlYSxTQUFmLENBQXlCYSxFQUF6QixFQUE2QnJMLENBQTdCO0FBQ0FBLE1BQUFBLENBQUMsQ0FBQ3lGLEtBQUYsQ0FBUXZKLENBQVIsRUFBV0EsQ0FBWCxFQWhEK0MsQ0FnRGhDOztBQUNmLGFBQU9BLENBQUMsQ0FBQzhELENBQUYsR0FBTXFMLEVBQWIsRUFBaUI7QUFDYm5QLFFBQUFBLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDOEQsQ0FBRixFQUFELENBQUQsR0FBVyxDQUFYO0FBQ0g7O0FBQ0QsYUFBTyxFQUFFMkMsQ0FBRixJQUFPLENBQWQsRUFBaUI7QUFDYjtBQUNBLFlBQUlrSixFQUFFLEdBQUl0UCxDQUFDLENBQUMsRUFBRU0sQ0FBSCxDQUFELElBQVV5TyxFQUFYLEdBQWlCLEtBQUt6RixFQUF0QixHQUEyQnBDLElBQUksQ0FBQ29FLEtBQUwsQ0FBV3RMLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU82TyxFQUFQLEdBQVksQ0FBQ25QLENBQUMsQ0FBQ00sQ0FBQyxHQUFHLENBQUwsQ0FBRCxHQUFXNkgsQ0FBWixJQUFpQmtILEVBQXhDLENBQXBDOztBQUNBLFlBQUksQ0FBQ3JQLENBQUMsQ0FBQ00sQ0FBRCxDQUFELElBQVFYLENBQUMsQ0FBQzRPLEVBQUYsQ0FBSyxDQUFMLEVBQVFlLEVBQVIsRUFBWXRQLENBQVosRUFBZW9HLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIwSSxFQUFyQixDQUFULElBQXFDUSxFQUF6QyxFQUE2QztBQUFFO0FBQzNDM1AsVUFBQUEsQ0FBQyxDQUFDc08sU0FBRixDQUFZN0gsQ0FBWixFQUFlM0MsQ0FBZjtBQUNBekQsVUFBQUEsQ0FBQyxDQUFDa0osS0FBRixDQUFRekYsQ0FBUixFQUFXekQsQ0FBWDs7QUFDQSxpQkFBT0EsQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBTyxFQUFFZ1AsRUFBaEIsRUFBb0I7QUFDaEJ0UCxZQUFBQSxDQUFDLENBQUNrSixLQUFGLENBQVF6RixDQUFSLEVBQVd6RCxDQUFYO0FBQ0g7QUFDSjtBQUNKOztBQUNELFVBQUltTSxDQUFDLElBQUksSUFBVCxFQUFlO0FBQ1huTSxRQUFBQSxDQUFDLENBQUNrTyxTQUFGLENBQVlZLEVBQVosRUFBZ0IzQyxDQUFoQjs7QUFDQSxZQUFJd0MsRUFBRSxJQUFJQyxFQUFWLEVBQWM7QUFDVm5HLFVBQUFBLFVBQVUsQ0FBQ1EsSUFBWCxDQUFnQkMsS0FBaEIsQ0FBc0JpRCxDQUF0QixFQUF5QkEsQ0FBekI7QUFDSDtBQUNKOztBQUNEbk0sTUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNcUwsRUFBTjtBQUNBOU8sTUFBQUEsQ0FBQyxDQUFDZ08sS0FBRjs7QUFDQSxVQUFJYSxHQUFHLEdBQUcsQ0FBVixFQUFhO0FBQ1Q3TyxRQUFBQSxDQUFDLENBQUNnTCxRQUFGLENBQVc2RCxHQUFYLEVBQWdCN08sQ0FBaEI7QUFDSCxPQXpFOEMsQ0F5RTdDOzs7QUFDRixVQUFJMk8sRUFBRSxHQUFHLENBQVQsRUFBWTtBQUNSbEcsUUFBQUEsVUFBVSxDQUFDUSxJQUFYLENBQWdCQyxLQUFoQixDQUFzQmxKLENBQXRCLEVBQXlCQSxDQUF6QjtBQUNIO0FBQ0osS0E3RUQsQ0EvM0J3QyxDQTY4QnhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQnlOLFFBQXJCLEdBQWdDLFlBQVk7QUFDeEMsVUFBSSxLQUFLOUwsQ0FBTCxHQUFTLENBQWIsRUFBZ0I7QUFDWixlQUFPLENBQVA7QUFDSDs7QUFDRCxVQUFJL0QsQ0FBQyxHQUFHLEtBQUssQ0FBTCxDQUFSOztBQUNBLFVBQUksQ0FBQ0EsQ0FBQyxHQUFHLENBQUwsS0FBVyxDQUFmLEVBQWtCO0FBQ2QsZUFBTyxDQUFQO0FBQ0g7O0FBQ0QsVUFBSUMsQ0FBQyxHQUFHRCxDQUFDLEdBQUcsQ0FBWixDQVJ3QyxDQVF6Qjs7QUFDZkMsTUFBQUEsQ0FBQyxHQUFJQSxDQUFDLElBQUksSUFBSSxDQUFDRCxDQUFDLEdBQUcsR0FBTCxJQUFZQyxDQUFwQixDQUFGLEdBQTRCLEdBQWhDLENBVHdDLENBU0g7O0FBQ3JDQSxNQUFBQSxDQUFDLEdBQUlBLENBQUMsSUFBSSxJQUFJLENBQUNELENBQUMsR0FBRyxJQUFMLElBQWFDLENBQXJCLENBQUYsR0FBNkIsSUFBakMsQ0FWd0MsQ0FVRDs7QUFDdkNBLE1BQUFBLENBQUMsR0FBSUEsQ0FBQyxJQUFJLEtBQU0sQ0FBQ0QsQ0FBQyxHQUFHLE1BQUwsSUFBZUMsQ0FBaEIsR0FBcUIsTUFBMUIsQ0FBSixDQUFGLEdBQTRDLE1BQWhELENBWHdDLENBV2dCO0FBQ3hEO0FBQ0E7O0FBQ0FBLE1BQUFBLENBQUMsR0FBSUEsQ0FBQyxJQUFJLElBQUlELENBQUMsR0FBR0MsQ0FBSixHQUFRLEtBQUt1SyxFQUFyQixDQUFGLEdBQThCLEtBQUtBLEVBQXZDLENBZHdDLENBY0c7QUFDM0M7O0FBQ0EsYUFBUXZLLENBQUMsR0FBRyxDQUFMLEdBQVUsS0FBS3VLLEVBQUwsR0FBVXZLLENBQXBCLEdBQXdCLENBQUNBLENBQWhDO0FBQ0gsS0FqQkQsQ0F4OUJ3QyxDQTArQnhDO0FBQ0E7OztBQUNBOEksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjZILE1BQXJCLEdBQThCLFlBQVk7QUFDdEMsYUFBTyxDQUFFLEtBQUtsRyxDQUFMLEdBQVMsQ0FBVixHQUFnQixLQUFLLENBQUwsSUFBVSxDQUExQixHQUErQixLQUFLNUMsQ0FBckMsS0FBMkMsQ0FBbEQ7QUFDSCxLQUZELENBNStCd0MsQ0ErK0J4QztBQUNBOzs7QUFDQTRILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJnSSxHQUFyQixHQUEyQixVQUFVM0IsQ0FBVixFQUFhdUIsQ0FBYixFQUFnQjtBQUN2QyxVQUFJdkIsQ0FBQyxHQUFHLFVBQUosSUFBa0JBLENBQUMsR0FBRyxDQUExQixFQUE2QjtBQUN6QixlQUFPTSxVQUFVLENBQUMyRSxHQUFsQjtBQUNIOztBQUNELFVBQUlwTixDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxVQUFJK0QsRUFBRSxHQUFHL0QsR0FBRyxFQUFaO0FBQ0EsVUFBSXVELENBQUMsR0FBRzdDLENBQUMsQ0FBQytDLE9BQUYsQ0FBVSxJQUFWLENBQVI7QUFDQSxVQUFJbk0sQ0FBQyxHQUFHK0ksS0FBSyxDQUFDbEIsQ0FBRCxDQUFMLEdBQVcsQ0FBbkI7QUFDQW9FLE1BQUFBLENBQUMsQ0FBQ3ZDLE1BQUYsQ0FBU2hLLENBQVQ7O0FBQ0EsYUFBTyxFQUFFTSxDQUFGLElBQU8sQ0FBZCxFQUFpQjtBQUNib0osUUFBQUEsQ0FBQyxDQUFDaUQsS0FBRixDQUFRM00sQ0FBUixFQUFXK00sRUFBWDs7QUFDQSxZQUFJLENBQUM1RSxDQUFDLEdBQUksS0FBSzdILENBQVgsSUFBaUIsQ0FBckIsRUFBd0I7QUFDcEJvSixVQUFBQSxDQUFDLENBQUNrRCxLQUFGLENBQVFHLEVBQVIsRUFBWVIsQ0FBWixFQUFldk0sQ0FBZjtBQUNILFNBRkQsTUFHSztBQUNELGNBQUl5RCxDQUFDLEdBQUd6RCxDQUFSO0FBQ0FBLFVBQUFBLENBQUMsR0FBRytNLEVBQUo7QUFDQUEsVUFBQUEsRUFBRSxHQUFHdEosQ0FBTDtBQUNIO0FBQ0o7O0FBQ0QsYUFBT2lHLENBQUMsQ0FBQ3NELE1BQUYsQ0FBU2hOLENBQVQsQ0FBUDtBQUNILEtBckJELENBai9Cd0MsQ0F1Z0N4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIwTixTQUFyQixHQUFpQyxVQUFVeFAsQ0FBVixFQUFhO0FBQzFDLGFBQU9rSCxJQUFJLENBQUNvRSxLQUFMLENBQVdwRSxJQUFJLENBQUN1SSxHQUFMLEdBQVcsS0FBSzFHLEVBQWhCLEdBQXFCN0IsSUFBSSxDQUFDd0ksR0FBTCxDQUFTMVAsQ0FBVCxDQUFoQyxDQUFQO0FBQ0gsS0FGRCxDQXpnQ3dDLENBNGdDeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCK0csT0FBckIsR0FBK0IsVUFBVXpILENBQVYsRUFBYTtBQUN4QyxVQUFJQSxDQUFDLElBQUksSUFBVCxFQUFlO0FBQ1hBLFFBQUFBLENBQUMsR0FBRyxFQUFKO0FBQ0g7O0FBQ0QsVUFBSSxLQUFLaUosTUFBTCxNQUFpQixDQUFqQixJQUFzQmpKLENBQUMsR0FBRyxDQUExQixJQUErQkEsQ0FBQyxHQUFHLEVBQXZDLEVBQTJDO0FBQ3ZDLGVBQU8sR0FBUDtBQUNIOztBQUNELFVBQUl1TyxFQUFFLEdBQUcsS0FBS0gsU0FBTCxDQUFlcE8sQ0FBZixDQUFUO0FBQ0EsVUFBSWUsQ0FBQyxHQUFHK0UsSUFBSSxDQUFDbUcsR0FBTCxDQUFTak0sQ0FBVCxFQUFZdU8sRUFBWixDQUFSO0FBQ0EsVUFBSXhPLENBQUMsR0FBR2tMLEdBQUcsQ0FBQ2xLLENBQUQsQ0FBWDtBQUNBLFVBQUl4QyxDQUFDLEdBQUdxSixHQUFHLEVBQVg7QUFDQSxVQUFJVSxDQUFDLEdBQUdWLEdBQUcsRUFBWDtBQUNBLFVBQUloSixDQUFDLEdBQUcsRUFBUjtBQUNBLFdBQUt3SixRQUFMLENBQWNySSxDQUFkLEVBQWlCeEIsQ0FBakIsRUFBb0IrSixDQUFwQjs7QUFDQSxhQUFPL0osQ0FBQyxDQUFDMEssTUFBRixLQUFhLENBQXBCLEVBQXVCO0FBQ25CckssUUFBQUEsQ0FBQyxHQUFHLENBQUNtQyxDQUFDLEdBQUd1SCxDQUFDLENBQUNPLFFBQUYsRUFBTCxFQUFtQnJHLFFBQW5CLENBQTRCeEMsQ0FBNUIsRUFBK0IyRyxNQUEvQixDQUFzQyxDQUF0QyxJQUEyQy9ILENBQS9DO0FBQ0FMLFFBQUFBLENBQUMsQ0FBQzZKLFFBQUYsQ0FBV3JJLENBQVgsRUFBY3hCLENBQWQsRUFBaUIrSixDQUFqQjtBQUNIOztBQUNELGFBQU9BLENBQUMsQ0FBQ08sUUFBRixHQUFhckcsUUFBYixDQUFzQnhDLENBQXRCLElBQTJCcEIsQ0FBbEM7QUFDSCxLQW5CRCxDQTlnQ3dDLENBa2lDeEM7QUFDQTs7O0FBQ0F5SSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCOEwsU0FBckIsR0FBaUMsVUFBVS9NLENBQVYsRUFBYU8sQ0FBYixFQUFnQjtBQUM3QyxXQUFLdU0sT0FBTCxDQUFhLENBQWI7O0FBQ0EsVUFBSXZNLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWEEsUUFBQUEsQ0FBQyxHQUFHLEVBQUo7QUFDSDs7QUFDRCxVQUFJdU8sRUFBRSxHQUFHLEtBQUtILFNBQUwsQ0FBZXBPLENBQWYsQ0FBVDtBQUNBLFVBQUlELENBQUMsR0FBRytGLElBQUksQ0FBQ21HLEdBQUwsQ0FBU2pNLENBQVQsRUFBWXVPLEVBQVosQ0FBUjtBQUNBLFVBQUk5QixFQUFFLEdBQUcsS0FBVDtBQUNBLFVBQUl6SCxDQUFDLEdBQUcsQ0FBUjtBQUNBLFVBQUl5RyxDQUFDLEdBQUcsQ0FBUjs7QUFDQSxXQUFLLElBQUl2TSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHTyxDQUFDLENBQUNKLE1BQXRCLEVBQThCLEVBQUVILENBQWhDLEVBQW1DO0FBQy9CLFlBQUlaLENBQUMsR0FBR3FPLEtBQUssQ0FBQ2xOLENBQUQsRUFBSVAsQ0FBSixDQUFiOztBQUNBLFlBQUlaLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxjQUFJbUIsQ0FBQyxDQUFDckIsTUFBRixDQUFTYyxDQUFULEtBQWUsR0FBZixJQUFzQixLQUFLK0osTUFBTCxNQUFpQixDQUEzQyxFQUE4QztBQUMxQ3dELFlBQUFBLEVBQUUsR0FBRyxJQUFMO0FBQ0g7O0FBQ0Q7QUFDSDs7QUFDRGhCLFFBQUFBLENBQUMsR0FBR3pMLENBQUMsR0FBR3lMLENBQUosR0FBUW5OLENBQVo7O0FBQ0EsWUFBSSxFQUFFMEcsQ0FBRixJQUFPdUosRUFBWCxFQUFlO0FBQ1gsZUFBS0MsU0FBTCxDQUFlek8sQ0FBZjtBQUNBLGVBQUswTyxVQUFMLENBQWdCaEQsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDQXpHLFVBQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0F5RyxVQUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSXpHLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxhQUFLd0osU0FBTCxDQUFlMUksSUFBSSxDQUFDbUcsR0FBTCxDQUFTak0sQ0FBVCxFQUFZZ0YsQ0FBWixDQUFmO0FBQ0EsYUFBS3lKLFVBQUwsQ0FBZ0JoRCxDQUFoQixFQUFtQixDQUFuQjtBQUNIOztBQUNELFVBQUlnQixFQUFKLEVBQVE7QUFDSnBGLFFBQUFBLFVBQVUsQ0FBQ1EsSUFBWCxDQUFnQkMsS0FBaEIsQ0FBc0IsSUFBdEIsRUFBNEIsSUFBNUI7QUFDSDtBQUNKLEtBakNELENBcGlDd0MsQ0Fza0N4QztBQUNBOzs7QUFDQVQsSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjRHLFVBQXJCLEdBQWtDLFVBQVV2RyxDQUFWLEVBQWFmLENBQWIsRUFBZ0JiLENBQWhCLEVBQW1CO0FBQ2pELFVBQUksWUFBWSxPQUFPYSxDQUF2QixFQUEwQjtBQUN0QjtBQUNBLFlBQUllLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUCxlQUFLd0wsT0FBTCxDQUFhLENBQWI7QUFDSCxTQUZELE1BR0s7QUFDRCxlQUFLakYsVUFBTCxDQUFnQnZHLENBQWhCLEVBQW1CNUIsQ0FBbkI7O0FBQ0EsY0FBSSxDQUFDLEtBQUs4SyxPQUFMLENBQWFsSixDQUFDLEdBQUcsQ0FBakIsQ0FBTCxFQUEwQjtBQUN0QjtBQUNBLGlCQUFLdUksU0FBTCxDQUFlakMsVUFBVSxDQUFDMkUsR0FBWCxDQUFlckMsU0FBZixDQUF5QjVJLENBQUMsR0FBRyxDQUE3QixDQUFmLEVBQWdEdkMsS0FBaEQsRUFBdUQsSUFBdkQ7QUFDSDs7QUFDRCxjQUFJLEtBQUsrSixNQUFMLEVBQUosRUFBbUI7QUFDZixpQkFBS2tHLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDSCxXQVJBLENBUUM7OztBQUNGLGlCQUFPLENBQUMsS0FBS3JDLGVBQUwsQ0FBcUJwTSxDQUFyQixDQUFSLEVBQWlDO0FBQzdCLGlCQUFLeU8sVUFBTCxDQUFnQixDQUFoQixFQUFtQixDQUFuQjs7QUFDQSxnQkFBSSxLQUFLekcsU0FBTCxLQUFtQmpILENBQXZCLEVBQTBCO0FBQ3RCLG1CQUFLK0csS0FBTCxDQUFXVCxVQUFVLENBQUMyRSxHQUFYLENBQWVyQyxTQUFmLENBQXlCNUksQ0FBQyxHQUFHLENBQTdCLENBQVgsRUFBNEMsSUFBNUM7QUFDSDtBQUNKO0FBQ0o7QUFDSixPQXJCRCxNQXNCSztBQUNEO0FBQ0EsWUFBSXpDLENBQUMsR0FBRyxFQUFSO0FBQ0EsWUFBSStELENBQUMsR0FBR3RCLENBQUMsR0FBRyxDQUFaO0FBQ0F6QyxRQUFBQSxDQUFDLENBQUNlLE1BQUYsR0FBVyxDQUFDMEIsQ0FBQyxJQUFJLENBQU4sSUFBVyxDQUF0QjtBQUNBZixRQUFBQSxDQUFDLENBQUMwTyxTQUFGLENBQVlwUSxDQUFaOztBQUNBLFlBQUkrRCxDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1AvRCxVQUFBQSxDQUFDLENBQUMsQ0FBRCxDQUFELElBQVMsQ0FBQyxLQUFLK0QsQ0FBTixJQUFXLENBQXBCO0FBQ0gsU0FGRCxNQUdLO0FBQ0QvRCxVQUFBQSxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sQ0FBUDtBQUNIOztBQUNELGFBQUtpSixVQUFMLENBQWdCakosQ0FBaEIsRUFBbUIsR0FBbkI7QUFDSDtBQUNKLEtBckNELENBeGtDd0MsQ0E4bUN4QztBQUNBOzs7QUFDQStJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUI0SSxTQUFyQixHQUFpQyxVQUFVdkksQ0FBVixFQUFhNE4sRUFBYixFQUFpQi9QLENBQWpCLEVBQW9CO0FBQ2pELFVBQUlNLENBQUo7QUFDQSxVQUFJMFAsQ0FBSjtBQUNBLFVBQUkvTSxDQUFDLEdBQUdpRSxJQUFJLENBQUNzRCxHQUFMLENBQVNySSxDQUFDLENBQUNzQixDQUFYLEVBQWMsS0FBS0EsQ0FBbkIsQ0FBUjs7QUFDQSxXQUFLbkQsQ0FBQyxHQUFHLENBQVQsRUFBWUEsQ0FBQyxHQUFHMkMsQ0FBaEIsRUFBbUIsRUFBRTNDLENBQXJCLEVBQXdCO0FBQ3BCTixRQUFBQSxDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPeVAsRUFBRSxDQUFDLEtBQUt6UCxDQUFMLENBQUQsRUFBVTZCLENBQUMsQ0FBQzdCLENBQUQsQ0FBWCxDQUFUO0FBQ0g7O0FBQ0QsVUFBSTZCLENBQUMsQ0FBQ3NCLENBQUYsR0FBTSxLQUFLQSxDQUFmLEVBQWtCO0FBQ2R1TSxRQUFBQSxDQUFDLEdBQUc3TixDQUFDLENBQUN0QixDQUFGLEdBQU0sS0FBS3lJLEVBQWY7O0FBQ0EsYUFBS2hKLENBQUMsR0FBRzJDLENBQVQsRUFBWTNDLENBQUMsR0FBRyxLQUFLbUQsQ0FBckIsRUFBd0IsRUFBRW5ELENBQTFCLEVBQTZCO0FBQ3pCTixVQUFBQSxDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPeVAsRUFBRSxDQUFDLEtBQUt6UCxDQUFMLENBQUQsRUFBVTBQLENBQVYsQ0FBVDtBQUNIOztBQUNEaFEsUUFBQUEsQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLEtBQUtBLENBQVg7QUFDSCxPQU5ELE1BT0s7QUFDRHVNLFFBQUFBLENBQUMsR0FBRyxLQUFLblAsQ0FBTCxHQUFTLEtBQUt5SSxFQUFsQjs7QUFDQSxhQUFLaEosQ0FBQyxHQUFHMkMsQ0FBVCxFQUFZM0MsQ0FBQyxHQUFHNkIsQ0FBQyxDQUFDc0IsQ0FBbEIsRUFBcUIsRUFBRW5ELENBQXZCLEVBQTBCO0FBQ3RCTixVQUFBQSxDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPeVAsRUFBRSxDQUFDQyxDQUFELEVBQUk3TixDQUFDLENBQUM3QixDQUFELENBQUwsQ0FBVDtBQUNIOztBQUNETixRQUFBQSxDQUFDLENBQUN5RCxDQUFGLEdBQU10QixDQUFDLENBQUNzQixDQUFSO0FBQ0g7O0FBQ0R6RCxNQUFBQSxDQUFDLENBQUNhLENBQUYsR0FBTWtQLEVBQUUsQ0FBQyxLQUFLbFAsQ0FBTixFQUFTc0IsQ0FBQyxDQUFDdEIsQ0FBWCxDQUFSO0FBQ0FiLE1BQUFBLENBQUMsQ0FBQ2dPLEtBQUY7QUFDSCxLQXZCRCxDQWhuQ3dDLENBd29DeEM7QUFDQTs7O0FBQ0F2RixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCMEosU0FBckIsR0FBaUMsVUFBVWpNLENBQVYsRUFBYXdRLEVBQWIsRUFBaUI7QUFDOUMsVUFBSS9QLENBQUMsR0FBR3lJLFVBQVUsQ0FBQzJFLEdBQVgsQ0FBZXJDLFNBQWYsQ0FBeUJ4TCxDQUF6QixDQUFSO0FBQ0EsV0FBS21MLFNBQUwsQ0FBZTFLLENBQWYsRUFBa0IrUCxFQUFsQixFQUFzQi9QLENBQXRCO0FBQ0EsYUFBT0EsQ0FBUDtBQUNILEtBSkQsQ0Exb0N3QyxDQStvQ3hDO0FBQ0E7OztBQUNBeUksSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQjhKLEtBQXJCLEdBQTZCLFVBQVV6SixDQUFWLEVBQWFuQyxDQUFiLEVBQWdCO0FBQ3pDLFVBQUlNLENBQUMsR0FBRyxDQUFSO0FBQ0EsVUFBSUMsQ0FBQyxHQUFHLENBQVI7QUFDQSxVQUFJMEMsQ0FBQyxHQUFHaUUsSUFBSSxDQUFDc0QsR0FBTCxDQUFTckksQ0FBQyxDQUFDc0IsQ0FBWCxFQUFjLEtBQUtBLENBQW5CLENBQVI7O0FBQ0EsYUFBT25ELENBQUMsR0FBRzJDLENBQVgsRUFBYztBQUNWMUMsUUFBQUEsQ0FBQyxJQUFJLEtBQUtELENBQUwsSUFBVTZCLENBQUMsQ0FBQzdCLENBQUQsQ0FBaEI7QUFDQU4sUUFBQUEsQ0FBQyxDQUFDTSxDQUFDLEVBQUYsQ0FBRCxHQUFTQyxDQUFDLEdBQUcsS0FBSytJLEVBQWxCO0FBQ0EvSSxRQUFBQSxDQUFDLEtBQUssS0FBS3dJLEVBQVg7QUFDSDs7QUFDRCxVQUFJNUcsQ0FBQyxDQUFDc0IsQ0FBRixHQUFNLEtBQUtBLENBQWYsRUFBa0I7QUFDZGxELFFBQUFBLENBQUMsSUFBSTRCLENBQUMsQ0FBQ3RCLENBQVA7O0FBQ0EsZUFBT1AsQ0FBQyxHQUFHLEtBQUttRCxDQUFoQixFQUFtQjtBQUNmbEQsVUFBQUEsQ0FBQyxJQUFJLEtBQUtELENBQUwsQ0FBTDtBQUNBTixVQUFBQSxDQUFDLENBQUNNLENBQUMsRUFBRixDQUFELEdBQVNDLENBQUMsR0FBRyxLQUFLK0ksRUFBbEI7QUFDQS9JLFVBQUFBLENBQUMsS0FBSyxLQUFLd0ksRUFBWDtBQUNIOztBQUNEeEksUUFBQUEsQ0FBQyxJQUFJLEtBQUtNLENBQVY7QUFDSCxPQVJELE1BU0s7QUFDRE4sUUFBQUEsQ0FBQyxJQUFJLEtBQUtNLENBQVY7O0FBQ0EsZUFBT1AsQ0FBQyxHQUFHNkIsQ0FBQyxDQUFDc0IsQ0FBYixFQUFnQjtBQUNabEQsVUFBQUEsQ0FBQyxJQUFJNEIsQ0FBQyxDQUFDN0IsQ0FBRCxDQUFOO0FBQ0FOLFVBQUFBLENBQUMsQ0FBQ00sQ0FBQyxFQUFGLENBQUQsR0FBU0MsQ0FBQyxHQUFHLEtBQUsrSSxFQUFsQjtBQUNBL0ksVUFBQUEsQ0FBQyxLQUFLLEtBQUt3SSxFQUFYO0FBQ0g7O0FBQ0R4SSxRQUFBQSxDQUFDLElBQUk0QixDQUFDLENBQUN0QixDQUFQO0FBQ0g7O0FBQ0RiLE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFPTixDQUFDLEdBQUcsQ0FBTCxHQUFVLENBQUMsQ0FBWCxHQUFlLENBQXJCOztBQUNBLFVBQUlBLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUFAsUUFBQUEsQ0FBQyxDQUFDTSxDQUFDLEVBQUYsQ0FBRCxHQUFTQyxDQUFUO0FBQ0gsT0FGRCxNQUdLLElBQUlBLENBQUMsR0FBRyxDQUFDLENBQVQsRUFBWTtBQUNiUCxRQUFBQSxDQUFDLENBQUNNLENBQUMsRUFBRixDQUFELEdBQVMsS0FBSzRKLEVBQUwsR0FBVTNKLENBQW5CO0FBQ0g7O0FBQ0RQLE1BQUFBLENBQUMsQ0FBQ3lELENBQUYsR0FBTW5ELENBQU47QUFDQU4sTUFBQUEsQ0FBQyxDQUFDZ08sS0FBRjtBQUNILEtBcENELENBanBDd0MsQ0FzckN4QztBQUNBOzs7QUFDQXZGLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUI4TixTQUFyQixHQUFpQyxVQUFVclEsQ0FBVixFQUFhO0FBQzFDLFdBQUssS0FBS2tFLENBQVYsSUFBZSxLQUFLOEssRUFBTCxDQUFRLENBQVIsRUFBV2hQLENBQUMsR0FBRyxDQUFmLEVBQWtCLElBQWxCLEVBQXdCLENBQXhCLEVBQTJCLENBQTNCLEVBQThCLEtBQUtrRSxDQUFuQyxDQUFmO0FBQ0EsUUFBRSxLQUFLQSxDQUFQO0FBQ0EsV0FBS3VLLEtBQUw7QUFDSCxLQUpELENBeHJDd0MsQ0E2ckN4QztBQUNBOzs7QUFDQXZGLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIrTixVQUFyQixHQUFrQyxVQUFVdFEsQ0FBVixFQUFhc04sQ0FBYixFQUFnQjtBQUM5QyxVQUFJdE4sQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNSO0FBQ0g7O0FBQ0QsYUFBTyxLQUFLa0UsQ0FBTCxJQUFVb0osQ0FBakIsRUFBb0I7QUFDaEIsYUFBSyxLQUFLcEosQ0FBTCxFQUFMLElBQWlCLENBQWpCO0FBQ0g7O0FBQ0QsV0FBS29KLENBQUwsS0FBV3ROLENBQVg7O0FBQ0EsYUFBTyxLQUFLc04sQ0FBTCxLQUFXLEtBQUszQyxFQUF2QixFQUEyQjtBQUN2QixhQUFLMkMsQ0FBTCxLQUFXLEtBQUszQyxFQUFoQjs7QUFDQSxZQUFJLEVBQUUyQyxDQUFGLElBQU8sS0FBS3BKLENBQWhCLEVBQW1CO0FBQ2YsZUFBSyxLQUFLQSxDQUFMLEVBQUwsSUFBaUIsQ0FBakI7QUFDSDs7QUFDRCxVQUFFLEtBQUtvSixDQUFMLENBQUY7QUFDSDtBQUNKLEtBZkQsQ0EvckN3QyxDQStzQ3hDO0FBQ0E7QUFDQTs7O0FBQ0FwRSxJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCbU8sZUFBckIsR0FBdUMsVUFBVTlOLENBQVYsRUFBYTVDLENBQWIsRUFBZ0JTLENBQWhCLEVBQW1CO0FBQ3RELFVBQUlNLENBQUMsR0FBRzRHLElBQUksQ0FBQ3NELEdBQUwsQ0FBUyxLQUFLL0csQ0FBTCxHQUFTdEIsQ0FBQyxDQUFDc0IsQ0FBcEIsRUFBdUJsRSxDQUF2QixDQUFSO0FBQ0FTLE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFNLENBQU4sQ0FGc0QsQ0FFN0M7O0FBQ1RiLE1BQUFBLENBQUMsQ0FBQ3lELENBQUYsR0FBTW5ELENBQU47O0FBQ0EsYUFBT0EsQ0FBQyxHQUFHLENBQVgsRUFBYztBQUNWTixRQUFBQSxDQUFDLENBQUMsRUFBRU0sQ0FBSCxDQUFELEdBQVMsQ0FBVDtBQUNIOztBQUNELFdBQUssSUFBSThGLENBQUMsR0FBR3BHLENBQUMsQ0FBQ3lELENBQUYsR0FBTSxLQUFLQSxDQUF4QixFQUEyQm5ELENBQUMsR0FBRzhGLENBQS9CLEVBQWtDLEVBQUU5RixDQUFwQyxFQUF1QztBQUNuQ04sUUFBQUEsQ0FBQyxDQUFDTSxDQUFDLEdBQUcsS0FBS21ELENBQVYsQ0FBRCxHQUFnQixLQUFLOEssRUFBTCxDQUFRLENBQVIsRUFBV3BNLENBQUMsQ0FBQzdCLENBQUQsQ0FBWixFQUFpQk4sQ0FBakIsRUFBb0JNLENBQXBCLEVBQXVCLENBQXZCLEVBQTBCLEtBQUttRCxDQUEvQixDQUFoQjtBQUNIOztBQUNELFdBQUssSUFBSTJDLENBQUMsR0FBR2MsSUFBSSxDQUFDc0QsR0FBTCxDQUFTckksQ0FBQyxDQUFDc0IsQ0FBWCxFQUFjbEUsQ0FBZCxDQUFiLEVBQStCZSxDQUFDLEdBQUc4RixDQUFuQyxFQUFzQyxFQUFFOUYsQ0FBeEMsRUFBMkM7QUFDdkMsYUFBS2lPLEVBQUwsQ0FBUSxDQUFSLEVBQVdwTSxDQUFDLENBQUM3QixDQUFELENBQVosRUFBaUJOLENBQWpCLEVBQW9CTSxDQUFwQixFQUF1QixDQUF2QixFQUEwQmYsQ0FBQyxHQUFHZSxDQUE5QjtBQUNIOztBQUNETixNQUFBQSxDQUFDLENBQUNnTyxLQUFGO0FBQ0gsS0FkRCxDQWx0Q3dDLENBaXVDeEM7QUFDQTtBQUNBOzs7QUFDQXZGLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJvTyxlQUFyQixHQUF1QyxVQUFVL04sQ0FBVixFQUFhNUMsQ0FBYixFQUFnQlMsQ0FBaEIsRUFBbUI7QUFDdEQsUUFBRVQsQ0FBRjtBQUNBLFVBQUllLENBQUMsR0FBR04sQ0FBQyxDQUFDeUQsQ0FBRixHQUFNLEtBQUtBLENBQUwsR0FBU3RCLENBQUMsQ0FBQ3NCLENBQVgsR0FBZWxFLENBQTdCO0FBQ0FTLE1BQUFBLENBQUMsQ0FBQ2EsQ0FBRixHQUFNLENBQU4sQ0FIc0QsQ0FHN0M7O0FBQ1QsYUFBTyxFQUFFUCxDQUFGLElBQU8sQ0FBZCxFQUFpQjtBQUNiTixRQUFBQSxDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPLENBQVA7QUFDSDs7QUFDRCxXQUFLQSxDQUFDLEdBQUc0RyxJQUFJLENBQUMvRCxHQUFMLENBQVM1RCxDQUFDLEdBQUcsS0FBS2tFLENBQWxCLEVBQXFCLENBQXJCLENBQVQsRUFBa0NuRCxDQUFDLEdBQUc2QixDQUFDLENBQUNzQixDQUF4QyxFQUEyQyxFQUFFbkQsQ0FBN0MsRUFBZ0Q7QUFDNUNOLFFBQUFBLENBQUMsQ0FBQyxLQUFLeUQsQ0FBTCxHQUFTbkQsQ0FBVCxHQUFhZixDQUFkLENBQUQsR0FBb0IsS0FBS2dQLEVBQUwsQ0FBUWhQLENBQUMsR0FBR2UsQ0FBWixFQUFlNkIsQ0FBQyxDQUFDN0IsQ0FBRCxDQUFoQixFQUFxQk4sQ0FBckIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBM0IsRUFBOEIsS0FBS3lELENBQUwsR0FBU25ELENBQVQsR0FBYWYsQ0FBM0MsQ0FBcEI7QUFDSDs7QUFDRFMsTUFBQUEsQ0FBQyxDQUFDZ08sS0FBRjtBQUNBaE8sTUFBQUEsQ0FBQyxDQUFDa08sU0FBRixDQUFZLENBQVosRUFBZWxPLENBQWY7QUFDSCxLQVpELENBcHVDd0MsQ0FpdkN4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUIyTCxNQUFyQixHQUE4QixVQUFVbE8sQ0FBVixFQUFhO0FBQ3ZDLFVBQUlBLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDUixlQUFPLENBQVA7QUFDSDs7QUFDRCxVQUFJNEIsQ0FBQyxHQUFHLEtBQUsrSSxFQUFMLEdBQVUzSyxDQUFsQjtBQUNBLFVBQUlTLENBQUMsR0FBSSxLQUFLYSxDQUFMLEdBQVMsQ0FBVixHQUFldEIsQ0FBQyxHQUFHLENBQW5CLEdBQXVCLENBQS9COztBQUNBLFVBQUksS0FBS2tFLENBQUwsR0FBUyxDQUFiLEVBQWdCO0FBQ1osWUFBSXRDLENBQUMsSUFBSSxDQUFULEVBQVk7QUFDUm5CLFVBQUFBLENBQUMsR0FBRyxLQUFLLENBQUwsSUFBVVQsQ0FBZDtBQUNILFNBRkQsTUFHSztBQUNELGVBQUssSUFBSWUsQ0FBQyxHQUFHLEtBQUttRCxDQUFMLEdBQVMsQ0FBdEIsRUFBeUJuRCxDQUFDLElBQUksQ0FBOUIsRUFBaUMsRUFBRUEsQ0FBbkMsRUFBc0M7QUFDbENOLFlBQUFBLENBQUMsR0FBRyxDQUFDbUIsQ0FBQyxHQUFHbkIsQ0FBSixHQUFRLEtBQUtNLENBQUwsQ0FBVCxJQUFvQmYsQ0FBeEI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsYUFBT1MsQ0FBUDtBQUNILEtBakJELENBbnZDd0MsQ0Fxd0N4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUI0TCxXQUFyQixHQUFtQyxVQUFVakssQ0FBVixFQUFhO0FBQzVDLFVBQUkwTSxFQUFFLEdBQUcsS0FBS3RFLFFBQUwsQ0FBY3BELFVBQVUsQ0FBQzJFLEdBQXpCLENBQVQ7QUFDQSxVQUFJdE0sQ0FBQyxHQUFHcVAsRUFBRSxDQUFDaEYsZUFBSCxFQUFSOztBQUNBLFVBQUlySyxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ1IsZUFBTyxLQUFQO0FBQ0g7O0FBQ0QsVUFBSWQsQ0FBQyxHQUFHbVEsRUFBRSxDQUFDakYsVUFBSCxDQUFjcEssQ0FBZCxDQUFSO0FBQ0EyQyxNQUFBQSxDQUFDLEdBQUlBLENBQUMsR0FBRyxDQUFMLElBQVcsQ0FBZjs7QUFDQSxVQUFJQSxDQUFDLEdBQUc4RSxTQUFTLENBQUM5SCxNQUFsQixFQUEwQjtBQUN0QmdELFFBQUFBLENBQUMsR0FBRzhFLFNBQVMsQ0FBQzlILE1BQWQ7QUFDSDs7QUFDRCxVQUFJMEIsQ0FBQyxHQUFHNkcsR0FBRyxFQUFYOztBQUNBLFdBQUssSUFBSTFJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdtRCxDQUFwQixFQUF1QixFQUFFbkQsQ0FBekIsRUFBNEI7QUFDeEI7QUFDQTZCLFFBQUFBLENBQUMsQ0FBQ3dMLE9BQUYsQ0FBVXBGLFNBQVMsQ0FBQ3JCLElBQUksQ0FBQ29FLEtBQUwsQ0FBV3BFLElBQUksQ0FBQ2tKLE1BQUwsS0FBZ0I3SCxTQUFTLENBQUM5SCxNQUFyQyxDQUFELENBQW5CO0FBQ0EsWUFBSWQsQ0FBQyxHQUFHd0MsQ0FBQyxDQUFDaUssTUFBRixDQUFTcE0sQ0FBVCxFQUFZLElBQVosQ0FBUjs7QUFDQSxZQUFJTCxDQUFDLENBQUN3SixTQUFGLENBQVlWLFVBQVUsQ0FBQzJFLEdBQXZCLEtBQStCLENBQS9CLElBQW9Dek4sQ0FBQyxDQUFDd0osU0FBRixDQUFZZ0gsRUFBWixLQUFtQixDQUEzRCxFQUE4RDtBQUMxRCxjQUFJL0osQ0FBQyxHQUFHLENBQVI7O0FBQ0EsaUJBQU9BLENBQUMsS0FBS3RGLENBQU4sSUFBV25CLENBQUMsQ0FBQ3dKLFNBQUYsQ0FBWWdILEVBQVosS0FBbUIsQ0FBckMsRUFBd0M7QUFDcEN4USxZQUFBQSxDQUFDLEdBQUdBLENBQUMsQ0FBQzhKLFNBQUYsQ0FBWSxDQUFaLEVBQWUsSUFBZixDQUFKOztBQUNBLGdCQUFJOUosQ0FBQyxDQUFDd0osU0FBRixDQUFZVixVQUFVLENBQUMyRSxHQUF2QixLQUErQixDQUFuQyxFQUFzQztBQUNsQyxxQkFBTyxLQUFQO0FBQ0g7QUFDSjs7QUFDRCxjQUFJek4sQ0FBQyxDQUFDd0osU0FBRixDQUFZZ0gsRUFBWixLQUFtQixDQUF2QixFQUEwQjtBQUN0QixtQkFBTyxLQUFQO0FBQ0g7QUFDSjtBQUNKOztBQUNELGFBQU8sSUFBUDtBQUNILEtBOUJELENBdndDd0MsQ0FzeUN4QztBQUNBOzs7QUFDQTFILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ1TyxNQUFyQixHQUE4QixZQUFZO0FBQ3RDLFVBQUlyUSxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQSxXQUFLd0YsUUFBTCxDQUFjeE8sQ0FBZDtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUpELENBeHlDd0MsQ0E2eUN4QztBQUNBOzs7QUFDQXlJLElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJ3TyxJQUFyQixHQUE0QixVQUFVbk8sQ0FBVixFQUFhb08sUUFBYixFQUF1QjtBQUMvQyxVQUFJN1EsQ0FBQyxHQUFJLEtBQUttQixDQUFMLEdBQVMsQ0FBVixHQUFlLEtBQUsrSCxNQUFMLEVBQWYsR0FBK0IsS0FBS21CLEtBQUwsRUFBdkM7QUFDQSxVQUFJcEssQ0FBQyxHQUFJd0MsQ0FBQyxDQUFDdEIsQ0FBRixHQUFNLENBQVAsR0FBWXNCLENBQUMsQ0FBQ3lHLE1BQUYsRUFBWixHQUF5QnpHLENBQUMsQ0FBQzRILEtBQUYsRUFBakM7O0FBQ0EsVUFBSXJLLENBQUMsQ0FBQ3lKLFNBQUYsQ0FBWXhKLENBQVosSUFBaUIsQ0FBckIsRUFBd0I7QUFDcEIsWUFBSThELENBQUMsR0FBRy9ELENBQVI7QUFDQUEsUUFBQUEsQ0FBQyxHQUFHQyxDQUFKO0FBQ0FBLFFBQUFBLENBQUMsR0FBRzhELENBQUo7QUFDSDs7QUFDRCxVQUFJbkQsQ0FBQyxHQUFHWixDQUFDLENBQUN5TCxlQUFGLEVBQVI7QUFDQSxVQUFJb0IsQ0FBQyxHQUFHNU0sQ0FBQyxDQUFDd0wsZUFBRixFQUFSOztBQUNBLFVBQUlvQixDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1BnRSxRQUFBQSxRQUFRLENBQUM3USxDQUFELENBQVI7QUFDQTtBQUNIOztBQUNELFVBQUlZLENBQUMsR0FBR2lNLENBQVIsRUFBVztBQUNQQSxRQUFBQSxDQUFDLEdBQUdqTSxDQUFKO0FBQ0g7O0FBQ0QsVUFBSWlNLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUDdNLFFBQUFBLENBQUMsQ0FBQ3NMLFFBQUYsQ0FBV3VCLENBQVgsRUFBYzdNLENBQWQ7QUFDQUMsUUFBQUEsQ0FBQyxDQUFDcUwsUUFBRixDQUFXdUIsQ0FBWCxFQUFjNU0sQ0FBZDtBQUNILE9BcEI4QyxDQXFCL0M7OztBQUNBLFVBQUk2USxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFZO0FBQ3BCLFlBQUksQ0FBQ2xRLENBQUMsR0FBR1osQ0FBQyxDQUFDeUwsZUFBRixFQUFMLElBQTRCLENBQWhDLEVBQW1DO0FBQy9CekwsVUFBQUEsQ0FBQyxDQUFDc0wsUUFBRixDQUFXMUssQ0FBWCxFQUFjWixDQUFkO0FBQ0g7O0FBQ0QsWUFBSSxDQUFDWSxDQUFDLEdBQUdYLENBQUMsQ0FBQ3dMLGVBQUYsRUFBTCxJQUE0QixDQUFoQyxFQUFtQztBQUMvQnhMLFVBQUFBLENBQUMsQ0FBQ3FMLFFBQUYsQ0FBVzFLLENBQVgsRUFBY1gsQ0FBZDtBQUNIOztBQUNELFlBQUlELENBQUMsQ0FBQ3lKLFNBQUYsQ0FBWXhKLENBQVosS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJELFVBQUFBLENBQUMsQ0FBQ3dKLEtBQUYsQ0FBUXZKLENBQVIsRUFBV0QsQ0FBWDtBQUNBQSxVQUFBQSxDQUFDLENBQUNzTCxRQUFGLENBQVcsQ0FBWCxFQUFjdEwsQ0FBZDtBQUNILFNBSEQsTUFJSztBQUNEQyxVQUFBQSxDQUFDLENBQUN1SixLQUFGLENBQVF4SixDQUFSLEVBQVdDLENBQVg7QUFDQUEsVUFBQUEsQ0FBQyxDQUFDcUwsUUFBRixDQUFXLENBQVgsRUFBY3JMLENBQWQ7QUFDSDs7QUFDRCxZQUFJLEVBQUVELENBQUMsQ0FBQzJLLE1BQUYsS0FBYSxDQUFmLENBQUosRUFBdUI7QUFDbkIsY0FBSWtDLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDUDVNLFlBQUFBLENBQUMsQ0FBQ3NMLFFBQUYsQ0FBV3NCLENBQVgsRUFBYzVNLENBQWQ7QUFDSDs7QUFDRDhRLFVBQUFBLFVBQVUsQ0FBQyxZQUFZO0FBQUVGLFlBQUFBLFFBQVEsQ0FBQzVRLENBQUQsQ0FBUjtBQUFjLFdBQTdCLEVBQStCLENBQS9CLENBQVYsQ0FKbUIsQ0FJMEI7QUFDaEQsU0FMRCxNQU1LO0FBQ0Q4USxVQUFBQSxVQUFVLENBQUNELEtBQUQsRUFBUSxDQUFSLENBQVY7QUFDSDtBQUNKLE9BeEJEOztBQXlCQUMsTUFBQUEsVUFBVSxDQUFDRCxLQUFELEVBQVEsRUFBUixDQUFWO0FBQ0gsS0FoREQsQ0EveUN3QyxDQWcyQ3hDOzs7QUFDQS9ILElBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUI0TyxlQUFyQixHQUF1QyxVQUFVdk8sQ0FBVixFQUFhZixDQUFiLEVBQWdCYixDQUFoQixFQUFtQmdRLFFBQW5CLEVBQTZCO0FBQ2hFLFVBQUksWUFBWSxPQUFPblAsQ0FBdkIsRUFBMEI7QUFDdEIsWUFBSWUsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQLGVBQUt3TCxPQUFMLENBQWEsQ0FBYjtBQUNILFNBRkQsTUFHSztBQUNELGVBQUtqRixVQUFMLENBQWdCdkcsQ0FBaEIsRUFBbUI1QixDQUFuQjs7QUFDQSxjQUFJLENBQUMsS0FBSzhLLE9BQUwsQ0FBYWxKLENBQUMsR0FBRyxDQUFqQixDQUFMLEVBQTBCO0FBQ3RCLGlCQUFLdUksU0FBTCxDQUFlakMsVUFBVSxDQUFDMkUsR0FBWCxDQUFlckMsU0FBZixDQUF5QjVJLENBQUMsR0FBRyxDQUE3QixDQUFmLEVBQWdEdkMsS0FBaEQsRUFBdUQsSUFBdkQ7QUFDSDs7QUFDRCxjQUFJLEtBQUsrSixNQUFMLEVBQUosRUFBbUI7QUFDZixpQkFBS2tHLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDSDs7QUFDRCxjQUFJYyxLQUFLLEdBQUcsSUFBWjs7QUFDQSxjQUFJQyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxHQUFZO0FBQ3ZCRCxZQUFBQSxLQUFLLENBQUNkLFVBQU4sQ0FBaUIsQ0FBakIsRUFBb0IsQ0FBcEI7O0FBQ0EsZ0JBQUljLEtBQUssQ0FBQ3ZILFNBQU4sS0FBb0JqSCxDQUF4QixFQUEyQjtBQUN2QndPLGNBQUFBLEtBQUssQ0FBQ3pILEtBQU4sQ0FBWVQsVUFBVSxDQUFDMkUsR0FBWCxDQUFlckMsU0FBZixDQUF5QjVJLENBQUMsR0FBRyxDQUE3QixDQUFaLEVBQTZDd08sS0FBN0M7QUFDSDs7QUFDRCxnQkFBSUEsS0FBSyxDQUFDbkQsZUFBTixDQUFzQnBNLENBQXRCLENBQUosRUFBOEI7QUFDMUJxUCxjQUFBQSxVQUFVLENBQUMsWUFBWTtBQUFFRixnQkFBQUEsUUFBUTtBQUFLLGVBQTVCLEVBQThCLENBQTlCLENBQVYsQ0FEMEIsQ0FDa0I7QUFDL0MsYUFGRCxNQUdLO0FBQ0RFLGNBQUFBLFVBQVUsQ0FBQ0csUUFBRCxFQUFXLENBQVgsQ0FBVjtBQUNIO0FBQ0osV0FYRDs7QUFZQUgsVUFBQUEsVUFBVSxDQUFDRyxRQUFELEVBQVcsQ0FBWCxDQUFWO0FBQ0g7QUFDSixPQTNCRCxNQTRCSztBQUNELFlBQUlsUixDQUFDLEdBQUcsRUFBUjtBQUNBLFlBQUkrRCxDQUFDLEdBQUd0QixDQUFDLEdBQUcsQ0FBWjtBQUNBekMsUUFBQUEsQ0FBQyxDQUFDZSxNQUFGLEdBQVcsQ0FBQzBCLENBQUMsSUFBSSxDQUFOLElBQVcsQ0FBdEI7QUFDQWYsUUFBQUEsQ0FBQyxDQUFDME8sU0FBRixDQUFZcFEsQ0FBWjs7QUFDQSxZQUFJK0QsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQL0QsVUFBQUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxJQUFTLENBQUMsS0FBSytELENBQU4sSUFBVyxDQUFwQjtBQUNILFNBRkQsTUFHSztBQUNEL0QsVUFBQUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQVA7QUFDSDs7QUFDRCxhQUFLaUosVUFBTCxDQUFnQmpKLENBQWhCLEVBQW1CLEdBQW5CO0FBQ0g7QUFDSixLQTFDRDs7QUEyQ0EsV0FBTytJLFVBQVA7QUFDSCxHQTc0QytCLEVBQWhDLENBejdCNEIsQ0F1MEU1QjtBQUNBOzs7QUFDQSxNQUFJNkUsT0FBTztBQUFHO0FBQWUsY0FBWTtBQUNyQyxhQUFTQSxPQUFULEdBQW1CLENBQ2xCLENBRm9DLENBR3JDOzs7QUFDQUEsSUFBQUEsT0FBTyxDQUFDeEwsU0FBUixDQUFrQjJLLE9BQWxCLEdBQTRCLFVBQVUvTSxDQUFWLEVBQWE7QUFDckMsYUFBT0EsQ0FBUDtBQUNILEtBRkQsQ0FKcUMsQ0FPckM7OztBQUNBNE4sSUFBQUEsT0FBTyxDQUFDeEwsU0FBUixDQUFrQmtMLE1BQWxCLEdBQTJCLFVBQVV0TixDQUFWLEVBQWE7QUFDcEMsYUFBT0EsQ0FBUDtBQUNILEtBRkQsQ0FScUMsQ0FXckM7OztBQUNBNE4sSUFBQUEsT0FBTyxDQUFDeEwsU0FBUixDQUFrQjhLLEtBQWxCLEdBQTBCLFVBQVVsTixDQUFWLEVBQWFDLENBQWIsRUFBZ0JLLENBQWhCLEVBQW1CO0FBQ3pDTixNQUFBQSxDQUFDLENBQUNxTSxVQUFGLENBQWFwTSxDQUFiLEVBQWdCSyxDQUFoQjtBQUNILEtBRkQsQ0FacUMsQ0FlckM7OztBQUNBc04sSUFBQUEsT0FBTyxDQUFDeEwsU0FBUixDQUFrQjZLLEtBQWxCLEdBQTBCLFVBQVVqTixDQUFWLEVBQWFNLENBQWIsRUFBZ0I7QUFDdENOLE1BQUFBLENBQUMsQ0FBQzhPLFFBQUYsQ0FBV3hPLENBQVg7QUFDSCxLQUZEOztBQUdBLFdBQU9zTixPQUFQO0FBQ0gsR0FwQjRCLEVBQTdCLENBejBFNEIsQ0E4MUU1Qjs7O0FBQ0EsTUFBSTFELE9BQU87QUFBRztBQUFlLGNBQVk7QUFDckMsYUFBU0EsT0FBVCxDQUFpQjNHLENBQWpCLEVBQW9CO0FBQ2hCLFdBQUtBLENBQUwsR0FBU0EsQ0FBVDtBQUNILEtBSG9DLENBSXJDOzs7QUFDQTJHLElBQUFBLE9BQU8sQ0FBQzlILFNBQVIsQ0FBa0IySyxPQUFsQixHQUE0QixVQUFVL00sQ0FBVixFQUFhO0FBQ3JDLFVBQUlBLENBQUMsQ0FBQ21CLENBQUYsR0FBTSxDQUFOLElBQVduQixDQUFDLENBQUN5SixTQUFGLENBQVksS0FBS2xHLENBQWpCLEtBQXVCLENBQXRDLEVBQXlDO0FBQ3JDLGVBQU92RCxDQUFDLENBQUM2SixHQUFGLENBQU0sS0FBS3RHLENBQVgsQ0FBUDtBQUNILE9BRkQsTUFHSztBQUNELGVBQU92RCxDQUFQO0FBQ0g7QUFDSixLQVBELENBTHFDLENBYXJDOzs7QUFDQWtLLElBQUFBLE9BQU8sQ0FBQzlILFNBQVIsQ0FBa0JrTCxNQUFsQixHQUEyQixVQUFVdE4sQ0FBVixFQUFhO0FBQ3BDLGFBQU9BLENBQVA7QUFDSCxLQUZELENBZHFDLENBaUJyQzs7O0FBQ0FrSyxJQUFBQSxPQUFPLENBQUM5SCxTQUFSLENBQWtCK08sTUFBbEIsR0FBMkIsVUFBVW5SLENBQVYsRUFBYTtBQUNwQ0EsTUFBQUEsQ0FBQyxDQUFDOEosUUFBRixDQUFXLEtBQUt2RyxDQUFoQixFQUFtQixJQUFuQixFQUF5QnZELENBQXpCO0FBQ0gsS0FGRCxDQWxCcUMsQ0FxQnJDOzs7QUFDQWtLLElBQUFBLE9BQU8sQ0FBQzlILFNBQVIsQ0FBa0I4SyxLQUFsQixHQUEwQixVQUFVbE4sQ0FBVixFQUFhQyxDQUFiLEVBQWdCSyxDQUFoQixFQUFtQjtBQUN6Q04sTUFBQUEsQ0FBQyxDQUFDcU0sVUFBRixDQUFhcE0sQ0FBYixFQUFnQkssQ0FBaEI7QUFDQSxXQUFLNlEsTUFBTCxDQUFZN1EsQ0FBWjtBQUNILEtBSEQsQ0F0QnFDLENBMEJyQzs7O0FBQ0E0SixJQUFBQSxPQUFPLENBQUM5SCxTQUFSLENBQWtCNkssS0FBbEIsR0FBMEIsVUFBVWpOLENBQVYsRUFBYU0sQ0FBYixFQUFnQjtBQUN0Q04sTUFBQUEsQ0FBQyxDQUFDOE8sUUFBRixDQUFXeE8sQ0FBWDtBQUNBLFdBQUs2USxNQUFMLENBQVk3USxDQUFaO0FBQ0gsS0FIRDs7QUFJQSxXQUFPNEosT0FBUDtBQUNILEdBaEM0QixFQUE3QixDQS8xRTRCLENBZzRFNUI7QUFDQTtBQUNBOzs7QUFDQSxNQUFJQyxVQUFVO0FBQUc7QUFBZSxjQUFZO0FBQ3hDLGFBQVNBLFVBQVQsQ0FBb0I1RyxDQUFwQixFQUF1QjtBQUNuQixXQUFLQSxDQUFMLEdBQVNBLENBQVQ7QUFDQSxXQUFLNk4sRUFBTCxHQUFVN04sQ0FBQyxDQUFDc00sUUFBRixFQUFWO0FBQ0EsV0FBS3dCLEdBQUwsR0FBVyxLQUFLRCxFQUFMLEdBQVUsTUFBckI7QUFDQSxXQUFLRSxHQUFMLEdBQVcsS0FBS0YsRUFBTCxJQUFXLEVBQXRCO0FBQ0EsV0FBS0csRUFBTCxHQUFVLENBQUMsS0FBTWhPLENBQUMsQ0FBQzhGLEVBQUYsR0FBTyxFQUFkLElBQXFCLENBQS9CO0FBQ0EsV0FBS21JLEdBQUwsR0FBVyxJQUFJak8sQ0FBQyxDQUFDUSxDQUFqQjtBQUNILEtBUnVDLENBU3hDO0FBQ0E7OztBQUNBb0csSUFBQUEsVUFBVSxDQUFDL0gsU0FBWCxDQUFxQjJLLE9BQXJCLEdBQStCLFVBQVUvTSxDQUFWLEVBQWE7QUFDeEMsVUFBSU0sQ0FBQyxHQUFHZ0osR0FBRyxFQUFYO0FBQ0F0SixNQUFBQSxDQUFDLENBQUN5SCxHQUFGLEdBQVE4RyxTQUFSLENBQWtCLEtBQUtoTCxDQUFMLENBQU9RLENBQXpCLEVBQTRCekQsQ0FBNUI7QUFDQUEsTUFBQUEsQ0FBQyxDQUFDd0osUUFBRixDQUFXLEtBQUt2RyxDQUFoQixFQUFtQixJQUFuQixFQUF5QmpELENBQXpCOztBQUNBLFVBQUlOLENBQUMsQ0FBQ21CLENBQUYsR0FBTSxDQUFOLElBQVdiLENBQUMsQ0FBQ21KLFNBQUYsQ0FBWVYsVUFBVSxDQUFDUSxJQUF2QixJQUErQixDQUE5QyxFQUFpRDtBQUM3QyxhQUFLaEcsQ0FBTCxDQUFPaUcsS0FBUCxDQUFhbEosQ0FBYixFQUFnQkEsQ0FBaEI7QUFDSDs7QUFDRCxhQUFPQSxDQUFQO0FBQ0gsS0FSRCxDQVh3QyxDQW9CeEM7QUFDQTs7O0FBQ0E2SixJQUFBQSxVQUFVLENBQUMvSCxTQUFYLENBQXFCa0wsTUFBckIsR0FBOEIsVUFBVXROLENBQVYsRUFBYTtBQUN2QyxVQUFJTSxDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQXRKLE1BQUFBLENBQUMsQ0FBQ3NLLE1BQUYsQ0FBU2hLLENBQVQ7QUFDQSxXQUFLNlEsTUFBTCxDQUFZN1EsQ0FBWjtBQUNBLGFBQU9BLENBQVA7QUFDSCxLQUxELENBdEJ3QyxDQTRCeEM7QUFDQTs7O0FBQ0E2SixJQUFBQSxVQUFVLENBQUMvSCxTQUFYLENBQXFCK08sTUFBckIsR0FBOEIsVUFBVW5SLENBQVYsRUFBYTtBQUN2QyxhQUFPQSxDQUFDLENBQUMrRCxDQUFGLElBQU8sS0FBS3lOLEdBQW5CLEVBQXdCO0FBQ3BCO0FBQ0F4UixRQUFBQSxDQUFDLENBQUNBLENBQUMsQ0FBQytELENBQUYsRUFBRCxDQUFELEdBQVcsQ0FBWDtBQUNIOztBQUNELFdBQUssSUFBSW5ELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBSzJDLENBQUwsQ0FBT1EsQ0FBM0IsRUFBOEIsRUFBRW5ELENBQWhDLEVBQW1DO0FBQy9CO0FBQ0EsWUFBSThGLENBQUMsR0FBRzFHLENBQUMsQ0FBQ1ksQ0FBRCxDQUFELEdBQU8sTUFBZjtBQUNBLFlBQUk2USxFQUFFLEdBQUkvSyxDQUFDLEdBQUcsS0FBSzJLLEdBQVQsSUFBZ0IsQ0FBRTNLLENBQUMsR0FBRyxLQUFLNEssR0FBVCxHQUFlLENBQUN0UixDQUFDLENBQUNZLENBQUQsQ0FBRCxJQUFRLEVBQVQsSUFBZSxLQUFLeVEsR0FBcEMsR0FBMkMsS0FBS0UsRUFBakQsS0FBd0QsRUFBeEUsQ0FBRCxHQUFnRnZSLENBQUMsQ0FBQzRKLEVBQTNGLENBSCtCLENBSS9COztBQUNBbEQsUUFBQUEsQ0FBQyxHQUFHOUYsQ0FBQyxHQUFHLEtBQUsyQyxDQUFMLENBQU9RLENBQWY7QUFDQS9ELFFBQUFBLENBQUMsQ0FBQzBHLENBQUQsQ0FBRCxJQUFRLEtBQUtuRCxDQUFMLENBQU9zTCxFQUFQLENBQVUsQ0FBVixFQUFhNEMsRUFBYixFQUFpQnpSLENBQWpCLEVBQW9CWSxDQUFwQixFQUF1QixDQUF2QixFQUEwQixLQUFLMkMsQ0FBTCxDQUFPUSxDQUFqQyxDQUFSLENBTitCLENBTy9COztBQUNBLGVBQU8vRCxDQUFDLENBQUMwRyxDQUFELENBQUQsSUFBUTFHLENBQUMsQ0FBQ3dLLEVBQWpCLEVBQXFCO0FBQ2pCeEssVUFBQUEsQ0FBQyxDQUFDMEcsQ0FBRCxDQUFELElBQVExRyxDQUFDLENBQUN3SyxFQUFWO0FBQ0F4SyxVQUFBQSxDQUFDLENBQUMsRUFBRTBHLENBQUgsQ0FBRDtBQUNIO0FBQ0o7O0FBQ0QxRyxNQUFBQSxDQUFDLENBQUNzTyxLQUFGO0FBQ0F0TyxNQUFBQSxDQUFDLENBQUN3TyxTQUFGLENBQVksS0FBS2pMLENBQUwsQ0FBT1EsQ0FBbkIsRUFBc0IvRCxDQUF0Qjs7QUFDQSxVQUFJQSxDQUFDLENBQUN5SixTQUFGLENBQVksS0FBS2xHLENBQWpCLEtBQXVCLENBQTNCLEVBQThCO0FBQzFCdkQsUUFBQUEsQ0FBQyxDQUFDd0osS0FBRixDQUFRLEtBQUtqRyxDQUFiLEVBQWdCdkQsQ0FBaEI7QUFDSDtBQUNKLEtBdkJELENBOUJ3QyxDQXNEeEM7QUFDQTs7O0FBQ0FtSyxJQUFBQSxVQUFVLENBQUMvSCxTQUFYLENBQXFCOEssS0FBckIsR0FBNkIsVUFBVWxOLENBQVYsRUFBYUMsQ0FBYixFQUFnQkssQ0FBaEIsRUFBbUI7QUFDNUNOLE1BQUFBLENBQUMsQ0FBQ3FNLFVBQUYsQ0FBYXBNLENBQWIsRUFBZ0JLLENBQWhCO0FBQ0EsV0FBSzZRLE1BQUwsQ0FBWTdRLENBQVo7QUFDSCxLQUhELENBeER3QyxDQTREeEM7QUFDQTs7O0FBQ0E2SixJQUFBQSxVQUFVLENBQUMvSCxTQUFYLENBQXFCNkssS0FBckIsR0FBNkIsVUFBVWpOLENBQVYsRUFBYU0sQ0FBYixFQUFnQjtBQUN6Q04sTUFBQUEsQ0FBQyxDQUFDOE8sUUFBRixDQUFXeE8sQ0FBWDtBQUNBLFdBQUs2USxNQUFMLENBQVk3USxDQUFaO0FBQ0gsS0FIRDs7QUFJQSxXQUFPNkosVUFBUDtBQUNILEdBbkUrQixFQUFoQyxDQW40RTRCLENBdThFNUI7QUFDQTtBQUNBOzs7QUFDQSxNQUFJeUMsT0FBTztBQUFHO0FBQWUsY0FBWTtBQUNyQyxhQUFTQSxPQUFULENBQWlCckosQ0FBakIsRUFBb0I7QUFDaEIsV0FBS0EsQ0FBTCxHQUFTQSxDQUFULENBRGdCLENBRWhCOztBQUNBLFdBQUs4SixFQUFMLEdBQVUvRCxHQUFHLEVBQWI7QUFDQSxXQUFLb0ksRUFBTCxHQUFVcEksR0FBRyxFQUFiO0FBQ0FQLE1BQUFBLFVBQVUsQ0FBQzJFLEdBQVgsQ0FBZWEsU0FBZixDQUF5QixJQUFJaEwsQ0FBQyxDQUFDUSxDQUEvQixFQUFrQyxLQUFLc0osRUFBdkM7QUFDQSxXQUFLc0UsRUFBTCxHQUFVLEtBQUt0RSxFQUFMLENBQVFmLE1BQVIsQ0FBZS9JLENBQWYsQ0FBVjtBQUNILEtBUm9DLENBU3JDOzs7QUFDQXFKLElBQUFBLE9BQU8sQ0FBQ3hLLFNBQVIsQ0FBa0IySyxPQUFsQixHQUE0QixVQUFVL00sQ0FBVixFQUFhO0FBQ3JDLFVBQUlBLENBQUMsQ0FBQ21CLENBQUYsR0FBTSxDQUFOLElBQVduQixDQUFDLENBQUMrRCxDQUFGLEdBQU0sSUFBSSxLQUFLUixDQUFMLENBQU9RLENBQWhDLEVBQW1DO0FBQy9CLGVBQU8vRCxDQUFDLENBQUM2SixHQUFGLENBQU0sS0FBS3RHLENBQVgsQ0FBUDtBQUNILE9BRkQsTUFHSyxJQUFJdkQsQ0FBQyxDQUFDeUosU0FBRixDQUFZLEtBQUtsRyxDQUFqQixJQUFzQixDQUExQixFQUE2QjtBQUM5QixlQUFPdkQsQ0FBUDtBQUNILE9BRkksTUFHQTtBQUNELFlBQUlNLENBQUMsR0FBR2dKLEdBQUcsRUFBWDtBQUNBdEosUUFBQUEsQ0FBQyxDQUFDc0ssTUFBRixDQUFTaEssQ0FBVDtBQUNBLGFBQUs2USxNQUFMLENBQVk3USxDQUFaO0FBQ0EsZUFBT0EsQ0FBUDtBQUNIO0FBQ0osS0FiRCxDQVZxQyxDQXdCckM7OztBQUNBc00sSUFBQUEsT0FBTyxDQUFDeEssU0FBUixDQUFrQmtMLE1BQWxCLEdBQTJCLFVBQVV0TixDQUFWLEVBQWE7QUFDcEMsYUFBT0EsQ0FBUDtBQUNILEtBRkQsQ0F6QnFDLENBNEJyQztBQUNBOzs7QUFDQTRNLElBQUFBLE9BQU8sQ0FBQ3hLLFNBQVIsQ0FBa0IrTyxNQUFsQixHQUEyQixVQUFVblIsQ0FBVixFQUFhO0FBQ3BDQSxNQUFBQSxDQUFDLENBQUN3TyxTQUFGLENBQVksS0FBS2pMLENBQUwsQ0FBT1EsQ0FBUCxHQUFXLENBQXZCLEVBQTBCLEtBQUtzSixFQUEvQjs7QUFDQSxVQUFJck4sQ0FBQyxDQUFDK0QsQ0FBRixHQUFNLEtBQUtSLENBQUwsQ0FBT1EsQ0FBUCxHQUFXLENBQXJCLEVBQXdCO0FBQ3BCL0QsUUFBQUEsQ0FBQyxDQUFDK0QsQ0FBRixHQUFNLEtBQUtSLENBQUwsQ0FBT1EsQ0FBUCxHQUFXLENBQWpCO0FBQ0EvRCxRQUFBQSxDQUFDLENBQUNzTyxLQUFGO0FBQ0g7O0FBQ0QsV0FBS3FELEVBQUwsQ0FBUW5CLGVBQVIsQ0FBd0IsS0FBS25ELEVBQTdCLEVBQWlDLEtBQUs5SixDQUFMLENBQU9RLENBQVAsR0FBVyxDQUE1QyxFQUErQyxLQUFLMk4sRUFBcEQ7QUFDQSxXQUFLbk8sQ0FBTCxDQUFPZ04sZUFBUCxDQUF1QixLQUFLbUIsRUFBNUIsRUFBZ0MsS0FBS25PLENBQUwsQ0FBT1EsQ0FBUCxHQUFXLENBQTNDLEVBQThDLEtBQUtzSixFQUFuRDs7QUFDQSxhQUFPck4sQ0FBQyxDQUFDeUosU0FBRixDQUFZLEtBQUs0RCxFQUFqQixJQUF1QixDQUE5QixFQUFpQztBQUM3QnJOLFFBQUFBLENBQUMsQ0FBQ21RLFVBQUYsQ0FBYSxDQUFiLEVBQWdCLEtBQUs1TSxDQUFMLENBQU9RLENBQVAsR0FBVyxDQUEzQjtBQUNIOztBQUNEL0QsTUFBQUEsQ0FBQyxDQUFDd0osS0FBRixDQUFRLEtBQUs2RCxFQUFiLEVBQWlCck4sQ0FBakI7O0FBQ0EsYUFBT0EsQ0FBQyxDQUFDeUosU0FBRixDQUFZLEtBQUtsRyxDQUFqQixLQUF1QixDQUE5QixFQUFpQztBQUM3QnZELFFBQUFBLENBQUMsQ0FBQ3dKLEtBQUYsQ0FBUSxLQUFLakcsQ0FBYixFQUFnQnZELENBQWhCO0FBQ0g7QUFDSixLQWZELENBOUJxQyxDQThDckM7QUFDQTs7O0FBQ0E0TSxJQUFBQSxPQUFPLENBQUN4SyxTQUFSLENBQWtCOEssS0FBbEIsR0FBMEIsVUFBVWxOLENBQVYsRUFBYUMsQ0FBYixFQUFnQkssQ0FBaEIsRUFBbUI7QUFDekNOLE1BQUFBLENBQUMsQ0FBQ3FNLFVBQUYsQ0FBYXBNLENBQWIsRUFBZ0JLLENBQWhCO0FBQ0EsV0FBSzZRLE1BQUwsQ0FBWTdRLENBQVo7QUFDSCxLQUhELENBaERxQyxDQW9EckM7QUFDQTs7O0FBQ0FzTSxJQUFBQSxPQUFPLENBQUN4SyxTQUFSLENBQWtCNkssS0FBbEIsR0FBMEIsVUFBVWpOLENBQVYsRUFBYU0sQ0FBYixFQUFnQjtBQUN0Q04sTUFBQUEsQ0FBQyxDQUFDOE8sUUFBRixDQUFXeE8sQ0FBWDtBQUNBLFdBQUs2USxNQUFMLENBQVk3USxDQUFaO0FBQ0gsS0FIRDs7QUFJQSxXQUFPc00sT0FBUDtBQUNILEdBM0Q0QixFQUE3QixDQTE4RTRCLENBc2dGNUI7QUFDQTtBQUNBOzs7QUFDQSxXQUFTdEQsR0FBVCxHQUFlO0FBQUUsV0FBTyxJQUFJUCxVQUFKLENBQWUsSUFBZixDQUFQO0FBQThCOztBQUMvQyxXQUFTNkksV0FBVCxDQUFxQmxOLEdBQXJCLEVBQTBCcEUsQ0FBMUIsRUFBNkI7QUFDekIsV0FBTyxJQUFJeUksVUFBSixDQUFlckUsR0FBZixFQUFvQnBFLENBQXBCLENBQVA7QUFDSCxHQTVnRjJCLENBNmdGNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFdBQVN1UixHQUFULENBQWFqUixDQUFiLEVBQWdCWixDQUFoQixFQUFtQm1OLENBQW5CLEVBQXNCekcsQ0FBdEIsRUFBeUI3RixDQUF6QixFQUE0QmhCLENBQTVCLEVBQStCO0FBQzNCLFdBQU8sRUFBRUEsQ0FBRixJQUFPLENBQWQsRUFBaUI7QUFDYixVQUFJeUIsQ0FBQyxHQUFHdEIsQ0FBQyxHQUFHLEtBQUtZLENBQUMsRUFBTixDQUFKLEdBQWdCdU0sQ0FBQyxDQUFDekcsQ0FBRCxDQUFqQixHQUF1QjdGLENBQS9CO0FBQ0FBLE1BQUFBLENBQUMsR0FBRzJHLElBQUksQ0FBQ29FLEtBQUwsQ0FBV3RLLENBQUMsR0FBRyxTQUFmLENBQUo7QUFDQTZMLE1BQUFBLENBQUMsQ0FBQ3pHLENBQUMsRUFBRixDQUFELEdBQVNwRixDQUFDLEdBQUcsU0FBYjtBQUNIOztBQUNELFdBQU9ULENBQVA7QUFDSCxHQTNoRjJCLENBNGhGNUI7QUFDQTtBQUNBOzs7QUFDQSxXQUFTaVIsR0FBVCxDQUFhbFIsQ0FBYixFQUFnQlosQ0FBaEIsRUFBbUJtTixDQUFuQixFQUFzQnpHLENBQXRCLEVBQXlCN0YsQ0FBekIsRUFBNEJoQixDQUE1QixFQUErQjtBQUMzQixRQUFJa1MsRUFBRSxHQUFHL1IsQ0FBQyxHQUFHLE1BQWI7QUFDQSxRQUFJZ1MsRUFBRSxHQUFHaFMsQ0FBQyxJQUFJLEVBQWQ7O0FBQ0EsV0FBTyxFQUFFSCxDQUFGLElBQU8sQ0FBZCxFQUFpQjtBQUNiLFVBQUlpRSxDQUFDLEdBQUcsS0FBS2xELENBQUwsSUFBVSxNQUFsQjtBQUNBLFVBQUlELENBQUMsR0FBRyxLQUFLQyxDQUFDLEVBQU4sS0FBYSxFQUFyQjtBQUNBLFVBQUkyQyxDQUFDLEdBQUd5TyxFQUFFLEdBQUdsTyxDQUFMLEdBQVNuRCxDQUFDLEdBQUdvUixFQUFyQjtBQUNBak8sTUFBQUEsQ0FBQyxHQUFHaU8sRUFBRSxHQUFHak8sQ0FBTCxJQUFVLENBQUNQLENBQUMsR0FBRyxNQUFMLEtBQWdCLEVBQTFCLElBQWdDNEosQ0FBQyxDQUFDekcsQ0FBRCxDQUFqQyxJQUF3QzdGLENBQUMsR0FBRyxVQUE1QyxDQUFKO0FBQ0FBLE1BQUFBLENBQUMsR0FBRyxDQUFDaUQsQ0FBQyxLQUFLLEVBQVAsS0FBY1AsQ0FBQyxLQUFLLEVBQXBCLElBQTBCeU8sRUFBRSxHQUFHclIsQ0FBL0IsSUFBb0NFLENBQUMsS0FBSyxFQUExQyxDQUFKO0FBQ0FzTSxNQUFBQSxDQUFDLENBQUN6RyxDQUFDLEVBQUYsQ0FBRCxHQUFTNUMsQ0FBQyxHQUFHLFVBQWI7QUFDSDs7QUFDRCxXQUFPakQsQ0FBUDtBQUNILEdBM2lGMkIsQ0E0aUY1QjtBQUNBOzs7QUFDQSxXQUFTb1IsR0FBVCxDQUFhclIsQ0FBYixFQUFnQlosQ0FBaEIsRUFBbUJtTixDQUFuQixFQUFzQnpHLENBQXRCLEVBQXlCN0YsQ0FBekIsRUFBNEJoQixDQUE1QixFQUErQjtBQUMzQixRQUFJa1MsRUFBRSxHQUFHL1IsQ0FBQyxHQUFHLE1BQWI7QUFDQSxRQUFJZ1MsRUFBRSxHQUFHaFMsQ0FBQyxJQUFJLEVBQWQ7O0FBQ0EsV0FBTyxFQUFFSCxDQUFGLElBQU8sQ0FBZCxFQUFpQjtBQUNiLFVBQUlpRSxDQUFDLEdBQUcsS0FBS2xELENBQUwsSUFBVSxNQUFsQjtBQUNBLFVBQUlELENBQUMsR0FBRyxLQUFLQyxDQUFDLEVBQU4sS0FBYSxFQUFyQjtBQUNBLFVBQUkyQyxDQUFDLEdBQUd5TyxFQUFFLEdBQUdsTyxDQUFMLEdBQVNuRCxDQUFDLEdBQUdvUixFQUFyQjtBQUNBak8sTUFBQUEsQ0FBQyxHQUFHaU8sRUFBRSxHQUFHak8sQ0FBTCxJQUFVLENBQUNQLENBQUMsR0FBRyxNQUFMLEtBQWdCLEVBQTFCLElBQWdDNEosQ0FBQyxDQUFDekcsQ0FBRCxDQUFqQyxHQUF1QzdGLENBQTNDO0FBQ0FBLE1BQUFBLENBQUMsR0FBRyxDQUFDaUQsQ0FBQyxJQUFJLEVBQU4sS0FBYVAsQ0FBQyxJQUFJLEVBQWxCLElBQXdCeU8sRUFBRSxHQUFHclIsQ0FBakM7QUFDQXdNLE1BQUFBLENBQUMsQ0FBQ3pHLENBQUMsRUFBRixDQUFELEdBQVM1QyxDQUFDLEdBQUcsU0FBYjtBQUNIOztBQUNELFdBQU9qRCxDQUFQO0FBQ0g7O0FBQ0QsTUFBSStILElBQUksSUFBS3NKLFNBQVMsQ0FBQ0MsT0FBVixJQUFxQiw2QkFBbEMsRUFBa0U7QUFDOURwSixJQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCeU0sRUFBckIsR0FBMEJpRCxHQUExQjtBQUNBcEosSUFBQUEsS0FBSyxHQUFHLEVBQVI7QUFDSCxHQUhELE1BSUssSUFBSUUsSUFBSSxJQUFLc0osU0FBUyxDQUFDQyxPQUFWLElBQXFCLFVBQWxDLEVBQStDO0FBQ2hEcEosSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQnlNLEVBQXJCLEdBQTBCZ0QsR0FBMUI7QUFDQW5KLElBQUFBLEtBQUssR0FBRyxFQUFSO0FBQ0gsR0FISSxNQUlBO0FBQUU7QUFDSEssSUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQnlNLEVBQXJCLEdBQTBCb0QsR0FBMUI7QUFDQXZKLElBQUFBLEtBQUssR0FBRyxFQUFSO0FBQ0g7O0FBQ0RLLEVBQUFBLFVBQVUsQ0FBQzNHLFNBQVgsQ0FBcUJpSCxFQUFyQixHQUEwQlgsS0FBMUI7QUFDQUssRUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQndILEVBQXJCLEdBQTJCLENBQUMsS0FBS2xCLEtBQU4sSUFBZSxDQUExQztBQUNBSyxFQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCb0ksRUFBckIsR0FBMkIsS0FBSzlCLEtBQWhDO0FBQ0EsTUFBSTBKLEtBQUssR0FBRyxFQUFaO0FBQ0FySixFQUFBQSxVQUFVLENBQUMzRyxTQUFYLENBQXFCc04sRUFBckIsR0FBMEJsSSxJQUFJLENBQUNtRyxHQUFMLENBQVMsQ0FBVCxFQUFZeUUsS0FBWixDQUExQjtBQUNBckosRUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQm1OLEVBQXJCLEdBQTBCNkMsS0FBSyxHQUFHMUosS0FBbEM7QUFDQUssRUFBQUEsVUFBVSxDQUFDM0csU0FBWCxDQUFxQm9OLEVBQXJCLEdBQTBCLElBQUk5RyxLQUFKLEdBQVkwSixLQUF0QyxDQTdrRjRCLENBOGtGNUI7O0FBQ0EsTUFBSUMsS0FBSyxHQUFHLEVBQVo7QUFDQSxNQUFJQyxFQUFKO0FBQ0EsTUFBSUMsRUFBSjtBQUNBRCxFQUFBQSxFQUFFLEdBQUcsSUFBSXJOLFVBQUosQ0FBZSxDQUFmLENBQUw7O0FBQ0EsT0FBS3NOLEVBQUUsR0FBRyxDQUFWLEVBQWFBLEVBQUUsSUFBSSxDQUFuQixFQUFzQixFQUFFQSxFQUF4QixFQUE0QjtBQUN4QkYsSUFBQUEsS0FBSyxDQUFDQyxFQUFFLEVBQUgsQ0FBTCxHQUFjQyxFQUFkO0FBQ0g7O0FBQ0RELEVBQUFBLEVBQUUsR0FBRyxJQUFJck4sVUFBSixDQUFlLENBQWYsQ0FBTDs7QUFDQSxPQUFLc04sRUFBRSxHQUFHLEVBQVYsRUFBY0EsRUFBRSxHQUFHLEVBQW5CLEVBQXVCLEVBQUVBLEVBQXpCLEVBQTZCO0FBQ3pCRixJQUFBQSxLQUFLLENBQUNDLEVBQUUsRUFBSCxDQUFMLEdBQWNDLEVBQWQ7QUFDSDs7QUFDREQsRUFBQUEsRUFBRSxHQUFHLElBQUlyTixVQUFKLENBQWUsQ0FBZixDQUFMOztBQUNBLE9BQUtzTixFQUFFLEdBQUcsRUFBVixFQUFjQSxFQUFFLEdBQUcsRUFBbkIsRUFBdUIsRUFBRUEsRUFBekIsRUFBNkI7QUFDekJGLElBQUFBLEtBQUssQ0FBQ0MsRUFBRSxFQUFILENBQUwsR0FBY0MsRUFBZDtBQUNIOztBQUNELFdBQVNsRSxLQUFULENBQWVsTixDQUFmLEVBQWtCUCxDQUFsQixFQUFxQjtBQUNqQixRQUFJQyxDQUFDLEdBQUd3UixLQUFLLENBQUNsUixDQUFDLENBQUM4RCxVQUFGLENBQWFyRSxDQUFiLENBQUQsQ0FBYjtBQUNBLFdBQVFDLENBQUMsSUFBSSxJQUFOLEdBQWMsQ0FBQyxDQUFmLEdBQW1CQSxDQUExQjtBQUNILEdBam1GMkIsQ0FrbUY1Qjs7O0FBQ0EsV0FBUzhMLEdBQVQsQ0FBYS9MLENBQWIsRUFBZ0I7QUFDWixRQUFJTixDQUFDLEdBQUdnSixHQUFHLEVBQVg7QUFDQWhKLElBQUFBLENBQUMsQ0FBQzJOLE9BQUYsQ0FBVXJOLENBQVY7QUFDQSxXQUFPTixDQUFQO0FBQ0gsR0F2bUYyQixDQXdtRjVCOzs7QUFDQSxXQUFTcUosS0FBVCxDQUFlM0osQ0FBZixFQUFrQjtBQUNkLFFBQUlNLENBQUMsR0FBRyxDQUFSO0FBQ0EsUUFBSXlELENBQUo7O0FBQ0EsUUFBSSxDQUFDQSxDQUFDLEdBQUcvRCxDQUFDLEtBQUssRUFBWCxLQUFrQixDQUF0QixFQUF5QjtBQUNyQkEsTUFBQUEsQ0FBQyxHQUFHK0QsQ0FBSjtBQUNBekQsTUFBQUEsQ0FBQyxJQUFJLEVBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUN5RCxDQUFDLEdBQUcvRCxDQUFDLElBQUksQ0FBVixLQUFnQixDQUFwQixFQUF1QjtBQUNuQkEsTUFBQUEsQ0FBQyxHQUFHK0QsQ0FBSjtBQUNBekQsTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUN5RCxDQUFDLEdBQUcvRCxDQUFDLElBQUksQ0FBVixLQUFnQixDQUFwQixFQUF1QjtBQUNuQkEsTUFBQUEsQ0FBQyxHQUFHK0QsQ0FBSjtBQUNBekQsTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUN5RCxDQUFDLEdBQUcvRCxDQUFDLElBQUksQ0FBVixLQUFnQixDQUFwQixFQUF1QjtBQUNuQkEsTUFBQUEsQ0FBQyxHQUFHK0QsQ0FBSjtBQUNBekQsTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxRQUFJLENBQUN5RCxDQUFDLEdBQUcvRCxDQUFDLElBQUksQ0FBVixLQUFnQixDQUFwQixFQUF1QjtBQUNuQkEsTUFBQUEsQ0FBQyxHQUFHK0QsQ0FBSjtBQUNBekQsTUFBQUEsQ0FBQyxJQUFJLENBQUw7QUFDSDs7QUFDRCxXQUFPQSxDQUFQO0FBQ0gsR0Fqb0YyQixDQWtvRjVCOzs7QUFDQXlJLEVBQUFBLFVBQVUsQ0FBQ1EsSUFBWCxHQUFrQm9ELEdBQUcsQ0FBQyxDQUFELENBQXJCO0FBQ0E1RCxFQUFBQSxVQUFVLENBQUMyRSxHQUFYLEdBQWlCZixHQUFHLENBQUMsQ0FBRCxDQUFwQixDQXBvRjRCLENBc29GNUI7O0FBQ0EsTUFBSTZGLE9BQU87QUFBRztBQUFlLGNBQVk7QUFDckMsYUFBU0EsT0FBVCxHQUFtQjtBQUNmLFdBQUs1UixDQUFMLEdBQVMsQ0FBVDtBQUNBLFdBQUs4RixDQUFMLEdBQVMsQ0FBVDtBQUNBLFdBQUsrTCxDQUFMLEdBQVMsRUFBVDtBQUNILEtBTG9DLENBTXJDO0FBQ0E7OztBQUNBRCxJQUFBQSxPQUFPLENBQUNwUSxTQUFSLENBQWtCc1EsSUFBbEIsR0FBeUIsVUFBVUMsR0FBVixFQUFlO0FBQ3BDLFVBQUkvUixDQUFKO0FBQ0EsVUFBSThGLENBQUo7QUFDQSxVQUFJM0MsQ0FBSjs7QUFDQSxXQUFLbkQsQ0FBQyxHQUFHLENBQVQsRUFBWUEsQ0FBQyxHQUFHLEdBQWhCLEVBQXFCLEVBQUVBLENBQXZCLEVBQTBCO0FBQ3RCLGFBQUs2UixDQUFMLENBQU83UixDQUFQLElBQVlBLENBQVo7QUFDSDs7QUFDRDhGLE1BQUFBLENBQUMsR0FBRyxDQUFKOztBQUNBLFdBQUs5RixDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUcsR0FBaEIsRUFBcUIsRUFBRUEsQ0FBdkIsRUFBMEI7QUFDdEI4RixRQUFBQSxDQUFDLEdBQUlBLENBQUMsR0FBRyxLQUFLK0wsQ0FBTCxDQUFPN1IsQ0FBUCxDQUFKLEdBQWdCK1IsR0FBRyxDQUFDL1IsQ0FBQyxHQUFHK1IsR0FBRyxDQUFDNVIsTUFBVCxDQUFwQixHQUF3QyxHQUE1QztBQUNBZ0QsUUFBQUEsQ0FBQyxHQUFHLEtBQUswTyxDQUFMLENBQU83UixDQUFQLENBQUo7QUFDQSxhQUFLNlIsQ0FBTCxDQUFPN1IsQ0FBUCxJQUFZLEtBQUs2UixDQUFMLENBQU8vTCxDQUFQLENBQVo7QUFDQSxhQUFLK0wsQ0FBTCxDQUFPL0wsQ0FBUCxJQUFZM0MsQ0FBWjtBQUNIOztBQUNELFdBQUtuRCxDQUFMLEdBQVMsQ0FBVDtBQUNBLFdBQUs4RixDQUFMLEdBQVMsQ0FBVDtBQUNILEtBaEJELENBUnFDLENBeUJyQzs7O0FBQ0E4TCxJQUFBQSxPQUFPLENBQUNwUSxTQUFSLENBQWtCd1EsSUFBbEIsR0FBeUIsWUFBWTtBQUNqQyxVQUFJN08sQ0FBSjtBQUNBLFdBQUtuRCxDQUFMLEdBQVUsS0FBS0EsQ0FBTCxHQUFTLENBQVYsR0FBZSxHQUF4QjtBQUNBLFdBQUs4RixDQUFMLEdBQVUsS0FBS0EsQ0FBTCxHQUFTLEtBQUsrTCxDQUFMLENBQU8sS0FBSzdSLENBQVosQ0FBVixHQUE0QixHQUFyQztBQUNBbUQsTUFBQUEsQ0FBQyxHQUFHLEtBQUswTyxDQUFMLENBQU8sS0FBSzdSLENBQVosQ0FBSjtBQUNBLFdBQUs2UixDQUFMLENBQU8sS0FBSzdSLENBQVosSUFBaUIsS0FBSzZSLENBQUwsQ0FBTyxLQUFLL0wsQ0FBWixDQUFqQjtBQUNBLFdBQUsrTCxDQUFMLENBQU8sS0FBSy9MLENBQVosSUFBaUIzQyxDQUFqQjtBQUNBLGFBQU8sS0FBSzBPLENBQUwsQ0FBUTFPLENBQUMsR0FBRyxLQUFLME8sQ0FBTCxDQUFPLEtBQUs3UixDQUFaLENBQUwsR0FBdUIsR0FBOUIsQ0FBUDtBQUNILEtBUkQ7O0FBU0EsV0FBTzRSLE9BQVA7QUFDSCxHQXBDNEIsRUFBN0IsQ0F2b0Y0QixDQTRxRjVCOzs7QUFDQSxXQUFTSyxhQUFULEdBQXlCO0FBQ3JCLFdBQU8sSUFBSUwsT0FBSixFQUFQO0FBQ0gsR0EvcUYyQixDQWdyRjVCO0FBQ0E7OztBQUNBLE1BQUlNLFNBQVMsR0FBRyxHQUFoQixDQWxyRjRCLENBb3JGNUI7O0FBQ0EsTUFBSUMsU0FBSjtBQUNBLE1BQUlDLFFBQVEsR0FBRyxJQUFmO0FBQ0EsTUFBSUMsUUFBSixDQXZyRjRCLENBd3JGNUI7O0FBQ0EsTUFBSUQsUUFBUSxJQUFJLElBQWhCLEVBQXNCO0FBQ2xCQSxJQUFBQSxRQUFRLEdBQUcsRUFBWDtBQUNBQyxJQUFBQSxRQUFRLEdBQUcsQ0FBWDtBQUNBLFFBQUlsUCxDQUFDLEdBQUcsS0FBSyxDQUFiOztBQUNBLFFBQUltUCxNQUFNLENBQUNDLE1BQVAsSUFBaUJELE1BQU0sQ0FBQ0MsTUFBUCxDQUFjQyxlQUFuQyxFQUFvRDtBQUNoRDtBQUNBLFVBQUlwSixDQUFDLEdBQUcsSUFBSXFKLFdBQUosQ0FBZ0IsR0FBaEIsQ0FBUjtBQUNBSCxNQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBY0MsZUFBZCxDQUE4QnBKLENBQTlCOztBQUNBLFdBQUtqRyxDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUdpRyxDQUFDLENBQUNqSixNQUFsQixFQUEwQixFQUFFZ0QsQ0FBNUIsRUFBK0I7QUFDM0JpUCxRQUFBQSxRQUFRLENBQUNDLFFBQVEsRUFBVCxDQUFSLEdBQXVCakosQ0FBQyxDQUFDakcsQ0FBRCxDQUFELEdBQU8sR0FBOUI7QUFDSDtBQUNKLEtBWGlCLENBWWxCO0FBQ0E7OztBQUNBLFFBQUl1UCxxQkFBcUIsR0FBRyxTQUF4QkEscUJBQXdCLENBQVVDLEVBQVYsRUFBYztBQUN0QyxXQUFLQyxLQUFMLEdBQWEsS0FBS0EsS0FBTCxJQUFjLENBQTNCOztBQUNBLFVBQUksS0FBS0EsS0FBTCxJQUFjLEdBQWQsSUFBcUJQLFFBQVEsSUFBSUgsU0FBckMsRUFBZ0Q7QUFDNUMsWUFBSUksTUFBTSxDQUFDTyxtQkFBWCxFQUFnQztBQUM1QlAsVUFBQUEsTUFBTSxDQUFDTyxtQkFBUCxDQUEyQixXQUEzQixFQUF3Q0gscUJBQXhDLEVBQStELEtBQS9EO0FBQ0gsU0FGRCxNQUdLLElBQUlKLE1BQU0sQ0FBQ1EsV0FBWCxFQUF3QjtBQUN6QlIsVUFBQUEsTUFBTSxDQUFDUSxXQUFQLENBQW1CLGFBQW5CLEVBQWtDSixxQkFBbEM7QUFDSDs7QUFDRDtBQUNIOztBQUNELFVBQUk7QUFDQSxZQUFJSyxnQkFBZ0IsR0FBR0osRUFBRSxDQUFDdlQsQ0FBSCxHQUFPdVQsRUFBRSxDQUFDdFQsQ0FBakM7QUFDQStTLFFBQUFBLFFBQVEsQ0FBQ0MsUUFBUSxFQUFULENBQVIsR0FBdUJVLGdCQUFnQixHQUFHLEdBQTFDO0FBQ0EsYUFBS0gsS0FBTCxJQUFjLENBQWQ7QUFDSCxPQUpELENBS0EsT0FBTy9LLENBQVAsRUFBVSxDQUNOO0FBQ0g7QUFDSixLQW5CRDs7QUFvQkEsUUFBSXlLLE1BQU0sQ0FBQ1UsZ0JBQVgsRUFBNkI7QUFDekJWLE1BQUFBLE1BQU0sQ0FBQ1UsZ0JBQVAsQ0FBd0IsV0FBeEIsRUFBcUNOLHFCQUFyQyxFQUE0RCxLQUE1RDtBQUNILEtBRkQsTUFHSyxJQUFJSixNQUFNLENBQUNXLFdBQVgsRUFBd0I7QUFDekJYLE1BQUFBLE1BQU0sQ0FBQ1csV0FBUCxDQUFtQixhQUFuQixFQUFrQ1AscUJBQWxDO0FBQ0g7QUFDSjs7QUFDRCxXQUFTUSxZQUFULEdBQXdCO0FBQ3BCLFFBQUlmLFNBQVMsSUFBSSxJQUFqQixFQUF1QjtBQUNuQkEsTUFBQUEsU0FBUyxHQUFHRixhQUFhLEVBQXpCLENBRG1CLENBRW5COztBQUNBLGFBQU9JLFFBQVEsR0FBR0gsU0FBbEIsRUFBNkI7QUFDekIsWUFBSXBDLE1BQU0sR0FBR2xKLElBQUksQ0FBQ29FLEtBQUwsQ0FBVyxRQUFRcEUsSUFBSSxDQUFDa0osTUFBTCxFQUFuQixDQUFiO0FBQ0FzQyxRQUFBQSxRQUFRLENBQUNDLFFBQVEsRUFBVCxDQUFSLEdBQXVCdkMsTUFBTSxHQUFHLEdBQWhDO0FBQ0g7O0FBQ0RxQyxNQUFBQSxTQUFTLENBQUNMLElBQVYsQ0FBZU0sUUFBZjs7QUFDQSxXQUFLQyxRQUFRLEdBQUcsQ0FBaEIsRUFBbUJBLFFBQVEsR0FBR0QsUUFBUSxDQUFDalMsTUFBdkMsRUFBK0MsRUFBRWtTLFFBQWpELEVBQTJEO0FBQ3ZERCxRQUFBQSxRQUFRLENBQUNDLFFBQUQsQ0FBUixHQUFxQixDQUFyQjtBQUNIOztBQUNEQSxNQUFBQSxRQUFRLEdBQUcsQ0FBWDtBQUNILEtBYm1CLENBY3BCOzs7QUFDQSxXQUFPRixTQUFTLENBQUNILElBQVYsRUFBUDtBQUNIOztBQUNELE1BQUltQixZQUFZO0FBQUc7QUFBZSxjQUFZO0FBQzFDLGFBQVNBLFlBQVQsR0FBd0IsQ0FDdkI7O0FBQ0RBLElBQUFBLFlBQVksQ0FBQzNSLFNBQWIsQ0FBdUJnTyxTQUF2QixHQUFtQyxVQUFVNEQsRUFBVixFQUFjO0FBQzdDLFdBQUssSUFBSXBULENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdvVCxFQUFFLENBQUNqVCxNQUF2QixFQUErQixFQUFFSCxDQUFqQyxFQUFvQztBQUNoQ29ULFFBQUFBLEVBQUUsQ0FBQ3BULENBQUQsQ0FBRixHQUFRa1QsWUFBWSxFQUFwQjtBQUNIO0FBQ0osS0FKRDs7QUFLQSxXQUFPQyxZQUFQO0FBQ0gsR0FUaUMsRUFBbEMsQ0FudkY0QixDQTh2RjVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFTRSxTQUFULENBQW1COVMsQ0FBbkIsRUFBc0J0QixDQUF0QixFQUF5QjtBQUNyQixRQUFJQSxDQUFDLEdBQUdzQixDQUFDLENBQUNKLE1BQUYsR0FBVyxFQUFuQixFQUF1QjtBQUNuQm1ULE1BQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDBCQUFkO0FBQ0EsYUFBTyxJQUFQO0FBQ0g7O0FBQ0QsUUFBSXhQLEdBQUcsR0FBRzlFLENBQUMsR0FBR3NCLENBQUMsQ0FBQ0osTUFBTixHQUFlLENBQXpCO0FBQ0EsUUFBSXFULE1BQU0sR0FBRyxFQUFiOztBQUNBLFNBQUssSUFBSTlELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUczTCxHQUFwQixFQUF5QjJMLENBQUMsSUFBSSxDQUE5QixFQUFpQztBQUM3QjhELE1BQUFBLE1BQU0sSUFBSSxJQUFWO0FBQ0g7O0FBQ0QsUUFBSTdRLENBQUMsR0FBRyxTQUFTNlEsTUFBVCxHQUFrQixJQUFsQixHQUF5QmpULENBQWpDO0FBQ0EsV0FBT3lRLFdBQVcsQ0FBQ3JPLENBQUQsRUFBSSxFQUFKLENBQWxCO0FBQ0gsR0ExeEYyQixDQTJ4RjVCOzs7QUFDQSxXQUFTOFEsU0FBVCxDQUFtQmxULENBQW5CLEVBQXNCdEIsQ0FBdEIsRUFBeUI7QUFDckIsUUFBSUEsQ0FBQyxHQUFHc0IsQ0FBQyxDQUFDSixNQUFGLEdBQVcsRUFBbkIsRUFBdUI7QUFDbkI7QUFDQW1ULE1BQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDBCQUFkO0FBQ0EsYUFBTyxJQUFQO0FBQ0g7O0FBQ0QsUUFBSUgsRUFBRSxHQUFHLEVBQVQ7QUFDQSxRQUFJcFQsQ0FBQyxHQUFHTyxDQUFDLENBQUNKLE1BQUYsR0FBVyxDQUFuQjs7QUFDQSxXQUFPSCxDQUFDLElBQUksQ0FBTCxJQUFVZixDQUFDLEdBQUcsQ0FBckIsRUFBd0I7QUFDcEIsVUFBSWdCLENBQUMsR0FBR00sQ0FBQyxDQUFDOEQsVUFBRixDQUFhckUsQ0FBQyxFQUFkLENBQVI7O0FBQ0EsVUFBSUMsQ0FBQyxHQUFHLEdBQVIsRUFBYTtBQUNUO0FBQ0FtVCxRQUFBQSxFQUFFLENBQUMsRUFBRW5VLENBQUgsQ0FBRixHQUFVZ0IsQ0FBVjtBQUNILE9BSEQsTUFJSyxJQUFJQSxDQUFDLEdBQUcsR0FBSixJQUFXQSxDQUFDLEdBQUcsSUFBbkIsRUFBeUI7QUFDMUJtVCxRQUFBQSxFQUFFLENBQUMsRUFBRW5VLENBQUgsQ0FBRixHQUFXZ0IsQ0FBQyxHQUFHLEVBQUwsR0FBVyxHQUFyQjtBQUNBbVQsUUFBQUEsRUFBRSxDQUFDLEVBQUVuVSxDQUFILENBQUYsR0FBV2dCLENBQUMsSUFBSSxDQUFOLEdBQVcsR0FBckI7QUFDSCxPQUhJLE1BSUE7QUFDRG1ULFFBQUFBLEVBQUUsQ0FBQyxFQUFFblUsQ0FBSCxDQUFGLEdBQVdnQixDQUFDLEdBQUcsRUFBTCxHQUFXLEdBQXJCO0FBQ0FtVCxRQUFBQSxFQUFFLENBQUMsRUFBRW5VLENBQUgsQ0FBRixHQUFZZ0IsQ0FBQyxJQUFJLENBQU4sR0FBVyxFQUFaLEdBQWtCLEdBQTVCO0FBQ0FtVCxRQUFBQSxFQUFFLENBQUMsRUFBRW5VLENBQUgsQ0FBRixHQUFXZ0IsQ0FBQyxJQUFJLEVBQU4sR0FBWSxHQUF0QjtBQUNIO0FBQ0o7O0FBQ0RtVCxJQUFBQSxFQUFFLENBQUMsRUFBRW5VLENBQUgsQ0FBRixHQUFVLENBQVY7QUFDQSxRQUFJeVUsR0FBRyxHQUFHLElBQUlQLFlBQUosRUFBVjtBQUNBLFFBQUkvVCxDQUFDLEdBQUcsRUFBUjs7QUFDQSxXQUFPSCxDQUFDLEdBQUcsQ0FBWCxFQUFjO0FBQ1Y7QUFDQUcsTUFBQUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQVA7O0FBQ0EsYUFBT0EsQ0FBQyxDQUFDLENBQUQsQ0FBRCxJQUFRLENBQWYsRUFBa0I7QUFDZHNVLFFBQUFBLEdBQUcsQ0FBQ2xFLFNBQUosQ0FBY3BRLENBQWQ7QUFDSDs7QUFDRGdVLE1BQUFBLEVBQUUsQ0FBQyxFQUFFblUsQ0FBSCxDQUFGLEdBQVVHLENBQUMsQ0FBQyxDQUFELENBQVg7QUFDSDs7QUFDRGdVLElBQUFBLEVBQUUsQ0FBQyxFQUFFblUsQ0FBSCxDQUFGLEdBQVUsQ0FBVjtBQUNBbVUsSUFBQUEsRUFBRSxDQUFDLEVBQUVuVSxDQUFILENBQUYsR0FBVSxDQUFWO0FBQ0EsV0FBTyxJQUFJa0osVUFBSixDQUFlaUwsRUFBZixDQUFQO0FBQ0gsR0FsMEYyQixDQW0wRjVCOzs7QUFDQSxNQUFJTyxNQUFNO0FBQUc7QUFBZSxjQUFZO0FBQ3BDLGFBQVNBLE1BQVQsR0FBa0I7QUFDZCxXQUFLMVUsQ0FBTCxHQUFTLElBQVQ7QUFDQSxXQUFLNEksQ0FBTCxHQUFTLENBQVQ7QUFDQSxXQUFLaEgsQ0FBTCxHQUFTLElBQVQ7QUFDQSxXQUFLTSxDQUFMLEdBQVMsSUFBVDtBQUNBLFdBQUswSyxDQUFMLEdBQVMsSUFBVDtBQUNBLFdBQUsrSCxJQUFMLEdBQVksSUFBWjtBQUNBLFdBQUtDLElBQUwsR0FBWSxJQUFaO0FBQ0EsV0FBS0MsS0FBTCxHQUFhLElBQWI7QUFDSCxLQVZtQyxDQVdwQztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FILElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUJ1UyxRQUFqQixHQUE0QixVQUFVM1UsQ0FBVixFQUFhO0FBQ3JDLGFBQU9BLENBQUMsQ0FBQytKLFNBQUYsQ0FBWSxLQUFLdEIsQ0FBakIsRUFBb0IsS0FBSzVJLENBQXpCLENBQVA7QUFDSCxLQUZELENBZm9DLENBa0JwQztBQUNBOzs7QUFDQTBVLElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUJ3UyxTQUFqQixHQUE2QixVQUFVNVUsQ0FBVixFQUFhO0FBQ3RDLFVBQUksS0FBSytCLENBQUwsSUFBVSxJQUFWLElBQWtCLEtBQUswSyxDQUFMLElBQVUsSUFBaEMsRUFBc0M7QUFDbEMsZUFBT3pNLENBQUMsQ0FBQzBNLE1BQUYsQ0FBUyxLQUFLakwsQ0FBZCxFQUFpQixLQUFLNUIsQ0FBdEIsQ0FBUDtBQUNILE9BSHFDLENBSXRDOzs7QUFDQSxVQUFJZ1YsRUFBRSxHQUFHN1UsQ0FBQyxDQUFDNkosR0FBRixDQUFNLEtBQUs5SCxDQUFYLEVBQWMySyxNQUFkLENBQXFCLEtBQUs4SCxJQUExQixFQUFnQyxLQUFLelMsQ0FBckMsQ0FBVDtBQUNBLFVBQUkrUyxFQUFFLEdBQUc5VSxDQUFDLENBQUM2SixHQUFGLENBQU0sS0FBSzRDLENBQVgsRUFBY0MsTUFBZCxDQUFxQixLQUFLK0gsSUFBMUIsRUFBZ0MsS0FBS2hJLENBQXJDLENBQVQ7O0FBQ0EsYUFBT29JLEVBQUUsQ0FBQ3BMLFNBQUgsQ0FBYXFMLEVBQWIsSUFBbUIsQ0FBMUIsRUFBNkI7QUFDekJELFFBQUFBLEVBQUUsR0FBR0EsRUFBRSxDQUFDNUksR0FBSCxDQUFPLEtBQUtsSyxDQUFaLENBQUw7QUFDSDs7QUFDRCxhQUFPOFMsRUFBRSxDQUNKMUksUUFERSxDQUNPMkksRUFEUCxFQUVGMUksUUFGRSxDQUVPLEtBQUtzSSxLQUZaLEVBR0Y3SyxHQUhFLENBR0UsS0FBSzlILENBSFAsRUFJRnFLLFFBSkUsQ0FJTyxLQUFLSyxDQUpaLEVBS0ZSLEdBTEUsQ0FLRTZJLEVBTEYsQ0FBUDtBQU1ILEtBaEJELENBcEJvQyxDQXFDcEM7QUFDQTtBQUNBO0FBQ0E7OztBQUNBUCxJQUFBQSxNQUFNLENBQUNuUyxTQUFQLENBQWlCMlMsU0FBakIsR0FBNkIsVUFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ3pDLFVBQUlELENBQUMsSUFBSSxJQUFMLElBQWFDLENBQUMsSUFBSSxJQUFsQixJQUEwQkQsQ0FBQyxDQUFDalUsTUFBRixHQUFXLENBQXJDLElBQTBDa1UsQ0FBQyxDQUFDbFUsTUFBRixHQUFXLENBQXpELEVBQTREO0FBQ3hELGFBQUtsQixDQUFMLEdBQVMrUixXQUFXLENBQUNvRCxDQUFELEVBQUksRUFBSixDQUFwQjtBQUNBLGFBQUt2TSxDQUFMLEdBQVN6SCxRQUFRLENBQUNpVSxDQUFELEVBQUksRUFBSixDQUFqQjtBQUNILE9BSEQsTUFJSztBQUNEZixRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyx3QkFBZDtBQUNIO0FBQ0osS0FSRCxDQXpDb0MsQ0FrRHBDO0FBQ0E7OztBQUNBSSxJQUFBQSxNQUFNLENBQUNuUyxTQUFQLENBQWlCOFMsT0FBakIsR0FBMkIsVUFBVUMsSUFBVixFQUFnQjtBQUN2QyxVQUFJNVIsQ0FBQyxHQUFHOFEsU0FBUyxDQUFDYyxJQUFELEVBQVEsS0FBS3RWLENBQUwsQ0FBTzZKLFNBQVAsS0FBcUIsQ0FBdEIsSUFBNEIsQ0FBbkMsQ0FBakI7O0FBQ0EsVUFBSW5HLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWCxlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJMUMsQ0FBQyxHQUFHLEtBQUs4VCxRQUFMLENBQWNwUixDQUFkLENBQVI7O0FBQ0EsVUFBSTFDLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWCxlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJRixDQUFDLEdBQUdFLENBQUMsQ0FBQ3FELFFBQUYsQ0FBVyxFQUFYLENBQVI7O0FBQ0EsVUFBSSxDQUFDdkQsQ0FBQyxDQUFDSSxNQUFGLEdBQVcsQ0FBWixLQUFrQixDQUF0QixFQUF5QjtBQUNyQixlQUFPSixDQUFQO0FBQ0gsT0FGRCxNQUdLO0FBQ0QsZUFBTyxNQUFNQSxDQUFiO0FBQ0g7QUFDSixLQWhCRDtBQWlCQTtBQUNKO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSTRULElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUJnVCxXQUFqQixHQUErQixVQUFVRCxJQUFWLEVBQWdCO0FBQzNDLFVBQUlFLEtBQUssR0FBRyxJQUFaOztBQUNBLFVBQUloUCxTQUFTLEdBQUcsQ0FBRSxLQUFLeEcsQ0FBTCxDQUFPNkosU0FBUCxLQUFxQixDQUF0QixJQUE0QixDQUE3QixJQUFrQyxFQUFsRDs7QUFDQSxVQUFJO0FBQ0EsWUFBSTRMLElBQUksR0FBRyxFQUFYOztBQUNBLFlBQUlILElBQUksQ0FBQ3BVLE1BQUwsR0FBY3NGLFNBQWxCLEVBQTZCO0FBQ3pCLGNBQUlrUCxFQUFFLEdBQUdKLElBQUksQ0FBQ0ssS0FBTCxDQUFXLFdBQVgsQ0FBVDtBQUNBRCxVQUFBQSxFQUFFLENBQUNFLE9BQUgsQ0FBVyxVQUFVQyxLQUFWLEVBQWlCO0FBQ3hCLGdCQUFJQyxFQUFFLEdBQUdOLEtBQUssQ0FBQ0gsT0FBTixDQUFjUSxLQUFkLENBQVQ7O0FBQ0FKLFlBQUFBLElBQUksSUFBSUssRUFBUjtBQUNILFdBSEQ7QUFJQSxpQkFBT2pWLE9BQU8sQ0FBQzRVLElBQUQsQ0FBZDtBQUNIOztBQUNELFlBQUl2UixDQUFDLEdBQUcsS0FBS21SLE9BQUwsQ0FBYUMsSUFBYixDQUFSO0FBQ0EsWUFBSWxWLENBQUMsR0FBR1MsT0FBTyxDQUFDcUQsQ0FBRCxDQUFmO0FBQ0EsZUFBTzlELENBQVA7QUFDSCxPQWJELENBY0EsT0FBTzJWLEVBQVAsRUFBVztBQUNQLGVBQU8sS0FBUDtBQUNIO0FBQ0osS0FwQkQ7QUFxQkE7QUFDSjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lyQixJQUFBQSxNQUFNLENBQUNuUyxTQUFQLENBQWlCeVQsV0FBakIsR0FBK0IsVUFBVVYsSUFBVixFQUFnQjtBQUMzQyxVQUFJRSxLQUFLLEdBQUcsSUFBWjs7QUFDQSxVQUFJaFAsU0FBUyxHQUFJLEtBQUt4RyxDQUFMLENBQU82SixTQUFQLEtBQXFCLENBQXRCLElBQTRCLENBQTVDO0FBQ0F5TCxNQUFBQSxJQUFJLEdBQUdqVSxRQUFRLENBQUNpVSxJQUFELENBQWY7O0FBQ0EsVUFBSTtBQUNBLFlBQUlBLElBQUksQ0FBQ3BVLE1BQUwsR0FBY3NGLFNBQWxCLEVBQTZCO0FBQ3pCLGNBQUl5UCxJQUFJLEdBQUcsRUFBWDtBQUNBLGNBQUlQLEVBQUUsR0FBR0osSUFBSSxDQUFDSyxLQUFMLENBQVcsV0FBWCxDQUFULENBRnlCLENBRVM7O0FBQ2xDRCxVQUFBQSxFQUFFLENBQUNFLE9BQUgsQ0FBVyxVQUFVQyxLQUFWLEVBQWlCO0FBQ3hCLGdCQUFJQyxFQUFFLEdBQUdOLEtBQUssQ0FBQ1UsT0FBTixDQUFjTCxLQUFkLENBQVQ7O0FBQ0FJLFlBQUFBLElBQUksSUFBSUgsRUFBUjtBQUNILFdBSEQ7QUFJQSxpQkFBT0csSUFBUDtBQUNIOztBQUNELFlBQUk3VixDQUFDLEdBQUcsS0FBSzhWLE9BQUwsQ0FBYVosSUFBYixDQUFSO0FBQ0EsZUFBT2xWLENBQVA7QUFDSCxPQVpELENBYUEsT0FBTzJWLEVBQVAsRUFBVztBQUNQLGVBQU8sS0FBUDtBQUNIO0FBQ0osS0FwQkQsQ0FwR29DLENBeUhwQztBQUNBOzs7QUFDQXJCLElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUI0VCxVQUFqQixHQUE4QixVQUFVaEIsQ0FBVixFQUFhQyxDQUFiLEVBQWdCZ0IsQ0FBaEIsRUFBbUI7QUFDN0MsVUFBSWpCLENBQUMsSUFBSSxJQUFMLElBQWFDLENBQUMsSUFBSSxJQUFsQixJQUEwQkQsQ0FBQyxDQUFDalUsTUFBRixHQUFXLENBQXJDLElBQTBDa1UsQ0FBQyxDQUFDbFUsTUFBRixHQUFXLENBQXpELEVBQTREO0FBQ3hELGFBQUtsQixDQUFMLEdBQVMrUixXQUFXLENBQUNvRCxDQUFELEVBQUksRUFBSixDQUFwQjtBQUNBLGFBQUt2TSxDQUFMLEdBQVN6SCxRQUFRLENBQUNpVSxDQUFELEVBQUksRUFBSixDQUFqQjtBQUNBLGFBQUt4VCxDQUFMLEdBQVNtUSxXQUFXLENBQUNxRSxDQUFELEVBQUksRUFBSixDQUFwQjtBQUNILE9BSkQsTUFLSztBQUNEL0IsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUJBQWQ7QUFDSDtBQUNKLEtBVEQsQ0EzSG9DLENBcUlwQztBQUNBOzs7QUFDQUksSUFBQUEsTUFBTSxDQUFDblMsU0FBUCxDQUFpQjhULFlBQWpCLEdBQWdDLFVBQVVsQixDQUFWLEVBQWFDLENBQWIsRUFBZ0JnQixDQUFoQixFQUFtQkUsQ0FBbkIsRUFBc0JDLENBQXRCLEVBQXlCQyxFQUF6QixFQUE2QkMsRUFBN0IsRUFBaUNDLENBQWpDLEVBQW9DO0FBQ2hFLFVBQUl2QixDQUFDLElBQUksSUFBTCxJQUFhQyxDQUFDLElBQUksSUFBbEIsSUFBMEJELENBQUMsQ0FBQ2pVLE1BQUYsR0FBVyxDQUFyQyxJQUEwQ2tVLENBQUMsQ0FBQ2xVLE1BQUYsR0FBVyxDQUF6RCxFQUE0RDtBQUN4RCxhQUFLbEIsQ0FBTCxHQUFTK1IsV0FBVyxDQUFDb0QsQ0FBRCxFQUFJLEVBQUosQ0FBcEI7QUFDQSxhQUFLdk0sQ0FBTCxHQUFTekgsUUFBUSxDQUFDaVUsQ0FBRCxFQUFJLEVBQUosQ0FBakI7QUFDQSxhQUFLeFQsQ0FBTCxHQUFTbVEsV0FBVyxDQUFDcUUsQ0FBRCxFQUFJLEVBQUosQ0FBcEI7QUFDQSxhQUFLbFUsQ0FBTCxHQUFTNlAsV0FBVyxDQUFDdUUsQ0FBRCxFQUFJLEVBQUosQ0FBcEI7QUFDQSxhQUFLMUosQ0FBTCxHQUFTbUYsV0FBVyxDQUFDd0UsQ0FBRCxFQUFJLEVBQUosQ0FBcEI7QUFDQSxhQUFLNUIsSUFBTCxHQUFZNUMsV0FBVyxDQUFDeUUsRUFBRCxFQUFLLEVBQUwsQ0FBdkI7QUFDQSxhQUFLNUIsSUFBTCxHQUFZN0MsV0FBVyxDQUFDMEUsRUFBRCxFQUFLLEVBQUwsQ0FBdkI7QUFDQSxhQUFLNUIsS0FBTCxHQUFhOUMsV0FBVyxDQUFDMkUsQ0FBRCxFQUFJLEVBQUosQ0FBeEI7QUFDSCxPQVRELE1BVUs7QUFDRHJDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLHlCQUFkO0FBQ0g7QUFDSixLQWRELENBdklvQyxDQXNKcEM7QUFDQTs7O0FBQ0FJLElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUJvVSxRQUFqQixHQUE0QixVQUFVQyxDQUFWLEVBQWF4QixDQUFiLEVBQWdCO0FBQ3hDLFVBQUlYLEdBQUcsR0FBRyxJQUFJUCxZQUFKLEVBQVY7QUFDQSxVQUFJMkMsRUFBRSxHQUFHRCxDQUFDLElBQUksQ0FBZDtBQUNBLFdBQUtoTyxDQUFMLEdBQVN6SCxRQUFRLENBQUNpVSxDQUFELEVBQUksRUFBSixDQUFqQjtBQUNBLFVBQUkwQixFQUFFLEdBQUcsSUFBSTVOLFVBQUosQ0FBZWtNLENBQWYsRUFBa0IsRUFBbEIsQ0FBVDs7QUFDQSxlQUFTO0FBQ0wsaUJBQVM7QUFDTCxlQUFLbFQsQ0FBTCxHQUFTLElBQUlnSCxVQUFKLENBQWUwTixDQUFDLEdBQUdDLEVBQW5CLEVBQXVCLENBQXZCLEVBQTBCcEMsR0FBMUIsQ0FBVDs7QUFDQSxjQUFJLEtBQUt2UyxDQUFMLENBQ0NvSyxRQURELENBQ1VwRCxVQUFVLENBQUMyRSxHQURyQixFQUVDRyxHQUZELENBRUs4SSxFQUZMLEVBR0NsTixTQUhELENBR1dWLFVBQVUsQ0FBQzJFLEdBSHRCLEtBRzhCLENBSDlCLElBSUEsS0FBSzNMLENBQUwsQ0FBTytMLGVBQVAsQ0FBdUIsRUFBdkIsQ0FKSixFQUlnQztBQUM1QjtBQUNIO0FBQ0o7O0FBQ0QsaUJBQVM7QUFDTCxlQUFLckIsQ0FBTCxHQUFTLElBQUkxRCxVQUFKLENBQWUyTixFQUFmLEVBQW1CLENBQW5CLEVBQXNCcEMsR0FBdEIsQ0FBVDs7QUFDQSxjQUFJLEtBQUs3SCxDQUFMLENBQ0NOLFFBREQsQ0FDVXBELFVBQVUsQ0FBQzJFLEdBRHJCLEVBRUNHLEdBRkQsQ0FFSzhJLEVBRkwsRUFHQ2xOLFNBSEQsQ0FHV1YsVUFBVSxDQUFDMkUsR0FIdEIsS0FHOEIsQ0FIOUIsSUFJQSxLQUFLakIsQ0FBTCxDQUFPcUIsZUFBUCxDQUF1QixFQUF2QixDQUpKLEVBSWdDO0FBQzVCO0FBQ0g7QUFDSjs7QUFDRCxZQUFJLEtBQUsvTCxDQUFMLENBQU8wSCxTQUFQLENBQWlCLEtBQUtnRCxDQUF0QixLQUE0QixDQUFoQyxFQUFtQztBQUMvQixjQUFJMUksQ0FBQyxHQUFHLEtBQUtoQyxDQUFiO0FBQ0EsZUFBS0EsQ0FBTCxHQUFTLEtBQUswSyxDQUFkO0FBQ0EsZUFBS0EsQ0FBTCxHQUFTMUksQ0FBVDtBQUNIOztBQUNELFlBQUk2UyxFQUFFLEdBQUcsS0FBSzdVLENBQUwsQ0FBT29LLFFBQVAsQ0FBZ0JwRCxVQUFVLENBQUMyRSxHQUEzQixDQUFUO0FBQ0EsWUFBSW1KLEVBQUUsR0FBRyxLQUFLcEssQ0FBTCxDQUFPTixRQUFQLENBQWdCcEQsVUFBVSxDQUFDMkUsR0FBM0IsQ0FBVDtBQUNBLFlBQUlvSixHQUFHLEdBQUdGLEVBQUUsQ0FBQ3hLLFFBQUgsQ0FBWXlLLEVBQVosQ0FBVjs7QUFDQSxZQUFJQyxHQUFHLENBQUNqSixHQUFKLENBQVE4SSxFQUFSLEVBQVlsTixTQUFaLENBQXNCVixVQUFVLENBQUMyRSxHQUFqQyxLQUF5QyxDQUE3QyxFQUFnRDtBQUM1QyxlQUFLN04sQ0FBTCxHQUFTLEtBQUtrQyxDQUFMLENBQU9xSyxRQUFQLENBQWdCLEtBQUtLLENBQXJCLENBQVQ7QUFDQSxlQUFLaEwsQ0FBTCxHQUFTa1YsRUFBRSxDQUFDcEosVUFBSCxDQUFjdUosR0FBZCxDQUFUO0FBQ0EsZUFBS3RDLElBQUwsR0FBWSxLQUFLL1MsQ0FBTCxDQUFPb0ksR0FBUCxDQUFXK00sRUFBWCxDQUFaO0FBQ0EsZUFBS25DLElBQUwsR0FBWSxLQUFLaFQsQ0FBTCxDQUFPb0ksR0FBUCxDQUFXZ04sRUFBWCxDQUFaO0FBQ0EsZUFBS25DLEtBQUwsR0FBYSxLQUFLakksQ0FBTCxDQUFPYyxVQUFQLENBQWtCLEtBQUt4TCxDQUF2QixDQUFiO0FBQ0E7QUFDSDtBQUNKO0FBQ0osS0EzQ0QsQ0F4Sm9DLENBb01wQztBQUNBO0FBQ0E7OztBQUNBd1MsSUFBQUEsTUFBTSxDQUFDblMsU0FBUCxDQUFpQjJULE9BQWpCLEdBQTJCLFVBQVVnQixLQUFWLEVBQWlCO0FBQ3hDLFVBQUlsVyxDQUFDLEdBQUcrUSxXQUFXLENBQUNtRixLQUFELEVBQVEsRUFBUixDQUFuQjtBQUNBLFVBQUl4VCxDQUFDLEdBQUcsS0FBS3FSLFNBQUwsQ0FBZS9ULENBQWYsQ0FBUjs7QUFDQSxVQUFJMEMsQ0FBQyxJQUFJLElBQVQsRUFBZTtBQUNYLGVBQU8sSUFBUDtBQUNIOztBQUNELGFBQU95VCxXQUFXLENBQUN6VCxDQUFELEVBQUssS0FBSzFELENBQUwsQ0FBTzZKLFNBQVAsS0FBcUIsQ0FBdEIsSUFBNEIsQ0FBaEMsQ0FBbEI7QUFDSCxLQVBELENBdk1vQyxDQStNcEM7OztBQUNBNkssSUFBQUEsTUFBTSxDQUFDblMsU0FBUCxDQUFpQjZVLGFBQWpCLEdBQWlDLFVBQVVSLENBQVYsRUFBYXhCLENBQWIsRUFBZ0JwRSxRQUFoQixFQUEwQjtBQUN2RCxVQUFJeUQsR0FBRyxHQUFHLElBQUlQLFlBQUosRUFBVjtBQUNBLFVBQUkyQyxFQUFFLEdBQUdELENBQUMsSUFBSSxDQUFkO0FBQ0EsV0FBS2hPLENBQUwsR0FBU3pILFFBQVEsQ0FBQ2lVLENBQUQsRUFBSSxFQUFKLENBQWpCO0FBQ0EsVUFBSTBCLEVBQUUsR0FBRyxJQUFJNU4sVUFBSixDQUFla00sQ0FBZixFQUFrQixFQUFsQixDQUFUO0FBQ0EsVUFBSWlDLEdBQUcsR0FBRyxJQUFWLENBTHVELENBTXZEO0FBQ0E7O0FBQ0EsVUFBSUMsS0FBSyxHQUFHLFNBQVJBLEtBQVEsR0FBWTtBQUNwQixZQUFJQyxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFZO0FBQ3BCLGNBQUlGLEdBQUcsQ0FBQ25WLENBQUosQ0FBTTBILFNBQU4sQ0FBZ0J5TixHQUFHLENBQUN6SyxDQUFwQixLQUEwQixDQUE5QixFQUFpQztBQUM3QixnQkFBSTFJLENBQUMsR0FBR21ULEdBQUcsQ0FBQ25WLENBQVo7QUFDQW1WLFlBQUFBLEdBQUcsQ0FBQ25WLENBQUosR0FBUW1WLEdBQUcsQ0FBQ3pLLENBQVo7QUFDQXlLLFlBQUFBLEdBQUcsQ0FBQ3pLLENBQUosR0FBUTFJLENBQVI7QUFDSDs7QUFDRCxjQUFJNlMsRUFBRSxHQUFHTSxHQUFHLENBQUNuVixDQUFKLENBQU1vSyxRQUFOLENBQWVwRCxVQUFVLENBQUMyRSxHQUExQixDQUFUO0FBQ0EsY0FBSW1KLEVBQUUsR0FBR0ssR0FBRyxDQUFDekssQ0FBSixDQUFNTixRQUFOLENBQWVwRCxVQUFVLENBQUMyRSxHQUExQixDQUFUO0FBQ0EsY0FBSW9KLEdBQUcsR0FBR0YsRUFBRSxDQUFDeEssUUFBSCxDQUFZeUssRUFBWixDQUFWOztBQUNBLGNBQUlDLEdBQUcsQ0FBQ2pKLEdBQUosQ0FBUThJLEVBQVIsRUFBWWxOLFNBQVosQ0FBc0JWLFVBQVUsQ0FBQzJFLEdBQWpDLEtBQXlDLENBQTdDLEVBQWdEO0FBQzVDd0osWUFBQUEsR0FBRyxDQUFDclgsQ0FBSixHQUFRcVgsR0FBRyxDQUFDblYsQ0FBSixDQUFNcUssUUFBTixDQUFlOEssR0FBRyxDQUFDekssQ0FBbkIsQ0FBUjtBQUNBeUssWUFBQUEsR0FBRyxDQUFDelYsQ0FBSixHQUFRa1YsRUFBRSxDQUFDcEosVUFBSCxDQUFjdUosR0FBZCxDQUFSO0FBQ0FJLFlBQUFBLEdBQUcsQ0FBQzFDLElBQUosR0FBVzBDLEdBQUcsQ0FBQ3pWLENBQUosQ0FBTW9JLEdBQU4sQ0FBVStNLEVBQVYsQ0FBWDtBQUNBTSxZQUFBQSxHQUFHLENBQUN6QyxJQUFKLEdBQVd5QyxHQUFHLENBQUN6VixDQUFKLENBQU1vSSxHQUFOLENBQVVnTixFQUFWLENBQVg7QUFDQUssWUFBQUEsR0FBRyxDQUFDeEMsS0FBSixHQUFZd0MsR0FBRyxDQUFDekssQ0FBSixDQUFNYyxVQUFOLENBQWlCMkosR0FBRyxDQUFDblYsQ0FBckIsQ0FBWjtBQUNBZ1AsWUFBQUEsVUFBVSxDQUFDLFlBQVk7QUFDbkJGLGNBQUFBLFFBQVE7QUFDWCxhQUZTLEVBRVAsQ0FGTyxDQUFWLENBTjRDLENBUXJDO0FBQ1YsV0FURCxNQVVLO0FBQ0RFLFlBQUFBLFVBQVUsQ0FBQ29HLEtBQUQsRUFBUSxDQUFSLENBQVY7QUFDSDtBQUNKLFNBdEJEOztBQXVCQSxZQUFJRSxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFZO0FBQ3BCSCxVQUFBQSxHQUFHLENBQUN6SyxDQUFKLEdBQVFuRCxHQUFHLEVBQVg7QUFDQTROLFVBQUFBLEdBQUcsQ0FBQ3pLLENBQUosQ0FBTXVFLGVBQU4sQ0FBc0IwRixFQUF0QixFQUEwQixDQUExQixFQUE2QnBDLEdBQTdCLEVBQWtDLFlBQVk7QUFDMUM0QyxZQUFBQSxHQUFHLENBQUN6SyxDQUFKLENBQU1OLFFBQU4sQ0FBZXBELFVBQVUsQ0FBQzJFLEdBQTFCLEVBQStCa0QsSUFBL0IsQ0FBb0MrRixFQUFwQyxFQUF3QyxVQUFVclcsQ0FBVixFQUFhO0FBQ2pELGtCQUFJQSxDQUFDLENBQUNtSixTQUFGLENBQVlWLFVBQVUsQ0FBQzJFLEdBQXZCLEtBQStCLENBQS9CLElBQW9Dd0osR0FBRyxDQUFDekssQ0FBSixDQUFNcUIsZUFBTixDQUFzQixFQUF0QixDQUF4QyxFQUFtRTtBQUMvRGlELGdCQUFBQSxVQUFVLENBQUNxRyxLQUFELEVBQVEsQ0FBUixDQUFWO0FBQ0gsZUFGRCxNQUdLO0FBQ0RyRyxnQkFBQUEsVUFBVSxDQUFDc0csS0FBRCxFQUFRLENBQVIsQ0FBVjtBQUNIO0FBQ0osYUFQRDtBQVFILFdBVEQ7QUFVSCxTQVpEOztBQWFBLFlBQUlDLEtBQUssR0FBRyxTQUFSQSxLQUFRLEdBQVk7QUFDcEJKLFVBQUFBLEdBQUcsQ0FBQ25WLENBQUosR0FBUXVILEdBQUcsRUFBWDtBQUNBNE4sVUFBQUEsR0FBRyxDQUFDblYsQ0FBSixDQUFNaVAsZUFBTixDQUFzQnlGLENBQUMsR0FBR0MsRUFBMUIsRUFBOEIsQ0FBOUIsRUFBaUNwQyxHQUFqQyxFQUFzQyxZQUFZO0FBQzlDNEMsWUFBQUEsR0FBRyxDQUFDblYsQ0FBSixDQUFNb0ssUUFBTixDQUFlcEQsVUFBVSxDQUFDMkUsR0FBMUIsRUFBK0JrRCxJQUEvQixDQUFvQytGLEVBQXBDLEVBQXdDLFVBQVVyVyxDQUFWLEVBQWE7QUFDakQsa0JBQUlBLENBQUMsQ0FBQ21KLFNBQUYsQ0FBWVYsVUFBVSxDQUFDMkUsR0FBdkIsS0FBK0IsQ0FBL0IsSUFBb0N3SixHQUFHLENBQUNuVixDQUFKLENBQU0rTCxlQUFOLENBQXNCLEVBQXRCLENBQXhDLEVBQW1FO0FBQy9EaUQsZ0JBQUFBLFVBQVUsQ0FBQ3NHLEtBQUQsRUFBUSxDQUFSLENBQVY7QUFDSCxlQUZELE1BR0s7QUFDRHRHLGdCQUFBQSxVQUFVLENBQUN1RyxLQUFELEVBQVEsQ0FBUixDQUFWO0FBQ0g7QUFDSixhQVBEO0FBUUgsV0FURDtBQVVILFNBWkQ7O0FBYUF2RyxRQUFBQSxVQUFVLENBQUN1RyxLQUFELEVBQVEsQ0FBUixDQUFWO0FBQ0gsT0FuREQ7O0FBb0RBdkcsTUFBQUEsVUFBVSxDQUFDb0csS0FBRCxFQUFRLENBQVIsQ0FBVjtBQUNILEtBN0REOztBQThEQTVDLElBQUFBLE1BQU0sQ0FBQ25TLFNBQVAsQ0FBaUJtVixJQUFqQixHQUF3QixVQUFVcEMsSUFBVixFQUFnQnFDLFlBQWhCLEVBQThCQyxVQUE5QixFQUEwQztBQUM5RCxVQUFJMVEsTUFBTSxHQUFHMlEsZUFBZSxDQUFDRCxVQUFELENBQTVCO0FBQ0EsVUFBSUUsTUFBTSxHQUFHNVEsTUFBTSxHQUFHeVEsWUFBWSxDQUFDckMsSUFBRCxDQUFaLENBQW1CalIsUUFBbkIsRUFBdEI7QUFDQSxVQUFJWCxDQUFDLEdBQUcwUSxTQUFTLENBQUMwRCxNQUFELEVBQVMsS0FBSzlYLENBQUwsQ0FBTzZKLFNBQVAsS0FBcUIsQ0FBOUIsQ0FBakI7O0FBQ0EsVUFBSW5HLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWCxlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJMUMsQ0FBQyxHQUFHLEtBQUsrVCxTQUFMLENBQWVyUixDQUFmLENBQVI7O0FBQ0EsVUFBSTFDLENBQUMsSUFBSSxJQUFULEVBQWU7QUFDWCxlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJRixDQUFDLEdBQUdFLENBQUMsQ0FBQ3FELFFBQUYsQ0FBVyxFQUFYLENBQVI7O0FBQ0EsVUFBSSxDQUFDdkQsQ0FBQyxDQUFDSSxNQUFGLEdBQVcsQ0FBWixLQUFrQixDQUF0QixFQUF5QjtBQUNyQixlQUFPSixDQUFQO0FBQ0gsT0FGRCxNQUdLO0FBQ0QsZUFBTyxNQUFNQSxDQUFiO0FBQ0g7QUFDSixLQWxCRDs7QUFtQkE0VCxJQUFBQSxNQUFNLENBQUNuUyxTQUFQLENBQWlCd1YsTUFBakIsR0FBMEIsVUFBVXpDLElBQVYsRUFBZ0IwQyxTQUFoQixFQUEyQkwsWUFBM0IsRUFBeUM7QUFDL0QsVUFBSTNXLENBQUMsR0FBRytRLFdBQVcsQ0FBQ2lHLFNBQUQsRUFBWSxFQUFaLENBQW5CO0FBQ0EsVUFBSXRVLENBQUMsR0FBRyxLQUFLb1IsUUFBTCxDQUFjOVQsQ0FBZCxDQUFSOztBQUNBLFVBQUkwQyxDQUFDLElBQUksSUFBVCxFQUFlO0FBQ1gsZUFBTyxJQUFQO0FBQ0g7O0FBQ0QsVUFBSXVVLFFBQVEsR0FBR3ZVLENBQUMsQ0FBQ1csUUFBRixDQUFXLEVBQVgsRUFBZTZULE9BQWYsQ0FBdUIsUUFBdkIsRUFBaUMsRUFBakMsQ0FBZjtBQUNBLFVBQUlKLE1BQU0sR0FBR0ssa0JBQWtCLENBQUNGLFFBQUQsQ0FBL0I7QUFDQSxhQUFPSCxNQUFNLElBQUlILFlBQVksQ0FBQ3JDLElBQUQsQ0FBWixDQUFtQmpSLFFBQW5CLEVBQWpCO0FBQ0gsS0FURDs7QUFVQSxXQUFPcVEsTUFBUDtBQUNILEdBNVMyQixFQUE1QixDQXAwRjRCLENBaW5HNUI7OztBQUNBLFdBQVN5QyxXQUFULENBQXFCdlYsQ0FBckIsRUFBd0I1QixDQUF4QixFQUEyQjtBQUN2QixRQUFJNkIsQ0FBQyxHQUFHRCxDQUFDLENBQUNtSixXQUFGLEVBQVI7QUFDQSxRQUFJaEssQ0FBQyxHQUFHLENBQVI7O0FBQ0EsV0FBT0EsQ0FBQyxHQUFHYyxDQUFDLENBQUNYLE1BQU4sSUFBZ0JXLENBQUMsQ0FBQ2QsQ0FBRCxDQUFELElBQVEsQ0FBL0IsRUFBa0M7QUFDOUIsUUFBRUEsQ0FBRjtBQUNIOztBQUNELFFBQUljLENBQUMsQ0FBQ1gsTUFBRixHQUFXSCxDQUFYLElBQWdCZixDQUFDLEdBQUcsQ0FBcEIsSUFBeUI2QixDQUFDLENBQUNkLENBQUQsQ0FBRCxJQUFRLENBQXJDLEVBQXdDO0FBQ3BDLGFBQU8sSUFBUDtBQUNIOztBQUNELE1BQUVBLENBQUY7O0FBQ0EsV0FBT2MsQ0FBQyxDQUFDZCxDQUFELENBQUQsSUFBUSxDQUFmLEVBQWtCO0FBQ2QsVUFBSSxFQUFFQSxDQUFGLElBQU9jLENBQUMsQ0FBQ1gsTUFBYixFQUFxQjtBQUNqQixlQUFPLElBQVA7QUFDSDtBQUNKOztBQUNELFFBQUlELEdBQUcsR0FBRyxFQUFWOztBQUNBLFdBQU8sRUFBRUYsQ0FBRixHQUFNYyxDQUFDLENBQUNYLE1BQWYsRUFBdUI7QUFDbkIsVUFBSUYsQ0FBQyxHQUFHYSxDQUFDLENBQUNkLENBQUQsQ0FBRCxHQUFPLEdBQWY7O0FBQ0EsVUFBSUMsQ0FBQyxHQUFHLEdBQVIsRUFBYTtBQUNUO0FBQ0FDLFFBQUFBLEdBQUcsSUFBSTJFLE1BQU0sQ0FBQ0MsWUFBUCxDQUFvQjdFLENBQXBCLENBQVA7QUFDSCxPQUhELE1BSUssSUFBSUEsQ0FBQyxHQUFHLEdBQUosSUFBV0EsQ0FBQyxHQUFHLEdBQW5CLEVBQXdCO0FBQ3pCQyxRQUFBQSxHQUFHLElBQUkyRSxNQUFNLENBQUNDLFlBQVAsQ0FBcUIsQ0FBQzdFLENBQUMsR0FBRyxFQUFMLEtBQVksQ0FBYixHQUFtQmEsQ0FBQyxDQUFDZCxDQUFDLEdBQUcsQ0FBTCxDQUFELEdBQVcsRUFBbEQsQ0FBUDtBQUNBLFVBQUVBLENBQUY7QUFDSCxPQUhJLE1BSUE7QUFDREUsUUFBQUEsR0FBRyxJQUFJMkUsTUFBTSxDQUFDQyxZQUFQLENBQXFCLENBQUM3RSxDQUFDLEdBQUcsRUFBTCxLQUFZLEVBQWIsR0FBb0IsQ0FBQ2EsQ0FBQyxDQUFDZCxDQUFDLEdBQUcsQ0FBTCxDQUFELEdBQVcsRUFBWixLQUFtQixDQUF2QyxHQUE2Q2MsQ0FBQyxDQUFDZCxDQUFDLEdBQUcsQ0FBTCxDQUFELEdBQVcsRUFBNUUsQ0FBUDtBQUNBQSxRQUFBQSxDQUFDLElBQUksQ0FBTDtBQUNIO0FBQ0o7O0FBQ0QsV0FBT0UsR0FBUDtBQUNILEdBbHBHMkIsQ0FtcEc1Qjs7O0FBQ0EsTUFBSW1YLGNBQWMsR0FBRztBQUNqQkMsSUFBQUEsR0FBRyxFQUFFLHNDQURZO0FBRWpCQyxJQUFBQSxHQUFHLEVBQUUsc0NBRlk7QUFHakJDLElBQUFBLElBQUksRUFBRSxnQ0FIVztBQUlqQkMsSUFBQUEsTUFBTSxFQUFFLHdDQUpTO0FBS2pCQyxJQUFBQSxNQUFNLEVBQUUsd0NBTFM7QUFNakJDLElBQUFBLE1BQU0sRUFBRSx3Q0FOUztBQU9qQkMsSUFBQUEsTUFBTSxFQUFFLHdDQVBTO0FBUWpCQyxJQUFBQSxTQUFTLEVBQUU7QUFSTSxHQUFyQjs7QUFVQSxXQUFTZixlQUFULENBQXlCZ0IsSUFBekIsRUFBK0I7QUFDM0IsV0FBT1QsY0FBYyxDQUFDUyxJQUFELENBQWQsSUFBd0IsRUFBL0I7QUFDSDs7QUFDRCxXQUFTVixrQkFBVCxDQUE0QnRULEdBQTVCLEVBQWlDO0FBQzdCLFNBQUssSUFBSWlVLE1BQVQsSUFBbUJWLGNBQW5CLEVBQW1DO0FBQy9CLFVBQUlBLGNBQWMsQ0FBQ2pXLGNBQWYsQ0FBOEIyVyxNQUE5QixDQUFKLEVBQTJDO0FBQ3ZDLFlBQUk1UixNQUFNLEdBQUdrUixjQUFjLENBQUNVLE1BQUQsQ0FBM0I7QUFDQSxZQUFJaFUsR0FBRyxHQUFHb0MsTUFBTSxDQUFDaEcsTUFBakI7O0FBQ0EsWUFBSTJELEdBQUcsQ0FBQzJELE1BQUosQ0FBVyxDQUFYLEVBQWMxRCxHQUFkLEtBQXNCb0MsTUFBMUIsRUFBa0M7QUFDOUIsaUJBQU9yQyxHQUFHLENBQUMyRCxNQUFKLENBQVcxRCxHQUFYLENBQVA7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsV0FBT0QsR0FBUDtBQUNILEdBNXFHMkIsQ0E2cUc1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQUlrVSxLQUFLLEdBQUcsRUFBWjtBQUNBQSxFQUFBQSxLQUFLLENBQUNDLElBQU4sR0FBYTtBQUNUO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSUMsSUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxJQUFULEVBQWVDLE1BQWYsRUFBdUJDLFNBQXZCLEVBQWtDO0FBQ3RDLFVBQUksQ0FBRUQsTUFBRixJQUFZLENBQUVELElBQWxCLEVBQXdCO0FBQ3BCLGNBQU0sSUFBSTlWLEtBQUosQ0FBVSxpREFDWixnQ0FERSxDQUFOO0FBRUg7O0FBRUQsVUFBSWlXLENBQUMsR0FBRyxTQUFKQSxDQUFJLEdBQVcsQ0FBRSxDQUFyQjs7QUFDQUEsTUFBQUEsQ0FBQyxDQUFDOVcsU0FBRixHQUFjNFcsTUFBTSxDQUFDNVcsU0FBckI7QUFDQTJXLE1BQUFBLElBQUksQ0FBQzNXLFNBQUwsR0FBaUIsSUFBSThXLENBQUosRUFBakI7QUFDQUgsTUFBQUEsSUFBSSxDQUFDM1csU0FBTCxDQUFlRCxXQUFmLEdBQTZCNFcsSUFBN0I7QUFDQUEsTUFBQUEsSUFBSSxDQUFDSSxVQUFMLEdBQWtCSCxNQUFNLENBQUM1VyxTQUF6Qjs7QUFFQSxVQUFJNFcsTUFBTSxDQUFDNVcsU0FBUCxDQUFpQkQsV0FBakIsSUFBZ0NSLE1BQU0sQ0FBQ1MsU0FBUCxDQUFpQkQsV0FBckQsRUFBa0U7QUFDOUQ2VyxRQUFBQSxNQUFNLENBQUM1VyxTQUFQLENBQWlCRCxXQUFqQixHQUErQjZXLE1BQS9CO0FBQ0g7O0FBRUQsVUFBSUMsU0FBSixFQUFlO0FBQ1gsWUFBSXJZLENBQUo7O0FBQ0EsYUFBS0EsQ0FBTCxJQUFVcVksU0FBVixFQUFxQjtBQUNqQkYsVUFBQUEsSUFBSSxDQUFDM1csU0FBTCxDQUFleEIsQ0FBZixJQUFvQnFZLFNBQVMsQ0FBQ3JZLENBQUQsQ0FBN0I7QUFDSDtBQUVEO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDWSxZQUFJd1ksVUFBVSxHQUFHLHNCQUFXLENBQUUsQ0FBOUI7QUFBQSxZQUNJQyxHQUFHLEdBQUcsQ0FBQyxVQUFELEVBQWEsU0FBYixDQURWOztBQUVBLFlBQUk7QUFDQSxjQUFJLE9BQU9DLElBQVAsQ0FBWXBILFNBQVMsQ0FBQ3FILFNBQXRCLENBQUosRUFBc0M7QUFDbENILFlBQUFBLFVBQVUsR0FBRyxvQkFBUzlZLENBQVQsRUFBWWEsQ0FBWixFQUFlO0FBQ3hCLG1CQUFLUCxDQUFDLEdBQUcsQ0FBVCxFQUFZQSxDQUFDLEdBQUd5WSxHQUFHLENBQUN0WSxNQUFwQixFQUE0QkgsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsQ0FBcEMsRUFBdUM7QUFDbkMsb0JBQUk0WSxLQUFLLEdBQUdILEdBQUcsQ0FBQ3pZLENBQUQsQ0FBZjtBQUFBLG9CQUFvQjBQLENBQUMsR0FBR25QLENBQUMsQ0FBQ3FZLEtBQUQsQ0FBekI7O0FBQ0Esb0JBQUksT0FBT2xKLENBQVAsS0FBYSxVQUFiLElBQTJCQSxDQUFDLElBQUkzTyxNQUFNLENBQUNTLFNBQVAsQ0FBaUJvWCxLQUFqQixDQUFwQyxFQUE2RDtBQUN6RGxaLGtCQUFBQSxDQUFDLENBQUNrWixLQUFELENBQUQsR0FBV2xKLENBQVg7QUFDSDtBQUNKO0FBQ0osYUFQRDtBQVFIO0FBQ0osU0FYRCxDQVdFLE9BQU9zRixFQUFQLEVBQVcsQ0FBRTs7QUFBWXdELFFBQUFBLFVBQVUsQ0FBQ0wsSUFBSSxDQUFDM1csU0FBTixFQUFpQjZXLFNBQWpCLENBQVY7QUFDOUI7QUFDSjtBQTlEUSxHQUFiO0FBaUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsTUFBSVEsSUFBSSxHQUFHLEVBQVg7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFJLE9BQU9BLElBQUksQ0FBQ0MsSUFBWixJQUFvQixXQUFwQixJQUFtQyxDQUFDRCxJQUFJLENBQUNDLElBQTdDLEVBQW1ERCxJQUFJLENBQUNDLElBQUwsR0FBWSxFQUFaO0FBRW5EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQUQsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsR0FBcUIsSUFBSSxZQUFXO0FBQ2hDLFNBQUtDLGdCQUFMLEdBQXdCLFVBQVNoWixDQUFULEVBQVk7QUFDaEMsVUFBSUQsQ0FBQyxHQUFHQyxDQUFDLENBQUNzRCxRQUFGLENBQVcsRUFBWCxDQUFSO0FBQ0EsVUFBS3ZELENBQUMsQ0FBQ0ksTUFBRixHQUFXLENBQVosSUFBa0IsQ0FBdEIsRUFBeUJKLENBQUMsR0FBRyxNQUFNQSxDQUFWO0FBQ3pCLGFBQU9BLENBQVA7QUFDSCxLQUpEOztBQUtBLFNBQUtrWiw2QkFBTCxHQUFxQyxVQUFTQyxlQUFULEVBQTBCO0FBQzNELFVBQUluWixDQUFDLEdBQUdtWixlQUFlLENBQUM1VixRQUFoQixDQUF5QixFQUF6QixDQUFSOztBQUNBLFVBQUl2RCxDQUFDLENBQUMwSCxNQUFGLENBQVMsQ0FBVCxFQUFZLENBQVosS0FBa0IsR0FBdEIsRUFBMkI7QUFDdkIsWUFBSTFILENBQUMsQ0FBQ0ksTUFBRixHQUFXLENBQVgsSUFBZ0IsQ0FBcEIsRUFBdUI7QUFDbkJKLFVBQUFBLENBQUMsR0FBRyxNQUFNQSxDQUFWO0FBQ0gsU0FGRCxNQUVPO0FBQ0gsY0FBSSxDQUFFQSxDQUFDLENBQUM2VSxLQUFGLENBQVEsUUFBUixDQUFOLEVBQXlCO0FBQ3JCN1UsWUFBQUEsQ0FBQyxHQUFHLE9BQU9BLENBQVg7QUFDSDtBQUNKO0FBQ0osT0FSRCxNQVFPO0FBQ0gsWUFBSW9aLElBQUksR0FBR3BaLENBQUMsQ0FBQzBILE1BQUYsQ0FBUyxDQUFULENBQVg7QUFDQSxZQUFJMlIsTUFBTSxHQUFHRCxJQUFJLENBQUNoWixNQUFsQjs7QUFDQSxZQUFJaVosTUFBTSxHQUFHLENBQVQsSUFBYyxDQUFsQixFQUFxQjtBQUNqQkEsVUFBQUEsTUFBTSxJQUFJLENBQVY7QUFDSCxTQUZELE1BRU87QUFDSCxjQUFJLENBQUVyWixDQUFDLENBQUM2VSxLQUFGLENBQVEsUUFBUixDQUFOLEVBQXlCO0FBQ3JCd0UsWUFBQUEsTUFBTSxJQUFJLENBQVY7QUFDSDtBQUNKOztBQUNELFlBQUlDLEtBQUssR0FBRyxFQUFaOztBQUNBLGFBQUssSUFBSXJaLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdvWixNQUFwQixFQUE0QnBaLENBQUMsRUFBN0IsRUFBaUM7QUFDN0JxWixVQUFBQSxLQUFLLElBQUksR0FBVDtBQUNIOztBQUNELFlBQUlDLE1BQU0sR0FBRyxJQUFJblIsVUFBSixDQUFla1IsS0FBZixFQUFzQixFQUF0QixDQUFiO0FBQ0EsWUFBSUUsS0FBSyxHQUFHRCxNQUFNLENBQUNoUCxHQUFQLENBQVc0TyxlQUFYLEVBQTRCN04sR0FBNUIsQ0FBZ0NsRCxVQUFVLENBQUMyRSxHQUEzQyxDQUFaO0FBQ0EvTSxRQUFBQSxDQUFDLEdBQUd3WixLQUFLLENBQUNqVyxRQUFOLENBQWUsRUFBZixFQUFtQjZULE9BQW5CLENBQTJCLElBQTNCLEVBQWlDLEVBQWpDLENBQUo7QUFDSDs7QUFDRCxhQUFPcFgsQ0FBUDtBQUNILEtBN0JEO0FBOEJBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS3laLG1CQUFMLEdBQTJCLFVBQVNDLE9BQVQsRUFBa0JDLFNBQWxCLEVBQTZCO0FBQ3BELGFBQU9DLFFBQVEsQ0FBQ0YsT0FBRCxFQUFVQyxTQUFWLENBQWY7QUFDSCxLQUZEO0FBSUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS0UsU0FBTCxHQUFpQixVQUFTQyxLQUFULEVBQWdCO0FBQzdCLFVBQUlDLEtBQUssR0FBR2pCLElBQVo7QUFBQSxVQUNJa0IsVUFBVSxHQUFHRCxLQUFLLENBQUNoQixJQUR2QjtBQUFBLFVBRUlrQixXQUFXLEdBQUdELFVBQVUsQ0FBQ0UsVUFGN0I7QUFBQSxVQUdJQyxXQUFXLEdBQUdILFVBQVUsQ0FBQ0ksVUFIN0I7QUFBQSxVQUlJQyxhQUFhLEdBQUdMLFVBQVUsQ0FBQ00sWUFKL0I7QUFBQSxVQUtJQyxlQUFlLEdBQUdQLFVBQVUsQ0FBQ1EsY0FMakM7QUFBQSxVQU1JQyxRQUFRLEdBQUdULFVBQVUsQ0FBQ1UsT0FOMUI7QUFBQSxVQU9JQyxvQkFBb0IsR0FBR1gsVUFBVSxDQUFDWSxtQkFQdEM7QUFBQSxVQVFJQyxjQUFjLEdBQUdiLFVBQVUsQ0FBQ2MsYUFSaEM7QUFBQSxVQVNJQyxjQUFjLEdBQUdmLFVBQVUsQ0FBQ2dCLGFBVGhDO0FBQUEsVUFVSUMsaUJBQWlCLEdBQUdqQixVQUFVLENBQUNrQixnQkFWbkM7QUFBQSxVQVdJQyxtQkFBbUIsR0FBR25CLFVBQVUsQ0FBQ29CLGtCQVhyQztBQUFBLFVBWUlDLGlCQUFpQixHQUFHckIsVUFBVSxDQUFDc0IsZ0JBWm5DO0FBQUEsVUFhSUMsYUFBYSxHQUFHdkIsVUFBVSxDQUFDd0IsWUFiL0I7QUFBQSxVQWNJQyxXQUFXLEdBQUd6QixVQUFVLENBQUMwQixVQWQ3QjtBQUFBLFVBZUlDLG1CQUFtQixHQUFHM0IsVUFBVSxDQUFDNEIsa0JBZnJDO0FBQUEsVUFnQklDLFlBQVksR0FBRzdCLFVBQVUsQ0FBQzhCLFdBaEI5QjtBQUFBLFVBaUJJQyxPQUFPLEdBQUcvQixVQUFVLENBQUNnQyxNQWpCekI7QUFBQSxVQWtCSUMsZ0JBQWdCLEdBQUdqQyxVQUFVLENBQUNrQyxlQWxCbEM7QUFBQSxVQW1CSUMsVUFBVSxHQUFHbkMsVUFBVSxDQUFDaEIsUUFBWCxDQUFvQmEsU0FuQnJDO0FBcUJBLFVBQUl1QyxJQUFJLEdBQUdwYixNQUFNLENBQUNvYixJQUFQLENBQVl0QyxLQUFaLENBQVg7QUFDQSxVQUFJc0MsSUFBSSxDQUFDaGMsTUFBTCxJQUFlLENBQW5CLEVBQ0ksTUFBTSxpQ0FBTjtBQUNKLFVBQUk0UixHQUFHLEdBQUdvSyxJQUFJLENBQUMsQ0FBRCxDQUFkO0FBRUEsVUFBSSx5R0FBeUd4YixPQUF6RyxDQUFpSCxNQUFNb1IsR0FBTixHQUFZLEdBQTdILEtBQXFJLENBQUMsQ0FBMUksRUFDSSxNQUFNLG9CQUFvQkEsR0FBMUI7QUFFSixVQUFJQSxHQUFHLElBQUksTUFBWCxFQUFzQixPQUFPLElBQUlpSSxXQUFKLENBQWdCSCxLQUFLLENBQUM5SCxHQUFELENBQXJCLENBQVA7QUFDdEIsVUFBSUEsR0FBRyxJQUFJLEtBQVgsRUFBc0IsT0FBTyxJQUFJbUksV0FBSixDQUFnQkwsS0FBSyxDQUFDOUgsR0FBRCxDQUFyQixDQUFQO0FBQ3RCLFVBQUlBLEdBQUcsSUFBSSxRQUFYLEVBQXNCLE9BQU8sSUFBSXFJLGFBQUosQ0FBa0JQLEtBQUssQ0FBQzlILEdBQUQsQ0FBdkIsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksUUFBWCxFQUFzQixPQUFPLElBQUl1SSxlQUFKLENBQW9CVCxLQUFLLENBQUM5SCxHQUFELENBQXpCLENBQVA7QUFDdEIsVUFBSUEsR0FBRyxJQUFJLE1BQVgsRUFBc0IsT0FBTyxJQUFJeUksUUFBSixDQUFhWCxLQUFLLENBQUM5SCxHQUFELENBQWxCLENBQVA7QUFDdEIsVUFBSUEsR0FBRyxJQUFJLEtBQVgsRUFBc0IsT0FBTyxJQUFJMkksb0JBQUosQ0FBeUJiLEtBQUssQ0FBQzlILEdBQUQsQ0FBOUIsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksTUFBWCxFQUFzQixPQUFPLElBQUk2SSxjQUFKLENBQW1CZixLQUFLLENBQUM5SCxHQUFELENBQXhCLENBQVA7QUFDdEIsVUFBSUEsR0FBRyxJQUFJLFNBQVgsRUFBc0IsT0FBTyxJQUFJK0ksY0FBSixDQUFtQmpCLEtBQUssQ0FBQzlILEdBQUQsQ0FBeEIsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksUUFBWCxFQUFzQixPQUFPLElBQUlpSixpQkFBSixDQUFzQm5CLEtBQUssQ0FBQzlILEdBQUQsQ0FBM0IsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksUUFBWCxFQUFzQixPQUFPLElBQUltSixtQkFBSixDQUF3QnJCLEtBQUssQ0FBQzlILEdBQUQsQ0FBN0IsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksUUFBWCxFQUFzQixPQUFPLElBQUlxSixpQkFBSixDQUFzQnZCLEtBQUssQ0FBQzlILEdBQUQsQ0FBM0IsQ0FBUDtBQUN0QixVQUFJQSxHQUFHLElBQUksUUFBWCxFQUFzQixPQUFPLElBQUl1SixhQUFKLENBQWtCekIsS0FBSyxDQUFDOUgsR0FBRCxDQUF2QixDQUFQO0FBQ3RCLFVBQUlBLEdBQUcsSUFBSSxTQUFYLEVBQXNCLE9BQU8sSUFBSXlKLFdBQUosQ0FBZ0IzQixLQUFLLENBQUM5SCxHQUFELENBQXJCLENBQVA7QUFDdEIsVUFBSUEsR0FBRyxJQUFJLFNBQVgsRUFBc0IsT0FBTyxJQUFJMkosbUJBQUosQ0FBd0I3QixLQUFLLENBQUM5SCxHQUFELENBQTdCLENBQVA7O0FBRXRCLFVBQUlBLEdBQUcsSUFBSSxLQUFYLEVBQWtCO0FBQ2QsWUFBSXFLLFNBQVMsR0FBR3ZDLEtBQUssQ0FBQzlILEdBQUQsQ0FBckI7QUFDQSxZQUFJbFEsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsYUFBSyxJQUFJN0IsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR29jLFNBQVMsQ0FBQ2pjLE1BQTlCLEVBQXNDSCxDQUFDLEVBQXZDLEVBQTJDO0FBQ3ZDLGNBQUlxYyxPQUFPLEdBQUdILFVBQVUsQ0FBQ0UsU0FBUyxDQUFDcGMsQ0FBRCxDQUFWLENBQXhCOztBQUNBNkIsVUFBQUEsQ0FBQyxDQUFDeWEsSUFBRixDQUFPRCxPQUFQO0FBQ0g7O0FBQ0QsZUFBTyxJQUFJVCxZQUFKLENBQWlCO0FBQUMsbUJBQVMvWjtBQUFWLFNBQWpCLENBQVA7QUFDSDs7QUFFRCxVQUFJa1EsR0FBRyxJQUFJLEtBQVgsRUFBa0I7QUFDZCxZQUFJcUssU0FBUyxHQUFHdkMsS0FBSyxDQUFDOUgsR0FBRCxDQUFyQjtBQUNBLFlBQUlsUSxDQUFDLEdBQUcsRUFBUjs7QUFDQSxhQUFLLElBQUk3QixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHb2MsU0FBUyxDQUFDamMsTUFBOUIsRUFBc0NILENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsY0FBSXFjLE9BQU8sR0FBR0gsVUFBVSxDQUFDRSxTQUFTLENBQUNwYyxDQUFELENBQVYsQ0FBeEI7O0FBQ0E2QixVQUFBQSxDQUFDLENBQUN5YSxJQUFGLENBQU9ELE9BQVA7QUFDSDs7QUFDRCxlQUFPLElBQUlQLE9BQUosQ0FBWTtBQUFDLG1CQUFTamE7QUFBVixTQUFaLENBQVA7QUFDSDs7QUFFRCxVQUFJa1EsR0FBRyxJQUFJLEtBQVgsRUFBa0I7QUFDZCxZQUFJd0ssUUFBUSxHQUFHMUMsS0FBSyxDQUFDOUgsR0FBRCxDQUFwQjs7QUFDQSxZQUFJaFIsTUFBTSxDQUFDUyxTQUFQLENBQWlCOEIsUUFBakIsQ0FBMEJrWixJQUExQixDQUErQkQsUUFBL0IsTUFBNkMsZ0JBQTdDLElBQ0FBLFFBQVEsQ0FBQ3BjLE1BQVQsSUFBbUIsQ0FEdkIsRUFDMEI7QUFDdEIsY0FBSXNjLEdBQUcsR0FBR1AsVUFBVSxDQUFDSyxRQUFRLENBQUMsQ0FBRCxDQUFULENBQXBCOztBQUNBLGlCQUFPLElBQUlQLGdCQUFKLENBQXFCO0FBQUM1VixZQUFBQSxHQUFHLEVBQUVtVyxRQUFRLENBQUMsQ0FBRCxDQUFkO0FBQ3hCRyxZQUFBQSxRQUFRLEVBQUVILFFBQVEsQ0FBQyxDQUFELENBRE07QUFFeEJFLFlBQUFBLEdBQUcsRUFBRUE7QUFGbUIsV0FBckIsQ0FBUDtBQUdILFNBTkQsTUFNTztBQUNILGNBQUlFLFFBQVEsR0FBRyxFQUFmO0FBQ0EsY0FBSUosUUFBUSxDQUFDRyxRQUFULEtBQXNCNWEsU0FBMUIsRUFDSTZhLFFBQVEsQ0FBQ0QsUUFBVCxHQUFvQkgsUUFBUSxDQUFDRyxRQUE3QjtBQUNKLGNBQUlILFFBQVEsQ0FBQ25XLEdBQVQsS0FBaUJ0RSxTQUFyQixFQUNJNmEsUUFBUSxDQUFDdlcsR0FBVCxHQUFlbVcsUUFBUSxDQUFDblcsR0FBeEI7QUFDSixjQUFJbVcsUUFBUSxDQUFDRSxHQUFULEtBQWlCM2EsU0FBckIsRUFDSSxNQUFNLG1DQUFOO0FBQ0o2YSxVQUFBQSxRQUFRLENBQUNGLEdBQVQsR0FBZVAsVUFBVSxDQUFDSyxRQUFRLENBQUNFLEdBQVYsQ0FBekI7QUFDQSxpQkFBTyxJQUFJVCxnQkFBSixDQUFxQlcsUUFBckIsQ0FBUDtBQUNIO0FBQ0o7QUFDSixLQXJGRDtBQXVGQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLQyxhQUFMLEdBQXFCLFVBQVMvQyxLQUFULEVBQWdCO0FBQ2pDLFVBQUl3QyxPQUFPLEdBQUcsS0FBS3pDLFNBQUwsQ0FBZUMsS0FBZixDQUFkO0FBQ0EsYUFBT3dDLE9BQU8sQ0FBQ1EsYUFBUixFQUFQO0FBQ0gsS0FIRDtBQUlILEdBck5vQixFQUFyQjtBQXVOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBaEUsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUIrRCxXQUFuQixHQUFpQyxVQUFTL2EsR0FBVCxFQUFjO0FBQzNDLFFBQUl4QixDQUFDLEdBQUcsRUFBUjtBQUNBLFFBQUl3YyxHQUFHLEdBQUczYyxRQUFRLENBQUMyQixHQUFHLENBQUMwRixNQUFKLENBQVcsQ0FBWCxFQUFjLENBQWQsQ0FBRCxFQUFtQixFQUFuQixDQUFsQjtBQUNBLFFBQUl1VixFQUFFLEdBQUdwVyxJQUFJLENBQUNvRSxLQUFMLENBQVcrUixHQUFHLEdBQUcsRUFBakIsQ0FBVDtBQUNBLFFBQUlFLEVBQUUsR0FBR0YsR0FBRyxHQUFHLEVBQWY7QUFDQSxRQUFJeGMsQ0FBQyxHQUFHeWMsRUFBRSxHQUFHLEdBQUwsR0FBV0MsRUFBbkI7QUFFQSxRQUFJQyxNQUFNLEdBQUcsRUFBYjs7QUFDQSxTQUFLLElBQUlsZCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHK0IsR0FBRyxDQUFDNUIsTUFBeEIsRUFBZ0NILENBQUMsSUFBSSxDQUFyQyxFQUF3QztBQUNwQyxVQUFJK0MsS0FBSyxHQUFHM0MsUUFBUSxDQUFDMkIsR0FBRyxDQUFDMEYsTUFBSixDQUFXekgsQ0FBWCxFQUFjLENBQWQsQ0FBRCxFQUFtQixFQUFuQixDQUFwQjtBQUNBLFVBQUltZCxHQUFHLEdBQUcsQ0FBQyxhQUFhcGEsS0FBSyxDQUFDTyxRQUFOLENBQWUsQ0FBZixDQUFkLEVBQWlDOFosS0FBakMsQ0FBdUMsQ0FBRSxDQUF6QyxDQUFWO0FBQ0FGLE1BQUFBLE1BQU0sR0FBR0EsTUFBTSxHQUFHQyxHQUFHLENBQUMxVixNQUFKLENBQVcsQ0FBWCxFQUFjLENBQWQsQ0FBbEI7O0FBQ0EsVUFBSTBWLEdBQUcsQ0FBQzFWLE1BQUosQ0FBVyxDQUFYLEVBQWMsQ0FBZCxLQUFvQixHQUF4QixFQUE2QjtBQUN6QixZQUFJNFYsRUFBRSxHQUFHLElBQUlsVixVQUFKLENBQWUrVSxNQUFmLEVBQXVCLENBQXZCLENBQVQ7QUFDQTNjLFFBQUFBLENBQUMsR0FBR0EsQ0FBQyxHQUFHLEdBQUosR0FBVThjLEVBQUUsQ0FBQy9aLFFBQUgsQ0FBWSxFQUFaLENBQWQ7QUFDQTRaLFFBQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0g7QUFDSjs7QUFDRCxXQUFPM2MsQ0FBUDtBQUNILEdBbkJEO0FBcUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBc1ksRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJ1RSxXQUFuQixHQUFpQyxVQUFTQyxTQUFULEVBQW9CO0FBQ2pELFFBQUlDLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQVN4ZCxDQUFULEVBQVk7QUFDbkIsVUFBSUQsQ0FBQyxHQUFHQyxDQUFDLENBQUNzRCxRQUFGLENBQVcsRUFBWCxDQUFSO0FBQ0EsVUFBSXZELENBQUMsQ0FBQ0ksTUFBRixJQUFZLENBQWhCLEVBQW1CSixDQUFDLEdBQUcsTUFBTUEsQ0FBVjtBQUNuQixhQUFPQSxDQUFQO0FBQ0gsS0FKRDs7QUFNQSxRQUFJMGQsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBU0MsSUFBVCxFQUFlO0FBQ3pCLFVBQUkzZCxDQUFDLEdBQUcsRUFBUjtBQUNBLFVBQUlzZCxFQUFFLEdBQUcsSUFBSWxWLFVBQUosQ0FBZXVWLElBQWYsRUFBcUIsRUFBckIsQ0FBVDtBQUNBLFVBQUk1YyxDQUFDLEdBQUd1YyxFQUFFLENBQUMvWixRQUFILENBQVksQ0FBWixDQUFSO0FBQ0EsVUFBSXFhLE1BQU0sR0FBRyxJQUFJN2MsQ0FBQyxDQUFDWCxNQUFGLEdBQVcsQ0FBNUI7QUFDQSxVQUFJd2QsTUFBTSxJQUFJLENBQWQsRUFBaUJBLE1BQU0sR0FBRyxDQUFUO0FBQ2pCLFVBQUlDLElBQUksR0FBRyxFQUFYOztBQUNBLFdBQUssSUFBSTVkLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcyZCxNQUFwQixFQUE0QjNkLENBQUMsRUFBN0I7QUFBaUM0ZCxRQUFBQSxJQUFJLElBQUksR0FBUjtBQUFqQzs7QUFDQTljLE1BQUFBLENBQUMsR0FBRzhjLElBQUksR0FBRzljLENBQVg7O0FBQ0EsV0FBSyxJQUFJZCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHYyxDQUFDLENBQUNYLE1BQUYsR0FBVyxDQUEvQixFQUFrQ0gsQ0FBQyxJQUFJLENBQXZDLEVBQTBDO0FBQ3RDLFlBQUk2ZCxFQUFFLEdBQUcvYyxDQUFDLENBQUMyRyxNQUFGLENBQVN6SCxDQUFULEVBQVksQ0FBWixDQUFUO0FBQ0EsWUFBSUEsQ0FBQyxJQUFJYyxDQUFDLENBQUNYLE1BQUYsR0FBVyxDQUFwQixFQUF1QjBkLEVBQUUsR0FBRyxNQUFNQSxFQUFYO0FBQ3ZCOWQsUUFBQUEsQ0FBQyxJQUFJeWQsSUFBSSxDQUFDcGQsUUFBUSxDQUFDeWQsRUFBRCxFQUFLLENBQUwsQ0FBVCxDQUFUO0FBQ0g7O0FBQ0QsYUFBTzlkLENBQVA7QUFDSCxLQWZEOztBQWlCQSxRQUFJLENBQUV3ZCxTQUFTLENBQUMzSSxLQUFWLENBQWdCLFdBQWhCLENBQU4sRUFBb0M7QUFDaEMsWUFBTSwyQkFBMkIySSxTQUFqQztBQUNIOztBQUNELFFBQUl4ZCxDQUFDLEdBQUcsRUFBUjtBQUNBLFFBQUk4QixDQUFDLEdBQUcwYixTQUFTLENBQUNPLEtBQVYsQ0FBZ0IsR0FBaEIsQ0FBUjtBQUNBLFFBQUlkLEVBQUUsR0FBRzVjLFFBQVEsQ0FBQ3lCLENBQUMsQ0FBQyxDQUFELENBQUYsQ0FBUixHQUFpQixFQUFqQixHQUFzQnpCLFFBQVEsQ0FBQ3lCLENBQUMsQ0FBQyxDQUFELENBQUYsQ0FBdkM7QUFDQTlCLElBQUFBLENBQUMsSUFBSXlkLElBQUksQ0FBQ1IsRUFBRCxDQUFUO0FBQ0FuYixJQUFBQSxDQUFDLENBQUNrYyxNQUFGLENBQVMsQ0FBVCxFQUFZLENBQVo7O0FBQ0EsU0FBSyxJQUFJL2QsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzZCLENBQUMsQ0FBQzFCLE1BQXRCLEVBQThCSCxDQUFDLEVBQS9CLEVBQW1DO0FBQy9CRCxNQUFBQSxDQUFDLElBQUkwZCxPQUFPLENBQUM1YixDQUFDLENBQUM3QixDQUFELENBQUYsQ0FBWjtBQUNIOztBQUNELFdBQU9ELENBQVA7QUFDSCxHQXBDRCxDQTNsSDRCLENBa29INUI7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E4WSxFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVWtGLFVBQVYsR0FBdUIsWUFBVztBQUM5QixRQUFJQyxFQUFFLEdBQUcsRUFBVDtBQUVBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNJLFNBQUtDLHFCQUFMLEdBQTZCLFlBQVc7QUFDcEMsVUFBSSxPQUFPLEtBQUtELEVBQVosSUFBa0IsV0FBbEIsSUFBaUMsS0FBS0EsRUFBTCxJQUFXLElBQWhELEVBQXNEO0FBQ2xELGNBQU0sK0JBQU47QUFDSDs7QUFDRCxVQUFJLEtBQUtBLEVBQUwsQ0FBUTlkLE1BQVIsR0FBaUIsQ0FBakIsSUFBc0IsQ0FBMUIsRUFBNkI7QUFDekIsY0FBTSxzQ0FBc0M4ZCxFQUFFLENBQUM5ZCxNQUF6QyxHQUFrRCxLQUFsRCxHQUEwRCxLQUFLOGQsRUFBckU7QUFDSDs7QUFDRCxVQUFJaGYsQ0FBQyxHQUFHLEtBQUtnZixFQUFMLENBQVE5ZCxNQUFSLEdBQWlCLENBQXpCO0FBQ0EsVUFBSWdlLEVBQUUsR0FBR2xmLENBQUMsQ0FBQ3FFLFFBQUYsQ0FBVyxFQUFYLENBQVQ7O0FBQ0EsVUFBSTZhLEVBQUUsQ0FBQ2hlLE1BQUgsR0FBWSxDQUFaLElBQWlCLENBQXJCLEVBQXdCO0FBQ3BCZ2UsUUFBQUEsRUFBRSxHQUFHLE1BQU1BLEVBQVg7QUFDSDs7QUFDRCxVQUFJbGYsQ0FBQyxHQUFHLEdBQVIsRUFBYTtBQUNULGVBQU9rZixFQUFQO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsWUFBSUMsS0FBSyxHQUFHRCxFQUFFLENBQUNoZSxNQUFILEdBQVksQ0FBeEI7O0FBQ0EsWUFBSWllLEtBQUssR0FBRyxFQUFaLEVBQWdCO0FBQ1osZ0JBQU0sbURBQW1EbmYsQ0FBQyxDQUFDcUUsUUFBRixDQUFXLEVBQVgsQ0FBekQ7QUFDSDs7QUFDRCxZQUFJK2EsSUFBSSxHQUFHLE1BQU1ELEtBQWpCO0FBQ0EsZUFBT0MsSUFBSSxDQUFDL2EsUUFBTCxDQUFjLEVBQWQsSUFBb0I2YSxFQUEzQjtBQUNIO0FBQ0osS0F0QkQ7QUF3QkE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUt0QixhQUFMLEdBQXFCLFlBQVc7QUFDNUIsVUFBSSxLQUFLeUIsSUFBTCxJQUFhLElBQWIsSUFBcUIsS0FBS0MsVUFBOUIsRUFBMEM7QUFDdEMsYUFBS04sRUFBTCxHQUFVLEtBQUtPLGdCQUFMLEVBQVY7QUFDQSxhQUFLQyxFQUFMLEdBQVUsS0FBS1AscUJBQUwsRUFBVjtBQUNBLGFBQUtJLElBQUwsR0FBWSxLQUFLSSxFQUFMLEdBQVUsS0FBS0QsRUFBZixHQUFvQixLQUFLUixFQUFyQztBQUNBLGFBQUtNLFVBQUwsR0FBa0IsS0FBbEIsQ0FKc0MsQ0FLdEM7QUFDSDs7QUFDRCxhQUFPLEtBQUtELElBQVo7QUFDSCxLQVREO0FBV0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUtLLFdBQUwsR0FBbUIsWUFBVztBQUMxQixXQUFLOUIsYUFBTDtBQUNBLGFBQU8sS0FBS29CLEVBQVo7QUFDSCxLQUhEOztBQUtBLFNBQUtPLGdCQUFMLEdBQXdCLFlBQVc7QUFDL0IsYUFBTyxFQUFQO0FBQ0gsS0FGRDtBQUdILEdBbkVELENBbnBINEIsQ0F3dEg1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTNGLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVOEYsaUJBQVYsR0FBOEIsVUFBU0MsTUFBVCxFQUFpQjtBQUMzQ2hHLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVOEYsaUJBQVYsQ0FBNEJyRyxVQUE1QixDQUF1Q2hYLFdBQXZDLENBQW1EaWIsSUFBbkQsQ0FBd0QsSUFBeEQ7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDSSxTQUFLc0MsU0FBTCxHQUFpQixZQUFXO0FBQ3hCLGFBQU8sS0FBS3ZlLENBQVo7QUFDSCxLQUZEO0FBSUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUt3ZSxTQUFMLEdBQWlCLFVBQVNDLElBQVQsRUFBZTtBQUM1QixXQUFLVixJQUFMLEdBQVksSUFBWjtBQUNBLFdBQUtDLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxXQUFLaGUsQ0FBTCxHQUFTeWUsSUFBVDtBQUNBLFdBQUtmLEVBQUwsR0FBVWdCLE1BQU0sQ0FBQyxLQUFLMWUsQ0FBTixDQUFoQjtBQUNILEtBTEQ7QUFPQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBSzJlLFlBQUwsR0FBb0IsVUFBU0MsWUFBVCxFQUF1QjtBQUN2QyxXQUFLYixJQUFMLEdBQVksSUFBWjtBQUNBLFdBQUtDLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxXQUFLaGUsQ0FBTCxHQUFTLElBQVQ7QUFDQSxXQUFLMGQsRUFBTCxHQUFVa0IsWUFBVjtBQUNILEtBTEQ7O0FBT0EsU0FBS1gsZ0JBQUwsR0FBd0IsWUFBVztBQUMvQixhQUFPLEtBQUtQLEVBQVo7QUFDSCxLQUZEOztBQUlBLFFBQUksT0FBT1ksTUFBUCxJQUFpQixXQUFyQixFQUFrQztBQUM5QixVQUFJLE9BQU9BLE1BQVAsSUFBaUIsUUFBckIsRUFBK0I7QUFDM0IsYUFBS0UsU0FBTCxDQUFlRixNQUFmO0FBQ0gsT0FGRCxNQUVPLElBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUM1QyxhQUFLRSxTQUFMLENBQWVGLE1BQU0sQ0FBQyxLQUFELENBQXJCO0FBQ0gsT0FGTSxNQUVBLElBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUM1QyxhQUFLSyxZQUFMLENBQWtCTCxNQUFNLENBQUMsS0FBRCxDQUF4QjtBQUNIO0FBQ0o7QUFDSixHQXZERDs7QUF3REE3RyxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVU4RixpQkFBNUIsRUFBK0MvRixJQUFJLENBQUNDLElBQUwsQ0FBVWtGLFVBQXpELEVBbHlINEIsQ0FteUg1QjtBQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQW5GLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVc0csZUFBVixHQUE0QixVQUFTUCxNQUFULEVBQWlCO0FBQ3pDaEcsSUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVzRyxlQUFWLENBQTBCN0csVUFBMUIsQ0FBcUNoWCxXQUFyQyxDQUFpRGliLElBQWpELENBQXNELElBQXRELEVBRHlDLENBR3pDOztBQUNBLFNBQUs2QyxjQUFMLEdBQXNCLFVBQVN4ZSxDQUFULEVBQVk7QUFDOUJ5ZSxNQUFBQSxHQUFHLEdBQUd6ZSxDQUFDLENBQUMwZSxPQUFGLEtBQWUxZSxDQUFDLENBQUMyZSxpQkFBRixLQUF3QixLQUE3QztBQUNBLFVBQUlDLE9BQU8sR0FBRyxJQUFJQyxJQUFKLENBQVNKLEdBQVQsQ0FBZDtBQUNBLGFBQU9HLE9BQVA7QUFDSCxLQUpEO0FBTUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUtFLFVBQUwsR0FBa0IsVUFBU0MsVUFBVCxFQUFxQkMsSUFBckIsRUFBMkJDLFVBQTNCLEVBQXVDO0FBQ3JELFVBQUl2YSxHQUFHLEdBQUcsS0FBS3dhLFdBQWY7QUFDQSxVQUFJbGYsQ0FBQyxHQUFHLEtBQUt3ZSxjQUFMLENBQW9CTyxVQUFwQixDQUFSO0FBQ0EsVUFBSUksSUFBSSxHQUFHbmIsTUFBTSxDQUFDaEUsQ0FBQyxDQUFDb2YsV0FBRixFQUFELENBQWpCO0FBQ0EsVUFBSUosSUFBSSxJQUFJLEtBQVosRUFBbUJHLElBQUksR0FBR0EsSUFBSSxDQUFDdlksTUFBTCxDQUFZLENBQVosRUFBZSxDQUFmLENBQVA7QUFDbkIsVUFBSXlZLEtBQUssR0FBRzNhLEdBQUcsQ0FBQ1YsTUFBTSxDQUFDaEUsQ0FBQyxDQUFDc2YsUUFBRixLQUFlLENBQWhCLENBQVAsRUFBMkIsQ0FBM0IsQ0FBZjtBQUNBLFVBQUlDLEdBQUcsR0FBRzdhLEdBQUcsQ0FBQ1YsTUFBTSxDQUFDaEUsQ0FBQyxDQUFDd2YsT0FBRixFQUFELENBQVAsRUFBc0IsQ0FBdEIsQ0FBYjtBQUNBLFVBQUlDLElBQUksR0FBRy9hLEdBQUcsQ0FBQ1YsTUFBTSxDQUFDaEUsQ0FBQyxDQUFDMGYsUUFBRixFQUFELENBQVAsRUFBdUIsQ0FBdkIsQ0FBZDtBQUNBLFVBQUlyVyxHQUFHLEdBQUczRSxHQUFHLENBQUNWLE1BQU0sQ0FBQ2hFLENBQUMsQ0FBQzJmLFVBQUYsRUFBRCxDQUFQLEVBQXlCLENBQXpCLENBQWI7QUFDQSxVQUFJQyxHQUFHLEdBQUdsYixHQUFHLENBQUNWLE1BQU0sQ0FBQ2hFLENBQUMsQ0FBQzZmLFVBQUYsRUFBRCxDQUFQLEVBQXlCLENBQXpCLENBQWI7QUFDQSxVQUFJbmdCLENBQUMsR0FBR3lmLElBQUksR0FBR0UsS0FBUCxHQUFlRSxHQUFmLEdBQXFCRSxJQUFyQixHQUE0QnBXLEdBQTVCLEdBQWtDdVcsR0FBMUM7O0FBQ0EsVUFBSVgsVUFBVSxLQUFLLElBQW5CLEVBQXlCO0FBQ3JCLFlBQUlhLE1BQU0sR0FBRzlmLENBQUMsQ0FBQytmLGVBQUYsRUFBYjs7QUFDQSxZQUFJRCxNQUFNLElBQUksQ0FBZCxFQUFpQjtBQUNiLGNBQUlFLE9BQU8sR0FBR3RiLEdBQUcsQ0FBQ1YsTUFBTSxDQUFDOGIsTUFBRCxDQUFQLEVBQWlCLENBQWpCLENBQWpCO0FBQ0FFLFVBQUFBLE9BQU8sR0FBR0EsT0FBTyxDQUFDMUosT0FBUixDQUFnQixPQUFoQixFQUF5QixFQUF6QixDQUFWO0FBQ0E1VyxVQUFBQSxDQUFDLEdBQUdBLENBQUMsR0FBRyxHQUFKLEdBQVVzZ0IsT0FBZDtBQUNIO0FBQ0o7O0FBQ0QsYUFBT3RnQixDQUFDLEdBQUcsR0FBWDtBQUNILEtBcEJEOztBQXNCQSxTQUFLd2YsV0FBTCxHQUFtQixVQUFTeGYsQ0FBVCxFQUFZd0QsR0FBWixFQUFpQjtBQUNoQyxVQUFJeEQsQ0FBQyxDQUFDSixNQUFGLElBQVk0RCxHQUFoQixFQUFxQixPQUFPeEQsQ0FBUDtBQUNyQixhQUFPLElBQUlXLEtBQUosQ0FBVTZDLEdBQUcsR0FBR3hELENBQUMsQ0FBQ0osTUFBUixHQUFpQixDQUEzQixFQUE4QjJnQixJQUE5QixDQUFtQyxHQUFuQyxJQUEwQ3ZnQixDQUFqRDtBQUNILEtBSEQsQ0ExQ3lDLENBK0N6Qzs7QUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS3VlLFNBQUwsR0FBaUIsWUFBVztBQUN4QixhQUFPLEtBQUt2ZSxDQUFaO0FBQ0gsS0FGRDtBQUlBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLd2UsU0FBTCxHQUFpQixVQUFTQyxJQUFULEVBQWU7QUFDNUIsV0FBS1YsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS2hlLENBQUwsR0FBU3llLElBQVQ7QUFDQSxXQUFLZixFQUFMLEdBQVVnQixNQUFNLENBQUNELElBQUQsQ0FBaEI7QUFDSCxLQUxEO0FBT0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLK0IsY0FBTCxHQUFzQixVQUFTZixJQUFULEVBQWVFLEtBQWYsRUFBc0JFLEdBQXRCLEVBQTJCRSxJQUEzQixFQUFpQ3BXLEdBQWpDLEVBQXNDdVcsR0FBdEMsRUFBMkM7QUFDN0QsVUFBSWIsVUFBVSxHQUFHLElBQUlGLElBQUosQ0FBU0EsSUFBSSxDQUFDc0IsR0FBTCxDQUFTaEIsSUFBVCxFQUFlRSxLQUFLLEdBQUcsQ0FBdkIsRUFBMEJFLEdBQTFCLEVBQStCRSxJQUEvQixFQUFxQ3BXLEdBQXJDLEVBQTBDdVcsR0FBMUMsRUFBK0MsQ0FBL0MsQ0FBVCxDQUFqQjtBQUNBLFdBQUtRLFNBQUwsQ0FBZXJCLFVBQWY7QUFDSCxLQUhEOztBQUtBLFNBQUtwQixnQkFBTCxHQUF3QixZQUFXO0FBQy9CLGFBQU8sS0FBS1AsRUFBWjtBQUNILEtBRkQ7QUFHSCxHQTdGRDs7QUE4RkFqRyxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVVzRyxlQUE1QixFQUE2Q3ZHLElBQUksQ0FBQ0MsSUFBTCxDQUFVa0YsVUFBdkQsRUE3NEg0QixDQTg0SDVCO0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBbkYsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVvSSxxQkFBVixHQUFrQyxVQUFTckMsTUFBVCxFQUFpQjtBQUMvQ2hHLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVOEYsaUJBQVYsQ0FBNEJyRyxVQUE1QixDQUF1Q2hYLFdBQXZDLENBQW1EaWIsSUFBbkQsQ0FBd0QsSUFBeEQ7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDSSxTQUFLMkUsb0JBQUwsR0FBNEIsVUFBU0MsZUFBVCxFQUEwQjtBQUNsRCxXQUFLOUMsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBSzhDLFNBQUwsR0FBaUJELGVBQWpCO0FBQ0gsS0FKRDtBQU1BO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLRSxnQkFBTCxHQUF3QixVQUFTQyxVQUFULEVBQXFCO0FBQ3pDLFdBQUtqRCxJQUFMLEdBQVksSUFBWjtBQUNBLFdBQUtDLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxXQUFLOEMsU0FBTCxDQUFlL0UsSUFBZixDQUFvQmlGLFVBQXBCO0FBQ0gsS0FKRDs7QUFNQSxTQUFLRixTQUFMLEdBQWlCLElBQUluZ0IsS0FBSixFQUFqQjs7QUFDQSxRQUFJLE9BQU8yZCxNQUFQLElBQWlCLFdBQXJCLEVBQWtDO0FBQzlCLFVBQUksT0FBT0EsTUFBTSxDQUFDLE9BQUQsQ0FBYixJQUEwQixXQUE5QixFQUEyQztBQUN2QyxhQUFLd0MsU0FBTCxHQUFpQnhDLE1BQU0sQ0FBQyxPQUFELENBQXZCO0FBQ0g7QUFDSjtBQUNKLEdBbkNEOztBQW9DQTdHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVW9JLHFCQUE1QixFQUFtRHJJLElBQUksQ0FBQ0MsSUFBTCxDQUFVa0YsVUFBN0QsRUE5N0g0QixDQWk4SDVCO0FBQ0E7QUFDQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVW1CLFVBQVYsR0FBdUIsWUFBVztBQUM5QnBCLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVbUIsVUFBVixDQUFxQjFCLFVBQXJCLENBQWdDaFgsV0FBaEMsQ0FBNENpYixJQUE1QyxDQUFpRCxJQUFqRDtBQUNBLFNBQUtrQyxFQUFMLEdBQVUsSUFBVjtBQUNBLFNBQUtKLElBQUwsR0FBWSxRQUFaO0FBQ0gsR0FKRDs7QUFLQXRHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVW1CLFVBQTVCLEVBQXdDcEIsSUFBSSxDQUFDQyxJQUFMLENBQVVrRixVQUFsRCxFQW45SDRCLENBcTlINUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQVYsR0FBdUIsVUFBUzBFLE1BQVQsRUFBaUI7QUFDcENoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQVYsQ0FBcUI1QixVQUFyQixDQUFnQ2hYLFdBQWhDLENBQTRDaWIsSUFBNUMsQ0FBaUQsSUFBakQ7QUFDQSxTQUFLa0MsRUFBTCxHQUFVLElBQVY7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDSSxTQUFLOEMsZUFBTCxHQUF1QixVQUFTdEksZUFBVCxFQUEwQjtBQUM3QyxXQUFLb0YsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS04sRUFBTCxHQUFVcEYsSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJFLDZCQUFuQixDQUFpREMsZUFBakQsQ0FBVjtBQUNILEtBSkQ7QUFNQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS3VJLFlBQUwsR0FBb0IsVUFBUzlYLFFBQVQsRUFBbUI7QUFDbkMsVUFBSTBULEVBQUUsR0FBRyxJQUFJbFYsVUFBSixDQUFldEQsTUFBTSxDQUFDOEUsUUFBRCxDQUFyQixFQUFpQyxFQUFqQyxDQUFUO0FBQ0EsV0FBSzZYLGVBQUwsQ0FBcUJuRSxFQUFyQjtBQUNILEtBSEQ7QUFLQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUtxRSxXQUFMLEdBQW1CLFVBQVN2QyxZQUFULEVBQXVCO0FBQ3RDLFdBQUtsQixFQUFMLEdBQVVrQixZQUFWO0FBQ0gsS0FGRDs7QUFJQSxTQUFLWCxnQkFBTCxHQUF3QixZQUFXO0FBQy9CLGFBQU8sS0FBS1AsRUFBWjtBQUNILEtBRkQ7O0FBSUEsUUFBSSxPQUFPWSxNQUFQLElBQWlCLFdBQXJCLEVBQWtDO0FBQzlCLFVBQUksT0FBT0EsTUFBTSxDQUFDLFFBQUQsQ0FBYixJQUEyQixXQUEvQixFQUE0QztBQUN4QyxhQUFLMkMsZUFBTCxDQUFxQjNDLE1BQU0sQ0FBQyxRQUFELENBQTNCO0FBQ0gsT0FGRCxNQUVPLElBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUM1QyxhQUFLNEMsWUFBTCxDQUFrQjVDLE1BQU0sQ0FBQyxLQUFELENBQXhCO0FBQ0gsT0FGTSxNQUVBLElBQUksT0FBT0EsTUFBUCxJQUFpQixRQUFyQixFQUErQjtBQUNsQyxhQUFLNEMsWUFBTCxDQUFrQjVDLE1BQWxCO0FBQ0gsT0FGTSxNQUVBLElBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUM1QyxhQUFLNkMsV0FBTCxDQUFpQjdDLE1BQU0sQ0FBQyxLQUFELENBQXZCO0FBQ0g7QUFDSjtBQUNKLEdBL0REOztBQWdFQTdHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQTVCLEVBQXdDdEIsSUFBSSxDQUFDQyxJQUFMLENBQVVrRixVQUFsRCxFQXRpSTRCLENBd2lJNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQW5GLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVdUIsWUFBVixHQUF5QixVQUFTd0UsTUFBVCxFQUFpQjtBQUN0QyxRQUFJQSxNQUFNLEtBQUsvYyxTQUFYLElBQXdCLE9BQU8rYyxNQUFNLENBQUNwQyxHQUFkLEtBQXNCLFdBQWxELEVBQStEO0FBQzNELFVBQUlrRixDQUFDLEdBQUc5SSxJQUFJLENBQUNDLElBQUwsQ0FBVUMsUUFBVixDQUFtQmEsU0FBbkIsQ0FBNkJpRixNQUFNLENBQUNwQyxHQUFwQyxDQUFSO0FBQ0FvQyxNQUFBQSxNQUFNLENBQUM5YyxHQUFQLEdBQWEsT0FBTzRmLENBQUMsQ0FBQzlFLGFBQUYsRUFBcEI7QUFDSDs7QUFDRGhFLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVdUIsWUFBVixDQUF1QjlCLFVBQXZCLENBQWtDaFgsV0FBbEMsQ0FBOENpYixJQUE5QyxDQUFtRCxJQUFuRDtBQUNBLFNBQUtrQyxFQUFMLEdBQVUsSUFBVjtBQUVBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNJLFNBQUtrRCw4QkFBTCxHQUFzQyxVQUFTQywrQkFBVCxFQUEwQztBQUM1RSxXQUFLdkQsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS04sRUFBTCxHQUFVNEQsK0JBQVY7QUFDSCxLQUpEO0FBTUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS0Msd0JBQUwsR0FBZ0MsVUFBU0MsVUFBVCxFQUFxQkMsTUFBckIsRUFBNkI7QUFDekQsVUFBSUQsVUFBVSxHQUFHLENBQWIsSUFBa0IsSUFBSUEsVUFBMUIsRUFBc0M7QUFDbEMsY0FBTSwyQ0FBMkNBLFVBQWpEO0FBQ0g7O0FBQ0QsVUFBSUUsV0FBVyxHQUFHLE1BQU1GLFVBQXhCO0FBQ0EsV0FBS3pELElBQUwsR0FBWSxJQUFaO0FBQ0EsV0FBS0MsVUFBTCxHQUFrQixJQUFsQjtBQUNBLFdBQUtOLEVBQUwsR0FBVWdFLFdBQVcsR0FBR0QsTUFBeEI7QUFDSCxLQVJEO0FBVUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS0UsaUJBQUwsR0FBeUIsVUFBU0MsWUFBVCxFQUF1QjtBQUM1Q0EsTUFBQUEsWUFBWSxHQUFHQSxZQUFZLENBQUNoTCxPQUFiLENBQXFCLEtBQXJCLEVBQTRCLEVBQTVCLENBQWY7QUFDQSxVQUFJNEssVUFBVSxHQUFHLElBQUlJLFlBQVksQ0FBQ2hpQixNQUFiLEdBQXNCLENBQTNDO0FBQ0EsVUFBSTRoQixVQUFVLElBQUksQ0FBbEIsRUFBcUJBLFVBQVUsR0FBRyxDQUFiOztBQUNyQixXQUFLLElBQUkvaEIsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsSUFBSStoQixVQUFyQixFQUFpQy9oQixDQUFDLEVBQWxDLEVBQXNDO0FBQ2xDbWlCLFFBQUFBLFlBQVksSUFBSSxHQUFoQjtBQUNIOztBQUNELFVBQUlwaUIsQ0FBQyxHQUFHLEVBQVI7O0FBQ0EsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHbWlCLFlBQVksQ0FBQ2hpQixNQUFiLEdBQXNCLENBQTFDLEVBQTZDSCxDQUFDLElBQUksQ0FBbEQsRUFBcUQ7QUFDakQsWUFBSWMsQ0FBQyxHQUFHcWhCLFlBQVksQ0FBQzFhLE1BQWIsQ0FBb0J6SCxDQUFwQixFQUF1QixDQUF2QixDQUFSO0FBQ0EsWUFBSVosQ0FBQyxHQUFHZ0IsUUFBUSxDQUFDVSxDQUFELEVBQUksQ0FBSixDQUFSLENBQWV3QyxRQUFmLENBQXdCLEVBQXhCLENBQVI7QUFDQSxZQUFJbEUsQ0FBQyxDQUFDZSxNQUFGLElBQVksQ0FBaEIsRUFBbUJmLENBQUMsR0FBRyxNQUFNQSxDQUFWO0FBQ25CVyxRQUFBQSxDQUFDLElBQUlYLENBQUw7QUFDSDs7QUFDRCxXQUFLa2YsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS04sRUFBTCxHQUFVLE1BQU04RCxVQUFOLEdBQW1CaGlCLENBQTdCO0FBQ0gsS0FqQkQ7QUFtQkE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLcWlCLGlCQUFMLEdBQXlCLFVBQVNDLFlBQVQsRUFBdUI7QUFDNUMsVUFBSTloQixDQUFDLEdBQUcsRUFBUjs7QUFDQSxXQUFLLElBQUlQLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdxaUIsWUFBWSxDQUFDbGlCLE1BQWpDLEVBQXlDSCxDQUFDLEVBQTFDLEVBQThDO0FBQzFDLFlBQUlxaUIsWUFBWSxDQUFDcmlCLENBQUQsQ0FBWixJQUFtQixJQUF2QixFQUE2QjtBQUN6Qk8sVUFBQUEsQ0FBQyxJQUFJLEdBQUw7QUFDSCxTQUZELE1BRU87QUFDSEEsVUFBQUEsQ0FBQyxJQUFJLEdBQUw7QUFDSDtBQUNKOztBQUNELFdBQUsyaEIsaUJBQUwsQ0FBdUIzaEIsQ0FBdkI7QUFDSCxLQVZEO0FBWUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUsraEIsYUFBTCxHQUFxQixVQUFTQyxPQUFULEVBQWtCO0FBQ25DLFVBQUkxZ0IsQ0FBQyxHQUFHLElBQUlYLEtBQUosQ0FBVXFoQixPQUFWLENBQVI7O0FBQ0EsV0FBSyxJQUFJdmlCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd1aUIsT0FBcEIsRUFBNkJ2aUIsQ0FBQyxFQUE5QixFQUFrQztBQUM5QjZCLFFBQUFBLENBQUMsQ0FBQzdCLENBQUQsQ0FBRCxHQUFPLEtBQVA7QUFDSDs7QUFDRCxhQUFPNkIsQ0FBUDtBQUNILEtBTkQ7O0FBUUEsU0FBSzJjLGdCQUFMLEdBQXdCLFlBQVc7QUFDL0IsYUFBTyxLQUFLUCxFQUFaO0FBQ0gsS0FGRDs7QUFJQSxRQUFJLE9BQU9ZLE1BQVAsSUFBaUIsV0FBckIsRUFBa0M7QUFDOUIsVUFBSSxPQUFPQSxNQUFQLElBQWlCLFFBQWpCLElBQTZCQSxNQUFNLENBQUM1YyxXQUFQLEdBQXFCMlMsS0FBckIsQ0FBMkIsYUFBM0IsQ0FBakMsRUFBNEU7QUFDeEUsYUFBS2dOLDhCQUFMLENBQW9DL0MsTUFBcEM7QUFDSCxPQUZELE1BRU8sSUFBSSxPQUFPQSxNQUFNLENBQUMsS0FBRCxDQUFiLElBQXdCLFdBQTVCLEVBQXlDO0FBQzVDLGFBQUsrQyw4QkFBTCxDQUFvQy9DLE1BQU0sQ0FBQyxLQUFELENBQTFDO0FBQ0gsT0FGTSxNQUVBLElBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUM1QyxhQUFLcUQsaUJBQUwsQ0FBdUJyRCxNQUFNLENBQUMsS0FBRCxDQUE3QjtBQUNILE9BRk0sTUFFQSxJQUFJLE9BQU9BLE1BQU0sQ0FBQyxPQUFELENBQWIsSUFBMEIsV0FBOUIsRUFBMkM7QUFDOUMsYUFBS3VELGlCQUFMLENBQXVCdkQsTUFBTSxDQUFDLE9BQUQsQ0FBN0I7QUFDSDtBQUNKO0FBQ0osR0FwSUQ7O0FBcUlBN0csRUFBQUEsS0FBSyxDQUFDQyxJQUFOLENBQVdDLE1BQVgsQ0FBa0JXLElBQUksQ0FBQ0MsSUFBTCxDQUFVdUIsWUFBNUIsRUFBMEN4QixJQUFJLENBQUNDLElBQUwsQ0FBVWtGLFVBQXBELEVBcHRJNEIsQ0FzdEk1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXlCLGNBQVYsR0FBMkIsVUFBU3NFLE1BQVQsRUFBaUI7QUFDeEMsUUFBSUEsTUFBTSxLQUFLL2MsU0FBWCxJQUF3QixPQUFPK2MsTUFBTSxDQUFDcEMsR0FBZCxLQUFzQixXQUFsRCxFQUErRDtBQUMzRCxVQUFJa0YsQ0FBQyxHQUFHOUksSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJhLFNBQW5CLENBQTZCaUYsTUFBTSxDQUFDcEMsR0FBcEMsQ0FBUjtBQUNBb0MsTUFBQUEsTUFBTSxDQUFDOWMsR0FBUCxHQUFhNGYsQ0FBQyxDQUFDOUUsYUFBRixFQUFiO0FBQ0g7O0FBQ0RoRSxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXlCLGNBQVYsQ0FBeUJoQyxVQUF6QixDQUFvQ2hYLFdBQXBDLENBQWdEaWIsSUFBaEQsQ0FBcUQsSUFBckQsRUFBMkRxQyxNQUEzRDtBQUNBLFNBQUtILEVBQUwsR0FBVSxJQUFWO0FBQ0gsR0FQRDs7QUFRQTFHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVXlCLGNBQTVCLEVBQTRDMUIsSUFBSSxDQUFDQyxJQUFMLENBQVU4RixpQkFBdEQsRUFud0k0QixDQXF3STVCOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EvRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVTJCLE9BQVYsR0FBb0IsWUFBVztBQUMzQjVCLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVMkIsT0FBVixDQUFrQmxDLFVBQWxCLENBQTZCaFgsV0FBN0IsQ0FBeUNpYixJQUF6QyxDQUE4QyxJQUE5QztBQUNBLFNBQUtrQyxFQUFMLEdBQVUsSUFBVjtBQUNBLFNBQUtKLElBQUwsR0FBWSxNQUFaO0FBQ0gsR0FKRDs7QUFLQXRHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVTJCLE9BQTVCLEVBQXFDNUIsSUFBSSxDQUFDQyxJQUFMLENBQVVrRixVQUEvQyxFQW54STRCLENBcXhJNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVTZCLG1CQUFWLEdBQWdDLFVBQVNrRSxNQUFULEVBQWlCO0FBQzdDLFFBQUlyQixJQUFJLEdBQUcsU0FBUEEsSUFBTyxDQUFTeGQsQ0FBVCxFQUFZO0FBQ25CLFVBQUlELENBQUMsR0FBR0MsQ0FBQyxDQUFDc0QsUUFBRixDQUFXLEVBQVgsQ0FBUjtBQUNBLFVBQUl2RCxDQUFDLENBQUNJLE1BQUYsSUFBWSxDQUFoQixFQUFtQkosQ0FBQyxHQUFHLE1BQU1BLENBQVY7QUFDbkIsYUFBT0EsQ0FBUDtBQUNILEtBSkQ7O0FBS0EsUUFBSTBkLE9BQU8sR0FBRyxTQUFWQSxPQUFVLENBQVNDLElBQVQsRUFBZTtBQUN6QixVQUFJM2QsQ0FBQyxHQUFHLEVBQVI7QUFDQSxVQUFJc2QsRUFBRSxHQUFHLElBQUlsVixVQUFKLENBQWV1VixJQUFmLEVBQXFCLEVBQXJCLENBQVQ7QUFDQSxVQUFJNWMsQ0FBQyxHQUFHdWMsRUFBRSxDQUFDL1osUUFBSCxDQUFZLENBQVosQ0FBUjtBQUNBLFVBQUlxYSxNQUFNLEdBQUcsSUFBSTdjLENBQUMsQ0FBQ1gsTUFBRixHQUFXLENBQTVCO0FBQ0EsVUFBSXdkLE1BQU0sSUFBSSxDQUFkLEVBQWlCQSxNQUFNLEdBQUcsQ0FBVDtBQUNqQixVQUFJQyxJQUFJLEdBQUcsRUFBWDs7QUFDQSxXQUFLLElBQUk1ZCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHMmQsTUFBcEIsRUFBNEIzZCxDQUFDLEVBQTdCO0FBQWlDNGQsUUFBQUEsSUFBSSxJQUFJLEdBQVI7QUFBakM7O0FBQ0E5YyxNQUFBQSxDQUFDLEdBQUc4YyxJQUFJLEdBQUc5YyxDQUFYOztBQUNBLFdBQUssSUFBSWQsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2MsQ0FBQyxDQUFDWCxNQUFGLEdBQVcsQ0FBL0IsRUFBa0NILENBQUMsSUFBSSxDQUF2QyxFQUEwQztBQUN0QyxZQUFJNmQsRUFBRSxHQUFHL2MsQ0FBQyxDQUFDMkcsTUFBRixDQUFTekgsQ0FBVCxFQUFZLENBQVosQ0FBVDtBQUNBLFlBQUlBLENBQUMsSUFBSWMsQ0FBQyxDQUFDWCxNQUFGLEdBQVcsQ0FBcEIsRUFBdUIwZCxFQUFFLEdBQUcsTUFBTUEsRUFBWDtBQUN2QjlkLFFBQUFBLENBQUMsSUFBSXlkLElBQUksQ0FBQ3BkLFFBQVEsQ0FBQ3lkLEVBQUQsRUFBSyxDQUFMLENBQVQsQ0FBVDtBQUNIOztBQUNELGFBQU85ZCxDQUFQO0FBQ0gsS0FmRDs7QUFpQkE4WSxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVTZCLG1CQUFWLENBQThCcEMsVUFBOUIsQ0FBeUNoWCxXQUF6QyxDQUFxRGliLElBQXJELENBQTBELElBQTFEO0FBQ0EsU0FBS2tDLEVBQUwsR0FBVSxJQUFWO0FBRUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0ksU0FBS2dELFdBQUwsR0FBbUIsVUFBU3ZDLFlBQVQsRUFBdUI7QUFDdEMsV0FBS2IsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS2hlLENBQUwsR0FBUyxJQUFUO0FBQ0EsV0FBSzBkLEVBQUwsR0FBVWtCLFlBQVY7QUFDSCxLQUxEO0FBT0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJLFNBQUtxRCxpQkFBTCxHQUF5QixVQUFTakYsU0FBVCxFQUFvQjtBQUN6QyxVQUFJLENBQUVBLFNBQVMsQ0FBQzNJLEtBQVYsQ0FBZ0IsV0FBaEIsQ0FBTixFQUFvQztBQUNoQyxjQUFNLDJCQUEyQjJJLFNBQWpDO0FBQ0g7O0FBQ0QsVUFBSXhkLENBQUMsR0FBRyxFQUFSO0FBQ0EsVUFBSThCLENBQUMsR0FBRzBiLFNBQVMsQ0FBQ08sS0FBVixDQUFnQixHQUFoQixDQUFSO0FBQ0EsVUFBSWQsRUFBRSxHQUFHNWMsUUFBUSxDQUFDeUIsQ0FBQyxDQUFDLENBQUQsQ0FBRixDQUFSLEdBQWlCLEVBQWpCLEdBQXNCekIsUUFBUSxDQUFDeUIsQ0FBQyxDQUFDLENBQUQsQ0FBRixDQUF2QztBQUNBOUIsTUFBQUEsQ0FBQyxJQUFJeWQsSUFBSSxDQUFDUixFQUFELENBQVQ7QUFDQW5iLE1BQUFBLENBQUMsQ0FBQ2tjLE1BQUYsQ0FBUyxDQUFULEVBQVksQ0FBWjs7QUFDQSxXQUFLLElBQUkvZCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHNkIsQ0FBQyxDQUFDMUIsTUFBdEIsRUFBOEJILENBQUMsRUFBL0IsRUFBbUM7QUFDL0JELFFBQUFBLENBQUMsSUFBSTBkLE9BQU8sQ0FBQzViLENBQUMsQ0FBQzdCLENBQUQsQ0FBRixDQUFaO0FBQ0g7O0FBQ0QsV0FBS3NlLElBQUwsR0FBWSxJQUFaO0FBQ0EsV0FBS0MsVUFBTCxHQUFrQixJQUFsQjtBQUNBLFdBQUtoZSxDQUFMLEdBQVMsSUFBVDtBQUNBLFdBQUswZCxFQUFMLEdBQVVsZSxDQUFWO0FBQ0gsS0FoQkQ7QUFrQkE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBSzBpQixZQUFMLEdBQW9CLFVBQVNDLE9BQVQsRUFBa0I7QUFDbEMsVUFBSUMsR0FBRyxHQUFHOUosSUFBSSxDQUFDQyxJQUFMLENBQVU4SixJQUFWLENBQWVDLEdBQWYsQ0FBbUJDLFFBQW5CLENBQTRCSixPQUE1QixDQUFWOztBQUNBLFVBQUlDLEdBQUcsS0FBSyxFQUFaLEVBQWdCO0FBQ1osYUFBS0gsaUJBQUwsQ0FBdUJHLEdBQXZCO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsY0FBTSw0Q0FBNENELE9BQWxEO0FBQ0g7QUFDSixLQVBEOztBQVNBLFNBQUtsRSxnQkFBTCxHQUF3QixZQUFXO0FBQy9CLGFBQU8sS0FBS1AsRUFBWjtBQUNILEtBRkQ7O0FBSUEsUUFBSVksTUFBTSxLQUFLL2MsU0FBZixFQUEwQjtBQUN0QixVQUFJLE9BQU8rYyxNQUFQLEtBQWtCLFFBQXRCLEVBQWdDO0FBQzVCLFlBQUlBLE1BQU0sQ0FBQ2pLLEtBQVAsQ0FBYSxpQkFBYixDQUFKLEVBQXFDO0FBQ2pDLGVBQUs0TixpQkFBTCxDQUF1QjNELE1BQXZCO0FBQ0gsU0FGRCxNQUVPO0FBQ0gsZUFBSzRELFlBQUwsQ0FBa0I1RCxNQUFsQjtBQUNIO0FBQ0osT0FORCxNQU1PLElBQUlBLE1BQU0sQ0FBQzhELEdBQVAsS0FBZTdnQixTQUFuQixFQUE4QjtBQUNqQyxhQUFLMGdCLGlCQUFMLENBQXVCM0QsTUFBTSxDQUFDOEQsR0FBOUI7QUFDSCxPQUZNLE1BRUEsSUFBSTlELE1BQU0sQ0FBQzljLEdBQVAsS0FBZUQsU0FBbkIsRUFBOEI7QUFDakMsYUFBSzRmLFdBQUwsQ0FBaUI3QyxNQUFNLENBQUM5YyxHQUF4QjtBQUNILE9BRk0sTUFFQSxJQUFJOGMsTUFBTSxDQUFDL0csSUFBUCxLQUFnQmhXLFNBQXBCLEVBQStCO0FBQ2xDLGFBQUsyZ0IsWUFBTCxDQUFrQjVELE1BQU0sQ0FBQy9HLElBQXpCO0FBQ0g7QUFDSjtBQUNKLEdBOUdEOztBQStHQUUsRUFBQUEsS0FBSyxDQUFDQyxJQUFOLENBQVdDLE1BQVgsQ0FBa0JXLElBQUksQ0FBQ0MsSUFBTCxDQUFVNkIsbUJBQTVCLEVBQWlEOUIsSUFBSSxDQUFDQyxJQUFMLENBQVVrRixVQUEzRCxFQXI1STRCLENBdTVJNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FuRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVStCLGFBQVYsR0FBMEIsVUFBU2dFLE1BQVQsRUFBaUI7QUFDdkNoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVStCLGFBQVYsQ0FBd0J0QyxVQUF4QixDQUFtQ2hYLFdBQW5DLENBQStDaWIsSUFBL0MsQ0FBb0QsSUFBcEQ7QUFDQSxTQUFLa0MsRUFBTCxHQUFVLElBQVY7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDSSxTQUFLOEMsZUFBTCxHQUF1QixVQUFTdEksZUFBVCxFQUEwQjtBQUM3QyxXQUFLb0YsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS04sRUFBTCxHQUFVcEYsSUFBSSxDQUFDQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJFLDZCQUFuQixDQUFpREMsZUFBakQsQ0FBVjtBQUNILEtBSkQ7QUFNQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ksU0FBS3VJLFlBQUwsR0FBb0IsVUFBUzlYLFFBQVQsRUFBbUI7QUFDbkMsVUFBSTBULEVBQUUsR0FBRyxJQUFJbFYsVUFBSixDQUFldEQsTUFBTSxDQUFDOEUsUUFBRCxDQUFyQixFQUFpQyxFQUFqQyxDQUFUO0FBQ0EsV0FBSzZYLGVBQUwsQ0FBcUJuRSxFQUFyQjtBQUNILEtBSEQ7QUFLQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSSxTQUFLcUUsV0FBTCxHQUFtQixVQUFTdkMsWUFBVCxFQUF1QjtBQUN0QyxXQUFLbEIsRUFBTCxHQUFVa0IsWUFBVjtBQUNILEtBRkQ7O0FBSUEsU0FBS1gsZ0JBQUwsR0FBd0IsWUFBVztBQUMvQixhQUFPLEtBQUtQLEVBQVo7QUFDSCxLQUZEOztBQUlBLFFBQUksT0FBT1ksTUFBUCxJQUFpQixXQUFyQixFQUFrQztBQUM5QixVQUFJLE9BQU9BLE1BQU0sQ0FBQyxLQUFELENBQWIsSUFBd0IsV0FBNUIsRUFBeUM7QUFDckMsYUFBSzRDLFlBQUwsQ0FBa0I1QyxNQUFNLENBQUMsS0FBRCxDQUF4QjtBQUNILE9BRkQsTUFFTyxJQUFJLE9BQU9BLE1BQVAsSUFBaUIsUUFBckIsRUFBK0I7QUFDbEMsYUFBSzRDLFlBQUwsQ0FBa0I1QyxNQUFsQjtBQUNILE9BRk0sTUFFQSxJQUFJLE9BQU9BLE1BQU0sQ0FBQyxLQUFELENBQWIsSUFBd0IsV0FBNUIsRUFBeUM7QUFDNUMsYUFBSzZDLFdBQUwsQ0FBaUI3QyxNQUFNLENBQUMsS0FBRCxDQUF2QjtBQUNIO0FBQ0o7QUFDSixHQXpERDs7QUEwREE3RyxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVUrQixhQUE1QixFQUEyQ2hDLElBQUksQ0FBQ0MsSUFBTCxDQUFVa0YsVUFBckQsRUFyK0k0QixDQXUrSTVCOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQW5GLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVaUMsYUFBVixHQUEwQixVQUFTOEQsTUFBVCxFQUFpQjtBQUN2Q2hHLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVaUMsYUFBVixDQUF3QnhDLFVBQXhCLENBQW1DaFgsV0FBbkMsQ0FBK0NpYixJQUEvQyxDQUFvRCxJQUFwRCxFQUEwRHFDLE1BQTFEO0FBQ0EsU0FBS0gsRUFBTCxHQUFVLElBQVY7QUFDSCxHQUhEOztBQUlBMUcsRUFBQUEsS0FBSyxDQUFDQyxJQUFOLENBQVdDLE1BQVgsQ0FBa0JXLElBQUksQ0FBQ0MsSUFBTCxDQUFVaUMsYUFBNUIsRUFBMkNsQyxJQUFJLENBQUNDLElBQUwsQ0FBVThGLGlCQUFyRCxFQXIvSTRCLENBdS9JNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBL0YsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVtQyxnQkFBVixHQUE2QixVQUFTNEQsTUFBVCxFQUFpQjtBQUMxQ2hHLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVbUMsZ0JBQVYsQ0FBMkIxQyxVQUEzQixDQUFzQ2hYLFdBQXRDLENBQWtEaWIsSUFBbEQsQ0FBdUQsSUFBdkQsRUFBNkRxQyxNQUE3RDtBQUNBLFNBQUtILEVBQUwsR0FBVSxJQUFWO0FBQ0gsR0FIRDs7QUFJQTFHLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVW1DLGdCQUE1QixFQUE4Q3BDLElBQUksQ0FBQ0MsSUFBTCxDQUFVOEYsaUJBQXhELEVBcmdKNEIsQ0F1Z0o1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EvRixFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXFDLGtCQUFWLEdBQStCLFVBQVMwRCxNQUFULEVBQWlCO0FBQzVDaEcsSUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVxQyxrQkFBVixDQUE2QjVDLFVBQTdCLENBQXdDaFgsV0FBeEMsQ0FBb0RpYixJQUFwRCxDQUF5RCxJQUF6RCxFQUErRHFDLE1BQS9EO0FBQ0EsU0FBS0gsRUFBTCxHQUFVLElBQVY7QUFDSCxHQUhEOztBQUlBMUcsRUFBQUEsS0FBSyxDQUFDQyxJQUFOLENBQVdDLE1BQVgsQ0FBa0JXLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUMsa0JBQTVCLEVBQWdEdEMsSUFBSSxDQUFDQyxJQUFMLENBQVU4RixpQkFBMUQsRUFyaEo0QixDQXVoSjVCOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQS9GLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVdUMsZ0JBQVYsR0FBNkIsVUFBU3dELE1BQVQsRUFBaUI7QUFDMUNoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVXVDLGdCQUFWLENBQTJCOUMsVUFBM0IsQ0FBc0NoWCxXQUF0QyxDQUFrRGliLElBQWxELENBQXVELElBQXZELEVBQTZEcUMsTUFBN0Q7QUFDQSxTQUFLSCxFQUFMLEdBQVUsSUFBVjtBQUNILEdBSEQ7O0FBSUExRyxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVV1QyxnQkFBNUIsRUFBOEN4QyxJQUFJLENBQUNDLElBQUwsQ0FBVThGLGlCQUF4RCxFQXJpSjRCLENBdWlKNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBL0YsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVV5QyxZQUFWLEdBQXlCLFVBQVNzRCxNQUFULEVBQWlCO0FBQ3RDaEcsSUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVV5QyxZQUFWLENBQXVCaEQsVUFBdkIsQ0FBa0NoWCxXQUFsQyxDQUE4Q2liLElBQTlDLENBQW1ELElBQW5ELEVBQXlEcUMsTUFBekQ7QUFDQSxTQUFLSCxFQUFMLEdBQVUsSUFBVjtBQUNILEdBSEQ7O0FBSUExRyxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVV5QyxZQUE1QixFQUEwQzFDLElBQUksQ0FBQ0MsSUFBTCxDQUFVOEYsaUJBQXBELEVBcmpKNEIsQ0F1ako1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQS9GLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVMkMsVUFBVixHQUF1QixVQUFTb0QsTUFBVCxFQUFpQjtBQUNwQ2hHLElBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVMkMsVUFBVixDQUFxQmxELFVBQXJCLENBQWdDaFgsV0FBaEMsQ0FBNENpYixJQUE1QyxDQUFpRCxJQUFqRCxFQUF1RHFDLE1BQXZEO0FBQ0EsU0FBS0gsRUFBTCxHQUFVLElBQVY7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDSSxTQUFLdUMsU0FBTCxHQUFpQixVQUFTckIsVUFBVCxFQUFxQjtBQUNsQyxXQUFLdEIsSUFBTCxHQUFZLElBQVo7QUFDQSxXQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsV0FBS3dFLElBQUwsR0FBWW5ELFVBQVo7QUFDQSxXQUFLcmYsQ0FBTCxHQUFTLEtBQUtvZixVQUFMLENBQWdCLEtBQUtvRCxJQUFyQixFQUEyQixLQUEzQixDQUFUO0FBQ0EsV0FBSzlFLEVBQUwsR0FBVWdCLE1BQU0sQ0FBQyxLQUFLMWUsQ0FBTixDQUFoQjtBQUNILEtBTkQ7O0FBUUEsU0FBS2llLGdCQUFMLEdBQXdCLFlBQVc7QUFDL0IsVUFBSSxPQUFPLEtBQUt1RSxJQUFaLElBQW9CLFdBQXBCLElBQW1DLE9BQU8sS0FBS3hpQixDQUFaLElBQWlCLFdBQXhELEVBQXFFO0FBQ2pFLGFBQUt3aUIsSUFBTCxHQUFZLElBQUlyRCxJQUFKLEVBQVo7QUFDQSxhQUFLbmYsQ0FBTCxHQUFTLEtBQUtvZixVQUFMLENBQWdCLEtBQUtvRCxJQUFyQixFQUEyQixLQUEzQixDQUFUO0FBQ0EsYUFBSzlFLEVBQUwsR0FBVWdCLE1BQU0sQ0FBQyxLQUFLMWUsQ0FBTixDQUFoQjtBQUNIOztBQUNELGFBQU8sS0FBSzBkLEVBQVo7QUFDSCxLQVBEOztBQVNBLFFBQUlZLE1BQU0sS0FBSy9jLFNBQWYsRUFBMEI7QUFDdEIsVUFBSStjLE1BQU0sQ0FBQy9hLEdBQVAsS0FBZWhDLFNBQW5CLEVBQThCO0FBQzFCLGFBQUtpZCxTQUFMLENBQWVGLE1BQU0sQ0FBQy9hLEdBQXRCO0FBQ0gsT0FGRCxNQUVPLElBQUksT0FBTythLE1BQVAsSUFBaUIsUUFBakIsSUFBNkJBLE1BQU0sQ0FBQ2pLLEtBQVAsQ0FBYSxjQUFiLENBQWpDLEVBQStEO0FBQ2xFLGFBQUttSyxTQUFMLENBQWVGLE1BQWY7QUFDSCxPQUZNLE1BRUEsSUFBSUEsTUFBTSxDQUFDOWMsR0FBUCxLQUFlRCxTQUFuQixFQUE4QjtBQUNqQyxhQUFLb2QsWUFBTCxDQUFrQkwsTUFBTSxDQUFDOWMsR0FBekI7QUFDSCxPQUZNLE1BRUEsSUFBSThjLE1BQU0sQ0FBQ2tFLElBQVAsS0FBZ0JqaEIsU0FBcEIsRUFBK0I7QUFDbEMsYUFBS21mLFNBQUwsQ0FBZXBDLE1BQU0sQ0FBQ2tFLElBQXRCO0FBQ0g7QUFDSjtBQUNKLEdBMUNEOztBQTJDQS9LLEVBQUFBLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxNQUFYLENBQWtCVyxJQUFJLENBQUNDLElBQUwsQ0FBVTJDLFVBQTVCLEVBQXdDNUMsSUFBSSxDQUFDQyxJQUFMLENBQVVzRyxlQUFsRCxFQTVuSjRCLENBOG5KNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQXZHLEVBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVNkMsa0JBQVYsR0FBK0IsVUFBU2tELE1BQVQsRUFBaUI7QUFDNUNoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVTZDLGtCQUFWLENBQTZCcEQsVUFBN0IsQ0FBd0NoWCxXQUF4QyxDQUFvRGliLElBQXBELENBQXlELElBQXpELEVBQStEcUMsTUFBL0Q7QUFDQSxTQUFLSCxFQUFMLEdBQVUsSUFBVjtBQUNBLFNBQUtvQixVQUFMLEdBQWtCLEtBQWxCO0FBRUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0ksU0FBS21CLFNBQUwsR0FBaUIsVUFBU3JCLFVBQVQsRUFBcUI7QUFDbEMsV0FBS3RCLElBQUwsR0FBWSxJQUFaO0FBQ0EsV0FBS0MsVUFBTCxHQUFrQixJQUFsQjtBQUNBLFdBQUt3RSxJQUFMLEdBQVluRCxVQUFaO0FBQ0EsV0FBS3JmLENBQUwsR0FBUyxLQUFLb2YsVUFBTCxDQUFnQixLQUFLb0QsSUFBckIsRUFBMkIsS0FBM0IsRUFBa0MsS0FBS2pELFVBQXZDLENBQVQ7QUFDQSxXQUFLN0IsRUFBTCxHQUFVZ0IsTUFBTSxDQUFDLEtBQUsxZSxDQUFOLENBQWhCO0FBQ0gsS0FORDs7QUFRQSxTQUFLaWUsZ0JBQUwsR0FBd0IsWUFBVztBQUMvQixVQUFJLEtBQUt1RSxJQUFMLEtBQWNqaEIsU0FBZCxJQUEyQixLQUFLdkIsQ0FBTCxLQUFXdUIsU0FBMUMsRUFBcUQ7QUFDakQsYUFBS2loQixJQUFMLEdBQVksSUFBSXJELElBQUosRUFBWjtBQUNBLGFBQUtuZixDQUFMLEdBQVMsS0FBS29mLFVBQUwsQ0FBZ0IsS0FBS29ELElBQXJCLEVBQTJCLEtBQTNCLEVBQWtDLEtBQUtqRCxVQUF2QyxDQUFUO0FBQ0EsYUFBSzdCLEVBQUwsR0FBVWdCLE1BQU0sQ0FBQyxLQUFLMWUsQ0FBTixDQUFoQjtBQUNIOztBQUNELGFBQU8sS0FBSzBkLEVBQVo7QUFDSCxLQVBEOztBQVNBLFFBQUlZLE1BQU0sS0FBSy9jLFNBQWYsRUFBMEI7QUFDdEIsVUFBSStjLE1BQU0sQ0FBQy9hLEdBQVAsS0FBZWhDLFNBQW5CLEVBQThCO0FBQzFCLGFBQUtpZCxTQUFMLENBQWVGLE1BQU0sQ0FBQy9hLEdBQXRCO0FBQ0gsT0FGRCxNQUVPLElBQUksT0FBTythLE1BQVAsSUFBaUIsUUFBakIsSUFBNkJBLE1BQU0sQ0FBQ2pLLEtBQVAsQ0FBYSxjQUFiLENBQWpDLEVBQStEO0FBQ2xFLGFBQUttSyxTQUFMLENBQWVGLE1BQWY7QUFDSCxPQUZNLE1BRUEsSUFBSUEsTUFBTSxDQUFDOWMsR0FBUCxLQUFlRCxTQUFuQixFQUE4QjtBQUNqQyxhQUFLb2QsWUFBTCxDQUFrQkwsTUFBTSxDQUFDOWMsR0FBekI7QUFDSCxPQUZNLE1BRUEsSUFBSThjLE1BQU0sQ0FBQ2tFLElBQVAsS0FBZ0JqaEIsU0FBcEIsRUFBK0I7QUFDbEMsYUFBS21mLFNBQUwsQ0FBZXBDLE1BQU0sQ0FBQ2tFLElBQXRCO0FBQ0g7O0FBQ0QsVUFBSWxFLE1BQU0sQ0FBQzhCLE1BQVAsS0FBa0IsSUFBdEIsRUFBNEI7QUFDeEIsYUFBS2IsVUFBTCxHQUFrQixJQUFsQjtBQUNIO0FBQ0o7QUFDSixHQWpERDs7QUFrREE5SCxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVU2QyxrQkFBNUIsRUFBZ0Q5QyxJQUFJLENBQUNDLElBQUwsQ0FBVXNHLGVBQTFELEVBcnNKNEIsQ0F1c0o1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBdkcsRUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVUrQyxXQUFWLEdBQXdCLFVBQVNnRCxNQUFULEVBQWlCO0FBQ3JDaEcsSUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVUrQyxXQUFWLENBQXNCdEQsVUFBdEIsQ0FBaUNoWCxXQUFqQyxDQUE2Q2liLElBQTdDLENBQWtELElBQWxELEVBQXdEcUMsTUFBeEQ7QUFDQSxTQUFLSCxFQUFMLEdBQVUsSUFBVjs7QUFDQSxTQUFLRixnQkFBTCxHQUF3QixZQUFXO0FBQy9CLFVBQUl6ZSxDQUFDLEdBQUcsRUFBUjs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBS3FoQixTQUFMLENBQWVsaEIsTUFBbkMsRUFBMkNILENBQUMsRUFBNUMsRUFBZ0Q7QUFDNUMsWUFBSXFjLE9BQU8sR0FBRyxLQUFLZ0YsU0FBTCxDQUFlcmhCLENBQWYsQ0FBZDtBQUNBRCxRQUFBQSxDQUFDLElBQUlzYyxPQUFPLENBQUNRLGFBQVIsRUFBTDtBQUNIOztBQUNELFdBQUtvQixFQUFMLEdBQVVsZSxDQUFWO0FBQ0EsYUFBTyxLQUFLa2UsRUFBWjtBQUNILEtBUkQ7QUFTSCxHQVpEOztBQWFBakcsRUFBQUEsS0FBSyxDQUFDQyxJQUFOLENBQVdDLE1BQVgsQ0FBa0JXLElBQUksQ0FBQ0MsSUFBTCxDQUFVK0MsV0FBNUIsRUFBeUNoRCxJQUFJLENBQUNDLElBQUwsQ0FBVW9JLHFCQUFuRCxFQW51SjRCLENBcXVKNUI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FySSxFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVWlELE1BQVYsR0FBbUIsVUFBUzhDLE1BQVQsRUFBaUI7QUFDaENoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVWlELE1BQVYsQ0FBaUJ4RCxVQUFqQixDQUE0QmhYLFdBQTVCLENBQXdDaWIsSUFBeEMsQ0FBNkMsSUFBN0MsRUFBbURxQyxNQUFuRDtBQUNBLFNBQUtILEVBQUwsR0FBVSxJQUFWO0FBQ0EsU0FBS3NFLFFBQUwsR0FBZ0IsSUFBaEIsQ0FIZ0MsQ0FHVjs7QUFDdEIsU0FBS3hFLGdCQUFMLEdBQXdCLFlBQVc7QUFDL0IsVUFBSTNjLENBQUMsR0FBRyxJQUFJWCxLQUFKLEVBQVI7O0FBQ0EsV0FBSyxJQUFJbEIsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLcWhCLFNBQUwsQ0FBZWxoQixNQUFuQyxFQUEyQ0gsQ0FBQyxFQUE1QyxFQUFnRDtBQUM1QyxZQUFJcWMsT0FBTyxHQUFHLEtBQUtnRixTQUFMLENBQWVyaEIsQ0FBZixDQUFkO0FBQ0E2QixRQUFBQSxDQUFDLENBQUN5YSxJQUFGLENBQU9ELE9BQU8sQ0FBQ1EsYUFBUixFQUFQO0FBQ0g7O0FBQ0QsVUFBSSxLQUFLbUcsUUFBTCxJQUFpQixJQUFyQixFQUEyQm5oQixDQUFDLENBQUNvaEIsSUFBRjtBQUMzQixXQUFLaEYsRUFBTCxHQUFVcGMsQ0FBQyxDQUFDaWYsSUFBRixDQUFPLEVBQVAsQ0FBVjtBQUNBLGFBQU8sS0FBSzdDLEVBQVo7QUFDSCxLQVREOztBQVdBLFFBQUksT0FBT1ksTUFBUCxJQUFpQixXQUFyQixFQUFrQztBQUM5QixVQUFJLE9BQU9BLE1BQU0sQ0FBQ3FFLFFBQWQsSUFBMEIsV0FBMUIsSUFDQXJFLE1BQU0sQ0FBQ3FFLFFBQVAsSUFBbUIsS0FEdkIsRUFFSSxLQUFLRixRQUFMLEdBQWdCLEtBQWhCO0FBQ1A7QUFDSixHQXBCRDs7QUFxQkFoTCxFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVVpRCxNQUE1QixFQUFvQ2xELElBQUksQ0FBQ0MsSUFBTCxDQUFVb0kscUJBQTlDLEVBM3dKNEIsQ0E2d0o1Qjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FySSxFQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVW1ELGVBQVYsR0FBNEIsVUFBUzRDLE1BQVQsRUFBaUI7QUFDekNoRyxJQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVW1ELGVBQVYsQ0FBMEIxRCxVQUExQixDQUFxQ2hYLFdBQXJDLENBQWlEaWIsSUFBakQsQ0FBc0QsSUFBdEQ7QUFDQSxTQUFLa0MsRUFBTCxHQUFVLElBQVY7QUFDQSxTQUFLVCxFQUFMLEdBQVUsRUFBVjtBQUNBLFNBQUtrRixVQUFMLEdBQWtCLElBQWxCO0FBQ0EsU0FBSzVCLFVBQUwsR0FBa0IsSUFBbEI7QUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0ksU0FBSzZCLGFBQUwsR0FBcUIsVUFBU0MsY0FBVCxFQUF5QkMsUUFBekIsRUFBbUMvQixVQUFuQyxFQUErQztBQUNoRSxXQUFLN0MsRUFBTCxHQUFVNEUsUUFBVjtBQUNBLFdBQUtILFVBQUwsR0FBa0JFLGNBQWxCO0FBQ0EsV0FBSzlCLFVBQUwsR0FBa0JBLFVBQWxCOztBQUNBLFVBQUksS0FBSzRCLFVBQVQsRUFBcUI7QUFDakIsYUFBS2xGLEVBQUwsR0FBVSxLQUFLc0QsVUFBTCxDQUFnQjFFLGFBQWhCLEVBQVY7QUFDQSxhQUFLeUIsSUFBTCxHQUFZLElBQVo7QUFDQSxhQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0gsT0FKRCxNQUlPO0FBQ0gsYUFBS04sRUFBTCxHQUFVLElBQVY7QUFDQSxhQUFLSyxJQUFMLEdBQVlpRCxVQUFVLENBQUMxRSxhQUFYLEVBQVo7QUFDQSxhQUFLeUIsSUFBTCxHQUFZLEtBQUtBLElBQUwsQ0FBVW5ILE9BQVYsQ0FBa0IsS0FBbEIsRUFBeUJtTSxRQUF6QixDQUFaO0FBQ0EsYUFBSy9FLFVBQUwsR0FBa0IsS0FBbEI7QUFDSDtBQUNKLEtBZEQ7O0FBZ0JBLFNBQUtDLGdCQUFMLEdBQXdCLFlBQVc7QUFDL0IsYUFBTyxLQUFLUCxFQUFaO0FBQ0gsS0FGRDs7QUFJQSxRQUFJLE9BQU9ZLE1BQVAsSUFBaUIsV0FBckIsRUFBa0M7QUFDOUIsVUFBSSxPQUFPQSxNQUFNLENBQUMsS0FBRCxDQUFiLElBQXdCLFdBQTVCLEVBQXlDO0FBQ3JDLGFBQUtILEVBQUwsR0FBVUcsTUFBTSxDQUFDLEtBQUQsQ0FBaEI7QUFDSDs7QUFDRCxVQUFJLE9BQU9BLE1BQU0sQ0FBQyxVQUFELENBQWIsSUFBNkIsV0FBakMsRUFBOEM7QUFDMUMsYUFBS3NFLFVBQUwsR0FBa0J0RSxNQUFNLENBQUMsVUFBRCxDQUF4QjtBQUNIOztBQUNELFVBQUksT0FBT0EsTUFBTSxDQUFDLEtBQUQsQ0FBYixJQUF3QixXQUE1QixFQUF5QztBQUNyQyxhQUFLMEMsVUFBTCxHQUFrQjFDLE1BQU0sQ0FBQyxLQUFELENBQXhCO0FBQ0EsYUFBS3VFLGFBQUwsQ0FBbUIsS0FBS0QsVUFBeEIsRUFBb0MsS0FBS3pFLEVBQXpDLEVBQTZDLEtBQUs2QyxVQUFsRDtBQUNIO0FBQ0o7QUFDSixHQWhERDs7QUFpREF2SixFQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FBV0MsTUFBWCxDQUFrQlcsSUFBSSxDQUFDQyxJQUFMLENBQVVtRCxlQUE1QixFQUE2Q3BELElBQUksQ0FBQ0MsSUFBTCxDQUFVa0YsVUFBdkQ7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFJdUYsZUFBZTtBQUFHO0FBQWUsWUFBVUMsTUFBVixFQUFrQjtBQUNuRG5pQixJQUFBQSxTQUFTLENBQUNraUIsZUFBRCxFQUFrQkMsTUFBbEIsQ0FBVDs7QUFDQSxhQUFTRCxlQUFULENBQXlCeFIsR0FBekIsRUFBOEI7QUFDMUIsVUFBSTBDLEtBQUssR0FBRytPLE1BQU0sQ0FBQ2hILElBQVAsQ0FBWSxJQUFaLEtBQXFCLElBQWpDLENBRDBCLENBRTFCO0FBQ0E7QUFDQTs7O0FBQ0EsVUFBSXpLLEdBQUosRUFBUztBQUNMO0FBQ0EsWUFBSSxPQUFPQSxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDekIwQyxVQUFBQSxLQUFLLENBQUNnUCxRQUFOLENBQWUxUixHQUFmO0FBQ0gsU0FGRCxNQUdLLElBQUl3UixlQUFlLENBQUNHLHFCQUFoQixDQUFzQzNSLEdBQXRDLEtBQ0x3UixlQUFlLENBQUNJLG9CQUFoQixDQUFxQzVSLEdBQXJDLENBREMsRUFDMEM7QUFDM0M7QUFDQTBDLFVBQUFBLEtBQUssQ0FBQ21QLG1CQUFOLENBQTBCN1IsR0FBMUI7QUFDSDtBQUNKOztBQUNELGFBQU8wQyxLQUFQO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0k4TyxJQUFBQSxlQUFlLENBQUMvaEIsU0FBaEIsQ0FBMEJpaUIsUUFBMUIsR0FBcUMsVUFBVUksR0FBVixFQUFlO0FBQ2hELFVBQUk7QUFDQSxZQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUNBLFlBQUlDLGVBQWUsR0FBRyxDQUF0QjtBQUNBLFlBQUlDLEtBQUssR0FBRyxxQ0FBWjtBQUNBLFlBQUlDLEdBQUcsR0FBR0QsS0FBSyxDQUFDdEwsSUFBTixDQUFXbUwsR0FBWCxJQUFrQmxpQixHQUFHLENBQUNDLE1BQUosQ0FBV2lpQixHQUFYLENBQWxCLEdBQW9DdGhCLE1BQU0sQ0FBQ0csT0FBUCxDQUFlbWhCLEdBQWYsQ0FBOUM7QUFDQSxZQUFJL0ssSUFBSSxHQUFHN1MsSUFBSSxDQUFDckUsTUFBTCxDQUFZcWlCLEdBQVosQ0FBWCxDQUxBLENBTUE7O0FBQ0EsWUFBSW5MLElBQUksQ0FBQzFWLEdBQUwsQ0FBU2pELE1BQVQsS0FBb0IsQ0FBeEIsRUFBMkI7QUFDdkIyWSxVQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQzFWLEdBQUwsQ0FBUyxDQUFULEVBQVlBLEdBQVosQ0FBZ0IsQ0FBaEIsQ0FBUDtBQUNIOztBQUNELFlBQUkwVixJQUFJLENBQUMxVixHQUFMLENBQVNqRCxNQUFULEtBQW9CLENBQXhCLEVBQTJCO0FBQ3ZCO0FBQ0EyakIsVUFBQUEsT0FBTyxHQUFHaEwsSUFBSSxDQUFDMVYsR0FBTCxDQUFTLENBQVQsRUFBWWtFLGlCQUFaLEVBQVYsQ0FGdUIsQ0FFb0I7O0FBQzNDLGVBQUtySSxDQUFMLEdBQVMrUixXQUFXLENBQUM4UyxPQUFELEVBQVUsRUFBVixDQUFwQjtBQUNBQyxVQUFBQSxlQUFlLEdBQUdqTCxJQUFJLENBQUMxVixHQUFMLENBQVMsQ0FBVCxFQUFZa0UsaUJBQVosRUFBbEIsQ0FKdUIsQ0FJNEI7O0FBQ25ELGVBQUtPLENBQUwsR0FBU3pILFFBQVEsQ0FBQzJqQixlQUFELEVBQWtCLEVBQWxCLENBQWpCO0FBQ0EsY0FBSUcsZ0JBQWdCLEdBQUdwTCxJQUFJLENBQUMxVixHQUFMLENBQVMsQ0FBVCxFQUFZa0UsaUJBQVosRUFBdkIsQ0FOdUIsQ0FNaUM7O0FBQ3hELGVBQUt6RyxDQUFMLEdBQVNtUSxXQUFXLENBQUNrVCxnQkFBRCxFQUFtQixFQUFuQixDQUFwQjtBQUNBLGNBQUlDLE1BQU0sR0FBR3JMLElBQUksQ0FBQzFWLEdBQUwsQ0FBUyxDQUFULEVBQVlrRSxpQkFBWixFQUFiLENBUnVCLENBUXVCOztBQUM5QyxlQUFLbkcsQ0FBTCxHQUFTNlAsV0FBVyxDQUFDbVQsTUFBRCxFQUFTLEVBQVQsQ0FBcEI7QUFDQSxjQUFJQyxNQUFNLEdBQUd0TCxJQUFJLENBQUMxVixHQUFMLENBQVMsQ0FBVCxFQUFZa0UsaUJBQVosRUFBYixDQVZ1QixDQVV1Qjs7QUFDOUMsZUFBS3VFLENBQUwsR0FBU21GLFdBQVcsQ0FBQ29ULE1BQUQsRUFBUyxFQUFULENBQXBCO0FBQ0EsY0FBSUMsU0FBUyxHQUFHdkwsSUFBSSxDQUFDMVYsR0FBTCxDQUFTLENBQVQsRUFBWWtFLGlCQUFaLEVBQWhCLENBWnVCLENBWTBCOztBQUNqRCxlQUFLc00sSUFBTCxHQUFZNUMsV0FBVyxDQUFDcVQsU0FBRCxFQUFZLEVBQVosQ0FBdkI7QUFDQSxjQUFJQyxTQUFTLEdBQUd4TCxJQUFJLENBQUMxVixHQUFMLENBQVMsQ0FBVCxFQUFZa0UsaUJBQVosRUFBaEIsQ0FkdUIsQ0FjMEI7O0FBQ2pELGVBQUt1TSxJQUFMLEdBQVk3QyxXQUFXLENBQUNzVCxTQUFELEVBQVksRUFBWixDQUF2QjtBQUNBLGNBQUlDLFdBQVcsR0FBR3pMLElBQUksQ0FBQzFWLEdBQUwsQ0FBUyxDQUFULEVBQVlrRSxpQkFBWixFQUFsQixDQWhCdUIsQ0FnQjRCOztBQUNuRCxlQUFLd00sS0FBTCxHQUFhOUMsV0FBVyxDQUFDdVQsV0FBRCxFQUFjLEVBQWQsQ0FBeEI7QUFDSCxTQWxCRCxNQW1CSyxJQUFJekwsSUFBSSxDQUFDMVYsR0FBTCxDQUFTakQsTUFBVCxLQUFvQixDQUF4QixFQUEyQjtBQUM1QjtBQUNBLGNBQUlxa0IsVUFBVSxHQUFHMUwsSUFBSSxDQUFDMVYsR0FBTCxDQUFTLENBQVQsQ0FBakI7QUFDQSxjQUFJcWhCLFFBQVEsR0FBR0QsVUFBVSxDQUFDcGhCLEdBQVgsQ0FBZSxDQUFmLENBQWY7QUFDQTBnQixVQUFBQSxPQUFPLEdBQUdXLFFBQVEsQ0FBQ3JoQixHQUFULENBQWEsQ0FBYixFQUFnQmtFLGlCQUFoQixFQUFWO0FBQ0EsZUFBS3JJLENBQUwsR0FBUytSLFdBQVcsQ0FBQzhTLE9BQUQsRUFBVSxFQUFWLENBQXBCO0FBQ0FDLFVBQUFBLGVBQWUsR0FBR1UsUUFBUSxDQUFDcmhCLEdBQVQsQ0FBYSxDQUFiLEVBQWdCa0UsaUJBQWhCLEVBQWxCO0FBQ0EsZUFBS08sQ0FBTCxHQUFTekgsUUFBUSxDQUFDMmpCLGVBQUQsRUFBa0IsRUFBbEIsQ0FBakI7QUFDSCxTQVJJLE1BU0E7QUFDRCxpQkFBTyxLQUFQO0FBQ0g7O0FBQ0QsZUFBTyxJQUFQO0FBQ0gsT0ExQ0QsQ0EyQ0EsT0FBTy9PLEVBQVAsRUFBVztBQUNQLGVBQU8sS0FBUDtBQUNIO0FBQ0osS0EvQ0Q7QUFnREE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSXVPLElBQUFBLGVBQWUsQ0FBQy9oQixTQUFoQixDQUEwQmtqQixpQkFBMUIsR0FBOEMsWUFBWTtBQUN0RCxVQUFJQyxPQUFPLEdBQUc7QUFDVkMsUUFBQUEsS0FBSyxFQUFFLENBQ0gsSUFBSS9MLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUIsVUFBZCxDQUF5QjtBQUFFLGlCQUFLO0FBQVAsU0FBekIsQ0FERyxFQUVILElBQUl0QixJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQWQsQ0FBeUI7QUFBRTBLLFVBQUFBLE1BQU0sRUFBRSxLQUFLNWxCO0FBQWYsU0FBekIsQ0FGRyxFQUdILElBQUk0WixJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQWQsQ0FBeUI7QUFBRSxpQkFBSyxLQUFLdFM7QUFBWixTQUF6QixDQUhHLEVBSUgsSUFBSWdSLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUIsVUFBZCxDQUF5QjtBQUFFMEssVUFBQUEsTUFBTSxFQUFFLEtBQUtoa0I7QUFBZixTQUF6QixDQUpHLEVBS0gsSUFBSWdZLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUIsVUFBZCxDQUF5QjtBQUFFMEssVUFBQUEsTUFBTSxFQUFFLEtBQUsxakI7QUFBZixTQUF6QixDQUxHLEVBTUgsSUFBSTBYLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUIsVUFBZCxDQUF5QjtBQUFFMEssVUFBQUEsTUFBTSxFQUFFLEtBQUtoWjtBQUFmLFNBQXpCLENBTkcsRUFPSCxJQUFJZ04sSUFBSSxDQUFDQyxJQUFMLENBQVVxQixVQUFkLENBQXlCO0FBQUUwSyxVQUFBQSxNQUFNLEVBQUUsS0FBS2pSO0FBQWYsU0FBekIsQ0FQRyxFQVFILElBQUlpRixJQUFJLENBQUNDLElBQUwsQ0FBVXFCLFVBQWQsQ0FBeUI7QUFBRTBLLFVBQUFBLE1BQU0sRUFBRSxLQUFLaFI7QUFBZixTQUF6QixDQVJHLEVBU0gsSUFBSWdGLElBQUksQ0FBQ0MsSUFBTCxDQUFVcUIsVUFBZCxDQUF5QjtBQUFFMEssVUFBQUEsTUFBTSxFQUFFLEtBQUsvUTtBQUFmLFNBQXpCLENBVEc7QUFERyxPQUFkO0FBYUEsVUFBSWdSLEdBQUcsR0FBRyxJQUFJak0sSUFBSSxDQUFDQyxJQUFMLENBQVUrQyxXQUFkLENBQTBCOEksT0FBMUIsQ0FBVjtBQUNBLGFBQU9HLEdBQUcsQ0FBQ2pJLGFBQUosRUFBUDtBQUNILEtBaEJEO0FBaUJBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7OztBQUNJMEcsSUFBQUEsZUFBZSxDQUFDL2hCLFNBQWhCLENBQTBCdWpCLG9CQUExQixHQUFpRCxZQUFZO0FBQ3pELGFBQU9qbEIsT0FBTyxDQUFDLEtBQUs0a0IsaUJBQUwsRUFBRCxDQUFkO0FBQ0gsS0FGRDtBQUdBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJbkIsSUFBQUEsZUFBZSxDQUFDL2hCLFNBQWhCLENBQTBCd2pCLGdCQUExQixHQUE2QyxZQUFZO0FBQ3JELFVBQUlDLGNBQWMsR0FBRyxJQUFJcE0sSUFBSSxDQUFDQyxJQUFMLENBQVUrQyxXQUFkLENBQTBCO0FBQzNDK0ksUUFBQUEsS0FBSyxFQUFFLENBQ0gsSUFBSS9MLElBQUksQ0FBQ0MsSUFBTCxDQUFVNkIsbUJBQWQsQ0FBa0M7QUFBRWdJLFVBQUFBLEdBQUcsRUFBRTtBQUFQLFNBQWxDLENBREcsRUFFSCxJQUFJOUosSUFBSSxDQUFDQyxJQUFMLENBQVUyQixPQUFkLEVBRkc7QUFEb0MsT0FBMUIsQ0FBckI7QUFNQSxVQUFJeUssZUFBZSxHQUFHLElBQUlyTSxJQUFJLENBQUNDLElBQUwsQ0FBVStDLFdBQWQsQ0FBMEI7QUFDNUMrSSxRQUFBQSxLQUFLLEVBQUUsQ0FDSCxJQUFJL0wsSUFBSSxDQUFDQyxJQUFMLENBQVVxQixVQUFkLENBQXlCO0FBQUUwSyxVQUFBQSxNQUFNLEVBQUUsS0FBSzVsQjtBQUFmLFNBQXpCLENBREcsRUFFSCxJQUFJNFosSUFBSSxDQUFDQyxJQUFMLENBQVVxQixVQUFkLENBQXlCO0FBQUUsaUJBQUssS0FBS3RTO0FBQVosU0FBekIsQ0FGRztBQURxQyxPQUExQixDQUF0QjtBQU1BLFVBQUkyYyxVQUFVLEdBQUcsSUFBSTNMLElBQUksQ0FBQ0MsSUFBTCxDQUFVdUIsWUFBZCxDQUEyQjtBQUN4Q3RZLFFBQUFBLEdBQUcsRUFBRSxPQUFPbWpCLGVBQWUsQ0FBQ3JJLGFBQWhCO0FBRDRCLE9BQTNCLENBQWpCO0FBR0EsVUFBSWlJLEdBQUcsR0FBRyxJQUFJak0sSUFBSSxDQUFDQyxJQUFMLENBQVUrQyxXQUFkLENBQTBCO0FBQ2hDK0ksUUFBQUEsS0FBSyxFQUFFLENBQUNLLGNBQUQsRUFBaUJULFVBQWpCO0FBRHlCLE9BQTFCLENBQVY7QUFHQSxhQUFPTSxHQUFHLENBQUNqSSxhQUFKLEVBQVA7QUFDSCxLQXBCRDtBQXFCQTtBQUNKO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSTBHLElBQUFBLGVBQWUsQ0FBQy9oQixTQUFoQixDQUEwQjJqQixtQkFBMUIsR0FBZ0QsWUFBWTtBQUN4RCxhQUFPcmxCLE9BQU8sQ0FBQyxLQUFLa2xCLGdCQUFMLEVBQUQsQ0FBZDtBQUNILEtBRkQ7QUFHQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSXpCLElBQUFBLGVBQWUsQ0FBQzZCLFFBQWhCLEdBQTJCLFVBQVV0aEIsR0FBVixFQUFldWhCLEtBQWYsRUFBc0I7QUFDN0NBLE1BQUFBLEtBQUssR0FBR0EsS0FBSyxJQUFJLEVBQWpCOztBQUNBLFVBQUksQ0FBQ3ZoQixHQUFMLEVBQVU7QUFDTixlQUFPQSxHQUFQO0FBQ0g7O0FBQ0QsVUFBSXdoQixLQUFLLEdBQUcsVUFBVUQsS0FBVixHQUFrQixtQkFBbEIsR0FBd0NBLEtBQXhDLEdBQWdELElBQTVEO0FBQ0EsYUFBT3ZoQixHQUFHLENBQUM4USxLQUFKLENBQVUyUSxNQUFNLENBQUNELEtBQUQsRUFBUSxHQUFSLENBQWhCLEVBQThCeEUsSUFBOUIsQ0FBbUMsSUFBbkMsQ0FBUDtBQUNILEtBUEQ7QUFRQTtBQUNKO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSXlDLElBQUFBLGVBQWUsQ0FBQy9oQixTQUFoQixDQUEwQmdrQixhQUExQixHQUEwQyxZQUFZO0FBQ2xELFVBQUl6VCxHQUFHLEdBQUcsbUNBQVY7QUFDQUEsTUFBQUEsR0FBRyxJQUFJd1IsZUFBZSxDQUFDNkIsUUFBaEIsQ0FBeUIsS0FBS0wsb0JBQUwsRUFBekIsSUFBd0QsSUFBL0Q7QUFDQWhULE1BQUFBLEdBQUcsSUFBSSwrQkFBUDtBQUNBLGFBQU9BLEdBQVA7QUFDSCxLQUxEO0FBTUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0l3UixJQUFBQSxlQUFlLENBQUMvaEIsU0FBaEIsQ0FBMEJpa0IsWUFBMUIsR0FBeUMsWUFBWTtBQUNqRCxVQUFJMVQsR0FBRyxHQUFHLDhCQUFWO0FBQ0FBLE1BQUFBLEdBQUcsSUFBSXdSLGVBQWUsQ0FBQzZCLFFBQWhCLENBQXlCLEtBQUtELG1CQUFMLEVBQXpCLElBQXVELElBQTlEO0FBQ0FwVCxNQUFBQSxHQUFHLElBQUksMEJBQVA7QUFDQSxhQUFPQSxHQUFQO0FBQ0gsS0FMRDtBQU1BO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJd1IsSUFBQUEsZUFBZSxDQUFDSSxvQkFBaEIsR0FBdUMsVUFBVWxILEdBQVYsRUFBZTtBQUNsREEsTUFBQUEsR0FBRyxHQUFHQSxHQUFHLElBQUksRUFBYjtBQUNBLGFBQU9BLEdBQUcsQ0FBQ3JiLGNBQUosQ0FBbUIsR0FBbkIsS0FBMkJxYixHQUFHLENBQUNyYixjQUFKLENBQW1CLEdBQW5CLENBQWxDO0FBQ0gsS0FIRDtBQUlBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0ltaUIsSUFBQUEsZUFBZSxDQUFDRyxxQkFBaEIsR0FBd0MsVUFBVWpILEdBQVYsRUFBZTtBQUNuREEsTUFBQUEsR0FBRyxHQUFHQSxHQUFHLElBQUksRUFBYjtBQUNBLGFBQVFBLEdBQUcsQ0FBQ3JiLGNBQUosQ0FBbUIsR0FBbkIsS0FDSnFiLEdBQUcsQ0FBQ3JiLGNBQUosQ0FBbUIsR0FBbkIsQ0FESSxJQUVKcWIsR0FBRyxDQUFDcmIsY0FBSixDQUFtQixHQUFuQixDQUZJLElBR0pxYixHQUFHLENBQUNyYixjQUFKLENBQW1CLEdBQW5CLENBSEksSUFJSnFiLEdBQUcsQ0FBQ3JiLGNBQUosQ0FBbUIsR0FBbkIsQ0FKSSxJQUtKcWIsR0FBRyxDQUFDcmIsY0FBSixDQUFtQixNQUFuQixDQUxJLElBTUpxYixHQUFHLENBQUNyYixjQUFKLENBQW1CLE1BQW5CLENBTkksSUFPSnFiLEdBQUcsQ0FBQ3JiLGNBQUosQ0FBbUIsT0FBbkIsQ0FQSjtBQVFILEtBVkQ7QUFXQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJbWlCLElBQUFBLGVBQWUsQ0FBQy9oQixTQUFoQixDQUEwQm9pQixtQkFBMUIsR0FBZ0QsVUFBVW5ILEdBQVYsRUFBZTtBQUMzRCxXQUFLeGQsQ0FBTCxHQUFTd2QsR0FBRyxDQUFDeGQsQ0FBYjtBQUNBLFdBQUs0SSxDQUFMLEdBQVM0VSxHQUFHLENBQUM1VSxDQUFiOztBQUNBLFVBQUk0VSxHQUFHLENBQUNyYixjQUFKLENBQW1CLEdBQW5CLENBQUosRUFBNkI7QUFDekIsYUFBS1AsQ0FBTCxHQUFTNGIsR0FBRyxDQUFDNWIsQ0FBYjtBQUNBLGFBQUtNLENBQUwsR0FBU3NiLEdBQUcsQ0FBQ3RiLENBQWI7QUFDQSxhQUFLMEssQ0FBTCxHQUFTNFEsR0FBRyxDQUFDNVEsQ0FBYjtBQUNBLGFBQUsrSCxJQUFMLEdBQVk2SSxHQUFHLENBQUM3SSxJQUFoQjtBQUNBLGFBQUtDLElBQUwsR0FBWTRJLEdBQUcsQ0FBQzVJLElBQWhCO0FBQ0EsYUFBS0MsS0FBTCxHQUFhMkksR0FBRyxDQUFDM0ksS0FBakI7QUFDSDtBQUNKLEtBWEQ7O0FBWUEsV0FBT3lQLGVBQVA7QUFDSCxHQXhSb0MsQ0F3Um5DNVAsTUF4Um1DLENBQXJDO0FBMFJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBSTdVLFNBQVM7QUFBRztBQUFlLGNBQVk7QUFDdkMsYUFBU0EsU0FBVCxDQUFtQjZsQixPQUFuQixFQUE0QjtBQUN4QkEsTUFBQUEsT0FBTyxHQUFHQSxPQUFPLElBQUksRUFBckI7QUFDQSxXQUFLZSxnQkFBTCxHQUF3QnRsQixRQUFRLENBQUN1a0IsT0FBTyxDQUFDZSxnQkFBVCxFQUEyQixFQUEzQixDQUFSLElBQTBDLElBQWxFO0FBQ0EsV0FBS0MsdUJBQUwsR0FBK0JoQixPQUFPLENBQUNnQix1QkFBUixJQUFtQyxRQUFsRSxDQUh3QixDQUdvRDs7QUFDNUUsV0FBS3ZXLEdBQUwsR0FBV3VWLE9BQU8sQ0FBQ3ZWLEdBQVIsSUFBZSxLQUExQixDQUp3QixDQUt4Qjs7QUFDQSxXQUFLMkMsR0FBTCxHQUFXLElBQVg7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSWpULElBQUFBLFNBQVMsQ0FBQzBDLFNBQVYsQ0FBb0Jva0IsTUFBcEIsR0FBNkIsVUFBVTdULEdBQVYsRUFBZTtBQUN4QyxVQUFJLEtBQUszQyxHQUFMLElBQVksS0FBSzJDLEdBQXJCLEVBQTBCO0FBQ3RCdUIsUUFBQUEsT0FBTyxDQUFDdVMsSUFBUixDQUFhLDZDQUFiO0FBQ0g7O0FBQ0QsV0FBSzlULEdBQUwsR0FBVyxJQUFJd1IsZUFBSixDQUFvQnhSLEdBQXBCLENBQVg7QUFDSCxLQUxEO0FBTUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lqVCxJQUFBQSxTQUFTLENBQUMwQyxTQUFWLENBQW9Cc2tCLGFBQXBCLEdBQW9DLFVBQVVDLE9BQVYsRUFBbUI7QUFDbkQ7QUFDQSxXQUFLSCxNQUFMLENBQVlHLE9BQVo7QUFDSCxLQUhEO0FBSUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lqbkIsSUFBQUEsU0FBUyxDQUFDMEMsU0FBVixDQUFvQndrQixZQUFwQixHQUFtQyxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pEO0FBQ0EsV0FBS0wsTUFBTCxDQUFZSyxNQUFaO0FBQ0gsS0FIRDtBQUlBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJbm5CLElBQUFBLFNBQVMsQ0FBQzBDLFNBQVYsQ0FBb0IyVCxPQUFwQixHQUE4QixVQUFVclIsR0FBVixFQUFlO0FBQ3pDO0FBQ0EsVUFBSTtBQUNBLGVBQU8sS0FBS29pQixNQUFMLEdBQWMvUSxPQUFkLENBQXNCN1UsUUFBUSxDQUFDd0QsR0FBRCxDQUE5QixDQUFQO0FBQ0gsT0FGRCxDQUdBLE9BQU9rUixFQUFQLEVBQVc7QUFDUCxlQUFPLEtBQVA7QUFDSDtBQUNKLEtBUkQ7QUFTQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSWxXLElBQUFBLFNBQVMsQ0FBQzBDLFNBQVYsQ0FBb0I4UyxPQUFwQixHQUE4QixVQUFVeFEsR0FBVixFQUFlO0FBQ3pDO0FBQ0EsVUFBSTtBQUNBLGVBQU9oRSxPQUFPLENBQUMsS0FBS29tQixNQUFMLEdBQWM1UixPQUFkLENBQXNCeFEsR0FBdEIsQ0FBRCxDQUFkO0FBQ0gsT0FGRCxDQUdBLE9BQU9rUixFQUFQLEVBQVc7QUFDUCxlQUFPLEtBQVA7QUFDSDtBQUNKLEtBUkQ7QUFTQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJbFcsSUFBQUEsU0FBUyxDQUFDMEMsU0FBVixDQUFvQmdULFdBQXBCLEdBQWtDLFVBQVUxUSxHQUFWLEVBQWU7QUFDN0MsVUFBSTtBQUNBLFlBQUlxaUIsU0FBUyxHQUFHLEtBQUtELE1BQUwsR0FBYzFSLFdBQWQsQ0FBMEIxUSxHQUExQixLQUFrQyxFQUFsRDtBQUNBLFlBQUlzaUIsU0FBUyxHQUFHLEtBQUtGLE1BQUwsR0FBY2pSLFdBQWQsQ0FBMEJrUixTQUExQixLQUF3QyxFQUF4RDtBQUNBLFlBQUl2VCxLQUFLLEdBQUcsQ0FBWjtBQUNBLFlBQUl5VCxHQUFHLEdBQUcsUUFBVjs7QUFDQSxlQUFPQSxHQUFHLENBQUMzTixJQUFKLENBQVMwTixTQUFULENBQVAsRUFBNEI7QUFDeEI7QUFDQXhULFVBQUFBLEtBQUs7QUFDTHVULFVBQUFBLFNBQVMsR0FBRyxLQUFLRCxNQUFMLEdBQWMxUixXQUFkLENBQTBCMVEsR0FBMUIsS0FBa0MsRUFBOUM7QUFDQXNpQixVQUFBQSxTQUFTLEdBQUcsS0FBS0YsTUFBTCxHQUFjalIsV0FBZCxDQUEwQmtSLFNBQTFCLEtBQXdDLEVBQXBELENBSndCLENBS3hCOztBQUNBLGNBQUl2VCxLQUFLLEdBQUcsRUFBWixFQUFnQjtBQUNaO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7O0FBQ0QsZUFBT3VULFNBQVA7QUFDSCxPQWxCRCxDQW1CQSxPQUFPblIsRUFBUCxFQUFXO0FBQ1AsZUFBTyxLQUFQO0FBQ0g7QUFDSixLQXZCRDtBQXdCQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJbFcsSUFBQUEsU0FBUyxDQUFDMEMsU0FBVixDQUFvQnlULFdBQXBCLEdBQWtDLFVBQVVuUixHQUFWLEVBQWU7QUFDN0MsVUFBSTtBQUNBLGVBQU8sS0FBS29pQixNQUFMLEdBQWNqUixXQUFkLENBQTBCblIsR0FBMUIsQ0FBUDtBQUNILE9BRkQsQ0FHQSxPQUFPa1IsRUFBUCxFQUFXO0FBQ1AsZUFBTyxLQUFQO0FBQ0g7QUFDSixLQVBEO0FBUUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lsVyxJQUFBQSxTQUFTLENBQUMwQyxTQUFWLENBQW9CbVYsSUFBcEIsR0FBMkIsVUFBVTdTLEdBQVYsRUFBZThTLFlBQWYsRUFBNkJDLFVBQTdCLEVBQXlDO0FBQ2hFO0FBQ0EsVUFBSTtBQUNBLGVBQU8vVyxPQUFPLENBQUMsS0FBS29tQixNQUFMLEdBQWN2UCxJQUFkLENBQW1CN1MsR0FBbkIsRUFBd0I4UyxZQUF4QixFQUFzQ0MsVUFBdEMsQ0FBRCxDQUFkO0FBQ0gsT0FGRCxDQUdBLE9BQU83QixFQUFQLEVBQVc7QUFDUCxlQUFPLEtBQVA7QUFDSDtBQUNKLEtBUkQ7QUFTQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSWxXLElBQUFBLFNBQVMsQ0FBQzBDLFNBQVYsQ0FBb0J3VixNQUFwQixHQUE2QixVQUFVbFQsR0FBVixFQUFlbVQsU0FBZixFQUEwQkwsWUFBMUIsRUFBd0M7QUFDakU7QUFDQSxVQUFJO0FBQ0EsZUFBTyxLQUFLc1AsTUFBTCxHQUFjbFAsTUFBZCxDQUFxQmxULEdBQXJCLEVBQTBCeEQsUUFBUSxDQUFDMlcsU0FBRCxDQUFsQyxFQUErQ0wsWUFBL0MsQ0FBUDtBQUNILE9BRkQsQ0FHQSxPQUFPNUIsRUFBUCxFQUFXO0FBQ1AsZUFBTyxLQUFQO0FBQ0g7QUFDSixLQVJEO0FBU0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lsVyxJQUFBQSxTQUFTLENBQUMwQyxTQUFWLENBQW9CMGtCLE1BQXBCLEdBQTZCLFVBQVVJLEVBQVYsRUFBYztBQUN2QztBQUNBLFVBQUksQ0FBQyxLQUFLdlUsR0FBVixFQUFlO0FBQ1g7QUFDQSxhQUFLQSxHQUFMLEdBQVcsSUFBSXdSLGVBQUosRUFBWDs7QUFDQSxZQUFJK0MsRUFBRSxJQUFJLEdBQUdoakIsUUFBSCxDQUFZa1osSUFBWixDQUFpQjhKLEVBQWpCLE1BQXlCLG1CQUFuQyxFQUF3RDtBQUNwRCxlQUFLdlUsR0FBTCxDQUFTc0UsYUFBVCxDQUF1QixLQUFLcVAsZ0JBQTVCLEVBQThDLEtBQUtDLHVCQUFuRCxFQUE0RVcsRUFBNUU7QUFDQTtBQUNILFNBTlUsQ0FPWDs7O0FBQ0EsYUFBS3ZVLEdBQUwsQ0FBUzZELFFBQVQsQ0FBa0IsS0FBSzhQLGdCQUF2QixFQUF5QyxLQUFLQyx1QkFBOUM7QUFDSDs7QUFDRCxhQUFPLEtBQUs1VCxHQUFaO0FBQ0gsS0FiRDtBQWNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0lqVCxJQUFBQSxTQUFTLENBQUMwQyxTQUFWLENBQW9CZ2tCLGFBQXBCLEdBQW9DLFlBQVk7QUFDNUM7QUFDQSxhQUFPLEtBQUtVLE1BQUwsR0FBY1YsYUFBZCxFQUFQO0FBQ0gsS0FIRDtBQUlBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0kxbUIsSUFBQUEsU0FBUyxDQUFDMEMsU0FBVixDQUFvQitrQixnQkFBcEIsR0FBdUMsWUFBWTtBQUMvQztBQUNBLGFBQU8sS0FBS0wsTUFBTCxHQUFjbkIsb0JBQWQsRUFBUDtBQUNILEtBSEQ7QUFJQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNJam1CLElBQUFBLFNBQVMsQ0FBQzBDLFNBQVYsQ0FBb0Jpa0IsWUFBcEIsR0FBbUMsWUFBWTtBQUMzQztBQUNBLGFBQU8sS0FBS1MsTUFBTCxHQUFjVCxZQUFkLEVBQVA7QUFDSCxLQUhEO0FBSUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDSTNtQixJQUFBQSxTQUFTLENBQUMwQyxTQUFWLENBQW9CZ2xCLGVBQXBCLEdBQXNDLFlBQVk7QUFDOUM7QUFDQSxhQUFPLEtBQUtOLE1BQUwsR0FBY2YsbUJBQWQsRUFBUDtBQUNILEtBSEQ7O0FBSUFybUIsSUFBQUEsU0FBUyxDQUFDMm5CLE9BQVYsR0FBb0IsT0FBcEI7QUFDQSxXQUFPM25CLFNBQVA7QUFDSCxHQXhOOEIsRUFBL0I7O0FBME5Bd1QsRUFBQUEsTUFBTSxDQUFDeFQsU0FBUCxHQUFtQkEsU0FBbkI7QUFFQUosRUFBQUEsT0FBTyxDQUFDSSxTQUFSLEdBQW9CQSxTQUFwQjtBQUNBSixFQUFBQSxPQUFPLFdBQVAsR0FBa0JJLFNBQWxCO0FBRUFpQyxFQUFBQSxNQUFNLENBQUMybEIsY0FBUCxDQUFzQmhvQixPQUF0QixFQUErQixZQUEvQixFQUE2QztBQUFFcUUsSUFBQUEsS0FBSyxFQUFFO0FBQVQsR0FBN0M7QUFFQyxDQXgyS0EsQ0FBRCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIChnbG9iYWwsIGZhY3RvcnkpIHtcblx0dHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnICYmIHR5cGVvZiBtb2R1bGUgIT09ICd1bmRlZmluZWQnID8gZmFjdG9yeShleHBvcnRzKSA6XG5cdHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZCA/IGRlZmluZShbJ2V4cG9ydHMnXSwgZmFjdG9yeSkgOlxuXHQoZmFjdG9yeSgoZ2xvYmFsLkpTRW5jcnlwdCA9IHt9KSkpO1xufSh0aGlzLCAoZnVuY3Rpb24gKGV4cG9ydHMpIHsgJ3VzZSBzdHJpY3QnO1xuXG52YXIgQklfUk0gPSBcIjAxMjM0NTY3ODlhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5elwiO1xuZnVuY3Rpb24gaW50MmNoYXIobikge1xuICAgIHJldHVybiBCSV9STS5jaGFyQXQobik7XG59XG4vLyNyZWdpb24gQklUX09QRVJBVElPTlNcbi8vIChwdWJsaWMpIHRoaXMgJiBhXG5mdW5jdGlvbiBvcF9hbmQoeCwgeSkge1xuICAgIHJldHVybiB4ICYgeTtcbn1cbi8vIChwdWJsaWMpIHRoaXMgfCBhXG5mdW5jdGlvbiBvcF9vcih4LCB5KSB7XG4gICAgcmV0dXJuIHggfCB5O1xufVxuLy8gKHB1YmxpYykgdGhpcyBeIGFcbmZ1bmN0aW9uIG9wX3hvcih4LCB5KSB7XG4gICAgcmV0dXJuIHggXiB5O1xufVxuLy8gKHB1YmxpYykgdGhpcyAmIH5hXG5mdW5jdGlvbiBvcF9hbmRub3QoeCwgeSkge1xuICAgIHJldHVybiB4ICYgfnk7XG59XG4vLyByZXR1cm4gaW5kZXggb2YgbG93ZXN0IDEtYml0IGluIHgsIHggPCAyXjMxXG5mdW5jdGlvbiBsYml0KHgpIHtcbiAgICBpZiAoeCA9PSAwKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICB9XG4gICAgdmFyIHIgPSAwO1xuICAgIGlmICgoeCAmIDB4ZmZmZikgPT0gMCkge1xuICAgICAgICB4ID4+PSAxNjtcbiAgICAgICAgciArPSAxNjtcbiAgICB9XG4gICAgaWYgKCh4ICYgMHhmZikgPT0gMCkge1xuICAgICAgICB4ID4+PSA4O1xuICAgICAgICByICs9IDg7XG4gICAgfVxuICAgIGlmICgoeCAmIDB4ZikgPT0gMCkge1xuICAgICAgICB4ID4+PSA0O1xuICAgICAgICByICs9IDQ7XG4gICAgfVxuICAgIGlmICgoeCAmIDMpID09IDApIHtcbiAgICAgICAgeCA+Pj0gMjtcbiAgICAgICAgciArPSAyO1xuICAgIH1cbiAgICBpZiAoKHggJiAxKSA9PSAwKSB7XG4gICAgICAgICsrcjtcbiAgICB9XG4gICAgcmV0dXJuIHI7XG59XG4vLyByZXR1cm4gbnVtYmVyIG9mIDEgYml0cyBpbiB4XG5mdW5jdGlvbiBjYml0KHgpIHtcbiAgICB2YXIgciA9IDA7XG4gICAgd2hpbGUgKHggIT0gMCkge1xuICAgICAgICB4ICY9IHggLSAxO1xuICAgICAgICArK3I7XG4gICAgfVxuICAgIHJldHVybiByO1xufVxuLy8jZW5kcmVnaW9uIEJJVF9PUEVSQVRJT05TXG5cbnZhciBiNjRtYXAgPSBcIkFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5Ky9cIjtcbnZhciBiNjRwYWQgPSBcIj1cIjtcbmZ1bmN0aW9uIGhleDJiNjQoaCkge1xuICAgIHZhciBpO1xuICAgIHZhciBjO1xuICAgIHZhciByZXQgPSBcIlwiO1xuICAgIGZvciAoaSA9IDA7IGkgKyAzIDw9IGgubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAgICAgYyA9IHBhcnNlSW50KGguc3Vic3RyaW5nKGksIGkgKyAzKSwgMTYpO1xuICAgICAgICByZXQgKz0gYjY0bWFwLmNoYXJBdChjID4+IDYpICsgYjY0bWFwLmNoYXJBdChjICYgNjMpO1xuICAgIH1cbiAgICBpZiAoaSArIDEgPT0gaC5sZW5ndGgpIHtcbiAgICAgICAgYyA9IHBhcnNlSW50KGguc3Vic3RyaW5nKGksIGkgKyAxKSwgMTYpO1xuICAgICAgICByZXQgKz0gYjY0bWFwLmNoYXJBdChjIDw8IDIpO1xuICAgIH1cbiAgICBlbHNlIGlmIChpICsgMiA9PSBoLmxlbmd0aCkge1xuICAgICAgICBjID0gcGFyc2VJbnQoaC5zdWJzdHJpbmcoaSwgaSArIDIpLCAxNik7XG4gICAgICAgIHJldCArPSBiNjRtYXAuY2hhckF0KGMgPj4gMikgKyBiNjRtYXAuY2hhckF0KChjICYgMykgPDwgNCk7XG4gICAgfVxuICAgIHdoaWxlICgocmV0Lmxlbmd0aCAmIDMpID4gMCkge1xuICAgICAgICByZXQgKz0gYjY0cGFkO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xufVxuLy8gY29udmVydCBhIGJhc2U2NCBzdHJpbmcgdG8gaGV4XG5mdW5jdGlvbiBiNjR0b2hleChzKSB7XG4gICAgdmFyIHJldCA9IFwiXCI7XG4gICAgdmFyIGk7XG4gICAgdmFyIGsgPSAwOyAvLyBiNjQgc3RhdGUsIDAtM1xuICAgIHZhciBzbG9wID0gMDtcbiAgICBmb3IgKGkgPSAwOyBpIDwgcy5sZW5ndGg7ICsraSkge1xuICAgICAgICBpZiAocy5jaGFyQXQoaSkgPT0gYjY0cGFkKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICB2YXIgdiA9IGI2NG1hcC5pbmRleE9mKHMuY2hhckF0KGkpKTtcbiAgICAgICAgaWYgKHYgPCAwKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoayA9PSAwKSB7XG4gICAgICAgICAgICByZXQgKz0gaW50MmNoYXIodiA+PiAyKTtcbiAgICAgICAgICAgIHNsb3AgPSB2ICYgMztcbiAgICAgICAgICAgIGsgPSAxO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGsgPT0gMSkge1xuICAgICAgICAgICAgcmV0ICs9IGludDJjaGFyKChzbG9wIDw8IDIpIHwgKHYgPj4gNCkpO1xuICAgICAgICAgICAgc2xvcCA9IHYgJiAweGY7XG4gICAgICAgICAgICBrID0gMjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChrID09IDIpIHtcbiAgICAgICAgICAgIHJldCArPSBpbnQyY2hhcihzbG9wKTtcbiAgICAgICAgICAgIHJldCArPSBpbnQyY2hhcih2ID4+IDIpO1xuICAgICAgICAgICAgc2xvcCA9IHYgJiAzO1xuICAgICAgICAgICAgayA9IDM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXQgKz0gaW50MmNoYXIoKHNsb3AgPDwgMikgfCAodiA+PiA0KSk7XG4gICAgICAgICAgICByZXQgKz0gaW50MmNoYXIodiAmIDB4Zik7XG4gICAgICAgICAgICBrID0gMDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoayA9PSAxKSB7XG4gICAgICAgIHJldCArPSBpbnQyY2hhcihzbG9wIDw8IDIpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xufVxuXG4vKiEgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXHJcbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7IHlvdSBtYXkgbm90IHVzZVxyXG50aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS4gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZVxyXG5MaWNlbnNlIGF0IGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG5cclxuVEhJUyBDT0RFIElTIFBST1ZJREVEIE9OIEFOICpBUyBJUyogQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWVxyXG5LSU5ELCBFSVRIRVIgRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgV0lUSE9VVCBMSU1JVEFUSU9OIEFOWSBJTVBMSUVEXHJcbldBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBUSVRMRSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UsXHJcbk1FUkNIQU5UQUJMSVRZIE9SIE5PTi1JTkZSSU5HRU1FTlQuXHJcblxyXG5TZWUgdGhlIEFwYWNoZSBWZXJzaW9uIDIuMCBMaWNlbnNlIGZvciBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnNcclxuYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xyXG4vKiBnbG9iYWwgUmVmbGVjdCwgUHJvbWlzZSAqL1xyXG5cclxudmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbihkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKGIuaGFzT3duUHJvcGVydHkocCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xyXG59XG5cbi8vIEhleCBKYXZhU2NyaXB0IGRlY29kZXJcbi8vIENvcHlyaWdodCAoYykgMjAwOC0yMDEzIExhcG8gTHVjaGluaSA8bGFwb0BsYXBvLml0PlxuLy8gUGVybWlzc2lvbiB0byB1c2UsIGNvcHksIG1vZGlmeSwgYW5kL29yIGRpc3RyaWJ1dGUgdGhpcyBzb2Z0d2FyZSBmb3IgYW55XG4vLyBwdXJwb3NlIHdpdGggb3Igd2l0aG91dCBmZWUgaXMgaGVyZWJ5IGdyYW50ZWQsIHByb3ZpZGVkIHRoYXQgdGhlIGFib3ZlXG4vLyBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIGFwcGVhciBpbiBhbGwgY29waWVzLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIgQU5EIFRIRSBBVVRIT1IgRElTQ0xBSU1TIEFMTCBXQVJSQU5USUVTXG4vLyBXSVRIIFJFR0FSRCBUTyBUSElTIFNPRlRXQVJFIElOQ0xVRElORyBBTEwgSU1QTElFRCBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFkgQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUlxuLy8gQU5ZIFNQRUNJQUwsIERJUkVDVCwgSU5ESVJFQ1QsIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyBPUiBBTlkgREFNQUdFU1xuLy8gV0hBVFNPRVZFUiBSRVNVTFRJTkcgRlJPTSBMT1NTIE9GIFVTRSwgREFUQSBPUiBQUk9GSVRTLCBXSEVUSEVSIElOIEFOXG4vLyBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1IgT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRlxuLy8gT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBVU0UgT1IgUEVSRk9STUFOQ0UgT0YgVEhJUyBTT0ZUV0FSRS5cbi8qanNoaW50IGJyb3dzZXI6IHRydWUsIHN0cmljdDogdHJ1ZSwgaW1tZWQ6IHRydWUsIGxhdGVkZWY6IHRydWUsIHVuZGVmOiB0cnVlLCByZWdleGRhc2g6IGZhbHNlICovXG52YXIgZGVjb2RlcjtcbnZhciBIZXggPSB7XG4gICAgZGVjb2RlOiBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgaTtcbiAgICAgICAgaWYgKGRlY29kZXIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdmFyIGhleCA9IFwiMDEyMzQ1Njc4OUFCQ0RFRlwiO1xuICAgICAgICAgICAgdmFyIGlnbm9yZSA9IFwiIFxcZlxcblxcclxcdFxcdTAwQTBcXHUyMDI4XFx1MjAyOVwiO1xuICAgICAgICAgICAgZGVjb2RlciA9IHt9O1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IDE2OyArK2kpIHtcbiAgICAgICAgICAgICAgICBkZWNvZGVyW2hleC5jaGFyQXQoaSldID0gaTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGhleCA9IGhleC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgZm9yIChpID0gMTA7IGkgPCAxNjsgKytpKSB7XG4gICAgICAgICAgICAgICAgZGVjb2RlcltoZXguY2hhckF0KGkpXSA9IGk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgaWdub3JlLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgZGVjb2RlcltpZ25vcmUuY2hhckF0KGkpXSA9IC0xO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBvdXQgPSBbXTtcbiAgICAgICAgdmFyIGJpdHMgPSAwO1xuICAgICAgICB2YXIgY2hhcl9jb3VudCA9IDA7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBhLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgYyA9IGEuY2hhckF0KGkpO1xuICAgICAgICAgICAgaWYgKGMgPT0gXCI9XCIpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGMgPSBkZWNvZGVyW2NdO1xuICAgICAgICAgICAgaWYgKGMgPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbGxlZ2FsIGNoYXJhY3RlciBhdCBvZmZzZXQgXCIgKyBpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJpdHMgfD0gYztcbiAgICAgICAgICAgIGlmICgrK2NoYXJfY291bnQgPj0gMikge1xuICAgICAgICAgICAgICAgIG91dFtvdXQubGVuZ3RoXSA9IGJpdHM7XG4gICAgICAgICAgICAgICAgYml0cyA9IDA7XG4gICAgICAgICAgICAgICAgY2hhcl9jb3VudCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBiaXRzIDw8PSA0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFyX2NvdW50KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJIZXggZW5jb2RpbmcgaW5jb21wbGV0ZTogNCBiaXRzIG1pc3NpbmdcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dDtcbiAgICB9XG59O1xuXG4vLyBCYXNlNjQgSmF2YVNjcmlwdCBkZWNvZGVyXG4vLyBDb3B5cmlnaHQgKGMpIDIwMDgtMjAxMyBMYXBvIEx1Y2hpbmkgPGxhcG9AbGFwby5pdD5cbi8vIFBlcm1pc3Npb24gdG8gdXNlLCBjb3B5LCBtb2RpZnksIGFuZC9vciBkaXN0cmlidXRlIHRoaXMgc29mdHdhcmUgZm9yIGFueVxuLy8gcHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLCBwcm92aWRlZCB0aGF0IHRoZSBhYm92ZVxuLy8gY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBhcHBlYXIgaW4gYWxsIGNvcGllcy5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiIEFORCBUSEUgQVVUSE9SIERJU0NMQUlNUyBBTEwgV0FSUkFOVElFU1xuLy8gV0lUSCBSRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZIEFORCBGSVRORVNTLiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SIEJFIExJQUJMRSBGT1Jcbi8vIEFOWSBTUEVDSUFMLCBESVJFQ1QsIElORElSRUNULCBPUiBDT05TRVFVRU5USUFMIERBTUFHRVMgT1IgQU5ZIERBTUFHRVNcbi8vIFdIQVRTT0VWRVIgUkVTVUxUSU5HIEZST00gTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTlxuLy8gQUNUSU9OIE9GIENPTlRSQUNULCBORUdMSUdFTkNFIE9SIE9USEVSIFRPUlRJT1VTIEFDVElPTiwgQVJJU0lORyBPVVQgT0Zcbi8vIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgVVNFIE9SIFBFUkZPUk1BTkNFIE9GIFRISVMgU09GVFdBUkUuXG4vKmpzaGludCBicm93c2VyOiB0cnVlLCBzdHJpY3Q6IHRydWUsIGltbWVkOiB0cnVlLCBsYXRlZGVmOiB0cnVlLCB1bmRlZjogdHJ1ZSwgcmVnZXhkYXNoOiBmYWxzZSAqL1xudmFyIGRlY29kZXIkMTtcbnZhciBCYXNlNjQgPSB7XG4gICAgZGVjb2RlOiBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgaTtcbiAgICAgICAgaWYgKGRlY29kZXIkMSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YXIgYjY0ID0gXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCI7XG4gICAgICAgICAgICB2YXIgaWdub3JlID0gXCI9IFxcZlxcblxcclxcdFxcdTAwQTBcXHUyMDI4XFx1MjAyOVwiO1xuICAgICAgICAgICAgZGVjb2RlciQxID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCA2NDsgKytpKSB7XG4gICAgICAgICAgICAgICAgZGVjb2RlciQxW2I2NC5jaGFyQXQoaSldID0gaTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBpZ25vcmUubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgICAgICBkZWNvZGVyJDFbaWdub3JlLmNoYXJBdChpKV0gPSAtMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgb3V0ID0gW107XG4gICAgICAgIHZhciBiaXRzID0gMDtcbiAgICAgICAgdmFyIGNoYXJfY291bnQgPSAwO1xuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgYS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGMgPSBhLmNoYXJBdChpKTtcbiAgICAgICAgICAgIGlmIChjID09IFwiPVwiKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjID0gZGVjb2RlciQxW2NdO1xuICAgICAgICAgICAgaWYgKGMgPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbGxlZ2FsIGNoYXJhY3RlciBhdCBvZmZzZXQgXCIgKyBpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJpdHMgfD0gYztcbiAgICAgICAgICAgIGlmICgrK2NoYXJfY291bnQgPj0gNCkge1xuICAgICAgICAgICAgICAgIG91dFtvdXQubGVuZ3RoXSA9IChiaXRzID4+IDE2KTtcbiAgICAgICAgICAgICAgICBvdXRbb3V0Lmxlbmd0aF0gPSAoYml0cyA+PiA4KSAmIDB4RkY7XG4gICAgICAgICAgICAgICAgb3V0W291dC5sZW5ndGhdID0gYml0cyAmIDB4RkY7XG4gICAgICAgICAgICAgICAgYml0cyA9IDA7XG4gICAgICAgICAgICAgICAgY2hhcl9jb3VudCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBiaXRzIDw8PSA2O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHN3aXRjaCAoY2hhcl9jb3VudCkge1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkJhc2U2NCBlbmNvZGluZyBpbmNvbXBsZXRlOiBhdCBsZWFzdCAyIGJpdHMgbWlzc2luZ1wiKTtcbiAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICBvdXRbb3V0Lmxlbmd0aF0gPSAoYml0cyA+PiAxMCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgb3V0W291dC5sZW5ndGhdID0gKGJpdHMgPj4gMTYpO1xuICAgICAgICAgICAgICAgIG91dFtvdXQubGVuZ3RoXSA9IChiaXRzID4+IDgpICYgMHhGRjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3V0O1xuICAgIH0sXG4gICAgcmU6IC8tLS0tLUJFR0lOIFteLV0rLS0tLS0oW0EtWmEtejAtOStcXC89XFxzXSspLS0tLS1FTkQgW14tXSstLS0tLXxiZWdpbi1iYXNlNjRbXlxcbl0rXFxuKFtBLVphLXowLTkrXFwvPVxcc10rKT09PT0vLFxuICAgIHVuYXJtb3I6IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHZhciBtID0gQmFzZTY0LnJlLmV4ZWMoYSk7XG4gICAgICAgIGlmIChtKSB7XG4gICAgICAgICAgICBpZiAobVsxXSkge1xuICAgICAgICAgICAgICAgIGEgPSBtWzFdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAobVsyXSkge1xuICAgICAgICAgICAgICAgIGEgPSBtWzJdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVnRXhwIG91dCBvZiBzeW5jXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBCYXNlNjQuZGVjb2RlKGEpO1xuICAgIH1cbn07XG5cbi8vIEJpZyBpbnRlZ2VyIGJhc2UtMTAgcHJpbnRpbmcgbGlicmFyeVxuLy8gQ29weXJpZ2h0IChjKSAyMDE0IExhcG8gTHVjaGluaSA8bGFwb0BsYXBvLml0PlxuLy8gUGVybWlzc2lvbiB0byB1c2UsIGNvcHksIG1vZGlmeSwgYW5kL29yIGRpc3RyaWJ1dGUgdGhpcyBzb2Z0d2FyZSBmb3IgYW55XG4vLyBwdXJwb3NlIHdpdGggb3Igd2l0aG91dCBmZWUgaXMgaGVyZWJ5IGdyYW50ZWQsIHByb3ZpZGVkIHRoYXQgdGhlIGFib3ZlXG4vLyBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIGFwcGVhciBpbiBhbGwgY29waWVzLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIgQU5EIFRIRSBBVVRIT1IgRElTQ0xBSU1TIEFMTCBXQVJSQU5USUVTXG4vLyBXSVRIIFJFR0FSRCBUTyBUSElTIFNPRlRXQVJFIElOQ0xVRElORyBBTEwgSU1QTElFRCBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFkgQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUlxuLy8gQU5ZIFNQRUNJQUwsIERJUkVDVCwgSU5ESVJFQ1QsIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyBPUiBBTlkgREFNQUdFU1xuLy8gV0hBVFNPRVZFUiBSRVNVTFRJTkcgRlJPTSBMT1NTIE9GIFVTRSwgREFUQSBPUiBQUk9GSVRTLCBXSEVUSEVSIElOIEFOXG4vLyBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1IgT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRlxuLy8gT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBVU0UgT1IgUEVSRk9STUFOQ0UgT0YgVEhJUyBTT0ZUV0FSRS5cbi8qanNoaW50IGJyb3dzZXI6IHRydWUsIHN0cmljdDogdHJ1ZSwgaW1tZWQ6IHRydWUsIGxhdGVkZWY6IHRydWUsIHVuZGVmOiB0cnVlLCByZWdleGRhc2g6IGZhbHNlICovXG52YXIgbWF4ID0gMTAwMDAwMDAwMDAwMDA7IC8vIGJpZ2dlc3QgaW50ZWdlciB0aGF0IGNhbiBzdGlsbCBmaXQgMl41MyB3aGVuIG11bHRpcGxpZWQgYnkgMjU2XG52YXIgSW50MTAgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gSW50MTAodmFsdWUpIHtcbiAgICAgICAgdGhpcy5idWYgPSBbK3ZhbHVlIHx8IDBdO1xuICAgIH1cbiAgICBJbnQxMC5wcm90b3R5cGUubXVsQWRkID0gZnVuY3Rpb24gKG0sIGMpIHtcbiAgICAgICAgLy8gYXNzZXJ0KG0gPD0gMjU2KVxuICAgICAgICB2YXIgYiA9IHRoaXMuYnVmO1xuICAgICAgICB2YXIgbCA9IGIubGVuZ3RoO1xuICAgICAgICB2YXIgaTtcbiAgICAgICAgdmFyIHQ7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICAgIHQgPSBiW2ldICogbSArIGM7XG4gICAgICAgICAgICBpZiAodCA8IG1heCkge1xuICAgICAgICAgICAgICAgIGMgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYyA9IDAgfCAodCAvIG1heCk7XG4gICAgICAgICAgICAgICAgdCAtPSBjICogbWF4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYltpXSA9IHQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGMgPiAwKSB7XG4gICAgICAgICAgICBiW2ldID0gYztcbiAgICAgICAgfVxuICAgIH07XG4gICAgSW50MTAucHJvdG90eXBlLnN1YiA9IGZ1bmN0aW9uIChjKSB7XG4gICAgICAgIC8vIGFzc2VydChtIDw9IDI1NilcbiAgICAgICAgdmFyIGIgPSB0aGlzLmJ1ZjtcbiAgICAgICAgdmFyIGwgPSBiLmxlbmd0aDtcbiAgICAgICAgdmFyIGk7XG4gICAgICAgIHZhciB0O1xuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgbDsgKytpKSB7XG4gICAgICAgICAgICB0ID0gYltpXSAtIGM7XG4gICAgICAgICAgICBpZiAodCA8IDApIHtcbiAgICAgICAgICAgICAgICB0ICs9IG1heDtcbiAgICAgICAgICAgICAgICBjID0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGMgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYltpXSA9IHQ7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKGJbYi5sZW5ndGggLSAxXSA9PT0gMCkge1xuICAgICAgICAgICAgYi5wb3AoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgSW50MTAucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gKGJhc2UpIHtcbiAgICAgICAgaWYgKChiYXNlIHx8IDEwKSAhPSAxMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwib25seSBiYXNlIDEwIGlzIHN1cHBvcnRlZFwiKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgYiA9IHRoaXMuYnVmO1xuICAgICAgICB2YXIgcyA9IGJbYi5sZW5ndGggLSAxXS50b1N0cmluZygpO1xuICAgICAgICBmb3IgKHZhciBpID0gYi5sZW5ndGggLSAyOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgcyArPSAobWF4ICsgYltpXSkudG9TdHJpbmcoKS5zdWJzdHJpbmcoMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHM7XG4gICAgfTtcbiAgICBJbnQxMC5wcm90b3R5cGUudmFsdWVPZiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGIgPSB0aGlzLmJ1ZjtcbiAgICAgICAgdmFyIHYgPSAwO1xuICAgICAgICBmb3IgKHZhciBpID0gYi5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgdiA9IHYgKiBtYXggKyBiW2ldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2O1xuICAgIH07XG4gICAgSW50MTAucHJvdG90eXBlLnNpbXBsaWZ5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgYiA9IHRoaXMuYnVmO1xuICAgICAgICByZXR1cm4gKGIubGVuZ3RoID09IDEpID8gYlswXSA6IHRoaXM7XG4gICAgfTtcbiAgICByZXR1cm4gSW50MTA7XG59KCkpO1xuXG4vLyBBU04uMSBKYXZhU2NyaXB0IGRlY29kZXJcbnZhciBlbGxpcHNpcyA9IFwiXFx1MjAyNlwiO1xudmFyIHJlVGltZVMgPSAvXihcXGRcXGQpKDBbMS05XXwxWzAtMl0pKDBbMS05XXxbMTJdXFxkfDNbMDFdKShbMDFdXFxkfDJbMC0zXSkoPzooWzAtNV1cXGQpKD86KFswLTVdXFxkKSg/OlsuLF0oXFxkezEsM30pKT8pPyk/KFp8Wy0rXSg/OlswXVxcZHwxWzAtMl0pKFswLTVdXFxkKT8pPyQvO1xudmFyIHJlVGltZUwgPSAvXihcXGRcXGRcXGRcXGQpKDBbMS05XXwxWzAtMl0pKDBbMS05XXxbMTJdXFxkfDNbMDFdKShbMDFdXFxkfDJbMC0zXSkoPzooWzAtNV1cXGQpKD86KFswLTVdXFxkKSg/OlsuLF0oXFxkezEsM30pKT8pPyk/KFp8Wy0rXSg/OlswXVxcZHwxWzAtMl0pKFswLTVdXFxkKT8pPyQvO1xuZnVuY3Rpb24gc3RyaW5nQ3V0KHN0ciwgbGVuKSB7XG4gICAgaWYgKHN0ci5sZW5ndGggPiBsZW4pIHtcbiAgICAgICAgc3RyID0gc3RyLnN1YnN0cmluZygwLCBsZW4pICsgZWxsaXBzaXM7XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG59XG52YXIgU3RyZWFtID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFN0cmVhbShlbmMsIHBvcykge1xuICAgICAgICB0aGlzLmhleERpZ2l0cyA9IFwiMDEyMzQ1Njc4OUFCQ0RFRlwiO1xuICAgICAgICBpZiAoZW5jIGluc3RhbmNlb2YgU3RyZWFtKSB7XG4gICAgICAgICAgICB0aGlzLmVuYyA9IGVuYy5lbmM7XG4gICAgICAgICAgICB0aGlzLnBvcyA9IGVuYy5wb3M7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBlbmMgc2hvdWxkIGJlIGFuIGFycmF5IG9yIGEgYmluYXJ5IHN0cmluZ1xuICAgICAgICAgICAgdGhpcy5lbmMgPSBlbmM7XG4gICAgICAgICAgICB0aGlzLnBvcyA9IHBvcztcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdHJlYW0ucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChwb3MpIHtcbiAgICAgICAgaWYgKHBvcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBwb3MgPSB0aGlzLnBvcysrO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwb3MgPj0gdGhpcy5lbmMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJSZXF1ZXN0aW5nIGJ5dGUgb2Zmc2V0IFwiICsgcG9zICsgXCIgb24gYSBzdHJlYW0gb2YgbGVuZ3RoIFwiICsgdGhpcy5lbmMubGVuZ3RoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKFwic3RyaW5nXCIgPT09IHR5cGVvZiB0aGlzLmVuYykgPyB0aGlzLmVuYy5jaGFyQ29kZUF0KHBvcykgOiB0aGlzLmVuY1twb3NdO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5oZXhCeXRlID0gZnVuY3Rpb24gKGIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaGV4RGlnaXRzLmNoYXJBdCgoYiA+PiA0KSAmIDB4RikgKyB0aGlzLmhleERpZ2l0cy5jaGFyQXQoYiAmIDB4Rik7XG4gICAgfTtcbiAgICBTdHJlYW0ucHJvdG90eXBlLmhleER1bXAgPSBmdW5jdGlvbiAoc3RhcnQsIGVuZCwgcmF3KSB7XG4gICAgICAgIHZhciBzID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOyArK2kpIHtcbiAgICAgICAgICAgIHMgKz0gdGhpcy5oZXhCeXRlKHRoaXMuZ2V0KGkpKTtcbiAgICAgICAgICAgIGlmIChyYXcgIT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKGkgJiAweEYpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDc6XG4gICAgICAgICAgICAgICAgICAgICAgICBzICs9IFwiICBcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4RjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHMgKz0gXCJcXG5cIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgcyArPSBcIiBcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHM7XG4gICAgfTtcbiAgICBTdHJlYW0ucHJvdG90eXBlLmlzQVNDSUkgPSBmdW5jdGlvbiAoc3RhcnQsIGVuZCkge1xuICAgICAgICBmb3IgKHZhciBpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkge1xuICAgICAgICAgICAgdmFyIGMgPSB0aGlzLmdldChpKTtcbiAgICAgICAgICAgIGlmIChjIDwgMzIgfHwgYyA+IDE3Nikge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuICAgIFN0cmVhbS5wcm90b3R5cGUucGFyc2VTdHJpbmdJU08gPSBmdW5jdGlvbiAoc3RhcnQsIGVuZCkge1xuICAgICAgICB2YXIgcyA9IFwiXCI7XG4gICAgICAgIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgKytpKSB7XG4gICAgICAgICAgICBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUodGhpcy5nZXQoaSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5wYXJzZVN0cmluZ1VURiA9IGZ1bmN0aW9uIChzdGFydCwgZW5kKSB7XG4gICAgICAgIHZhciBzID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOykge1xuICAgICAgICAgICAgdmFyIGMgPSB0aGlzLmdldChpKyspO1xuICAgICAgICAgICAgaWYgKGMgPCAxMjgpIHtcbiAgICAgICAgICAgICAgICBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICgoYyA+IDE5MSkgJiYgKGMgPCAyMjQpKSB7XG4gICAgICAgICAgICAgICAgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKCgoYyAmIDB4MUYpIDw8IDYpIHwgKHRoaXMuZ2V0KGkrKykgJiAweDNGKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKChjICYgMHgwRikgPDwgMTIpIHwgKCh0aGlzLmdldChpKyspICYgMHgzRikgPDwgNikgfCAodGhpcy5nZXQoaSsrKSAmIDB4M0YpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcztcbiAgICB9O1xuICAgIFN0cmVhbS5wcm90b3R5cGUucGFyc2VTdHJpbmdCTVAgPSBmdW5jdGlvbiAoc3RhcnQsIGVuZCkge1xuICAgICAgICB2YXIgc3RyID0gXCJcIjtcbiAgICAgICAgdmFyIGhpO1xuICAgICAgICB2YXIgbG87XG4gICAgICAgIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDspIHtcbiAgICAgICAgICAgIGhpID0gdGhpcy5nZXQoaSsrKTtcbiAgICAgICAgICAgIGxvID0gdGhpcy5nZXQoaSsrKTtcbiAgICAgICAgICAgIHN0ciArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKChoaSA8PCA4KSB8IGxvKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RyO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5wYXJzZVRpbWUgPSBmdW5jdGlvbiAoc3RhcnQsIGVuZCwgc2hvcnRZZWFyKSB7XG4gICAgICAgIHZhciBzID0gdGhpcy5wYXJzZVN0cmluZ0lTTyhzdGFydCwgZW5kKTtcbiAgICAgICAgdmFyIG0gPSAoc2hvcnRZZWFyID8gcmVUaW1lUyA6IHJlVGltZUwpLmV4ZWMocyk7XG4gICAgICAgIGlmICghbSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiVW5yZWNvZ25pemVkIHRpbWU6IFwiICsgcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2hvcnRZZWFyKSB7XG4gICAgICAgICAgICAvLyB0byBhdm9pZCBxdWVyeWluZyB0aGUgdGltZXIsIHVzZSB0aGUgZml4ZWQgcmFuZ2UgWzE5NzAsIDIwNjldXG4gICAgICAgICAgICAvLyBpdCB3aWxsIGNvbmZvcm0gd2l0aCBJVFUgWC40MDAgWy0xMCwgKzQwXSBzbGlkaW5nIHdpbmRvdyB1bnRpbCAyMDMwXG4gICAgICAgICAgICBtWzFdID0gK21bMV07XG4gICAgICAgICAgICBtWzFdICs9ICgrbVsxXSA8IDcwKSA/IDIwMDAgOiAxOTAwO1xuICAgICAgICB9XG4gICAgICAgIHMgPSBtWzFdICsgXCItXCIgKyBtWzJdICsgXCItXCIgKyBtWzNdICsgXCIgXCIgKyBtWzRdO1xuICAgICAgICBpZiAobVs1XSkge1xuICAgICAgICAgICAgcyArPSBcIjpcIiArIG1bNV07XG4gICAgICAgICAgICBpZiAobVs2XSkge1xuICAgICAgICAgICAgICAgIHMgKz0gXCI6XCIgKyBtWzZdO1xuICAgICAgICAgICAgICAgIGlmIChtWzddKSB7XG4gICAgICAgICAgICAgICAgICAgIHMgKz0gXCIuXCIgKyBtWzddO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAobVs4XSkge1xuICAgICAgICAgICAgcyArPSBcIiBVVENcIjtcbiAgICAgICAgICAgIGlmIChtWzhdICE9IFwiWlwiKSB7XG4gICAgICAgICAgICAgICAgcyArPSBtWzhdO1xuICAgICAgICAgICAgICAgIGlmIChtWzldKSB7XG4gICAgICAgICAgICAgICAgICAgIHMgKz0gXCI6XCIgKyBtWzldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcztcbiAgICB9O1xuICAgIFN0cmVhbS5wcm90b3R5cGUucGFyc2VJbnRlZ2VyID0gZnVuY3Rpb24gKHN0YXJ0LCBlbmQpIHtcbiAgICAgICAgdmFyIHYgPSB0aGlzLmdldChzdGFydCk7XG4gICAgICAgIHZhciBuZWcgPSAodiA+IDEyNyk7XG4gICAgICAgIHZhciBwYWQgPSBuZWcgPyAyNTUgOiAwO1xuICAgICAgICB2YXIgbGVuO1xuICAgICAgICB2YXIgcyA9IFwiXCI7XG4gICAgICAgIC8vIHNraXAgdW51c2VmdWwgYml0cyAobm90IGFsbG93ZWQgaW4gREVSKVxuICAgICAgICB3aGlsZSAodiA9PSBwYWQgJiYgKytzdGFydCA8IGVuZCkge1xuICAgICAgICAgICAgdiA9IHRoaXMuZ2V0KHN0YXJ0KTtcbiAgICAgICAgfVxuICAgICAgICBsZW4gPSBlbmQgLSBzdGFydDtcbiAgICAgICAgaWYgKGxlbiA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIG5lZyA/IC0xIDogMDtcbiAgICAgICAgfVxuICAgICAgICAvLyBzaG93IGJpdCBsZW5ndGggb2YgaHVnZSBpbnRlZ2Vyc1xuICAgICAgICBpZiAobGVuID4gNCkge1xuICAgICAgICAgICAgcyA9IHY7XG4gICAgICAgICAgICBsZW4gPDw9IDM7XG4gICAgICAgICAgICB3aGlsZSAoKCgrcyBeIHBhZCkgJiAweDgwKSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgcyA9ICtzIDw8IDE7XG4gICAgICAgICAgICAgICAgLS1sZW47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzID0gXCIoXCIgKyBsZW4gKyBcIiBiaXQpXFxuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZGVjb2RlIHRoZSBpbnRlZ2VyXG4gICAgICAgIGlmIChuZWcpIHtcbiAgICAgICAgICAgIHYgPSB2IC0gMjU2O1xuICAgICAgICB9XG4gICAgICAgIHZhciBuID0gbmV3IEludDEwKHYpO1xuICAgICAgICBmb3IgKHZhciBpID0gc3RhcnQgKyAxOyBpIDwgZW5kOyArK2kpIHtcbiAgICAgICAgICAgIG4ubXVsQWRkKDI1NiwgdGhpcy5nZXQoaSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzICsgbi50b1N0cmluZygpO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5wYXJzZUJpdFN0cmluZyA9IGZ1bmN0aW9uIChzdGFydCwgZW5kLCBtYXhMZW5ndGgpIHtcbiAgICAgICAgdmFyIHVudXNlZEJpdCA9IHRoaXMuZ2V0KHN0YXJ0KTtcbiAgICAgICAgdmFyIGxlbkJpdCA9ICgoZW5kIC0gc3RhcnQgLSAxKSA8PCAzKSAtIHVudXNlZEJpdDtcbiAgICAgICAgdmFyIGludHJvID0gXCIoXCIgKyBsZW5CaXQgKyBcIiBiaXQpXFxuXCI7XG4gICAgICAgIHZhciBzID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0ICsgMTsgaSA8IGVuZDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgYiA9IHRoaXMuZ2V0KGkpO1xuICAgICAgICAgICAgdmFyIHNraXAgPSAoaSA9PSBlbmQgLSAxKSA/IHVudXNlZEJpdCA6IDA7XG4gICAgICAgICAgICBmb3IgKHZhciBqID0gNzsgaiA+PSBza2lwOyAtLWopIHtcbiAgICAgICAgICAgICAgICBzICs9IChiID4+IGopICYgMSA/IFwiMVwiIDogXCIwXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocy5sZW5ndGggPiBtYXhMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50cm8gKyBzdHJpbmdDdXQocywgbWF4TGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaW50cm8gKyBzO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5wYXJzZU9jdGV0U3RyaW5nID0gZnVuY3Rpb24gKHN0YXJ0LCBlbmQsIG1heExlbmd0aCkge1xuICAgICAgICBpZiAodGhpcy5pc0FTQ0lJKHN0YXJ0LCBlbmQpKSB7XG4gICAgICAgICAgICByZXR1cm4gc3RyaW5nQ3V0KHRoaXMucGFyc2VTdHJpbmdJU08oc3RhcnQsIGVuZCksIG1heExlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGxlbiA9IGVuZCAtIHN0YXJ0O1xuICAgICAgICB2YXIgcyA9IFwiKFwiICsgbGVuICsgXCIgYnl0ZSlcXG5cIjtcbiAgICAgICAgbWF4TGVuZ3RoIC89IDI7IC8vIHdlIHdvcmsgaW4gYnl0ZXNcbiAgICAgICAgaWYgKGxlbiA+IG1heExlbmd0aCkge1xuICAgICAgICAgICAgZW5kID0gc3RhcnQgKyBtYXhMZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOyArK2kpIHtcbiAgICAgICAgICAgIHMgKz0gdGhpcy5oZXhCeXRlKHRoaXMuZ2V0KGkpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGVuID4gbWF4TGVuZ3RoKSB7XG4gICAgICAgICAgICBzICs9IGVsbGlwc2lzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzO1xuICAgIH07XG4gICAgU3RyZWFtLnByb3RvdHlwZS5wYXJzZU9JRCA9IGZ1bmN0aW9uIChzdGFydCwgZW5kLCBtYXhMZW5ndGgpIHtcbiAgICAgICAgdmFyIHMgPSBcIlwiO1xuICAgICAgICB2YXIgbiA9IG5ldyBJbnQxMCgpO1xuICAgICAgICB2YXIgYml0cyA9IDA7XG4gICAgICAgIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgdiA9IHRoaXMuZ2V0KGkpO1xuICAgICAgICAgICAgbi5tdWxBZGQoMTI4LCB2ICYgMHg3Rik7XG4gICAgICAgICAgICBiaXRzICs9IDc7XG4gICAgICAgICAgICBpZiAoISh2ICYgMHg4MCkpIHsgLy8gZmluaXNoZWRcbiAgICAgICAgICAgICAgICBpZiAocyA9PT0gXCJcIikge1xuICAgICAgICAgICAgICAgICAgICBuID0gbi5zaW1wbGlmeSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAobiBpbnN0YW5jZW9mIEludDEwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuLnN1Yig4MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzID0gXCIyLlwiICsgbi50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG0gPSBuIDwgODAgPyBuIDwgNDAgPyAwIDogMSA6IDI7XG4gICAgICAgICAgICAgICAgICAgICAgICBzID0gbSArIFwiLlwiICsgKG4gLSBtICogNDApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzICs9IFwiLlwiICsgbi50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocy5sZW5ndGggPiBtYXhMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN0cmluZ0N1dChzLCBtYXhMZW5ndGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBuID0gbmV3IEludDEwKCk7XG4gICAgICAgICAgICAgICAgYml0cyA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJpdHMgPiAwKSB7XG4gICAgICAgICAgICBzICs9IFwiLmluY29tcGxldGVcIjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcztcbiAgICB9O1xuICAgIHJldHVybiBTdHJlYW07XG59KCkpO1xudmFyIEFTTjEgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQVNOMShzdHJlYW0sIGhlYWRlciwgbGVuZ3RoLCB0YWcsIHN1Yikge1xuICAgICAgICBpZiAoISh0YWcgaW5zdGFuY2VvZiBBU04xVGFnKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0YWcgdmFsdWUuXCIpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3RyZWFtID0gc3RyZWFtO1xuICAgICAgICB0aGlzLmhlYWRlciA9IGhlYWRlcjtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMudGFnID0gdGFnO1xuICAgICAgICB0aGlzLnN1YiA9IHN1YjtcbiAgICB9XG4gICAgQVNOMS5wcm90b3R5cGUudHlwZU5hbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy50YWcudGFnQ2xhc3MpIHtcbiAgICAgICAgICAgIGNhc2UgMDogLy8gdW5pdmVyc2FsXG4gICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLnRhZy50YWdOdW1iZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDAwOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiRU9DXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgwMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIkJPT0xFQU5cIjtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDAyOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiSU5URUdFUlwiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MDM6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJCSVRfU1RSSU5HXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgwNDpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIk9DVEVUX1NUUklOR1wiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MDU6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJOVUxMXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgwNjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIk9CSkVDVF9JREVOVElGSUVSXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgwNzpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIk9iamVjdERlc2NyaXB0b3JcIjtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDA4OlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiRVhURVJOQUxcIjtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDA5OlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiUkVBTFwiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MEE6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJFTlVNRVJBVEVEXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgwQjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIkVNQkVEREVEX1BEVlwiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MEM6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJVVEY4U3RyaW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxMDpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlNFUVVFTkNFXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlNFVFwiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MTI6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJOdW1lcmljU3RyaW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxMzpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlByaW50YWJsZVN0cmluZ1wiOyAvLyBBU0NJSSBzdWJzZXRcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDE0OlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiVGVsZXRleFN0cmluZ1wiOyAvLyBha2EgVDYxU3RyaW5nXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxNTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlZpZGVvdGV4U3RyaW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxNjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIklBNVN0cmluZ1wiOyAvLyBBU0NJSVxuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MTc6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJVVENUaW1lXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxODpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIkdlbmVyYWxpemVkVGltZVwiO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDB4MTk6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJHcmFwaGljU3RyaW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxQTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlZpc2libGVTdHJpbmdcIjsgLy8gQVNDSUkgc3Vic2V0XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxQjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIkdlbmVyYWxTdHJpbmdcIjtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAweDFDOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiVW5pdmVyc2FsU3RyaW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMHgxRTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIkJNUFN0cmluZ1wiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gXCJVbml2ZXJzYWxfXCIgKyB0aGlzLnRhZy50YWdOdW1iZXIudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJBcHBsaWNhdGlvbl9cIiArIHRoaXMudGFnLnRhZ051bWJlci50b1N0cmluZygpO1xuICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgIHJldHVybiBcIltcIiArIHRoaXMudGFnLnRhZ051bWJlci50b1N0cmluZygpICsgXCJdXCI7IC8vIENvbnRleHRcbiAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJQcml2YXRlX1wiICsgdGhpcy50YWcudGFnTnVtYmVyLnRvU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEFTTjEucHJvdG90eXBlLmNvbnRlbnQgPSBmdW5jdGlvbiAobWF4TGVuZ3RoKSB7XG4gICAgICAgIGlmICh0aGlzLnRhZyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAobWF4TGVuZ3RoID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIG1heExlbmd0aCA9IEluZmluaXR5O1xuICAgICAgICB9XG4gICAgICAgIHZhciBjb250ZW50ID0gdGhpcy5wb3NDb250ZW50KCk7XG4gICAgICAgIHZhciBsZW4gPSBNYXRoLmFicyh0aGlzLmxlbmd0aCk7XG4gICAgICAgIGlmICghdGhpcy50YWcuaXNVbml2ZXJzYWwoKSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuc3ViICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiKFwiICsgdGhpcy5zdWIubGVuZ3RoICsgXCIgZWxlbSlcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnN0cmVhbS5wYXJzZU9jdGV0U3RyaW5nKGNvbnRlbnQsIGNvbnRlbnQgKyBsZW4sIG1heExlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgICAgc3dpdGNoICh0aGlzLnRhZy50YWdOdW1iZXIpIHtcbiAgICAgICAgICAgIGNhc2UgMHgwMTogLy8gQk9PTEVBTlxuICAgICAgICAgICAgICAgIHJldHVybiAodGhpcy5zdHJlYW0uZ2V0KGNvbnRlbnQpID09PSAwKSA/IFwiZmFsc2VcIiA6IFwidHJ1ZVwiO1xuICAgICAgICAgICAgY2FzZSAweDAyOiAvLyBJTlRFR0VSXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3RyZWFtLnBhcnNlSW50ZWdlcihjb250ZW50LCBjb250ZW50ICsgbGVuKTtcbiAgICAgICAgICAgIGNhc2UgMHgwMzogLy8gQklUX1NUUklOR1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnN1YiA/IFwiKFwiICsgdGhpcy5zdWIubGVuZ3RoICsgXCIgZWxlbSlcIiA6XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RyZWFtLnBhcnNlQml0U3RyaW5nKGNvbnRlbnQsIGNvbnRlbnQgKyBsZW4sIG1heExlbmd0aCk7XG4gICAgICAgICAgICBjYXNlIDB4MDQ6IC8vIE9DVEVUX1NUUklOR1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnN1YiA/IFwiKFwiICsgdGhpcy5zdWIubGVuZ3RoICsgXCIgZWxlbSlcIiA6XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RyZWFtLnBhcnNlT2N0ZXRTdHJpbmcoY29udGVudCwgY29udGVudCArIGxlbiwgbWF4TGVuZ3RoKTtcbiAgICAgICAgICAgIC8vIGNhc2UgMHgwNTogLy8gTlVMTFxuICAgICAgICAgICAgY2FzZSAweDA2OiAvLyBPQkpFQ1RfSURFTlRJRklFUlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnN0cmVhbS5wYXJzZU9JRChjb250ZW50LCBjb250ZW50ICsgbGVuLCBtYXhMZW5ndGgpO1xuICAgICAgICAgICAgLy8gY2FzZSAweDA3OiAvLyBPYmplY3REZXNjcmlwdG9yXG4gICAgICAgICAgICAvLyBjYXNlIDB4MDg6IC8vIEVYVEVSTkFMXG4gICAgICAgICAgICAvLyBjYXNlIDB4MDk6IC8vIFJFQUxcbiAgICAgICAgICAgIC8vIGNhc2UgMHgwQTogLy8gRU5VTUVSQVRFRFxuICAgICAgICAgICAgLy8gY2FzZSAweDBCOiAvLyBFTUJFRERFRF9QRFZcbiAgICAgICAgICAgIGNhc2UgMHgxMDogLy8gU0VRVUVOQ0VcbiAgICAgICAgICAgIGNhc2UgMHgxMTogLy8gU0VUXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuc3ViICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIihcIiArIHRoaXMuc3ViLmxlbmd0aCArIFwiIGVsZW0pXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCIobm8gZWxlbSlcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIDB4MEM6IC8vIFVURjhTdHJpbmdcbiAgICAgICAgICAgICAgICByZXR1cm4gc3RyaW5nQ3V0KHRoaXMuc3RyZWFtLnBhcnNlU3RyaW5nVVRGKGNvbnRlbnQsIGNvbnRlbnQgKyBsZW4pLCBtYXhMZW5ndGgpO1xuICAgICAgICAgICAgY2FzZSAweDEyOiAvLyBOdW1lcmljU3RyaW5nXG4gICAgICAgICAgICBjYXNlIDB4MTM6IC8vIFByaW50YWJsZVN0cmluZ1xuICAgICAgICAgICAgY2FzZSAweDE0OiAvLyBUZWxldGV4U3RyaW5nXG4gICAgICAgICAgICBjYXNlIDB4MTU6IC8vIFZpZGVvdGV4U3RyaW5nXG4gICAgICAgICAgICBjYXNlIDB4MTY6IC8vIElBNVN0cmluZ1xuICAgICAgICAgICAgLy8gY2FzZSAweDE5OiAvLyBHcmFwaGljU3RyaW5nXG4gICAgICAgICAgICBjYXNlIDB4MUE6IC8vIFZpc2libGVTdHJpbmdcbiAgICAgICAgICAgICAgICAvLyBjYXNlIDB4MUI6IC8vIEdlbmVyYWxTdHJpbmdcbiAgICAgICAgICAgICAgICAvLyBjYXNlIDB4MUM6IC8vIFVuaXZlcnNhbFN0cmluZ1xuICAgICAgICAgICAgICAgIHJldHVybiBzdHJpbmdDdXQodGhpcy5zdHJlYW0ucGFyc2VTdHJpbmdJU08oY29udGVudCwgY29udGVudCArIGxlbiksIG1heExlbmd0aCk7XG4gICAgICAgICAgICBjYXNlIDB4MUU6IC8vIEJNUFN0cmluZ1xuICAgICAgICAgICAgICAgIHJldHVybiBzdHJpbmdDdXQodGhpcy5zdHJlYW0ucGFyc2VTdHJpbmdCTVAoY29udGVudCwgY29udGVudCArIGxlbiksIG1heExlbmd0aCk7XG4gICAgICAgICAgICBjYXNlIDB4MTc6IC8vIFVUQ1RpbWVcbiAgICAgICAgICAgIGNhc2UgMHgxODogLy8gR2VuZXJhbGl6ZWRUaW1lXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3RyZWFtLnBhcnNlVGltZShjb250ZW50LCBjb250ZW50ICsgbGVuLCAodGhpcy50YWcudGFnTnVtYmVyID09IDB4MTcpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9O1xuICAgIEFTTjEucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50eXBlTmFtZSgpICsgXCJAXCIgKyB0aGlzLnN0cmVhbS5wb3MgKyBcIltoZWFkZXI6XCIgKyB0aGlzLmhlYWRlciArIFwiLGxlbmd0aDpcIiArIHRoaXMubGVuZ3RoICsgXCIsc3ViOlwiICsgKCh0aGlzLnN1YiA9PT0gbnVsbCkgPyBcIm51bGxcIiA6IHRoaXMuc3ViLmxlbmd0aCkgKyBcIl1cIjtcbiAgICB9O1xuICAgIEFTTjEucHJvdG90eXBlLnRvUHJldHR5U3RyaW5nID0gZnVuY3Rpb24gKGluZGVudCkge1xuICAgICAgICBpZiAoaW5kZW50ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGluZGVudCA9IFwiXCI7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHMgPSBpbmRlbnQgKyB0aGlzLnR5cGVOYW1lKCkgKyBcIiBAXCIgKyB0aGlzLnN0cmVhbS5wb3M7XG4gICAgICAgIGlmICh0aGlzLmxlbmd0aCA+PSAwKSB7XG4gICAgICAgICAgICBzICs9IFwiK1wiO1xuICAgICAgICB9XG4gICAgICAgIHMgKz0gdGhpcy5sZW5ndGg7XG4gICAgICAgIGlmICh0aGlzLnRhZy50YWdDb25zdHJ1Y3RlZCkge1xuICAgICAgICAgICAgcyArPSBcIiAoY29uc3RydWN0ZWQpXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoKHRoaXMudGFnLmlzVW5pdmVyc2FsKCkgJiYgKCh0aGlzLnRhZy50YWdOdW1iZXIgPT0gMHgwMykgfHwgKHRoaXMudGFnLnRhZ051bWJlciA9PSAweDA0KSkpICYmICh0aGlzLnN1YiAhPT0gbnVsbCkpIHtcbiAgICAgICAgICAgIHMgKz0gXCIgKGVuY2Fwc3VsYXRlcylcIjtcbiAgICAgICAgfVxuICAgICAgICBzICs9IFwiXFxuXCI7XG4gICAgICAgIGlmICh0aGlzLnN1YiAhPT0gbnVsbCkge1xuICAgICAgICAgICAgaW5kZW50ICs9IFwiICBcIjtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBtYXggPSB0aGlzLnN1Yi5sZW5ndGg7IGkgPCBtYXg7ICsraSkge1xuICAgICAgICAgICAgICAgIHMgKz0gdGhpcy5zdWJbaV0udG9QcmV0dHlTdHJpbmcoaW5kZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcztcbiAgICB9O1xuICAgIEFTTjEucHJvdG90eXBlLnBvc1N0YXJ0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdHJlYW0ucG9zO1xuICAgIH07XG4gICAgQVNOMS5wcm90b3R5cGUucG9zQ29udGVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RyZWFtLnBvcyArIHRoaXMuaGVhZGVyO1xuICAgIH07XG4gICAgQVNOMS5wcm90b3R5cGUucG9zRW5kID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdHJlYW0ucG9zICsgdGhpcy5oZWFkZXIgKyBNYXRoLmFicyh0aGlzLmxlbmd0aCk7XG4gICAgfTtcbiAgICBBU04xLnByb3RvdHlwZS50b0hleFN0cmluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RyZWFtLmhleER1bXAodGhpcy5wb3NTdGFydCgpLCB0aGlzLnBvc0VuZCgpLCB0cnVlKTtcbiAgICB9O1xuICAgIEFTTjEuZGVjb2RlTGVuZ3RoID0gZnVuY3Rpb24gKHN0cmVhbSkge1xuICAgICAgICB2YXIgYnVmID0gc3RyZWFtLmdldCgpO1xuICAgICAgICB2YXIgbGVuID0gYnVmICYgMHg3RjtcbiAgICAgICAgaWYgKGxlbiA9PSBidWYpIHtcbiAgICAgICAgICAgIHJldHVybiBsZW47XG4gICAgICAgIH1cbiAgICAgICAgLy8gbm8gcmVhc29uIHRvIHVzZSBJbnQxMCwgYXMgaXQgd291bGQgYmUgYSBodWdlIGJ1ZmZlciBhbnl3YXlzXG4gICAgICAgIGlmIChsZW4gPiA2KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJMZW5ndGggb3ZlciA0OCBiaXRzIG5vdCBzdXBwb3J0ZWQgYXQgcG9zaXRpb24gXCIgKyAoc3RyZWFtLnBvcyAtIDEpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGVuID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfSAvLyB1bmRlZmluZWRcbiAgICAgICAgYnVmID0gMDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47ICsraSkge1xuICAgICAgICAgICAgYnVmID0gKGJ1ZiAqIDI1NikgKyBzdHJlYW0uZ2V0KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGJ1ZjtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFJldHJpZXZlIHRoZSBoZXhhZGVjaW1hbCB2YWx1ZSAoYXMgYSBzdHJpbmcpIG9mIHRoZSBjdXJyZW50IEFTTi4xIGVsZW1lbnRcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgICAqIEBwdWJsaWNcbiAgICAgKi9cbiAgICBBU04xLnByb3RvdHlwZS5nZXRIZXhTdHJpbmdWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGhleFN0cmluZyA9IHRoaXMudG9IZXhTdHJpbmcoKTtcbiAgICAgICAgdmFyIG9mZnNldCA9IHRoaXMuaGVhZGVyICogMjtcbiAgICAgICAgdmFyIGxlbmd0aCA9IHRoaXMubGVuZ3RoICogMjtcbiAgICAgICAgcmV0dXJuIGhleFN0cmluZy5zdWJzdHIob2Zmc2V0LCBsZW5ndGgpO1xuICAgIH07XG4gICAgQVNOMS5kZWNvZGUgPSBmdW5jdGlvbiAoc3RyKSB7XG4gICAgICAgIHZhciBzdHJlYW07XG4gICAgICAgIGlmICghKHN0ciBpbnN0YW5jZW9mIFN0cmVhbSkpIHtcbiAgICAgICAgICAgIHN0cmVhbSA9IG5ldyBTdHJlYW0oc3RyLCAwKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHN0cmVhbSA9IHN0cjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgc3RyZWFtU3RhcnQgPSBuZXcgU3RyZWFtKHN0cmVhbSk7XG4gICAgICAgIHZhciB0YWcgPSBuZXcgQVNOMVRhZyhzdHJlYW0pO1xuICAgICAgICB2YXIgbGVuID0gQVNOMS5kZWNvZGVMZW5ndGgoc3RyZWFtKTtcbiAgICAgICAgdmFyIHN0YXJ0ID0gc3RyZWFtLnBvcztcbiAgICAgICAgdmFyIGhlYWRlciA9IHN0YXJ0IC0gc3RyZWFtU3RhcnQucG9zO1xuICAgICAgICB2YXIgc3ViID0gbnVsbDtcbiAgICAgICAgdmFyIGdldFN1YiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciByZXQgPSBbXTtcbiAgICAgICAgICAgIGlmIChsZW4gIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAvLyBkZWZpbml0ZSBsZW5ndGhcbiAgICAgICAgICAgICAgICB2YXIgZW5kID0gc3RhcnQgKyBsZW47XG4gICAgICAgICAgICAgICAgd2hpbGUgKHN0cmVhbS5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0W3JldC5sZW5ndGhdID0gQVNOMS5kZWNvZGUoc3RyZWFtKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHN0cmVhbS5wb3MgIT0gZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvbnRlbnQgc2l6ZSBpcyBub3QgY29ycmVjdCBmb3IgY29udGFpbmVyIHN0YXJ0aW5nIGF0IG9mZnNldCBcIiArIHN0YXJ0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyB1bmRlZmluZWQgbGVuZ3RoXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICg7Oykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHMgPSBBU04xLmRlY29kZShzdHJlYW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHMudGFnLmlzRU9DKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldFtyZXQubGVuZ3RoXSA9IHM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbGVuID0gc3RhcnQgLSBzdHJlYW0ucG9zOyAvLyB1bmRlZmluZWQgbGVuZ3RocyBhcmUgcmVwcmVzZW50ZWQgYXMgbmVnYXRpdmUgdmFsdWVzXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkV4Y2VwdGlvbiB3aGlsZSBkZWNvZGluZyB1bmRlZmluZWQgbGVuZ3RoIGNvbnRlbnQ6IFwiICsgZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKHRhZy50YWdDb25zdHJ1Y3RlZCkge1xuICAgICAgICAgICAgLy8gbXVzdCBoYXZlIHZhbGlkIGNvbnRlbnRcbiAgICAgICAgICAgIHN1YiA9IGdldFN1YigpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRhZy5pc1VuaXZlcnNhbCgpICYmICgodGFnLnRhZ051bWJlciA9PSAweDAzKSB8fCAodGFnLnRhZ051bWJlciA9PSAweDA0KSkpIHtcbiAgICAgICAgICAgIC8vIHNvbWV0aW1lcyBCaXRTdHJpbmcgYW5kIE9jdGV0U3RyaW5nIGFyZSB1c2VkIHRvIGVuY2Fwc3VsYXRlIEFTTi4xXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmICh0YWcudGFnTnVtYmVyID09IDB4MDMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0cmVhbS5nZXQoKSAhPSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJCSVQgU1RSSU5HcyB3aXRoIHVudXNlZCBiaXRzIGNhbm5vdCBlbmNhcHN1bGF0ZS5cIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3ViID0gZ2V0U3ViKCk7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdWIubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN1YltpXS50YWcuaXNFT0MoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRU9DIGlzIG5vdCBzdXBwb3NlZCB0byBiZSBhY3R1YWwgY29udGVudC5cIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIC8vIGJ1dCBzaWxlbnRseSBpZ25vcmUgd2hlbiB0aGV5IGRvbid0XG4gICAgICAgICAgICAgICAgc3ViID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoc3ViID09PSBudWxsKSB7XG4gICAgICAgICAgICBpZiAobGVuID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiV2UgY2FuJ3Qgc2tpcCBvdmVyIGFuIGludmFsaWQgdGFnIHdpdGggdW5kZWZpbmVkIGxlbmd0aCBhdCBvZmZzZXQgXCIgKyBzdGFydCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdHJlYW0ucG9zID0gc3RhcnQgKyBNYXRoLmFicyhsZW4pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgQVNOMShzdHJlYW1TdGFydCwgaGVhZGVyLCBsZW4sIHRhZywgc3ViKTtcbiAgICB9O1xuICAgIHJldHVybiBBU04xO1xufSgpKTtcbnZhciBBU04xVGFnID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEFTTjFUYWcoc3RyZWFtKSB7XG4gICAgICAgIHZhciBidWYgPSBzdHJlYW0uZ2V0KCk7XG4gICAgICAgIHRoaXMudGFnQ2xhc3MgPSBidWYgPj4gNjtcbiAgICAgICAgdGhpcy50YWdDb25zdHJ1Y3RlZCA9ICgoYnVmICYgMHgyMCkgIT09IDApO1xuICAgICAgICB0aGlzLnRhZ051bWJlciA9IGJ1ZiAmIDB4MUY7XG4gICAgICAgIGlmICh0aGlzLnRhZ051bWJlciA9PSAweDFGKSB7IC8vIGxvbmcgdGFnXG4gICAgICAgICAgICB2YXIgbiA9IG5ldyBJbnQxMCgpO1xuICAgICAgICAgICAgZG8ge1xuICAgICAgICAgICAgICAgIGJ1ZiA9IHN0cmVhbS5nZXQoKTtcbiAgICAgICAgICAgICAgICBuLm11bEFkZCgxMjgsIGJ1ZiAmIDB4N0YpO1xuICAgICAgICAgICAgfSB3aGlsZSAoYnVmICYgMHg4MCk7XG4gICAgICAgICAgICB0aGlzLnRhZ051bWJlciA9IG4uc2ltcGxpZnkoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBBU04xVGFnLnByb3RvdHlwZS5pc1VuaXZlcnNhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFnQ2xhc3MgPT09IDB4MDA7XG4gICAgfTtcbiAgICBBU04xVGFnLnByb3RvdHlwZS5pc0VPQyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFnQ2xhc3MgPT09IDB4MDAgJiYgdGhpcy50YWdOdW1iZXIgPT09IDB4MDA7XG4gICAgfTtcbiAgICByZXR1cm4gQVNOMVRhZztcbn0oKSk7XG5cbi8vIENvcHlyaWdodCAoYykgMjAwNSAgVG9tIFd1XG4vLyBCaXRzIHBlciBkaWdpdFxudmFyIGRiaXRzO1xuLy8gSmF2YVNjcmlwdCBlbmdpbmUgYW5hbHlzaXNcbnZhciBjYW5hcnkgPSAweGRlYWRiZWVmY2FmZTtcbnZhciBqX2xtID0gKChjYW5hcnkgJiAweGZmZmZmZikgPT0gMHhlZmNhZmUpO1xuLy8jcmVnaW9uXG52YXIgbG93cHJpbWVzID0gWzIsIDMsIDUsIDcsIDExLCAxMywgMTcsIDE5LCAyMywgMjksIDMxLCAzNywgNDEsIDQzLCA0NywgNTMsIDU5LCA2MSwgNjcsIDcxLCA3MywgNzksIDgzLCA4OSwgOTcsIDEwMSwgMTAzLCAxMDcsIDEwOSwgMTEzLCAxMjcsIDEzMSwgMTM3LCAxMzksIDE0OSwgMTUxLCAxNTcsIDE2MywgMTY3LCAxNzMsIDE3OSwgMTgxLCAxOTEsIDE5MywgMTk3LCAxOTksIDIxMSwgMjIzLCAyMjcsIDIyOSwgMjMzLCAyMzksIDI0MSwgMjUxLCAyNTcsIDI2MywgMjY5LCAyNzEsIDI3NywgMjgxLCAyODMsIDI5MywgMzA3LCAzMTEsIDMxMywgMzE3LCAzMzEsIDMzNywgMzQ3LCAzNDksIDM1MywgMzU5LCAzNjcsIDM3MywgMzc5LCAzODMsIDM4OSwgMzk3LCA0MDEsIDQwOSwgNDE5LCA0MjEsIDQzMSwgNDMzLCA0MzksIDQ0MywgNDQ5LCA0NTcsIDQ2MSwgNDYzLCA0NjcsIDQ3OSwgNDg3LCA0OTEsIDQ5OSwgNTAzLCA1MDksIDUyMSwgNTIzLCA1NDEsIDU0NywgNTU3LCA1NjMsIDU2OSwgNTcxLCA1NzcsIDU4NywgNTkzLCA1OTksIDYwMSwgNjA3LCA2MTMsIDYxNywgNjE5LCA2MzEsIDY0MSwgNjQzLCA2NDcsIDY1MywgNjU5LCA2NjEsIDY3MywgNjc3LCA2ODMsIDY5MSwgNzAxLCA3MDksIDcxOSwgNzI3LCA3MzMsIDczOSwgNzQzLCA3NTEsIDc1NywgNzYxLCA3NjksIDc3MywgNzg3LCA3OTcsIDgwOSwgODExLCA4MjEsIDgyMywgODI3LCA4MjksIDgzOSwgODUzLCA4NTcsIDg1OSwgODYzLCA4NzcsIDg4MSwgODgzLCA4ODcsIDkwNywgOTExLCA5MTksIDkyOSwgOTM3LCA5NDEsIDk0NywgOTUzLCA5NjcsIDk3MSwgOTc3LCA5ODMsIDk5MSwgOTk3XTtcbnZhciBscGxpbSA9ICgxIDw8IDI2KSAvIGxvd3ByaW1lc1tsb3dwcmltZXMubGVuZ3RoIC0gMV07XG4vLyNlbmRyZWdpb25cbi8vIChwdWJsaWMpIENvbnN0cnVjdG9yXG52YXIgQmlnSW50ZWdlciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBCaWdJbnRlZ2VyKGEsIGIsIGMpIHtcbiAgICAgICAgaWYgKGEgIT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKFwibnVtYmVyXCIgPT0gdHlwZW9mIGEpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmZyb21OdW1iZXIoYSwgYiwgYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChiID09IG51bGwgJiYgXCJzdHJpbmdcIiAhPSB0eXBlb2YgYSkge1xuICAgICAgICAgICAgICAgIHRoaXMuZnJvbVN0cmluZyhhLCAyNTYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcm9tU3RyaW5nKGEsIGIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8vI3JlZ2lvbiBQVUJMSUNcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS50b1N0cmluZyA9IGJuVG9TdHJpbmc7XG4gICAgLy8gKHB1YmxpYykgcmV0dXJuIHN0cmluZyByZXByZXNlbnRhdGlvbiBpbiBnaXZlbiByYWRpeFxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gKGIpIHtcbiAgICAgICAgaWYgKHRoaXMucyA8IDApIHtcbiAgICAgICAgICAgIHJldHVybiBcIi1cIiArIHRoaXMubmVnYXRlKCkudG9TdHJpbmcoYik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGs7XG4gICAgICAgIGlmIChiID09IDE2KSB7XG4gICAgICAgICAgICBrID0gNDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChiID09IDgpIHtcbiAgICAgICAgICAgIGsgPSAzO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGIgPT0gMikge1xuICAgICAgICAgICAgayA9IDE7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYiA9PSAzMikge1xuICAgICAgICAgICAgayA9IDU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYiA9PSA0KSB7XG4gICAgICAgICAgICBrID0gMjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvUmFkaXgoYik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGttID0gKDEgPDwgaykgLSAxO1xuICAgICAgICB2YXIgZDtcbiAgICAgICAgdmFyIG0gPSBmYWxzZTtcbiAgICAgICAgdmFyIHIgPSBcIlwiO1xuICAgICAgICB2YXIgaSA9IHRoaXMudDtcbiAgICAgICAgdmFyIHAgPSB0aGlzLkRCIC0gKGkgKiB0aGlzLkRCKSAlIGs7XG4gICAgICAgIGlmIChpLS0gPiAwKSB7XG4gICAgICAgICAgICBpZiAocCA8IHRoaXMuREIgJiYgKGQgPSB0aGlzW2ldID4+IHApID4gMCkge1xuICAgICAgICAgICAgICAgIG0gPSB0cnVlO1xuICAgICAgICAgICAgICAgIHIgPSBpbnQyY2hhcihkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdoaWxlIChpID49IDApIHtcbiAgICAgICAgICAgICAgICBpZiAocCA8IGspIHtcbiAgICAgICAgICAgICAgICAgICAgZCA9ICh0aGlzW2ldICYgKCgxIDw8IHApIC0gMSkpIDw8IChrIC0gcCk7XG4gICAgICAgICAgICAgICAgICAgIGQgfD0gdGhpc1stLWldID4+IChwICs9IHRoaXMuREIgLSBrKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGQgPSAodGhpc1tpXSA+PiAocCAtPSBrKSkgJiBrbTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHAgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcCArPSB0aGlzLkRCO1xuICAgICAgICAgICAgICAgICAgICAgICAgLS1pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChkID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBtID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG0pIHtcbiAgICAgICAgICAgICAgICAgICAgciArPSBpbnQyY2hhcihkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG0gPyByIDogXCIwXCI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5uZWdhdGUgPSBibk5lZ2F0ZTtcbiAgICAvLyAocHVibGljKSAtdGhpc1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm5lZ2F0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgQmlnSW50ZWdlci5aRVJPLnN1YlRvKHRoaXMsIHIpO1xuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmFicyA9IGJuQWJzO1xuICAgIC8vIChwdWJsaWMpIHx0aGlzfFxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmFicyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuICh0aGlzLnMgPCAwKSA/IHRoaXMubmVnYXRlKCkgOiB0aGlzO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuY29tcGFyZVRvID0gYm5Db21wYXJlVG87XG4gICAgLy8gKHB1YmxpYykgcmV0dXJuICsgaWYgdGhpcyA+IGEsIC0gaWYgdGhpcyA8IGEsIDAgaWYgZXF1YWxcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5jb21wYXJlVG8gPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgciA9IHRoaXMucyAtIGEucztcbiAgICAgICAgaWYgKHIgIT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHI7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGkgPSB0aGlzLnQ7XG4gICAgICAgIHIgPSBpIC0gYS50O1xuICAgICAgICBpZiAociAhPSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gKHRoaXMucyA8IDApID8gLXIgOiByO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlICgtLWkgPj0gMCkge1xuICAgICAgICAgICAgaWYgKChyID0gdGhpc1tpXSAtIGFbaV0pICE9IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gMDtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmJpdExlbmd0aCA9IGJuQml0TGVuZ3RoO1xuICAgIC8vIChwdWJsaWMpIHJldHVybiB0aGUgbnVtYmVyIG9mIGJpdHMgaW4gXCJ0aGlzXCJcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5iaXRMZW5ndGggPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0aGlzLnQgPD0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuREIgKiAodGhpcy50IC0gMSkgKyBuYml0cyh0aGlzW3RoaXMudCAtIDFdIF4gKHRoaXMucyAmIHRoaXMuRE0pKTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm1vZCA9IGJuTW9kO1xuICAgIC8vIChwdWJsaWMpIHRoaXMgbW9kIGFcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tb2QgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgciA9IG5iaSgpO1xuICAgICAgICB0aGlzLmFicygpLmRpdlJlbVRvKGEsIG51bGwsIHIpO1xuICAgICAgICBpZiAodGhpcy5zIDwgMCAmJiByLmNvbXBhcmVUbyhCaWdJbnRlZ2VyLlpFUk8pID4gMCkge1xuICAgICAgICAgICAgYS5zdWJUbyhyLCByKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm1vZFBvd0ludCA9IGJuTW9kUG93SW50O1xuICAgIC8vIChwdWJsaWMpIHRoaXNeZSAlIG0sIDAgPD0gZSA8IDJeMzJcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tb2RQb3dJbnQgPSBmdW5jdGlvbiAoZSwgbSkge1xuICAgICAgICB2YXIgejtcbiAgICAgICAgaWYgKGUgPCAyNTYgfHwgbS5pc0V2ZW4oKSkge1xuICAgICAgICAgICAgeiA9IG5ldyBDbGFzc2ljKG0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgeiA9IG5ldyBNb250Z29tZXJ5KG0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmV4cChlLCB6KTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmNsb25lID0gYm5DbG9uZTtcbiAgICAvLyAocHVibGljKVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmNsb25lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgciA9IG5iaSgpO1xuICAgICAgICB0aGlzLmNvcHlUbyhyKTtcbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5pbnRWYWx1ZSA9IGJuSW50VmFsdWU7XG4gICAgLy8gKHB1YmxpYykgcmV0dXJuIHZhbHVlIGFzIGludGVnZXJcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5pbnRWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMucyA8IDApIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnQgPT0gMSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzWzBdIC0gdGhpcy5EVjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMudCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMudCA9PSAxKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpc1swXTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0aGlzLnQgPT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgLy8gYXNzdW1lcyAxNiA8IERCIDwgMzJcbiAgICAgICAgcmV0dXJuICgodGhpc1sxXSAmICgoMSA8PCAoMzIgLSB0aGlzLkRCKSkgLSAxKSkgPDwgdGhpcy5EQikgfCB0aGlzWzBdO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuYnl0ZVZhbHVlID0gYm5CeXRlVmFsdWU7XG4gICAgLy8gKHB1YmxpYykgcmV0dXJuIHZhbHVlIGFzIGJ5dGVcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5ieXRlVmFsdWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAodGhpcy50ID09IDApID8gdGhpcy5zIDogKHRoaXNbMF0gPDwgMjQpID4+IDI0O1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuc2hvcnRWYWx1ZSA9IGJuU2hvcnRWYWx1ZTtcbiAgICAvLyAocHVibGljKSByZXR1cm4gdmFsdWUgYXMgc2hvcnQgKGFzc3VtZXMgREI+PTE2KVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnNob3J0VmFsdWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAodGhpcy50ID09IDApID8gdGhpcy5zIDogKHRoaXNbMF0gPDwgMTYpID4+IDE2O1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuc2lnbnVtID0gYm5TaWdOdW07XG4gICAgLy8gKHB1YmxpYykgMCBpZiB0aGlzID09IDAsIDEgaWYgdGhpcyA+IDBcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5zaWdudW0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0aGlzLnMgPCAwKSB7XG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodGhpcy50IDw9IDAgfHwgKHRoaXMudCA9PSAxICYmIHRoaXNbMF0gPD0gMCkpIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLnRvQnl0ZUFycmF5ID0gYm5Ub0J5dGVBcnJheTtcbiAgICAvLyAocHVibGljKSBjb252ZXJ0IHRvIGJpZ2VuZGlhbiBieXRlIGFycmF5XG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUudG9CeXRlQXJyYXkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBpID0gdGhpcy50O1xuICAgICAgICB2YXIgciA9IFtdO1xuICAgICAgICByWzBdID0gdGhpcy5zO1xuICAgICAgICB2YXIgcCA9IHRoaXMuREIgLSAoaSAqIHRoaXMuREIpICUgODtcbiAgICAgICAgdmFyIGQ7XG4gICAgICAgIHZhciBrID0gMDtcbiAgICAgICAgaWYgKGktLSA+IDApIHtcbiAgICAgICAgICAgIGlmIChwIDwgdGhpcy5EQiAmJiAoZCA9IHRoaXNbaV0gPj4gcCkgIT0gKHRoaXMucyAmIHRoaXMuRE0pID4+IHApIHtcbiAgICAgICAgICAgICAgICByW2srK10gPSBkIHwgKHRoaXMucyA8PCAodGhpcy5EQiAtIHApKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdoaWxlIChpID49IDApIHtcbiAgICAgICAgICAgICAgICBpZiAocCA8IDgpIHtcbiAgICAgICAgICAgICAgICAgICAgZCA9ICh0aGlzW2ldICYgKCgxIDw8IHApIC0gMSkpIDw8ICg4IC0gcCk7XG4gICAgICAgICAgICAgICAgICAgIGQgfD0gdGhpc1stLWldID4+IChwICs9IHRoaXMuREIgLSA4KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGQgPSAodGhpc1tpXSA+PiAocCAtPSA4KSkgJiAweGZmO1xuICAgICAgICAgICAgICAgICAgICBpZiAocCA8PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwICs9IHRoaXMuREI7XG4gICAgICAgICAgICAgICAgICAgICAgICAtLWk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKChkICYgMHg4MCkgIT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBkIHw9IC0yNTY7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChrID09IDAgJiYgKHRoaXMucyAmIDB4ODApICE9IChkICYgMHg4MCkpIHtcbiAgICAgICAgICAgICAgICAgICAgKytrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoayA+IDAgfHwgZCAhPSB0aGlzLnMpIHtcbiAgICAgICAgICAgICAgICAgICAgcltrKytdID0gZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5lcXVhbHMgPSBibkVxdWFscztcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5lcXVhbHMgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICByZXR1cm4gKHRoaXMuY29tcGFyZVRvKGEpID09IDApO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUubWluID0gYm5NaW47XG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUubWluID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgcmV0dXJuICh0aGlzLmNvbXBhcmVUbyhhKSA8IDApID8gdGhpcyA6IGE7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tYXggPSBibk1heDtcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tYXggPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICByZXR1cm4gKHRoaXMuY29tcGFyZVRvKGEpID4gMCkgPyB0aGlzIDogYTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmFuZCA9IGJuQW5kO1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmFuZCA9IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHRoaXMuYml0d2lzZVRvKGEsIG9wX2FuZCwgcik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUub3IgPSBibk9yO1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm9yID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5iaXR3aXNlVG8oYSwgb3Bfb3IsIHIpO1xuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLnhvciA9IGJuWG9yO1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnhvciA9IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHRoaXMuYml0d2lzZVRvKGEsIG9wX3hvciwgcik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuYW5kTm90ID0gYm5BbmROb3Q7XG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuYW5kTm90ID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5iaXR3aXNlVG8oYSwgb3BfYW5kbm90LCByKTtcbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5ub3QgPSBibk5vdDtcbiAgICAvLyAocHVibGljKSB+dGhpc1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm5vdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnQ7ICsraSkge1xuICAgICAgICAgICAgcltpXSA9IHRoaXMuRE0gJiB+dGhpc1tpXTtcbiAgICAgICAgfVxuICAgICAgICByLnQgPSB0aGlzLnQ7XG4gICAgICAgIHIucyA9IH50aGlzLnM7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuc2hpZnRMZWZ0ID0gYm5TaGlmdExlZnQ7XG4gICAgLy8gKHB1YmxpYykgdGhpcyA8PCBuXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuc2hpZnRMZWZ0ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgaWYgKG4gPCAwKSB7XG4gICAgICAgICAgICB0aGlzLnJTaGlmdFRvKC1uLCByKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubFNoaWZ0VG8obiwgcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5zaGlmdFJpZ2h0ID0gYm5TaGlmdFJpZ2h0O1xuICAgIC8vIChwdWJsaWMpIHRoaXMgPj4gblxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnNoaWZ0UmlnaHQgPSBmdW5jdGlvbiAobikge1xuICAgICAgICB2YXIgciA9IG5iaSgpO1xuICAgICAgICBpZiAobiA8IDApIHtcbiAgICAgICAgICAgIHRoaXMubFNoaWZ0VG8oLW4sIHIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yU2hpZnRUbyhuLCByKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmdldExvd2VzdFNldEJpdCA9IGJuR2V0TG93ZXN0U2V0Qml0O1xuICAgIC8vIChwdWJsaWMpIHJldHVybnMgaW5kZXggb2YgbG93ZXN0IDEtYml0IChvciAtMSBpZiBub25lKVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmdldExvd2VzdFNldEJpdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnQ7ICsraSkge1xuICAgICAgICAgICAgaWYgKHRoaXNbaV0gIT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBpICogdGhpcy5EQiArIGxiaXQodGhpc1tpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucyA8IDApIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnQgKiB0aGlzLkRCO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAtMTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmJpdENvdW50ID0gYm5CaXRDb3VudDtcbiAgICAvLyAocHVibGljKSByZXR1cm4gbnVtYmVyIG9mIHNldCBiaXRzXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuYml0Q291bnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByID0gMDtcbiAgICAgICAgdmFyIHggPSB0aGlzLnMgJiB0aGlzLkRNO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMudDsgKytpKSB7XG4gICAgICAgICAgICByICs9IGNiaXQodGhpc1tpXSBeIHgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUudGVzdEJpdCA9IGJuVGVzdEJpdDtcbiAgICAvLyAocHVibGljKSB0cnVlIGlmZiBudGggYml0IGlzIHNldFxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnRlc3RCaXQgPSBmdW5jdGlvbiAobikge1xuICAgICAgICB2YXIgaiA9IE1hdGguZmxvb3IobiAvIHRoaXMuREIpO1xuICAgICAgICBpZiAoaiA+PSB0aGlzLnQpIHtcbiAgICAgICAgICAgIHJldHVybiAodGhpcy5zICE9IDApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKHRoaXNbal0gJiAoMSA8PCAobiAlIHRoaXMuREIpKSkgIT0gMCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5zZXRCaXQgPSBiblNldEJpdDtcbiAgICAvLyAocHVibGljKSB0aGlzIHwgKDE8PG4pXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuc2V0Qml0ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlQml0KG4sIG9wX29yKTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmNsZWFyQml0ID0gYm5DbGVhckJpdDtcbiAgICAvLyAocHVibGljKSB0aGlzICYgfigxPDxuKVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmNsZWFyQml0ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlQml0KG4sIG9wX2FuZG5vdCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mbGlwQml0ID0gYm5GbGlwQml0O1xuICAgIC8vIChwdWJsaWMpIHRoaXMgXiAoMTw8bilcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mbGlwQml0ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlQml0KG4sIG9wX3hvcik7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5hZGQgPSBibkFkZDtcbiAgICAvLyAocHVibGljKSB0aGlzICsgYVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHRoaXMuYWRkVG8oYSwgcik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuc3VidHJhY3QgPSBiblN1YnRyYWN0O1xuICAgIC8vIChwdWJsaWMpIHRoaXMgLSBhXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuc3VidHJhY3QgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgciA9IG5iaSgpO1xuICAgICAgICB0aGlzLnN1YlRvKGEsIHIpO1xuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm11bHRpcGx5ID0gYm5NdWx0aXBseTtcbiAgICAvLyAocHVibGljKSB0aGlzICogYVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm11bHRpcGx5ID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5tdWx0aXBseVRvKGEsIHIpO1xuICAgICAgICByZXR1cm4gcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmRpdmlkZSA9IGJuRGl2aWRlO1xuICAgIC8vIChwdWJsaWMpIHRoaXMgLyBhXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuZGl2aWRlID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5kaXZSZW1UbyhhLCByLCBudWxsKTtcbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5yZW1haW5kZXIgPSBiblJlbWFpbmRlcjtcbiAgICAvLyAocHVibGljKSB0aGlzICUgYVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnJlbWFpbmRlciA9IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHRoaXMuZGl2UmVtVG8oYSwgbnVsbCwgcik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuZGl2aWRlQW5kUmVtYWluZGVyID0gYm5EaXZpZGVBbmRSZW1haW5kZXI7XG4gICAgLy8gKHB1YmxpYykgW3RoaXMvYSx0aGlzJWFdXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuZGl2aWRlQW5kUmVtYWluZGVyID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHEgPSBuYmkoKTtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5kaXZSZW1UbyhhLCBxLCByKTtcbiAgICAgICAgcmV0dXJuIFtxLCByXTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm1vZFBvdyA9IGJuTW9kUG93O1xuICAgIC8vIChwdWJsaWMpIHRoaXNeZSAlIG0gKEhBQyAxNC44NSlcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tb2RQb3cgPSBmdW5jdGlvbiAoZSwgbSkge1xuICAgICAgICB2YXIgaSA9IGUuYml0TGVuZ3RoKCk7XG4gICAgICAgIHZhciBrO1xuICAgICAgICB2YXIgciA9IG5idigxKTtcbiAgICAgICAgdmFyIHo7XG4gICAgICAgIGlmIChpIDw9IDApIHtcbiAgICAgICAgICAgIHJldHVybiByO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGkgPCAxOCkge1xuICAgICAgICAgICAgayA9IDE7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaSA8IDQ4KSB7XG4gICAgICAgICAgICBrID0gMztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpIDwgMTQ0KSB7XG4gICAgICAgICAgICBrID0gNDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpIDwgNzY4KSB7XG4gICAgICAgICAgICBrID0gNTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGsgPSA2O1xuICAgICAgICB9XG4gICAgICAgIGlmIChpIDwgOCkge1xuICAgICAgICAgICAgeiA9IG5ldyBDbGFzc2ljKG0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG0uaXNFdmVuKCkpIHtcbiAgICAgICAgICAgIHogPSBuZXcgQmFycmV0dChtKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHogPSBuZXcgTW9udGdvbWVyeShtKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBwcmVjb21wdXRhdGlvblxuICAgICAgICB2YXIgZyA9IFtdO1xuICAgICAgICB2YXIgbiA9IDM7XG4gICAgICAgIHZhciBrMSA9IGsgLSAxO1xuICAgICAgICB2YXIga20gPSAoMSA8PCBrKSAtIDE7XG4gICAgICAgIGdbMV0gPSB6LmNvbnZlcnQodGhpcyk7XG4gICAgICAgIGlmIChrID4gMSkge1xuICAgICAgICAgICAgdmFyIGcyID0gbmJpKCk7XG4gICAgICAgICAgICB6LnNxclRvKGdbMV0sIGcyKTtcbiAgICAgICAgICAgIHdoaWxlIChuIDw9IGttKSB7XG4gICAgICAgICAgICAgICAgZ1tuXSA9IG5iaSgpO1xuICAgICAgICAgICAgICAgIHoubXVsVG8oZzIsIGdbbiAtIDJdLCBnW25dKTtcbiAgICAgICAgICAgICAgICBuICs9IDI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGogPSBlLnQgLSAxO1xuICAgICAgICB2YXIgdztcbiAgICAgICAgdmFyIGlzMSA9IHRydWU7XG4gICAgICAgIHZhciByMiA9IG5iaSgpO1xuICAgICAgICB2YXIgdDtcbiAgICAgICAgaSA9IG5iaXRzKGVbal0pIC0gMTtcbiAgICAgICAgd2hpbGUgKGogPj0gMCkge1xuICAgICAgICAgICAgaWYgKGkgPj0gazEpIHtcbiAgICAgICAgICAgICAgICB3ID0gKGVbal0gPj4gKGkgLSBrMSkpICYga207XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB3ID0gKGVbal0gJiAoKDEgPDwgKGkgKyAxKSkgLSAxKSkgPDwgKGsxIC0gaSk7XG4gICAgICAgICAgICAgICAgaWYgKGogPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHcgfD0gZVtqIC0gMV0gPj4gKHRoaXMuREIgKyBpIC0gazEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG4gPSBrO1xuICAgICAgICAgICAgd2hpbGUgKCh3ICYgMSkgPT0gMCkge1xuICAgICAgICAgICAgICAgIHcgPj49IDE7XG4gICAgICAgICAgICAgICAgLS1uO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKChpIC09IG4pIDwgMCkge1xuICAgICAgICAgICAgICAgIGkgKz0gdGhpcy5EQjtcbiAgICAgICAgICAgICAgICAtLWo7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXMxKSB7IC8vIHJldCA9PSAxLCBkb24ndCBib3RoZXIgc3F1YXJpbmcgb3IgbXVsdGlwbHlpbmcgaXRcbiAgICAgICAgICAgICAgICBnW3ddLmNvcHlUbyhyKTtcbiAgICAgICAgICAgICAgICBpczEgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHdoaWxlIChuID4gMSkge1xuICAgICAgICAgICAgICAgICAgICB6LnNxclRvKHIsIHIyKTtcbiAgICAgICAgICAgICAgICAgICAgei5zcXJUbyhyMiwgcik7XG4gICAgICAgICAgICAgICAgICAgIG4gLT0gMjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG4gPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHouc3FyVG8ociwgcjIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdCA9IHI7XG4gICAgICAgICAgICAgICAgICAgIHIgPSByMjtcbiAgICAgICAgICAgICAgICAgICAgcjIgPSB0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB6Lm11bFRvKHIyLCBnW3ddLCByKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdoaWxlIChqID49IDAgJiYgKGVbal0gJiAoMSA8PCBpKSkgPT0gMCkge1xuICAgICAgICAgICAgICAgIHouc3FyVG8ociwgcjIpO1xuICAgICAgICAgICAgICAgIHQgPSByO1xuICAgICAgICAgICAgICAgIHIgPSByMjtcbiAgICAgICAgICAgICAgICByMiA9IHQ7XG4gICAgICAgICAgICAgICAgaWYgKC0taSA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaSA9IHRoaXMuREIgLSAxO1xuICAgICAgICAgICAgICAgICAgICAtLWo7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB6LnJldmVydChyKTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm1vZEludmVyc2UgPSBibk1vZEludmVyc2U7XG4gICAgLy8gKHB1YmxpYykgMS90aGlzICUgbSAoSEFDIDE0LjYxKVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm1vZEludmVyc2UgPSBmdW5jdGlvbiAobSkge1xuICAgICAgICB2YXIgYWMgPSBtLmlzRXZlbigpO1xuICAgICAgICBpZiAoKHRoaXMuaXNFdmVuKCkgJiYgYWMpIHx8IG0uc2lnbnVtKCkgPT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIEJpZ0ludGVnZXIuWkVSTztcbiAgICAgICAgfVxuICAgICAgICB2YXIgdSA9IG0uY2xvbmUoKTtcbiAgICAgICAgdmFyIHYgPSB0aGlzLmNsb25lKCk7XG4gICAgICAgIHZhciBhID0gbmJ2KDEpO1xuICAgICAgICB2YXIgYiA9IG5idigwKTtcbiAgICAgICAgdmFyIGMgPSBuYnYoMCk7XG4gICAgICAgIHZhciBkID0gbmJ2KDEpO1xuICAgICAgICB3aGlsZSAodS5zaWdudW0oKSAhPSAwKSB7XG4gICAgICAgICAgICB3aGlsZSAodS5pc0V2ZW4oKSkge1xuICAgICAgICAgICAgICAgIHUuclNoaWZ0VG8oMSwgdSk7XG4gICAgICAgICAgICAgICAgaWYgKGFjKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghYS5pc0V2ZW4oKSB8fCAhYi5pc0V2ZW4oKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYS5hZGRUbyh0aGlzLCBhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGIuc3ViVG8obSwgYik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYS5yU2hpZnRUbygxLCBhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoIWIuaXNFdmVuKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgYi5zdWJUbyhtLCBiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYi5yU2hpZnRUbygxLCBiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdoaWxlICh2LmlzRXZlbigpKSB7XG4gICAgICAgICAgICAgICAgdi5yU2hpZnRUbygxLCB2KTtcbiAgICAgICAgICAgICAgICBpZiAoYWMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFjLmlzRXZlbigpIHx8ICFkLmlzRXZlbigpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjLmFkZFRvKHRoaXMsIGMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZC5zdWJUbyhtLCBkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjLnJTaGlmdFRvKDEsIGMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmICghZC5pc0V2ZW4oKSkge1xuICAgICAgICAgICAgICAgICAgICBkLnN1YlRvKG0sIGQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkLnJTaGlmdFRvKDEsIGQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHUuY29tcGFyZVRvKHYpID49IDApIHtcbiAgICAgICAgICAgICAgICB1LnN1YlRvKHYsIHUpO1xuICAgICAgICAgICAgICAgIGlmIChhYykge1xuICAgICAgICAgICAgICAgICAgICBhLnN1YlRvKGMsIGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBiLnN1YlRvKGQsIGIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdi5zdWJUbyh1LCB2KTtcbiAgICAgICAgICAgICAgICBpZiAoYWMpIHtcbiAgICAgICAgICAgICAgICAgICAgYy5zdWJUbyhhLCBjKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZC5zdWJUbyhiLCBkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodi5jb21wYXJlVG8oQmlnSW50ZWdlci5PTkUpICE9IDApIHtcbiAgICAgICAgICAgIHJldHVybiBCaWdJbnRlZ2VyLlpFUk87XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGQuY29tcGFyZVRvKG0pID49IDApIHtcbiAgICAgICAgICAgIHJldHVybiBkLnN1YnRyYWN0KG0pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChkLnNpZ251bSgpIDwgMCkge1xuICAgICAgICAgICAgZC5hZGRUbyhtLCBkKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChkLnNpZ251bSgpIDwgMCkge1xuICAgICAgICAgICAgcmV0dXJuIGQuYWRkKG0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIGQ7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLnBvdyA9IGJuUG93O1xuICAgIC8vIChwdWJsaWMpIHRoaXNeZVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnBvdyA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmV4cChlLCBuZXcgTnVsbEV4cCgpKTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmdjZCA9IGJuR0NEO1xuICAgIC8vIChwdWJsaWMpIGdjZCh0aGlzLGEpIChIQUMgMTQuNTQpXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuZ2NkID0gZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgdmFyIHggPSAodGhpcy5zIDwgMCkgPyB0aGlzLm5lZ2F0ZSgpIDogdGhpcy5jbG9uZSgpO1xuICAgICAgICB2YXIgeSA9IChhLnMgPCAwKSA/IGEubmVnYXRlKCkgOiBhLmNsb25lKCk7XG4gICAgICAgIGlmICh4LmNvbXBhcmVUbyh5KSA8IDApIHtcbiAgICAgICAgICAgIHZhciB0ID0geDtcbiAgICAgICAgICAgIHggPSB5O1xuICAgICAgICAgICAgeSA9IHQ7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGkgPSB4LmdldExvd2VzdFNldEJpdCgpO1xuICAgICAgICB2YXIgZyA9IHkuZ2V0TG93ZXN0U2V0Qml0KCk7XG4gICAgICAgIGlmIChnIDwgMCkge1xuICAgICAgICAgICAgcmV0dXJuIHg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGkgPCBnKSB7XG4gICAgICAgICAgICBnID0gaTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZyA+IDApIHtcbiAgICAgICAgICAgIHguclNoaWZ0VG8oZywgeCk7XG4gICAgICAgICAgICB5LnJTaGlmdFRvKGcsIHkpO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlICh4LnNpZ251bSgpID4gMCkge1xuICAgICAgICAgICAgaWYgKChpID0geC5nZXRMb3dlc3RTZXRCaXQoKSkgPiAwKSB7XG4gICAgICAgICAgICAgICAgeC5yU2hpZnRUbyhpLCB4KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICgoaSA9IHkuZ2V0TG93ZXN0U2V0Qml0KCkpID4gMCkge1xuICAgICAgICAgICAgICAgIHkuclNoaWZ0VG8oaSwgeSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoeC5jb21wYXJlVG8oeSkgPj0gMCkge1xuICAgICAgICAgICAgICAgIHguc3ViVG8oeSwgeCk7XG4gICAgICAgICAgICAgICAgeC5yU2hpZnRUbygxLCB4KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHkuc3ViVG8oeCwgeSk7XG4gICAgICAgICAgICAgICAgeS5yU2hpZnRUbygxLCB5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZyA+IDApIHtcbiAgICAgICAgICAgIHkubFNoaWZ0VG8oZywgeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5pc1Byb2JhYmxlUHJpbWUgPSBibklzUHJvYmFibGVQcmltZTtcbiAgICAvLyAocHVibGljKSB0ZXN0IHByaW1hbGl0eSB3aXRoIGNlcnRhaW50eSA+PSAxLS41XnRcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5pc1Byb2JhYmxlUHJpbWUgPSBmdW5jdGlvbiAodCkge1xuICAgICAgICB2YXIgaTtcbiAgICAgICAgdmFyIHggPSB0aGlzLmFicygpO1xuICAgICAgICBpZiAoeC50ID09IDEgJiYgeFswXSA8PSBsb3dwcmltZXNbbG93cHJpbWVzLmxlbmd0aCAtIDFdKSB7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgbG93cHJpbWVzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHhbMF0gPT0gbG93cHJpbWVzW2ldKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoeC5pc0V2ZW4oKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGkgPSAxO1xuICAgICAgICB3aGlsZSAoaSA8IGxvd3ByaW1lcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHZhciBtID0gbG93cHJpbWVzW2ldO1xuICAgICAgICAgICAgdmFyIGogPSBpICsgMTtcbiAgICAgICAgICAgIHdoaWxlIChqIDwgbG93cHJpbWVzLmxlbmd0aCAmJiBtIDwgbHBsaW0pIHtcbiAgICAgICAgICAgICAgICBtICo9IGxvd3ByaW1lc1tqKytdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbSA9IHgubW9kSW50KG0pO1xuICAgICAgICAgICAgd2hpbGUgKGkgPCBqKSB7XG4gICAgICAgICAgICAgICAgaWYgKG0gJSBsb3dwcmltZXNbaSsrXSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHgubWlsbGVyUmFiaW4odCk7XG4gICAgfTtcbiAgICAvLyNlbmRyZWdpb24gUFVCTElDXG4gICAgLy8jcmVnaW9uIFBST1RFQ1RFRFxuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmNvcHlUbyA9IGJucENvcHlUbztcbiAgICAvLyAocHJvdGVjdGVkKSBjb3B5IHRoaXMgdG8gclxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmNvcHlUbyA9IGZ1bmN0aW9uIChyKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSB0aGlzLnQgLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgcltpXSA9IHRoaXNbaV07XG4gICAgICAgIH1cbiAgICAgICAgci50ID0gdGhpcy50O1xuICAgICAgICByLnMgPSB0aGlzLnM7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mcm9tSW50ID0gYm5wRnJvbUludDtcbiAgICAvLyAocHJvdGVjdGVkKSBzZXQgZnJvbSBpbnRlZ2VyIHZhbHVlIHgsIC1EViA8PSB4IDwgRFZcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mcm9tSW50ID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgdGhpcy50ID0gMTtcbiAgICAgICAgdGhpcy5zID0gKHggPCAwKSA/IC0xIDogMDtcbiAgICAgICAgaWYgKHggPiAwKSB7XG4gICAgICAgICAgICB0aGlzWzBdID0geDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh4IDwgLTEpIHtcbiAgICAgICAgICAgIHRoaXNbMF0gPSB4ICsgdGhpcy5EVjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudCA9IDA7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmZyb21TdHJpbmcgPSBibnBGcm9tU3RyaW5nO1xuICAgIC8vIChwcm90ZWN0ZWQpIHNldCBmcm9tIHN0cmluZyBhbmQgcmFkaXhcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mcm9tU3RyaW5nID0gZnVuY3Rpb24gKHMsIGIpIHtcbiAgICAgICAgdmFyIGs7XG4gICAgICAgIGlmIChiID09IDE2KSB7XG4gICAgICAgICAgICBrID0gNDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChiID09IDgpIHtcbiAgICAgICAgICAgIGsgPSAzO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGIgPT0gMjU2KSB7XG4gICAgICAgICAgICBrID0gODtcbiAgICAgICAgICAgIC8qIGJ5dGUgYXJyYXkgKi9cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChiID09IDIpIHtcbiAgICAgICAgICAgIGsgPSAxO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGIgPT0gMzIpIHtcbiAgICAgICAgICAgIGsgPSA1O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGIgPT0gNCkge1xuICAgICAgICAgICAgayA9IDI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmZyb21SYWRpeChzLCBiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnQgPSAwO1xuICAgICAgICB0aGlzLnMgPSAwO1xuICAgICAgICB2YXIgaSA9IHMubGVuZ3RoO1xuICAgICAgICB2YXIgbWkgPSBmYWxzZTtcbiAgICAgICAgdmFyIHNoID0gMDtcbiAgICAgICAgd2hpbGUgKC0taSA+PSAwKSB7XG4gICAgICAgICAgICB2YXIgeCA9IChrID09IDgpID8gKCtzW2ldKSAmIDB4ZmYgOiBpbnRBdChzLCBpKTtcbiAgICAgICAgICAgIGlmICh4IDwgMCkge1xuICAgICAgICAgICAgICAgIGlmIChzLmNoYXJBdChpKSA9PSBcIi1cIikge1xuICAgICAgICAgICAgICAgICAgICBtaSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbWkgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChzaCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpc1t0aGlzLnQrK10gPSB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoc2ggKyBrID4gdGhpcy5EQikge1xuICAgICAgICAgICAgICAgIHRoaXNbdGhpcy50IC0gMV0gfD0gKHggJiAoKDEgPDwgKHRoaXMuREIgLSBzaCkpIC0gMSkpIDw8IHNoO1xuICAgICAgICAgICAgICAgIHRoaXNbdGhpcy50KytdID0gKHggPj4gKHRoaXMuREIgLSBzaCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpc1t0aGlzLnQgLSAxXSB8PSB4IDw8IHNoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2ggKz0gaztcbiAgICAgICAgICAgIGlmIChzaCA+PSB0aGlzLkRCKSB7XG4gICAgICAgICAgICAgICAgc2ggLT0gdGhpcy5EQjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoayA9PSA4ICYmICgoK3NbMF0pICYgMHg4MCkgIT0gMCkge1xuICAgICAgICAgICAgdGhpcy5zID0gLTE7XG4gICAgICAgICAgICBpZiAoc2ggPiAwKSB7XG4gICAgICAgICAgICAgICAgdGhpc1t0aGlzLnQgLSAxXSB8PSAoKDEgPDwgKHRoaXMuREIgLSBzaCkpIC0gMSkgPDwgc2g7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jbGFtcCgpO1xuICAgICAgICBpZiAobWkpIHtcbiAgICAgICAgICAgIEJpZ0ludGVnZXIuWkVSTy5zdWJUbyh0aGlzLCB0aGlzKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuY2xhbXAgPSBibnBDbGFtcDtcbiAgICAvLyAocHJvdGVjdGVkKSBjbGFtcCBvZmYgZXhjZXNzIGhpZ2ggd29yZHNcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5jbGFtcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGMgPSB0aGlzLnMgJiB0aGlzLkRNO1xuICAgICAgICB3aGlsZSAodGhpcy50ID4gMCAmJiB0aGlzW3RoaXMudCAtIDFdID09IGMpIHtcbiAgICAgICAgICAgIC0tdGhpcy50O1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5kbFNoaWZ0VG8gPSBibnBETFNoaWZ0VG87XG4gICAgLy8gKHByb3RlY3RlZCkgciA9IHRoaXMgPDwgbipEQlxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmRsU2hpZnRUbyA9IGZ1bmN0aW9uIChuLCByKSB7XG4gICAgICAgIHZhciBpO1xuICAgICAgICBmb3IgKGkgPSB0aGlzLnQgLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgcltpICsgbl0gPSB0aGlzW2ldO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoaSA9IG4gLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgcltpXSA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgci50ID0gdGhpcy50ICsgbjtcbiAgICAgICAgci5zID0gdGhpcy5zO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuZHJTaGlmdFRvID0gYm5wRFJTaGlmdFRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIHIgPSB0aGlzID4+IG4qREJcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5kclNoaWZ0VG8gPSBmdW5jdGlvbiAobiwgcikge1xuICAgICAgICBmb3IgKHZhciBpID0gbjsgaSA8IHRoaXMudDsgKytpKSB7XG4gICAgICAgICAgICByW2kgLSBuXSA9IHRoaXNbaV07XG4gICAgICAgIH1cbiAgICAgICAgci50ID0gTWF0aC5tYXgodGhpcy50IC0gbiwgMCk7XG4gICAgICAgIHIucyA9IHRoaXMucztcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmxTaGlmdFRvID0gYm5wTFNoaWZ0VG87XG4gICAgLy8gKHByb3RlY3RlZCkgciA9IHRoaXMgPDwgblxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmxTaGlmdFRvID0gZnVuY3Rpb24gKG4sIHIpIHtcbiAgICAgICAgdmFyIGJzID0gbiAlIHRoaXMuREI7XG4gICAgICAgIHZhciBjYnMgPSB0aGlzLkRCIC0gYnM7XG4gICAgICAgIHZhciBibSA9ICgxIDw8IGNicykgLSAxO1xuICAgICAgICB2YXIgZHMgPSBNYXRoLmZsb29yKG4gLyB0aGlzLkRCKTtcbiAgICAgICAgdmFyIGMgPSAodGhpcy5zIDw8IGJzKSAmIHRoaXMuRE07XG4gICAgICAgIGZvciAodmFyIGkgPSB0aGlzLnQgLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgcltpICsgZHMgKyAxXSA9ICh0aGlzW2ldID4+IGNicykgfCBjO1xuICAgICAgICAgICAgYyA9ICh0aGlzW2ldICYgYm0pIDw8IGJzO1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIGkgPSBkcyAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICByW2ldID0gMDtcbiAgICAgICAgfVxuICAgICAgICByW2RzXSA9IGM7XG4gICAgICAgIHIudCA9IHRoaXMudCArIGRzICsgMTtcbiAgICAgICAgci5zID0gdGhpcy5zO1xuICAgICAgICByLmNsYW1wKCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5yU2hpZnRUbyA9IGJucFJTaGlmdFRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIHIgPSB0aGlzID4+IG5cbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5yU2hpZnRUbyA9IGZ1bmN0aW9uIChuLCByKSB7XG4gICAgICAgIHIucyA9IHRoaXMucztcbiAgICAgICAgdmFyIGRzID0gTWF0aC5mbG9vcihuIC8gdGhpcy5EQik7XG4gICAgICAgIGlmIChkcyA+PSB0aGlzLnQpIHtcbiAgICAgICAgICAgIHIudCA9IDA7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGJzID0gbiAlIHRoaXMuREI7XG4gICAgICAgIHZhciBjYnMgPSB0aGlzLkRCIC0gYnM7XG4gICAgICAgIHZhciBibSA9ICgxIDw8IGJzKSAtIDE7XG4gICAgICAgIHJbMF0gPSB0aGlzW2RzXSA+PiBicztcbiAgICAgICAgZm9yICh2YXIgaSA9IGRzICsgMTsgaSA8IHRoaXMudDsgKytpKSB7XG4gICAgICAgICAgICByW2kgLSBkcyAtIDFdIHw9ICh0aGlzW2ldICYgYm0pIDw8IGNicztcbiAgICAgICAgICAgIHJbaSAtIGRzXSA9IHRoaXNbaV0gPj4gYnM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJzID4gMCkge1xuICAgICAgICAgICAgclt0aGlzLnQgLSBkcyAtIDFdIHw9ICh0aGlzLnMgJiBibSkgPDwgY2JzO1xuICAgICAgICB9XG4gICAgICAgIHIudCA9IHRoaXMudCAtIGRzO1xuICAgICAgICByLmNsYW1wKCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5zdWJUbyA9IGJucFN1YlRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIHIgPSB0aGlzIC0gYVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnN1YlRvID0gZnVuY3Rpb24gKGEsIHIpIHtcbiAgICAgICAgdmFyIGkgPSAwO1xuICAgICAgICB2YXIgYyA9IDA7XG4gICAgICAgIHZhciBtID0gTWF0aC5taW4oYS50LCB0aGlzLnQpO1xuICAgICAgICB3aGlsZSAoaSA8IG0pIHtcbiAgICAgICAgICAgIGMgKz0gdGhpc1tpXSAtIGFbaV07XG4gICAgICAgICAgICByW2krK10gPSBjICYgdGhpcy5ETTtcbiAgICAgICAgICAgIGMgPj49IHRoaXMuREI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGEudCA8IHRoaXMudCkge1xuICAgICAgICAgICAgYyAtPSBhLnM7XG4gICAgICAgICAgICB3aGlsZSAoaSA8IHRoaXMudCkge1xuICAgICAgICAgICAgICAgIGMgKz0gdGhpc1tpXTtcbiAgICAgICAgICAgICAgICByW2krK10gPSBjICYgdGhpcy5ETTtcbiAgICAgICAgICAgICAgICBjID4+PSB0aGlzLkRCO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYyArPSB0aGlzLnM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjICs9IHRoaXMucztcbiAgICAgICAgICAgIHdoaWxlIChpIDwgYS50KSB7XG4gICAgICAgICAgICAgICAgYyAtPSBhW2ldO1xuICAgICAgICAgICAgICAgIHJbaSsrXSA9IGMgJiB0aGlzLkRNO1xuICAgICAgICAgICAgICAgIGMgPj49IHRoaXMuREI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjIC09IGEucztcbiAgICAgICAgfVxuICAgICAgICByLnMgPSAoYyA8IDApID8gLTEgOiAwO1xuICAgICAgICBpZiAoYyA8IC0xKSB7XG4gICAgICAgICAgICByW2krK10gPSB0aGlzLkRWICsgYztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChjID4gMCkge1xuICAgICAgICAgICAgcltpKytdID0gYztcbiAgICAgICAgfVxuICAgICAgICByLnQgPSBpO1xuICAgICAgICByLmNsYW1wKCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tdWx0aXBseVRvID0gYm5wTXVsdGlwbHlUbztcbiAgICAvLyAocHJvdGVjdGVkKSByID0gdGhpcyAqIGEsIHIgIT0gdGhpcyxhIChIQUMgMTQuMTIpXG4gICAgLy8gXCJ0aGlzXCIgc2hvdWxkIGJlIHRoZSBsYXJnZXIgb25lIGlmIGFwcHJvcHJpYXRlLlxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm11bHRpcGx5VG8gPSBmdW5jdGlvbiAoYSwgcikge1xuICAgICAgICB2YXIgeCA9IHRoaXMuYWJzKCk7XG4gICAgICAgIHZhciB5ID0gYS5hYnMoKTtcbiAgICAgICAgdmFyIGkgPSB4LnQ7XG4gICAgICAgIHIudCA9IGkgKyB5LnQ7XG4gICAgICAgIHdoaWxlICgtLWkgPj0gMCkge1xuICAgICAgICAgICAgcltpXSA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChpID0gMDsgaSA8IHkudDsgKytpKSB7XG4gICAgICAgICAgICByW2kgKyB4LnRdID0geC5hbSgwLCB5W2ldLCByLCBpLCAwLCB4LnQpO1xuICAgICAgICB9XG4gICAgICAgIHIucyA9IDA7XG4gICAgICAgIHIuY2xhbXAoKTtcbiAgICAgICAgaWYgKHRoaXMucyAhPSBhLnMpIHtcbiAgICAgICAgICAgIEJpZ0ludGVnZXIuWkVSTy5zdWJUbyhyLCByKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuc3F1YXJlVG8gPSBibnBTcXVhcmVUbztcbiAgICAvLyAocHJvdGVjdGVkKSByID0gdGhpc14yLCByICE9IHRoaXMgKEhBQyAxNC4xNilcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5zcXVhcmVUbyA9IGZ1bmN0aW9uIChyKSB7XG4gICAgICAgIHZhciB4ID0gdGhpcy5hYnMoKTtcbiAgICAgICAgdmFyIGkgPSByLnQgPSAyICogeC50O1xuICAgICAgICB3aGlsZSAoLS1pID49IDApIHtcbiAgICAgICAgICAgIHJbaV0gPSAwO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCB4LnQgLSAxOyArK2kpIHtcbiAgICAgICAgICAgIHZhciBjID0geC5hbShpLCB4W2ldLCByLCAyICogaSwgMCwgMSk7XG4gICAgICAgICAgICBpZiAoKHJbaSArIHgudF0gKz0geC5hbShpICsgMSwgMiAqIHhbaV0sIHIsIDIgKiBpICsgMSwgYywgeC50IC0gaSAtIDEpKSA+PSB4LkRWKSB7XG4gICAgICAgICAgICAgICAgcltpICsgeC50XSAtPSB4LkRWO1xuICAgICAgICAgICAgICAgIHJbaSArIHgudCArIDFdID0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoci50ID4gMCkge1xuICAgICAgICAgICAgcltyLnQgLSAxXSArPSB4LmFtKGksIHhbaV0sIHIsIDIgKiBpLCAwLCAxKTtcbiAgICAgICAgfVxuICAgICAgICByLnMgPSAwO1xuICAgICAgICByLmNsYW1wKCk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5kaXZSZW1UbyA9IGJucERpdlJlbVRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIGRpdmlkZSB0aGlzIGJ5IG0sIHF1b3RpZW50IGFuZCByZW1haW5kZXIgdG8gcSwgciAoSEFDIDE0LjIwKVxuICAgIC8vIHIgIT0gcSwgdGhpcyAhPSBtLiAgcSBvciByIG1heSBiZSBudWxsLlxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmRpdlJlbVRvID0gZnVuY3Rpb24gKG0sIHEsIHIpIHtcbiAgICAgICAgdmFyIHBtID0gbS5hYnMoKTtcbiAgICAgICAgaWYgKHBtLnQgPD0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciBwdCA9IHRoaXMuYWJzKCk7XG4gICAgICAgIGlmIChwdC50IDwgcG0udCkge1xuICAgICAgICAgICAgaWYgKHEgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHEuZnJvbUludCgwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvcHlUbyhyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAociA9PSBudWxsKSB7XG4gICAgICAgICAgICByID0gbmJpKCk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHkgPSBuYmkoKTtcbiAgICAgICAgdmFyIHRzID0gdGhpcy5zO1xuICAgICAgICB2YXIgbXMgPSBtLnM7XG4gICAgICAgIHZhciBuc2ggPSB0aGlzLkRCIC0gbmJpdHMocG1bcG0udCAtIDFdKTsgLy8gbm9ybWFsaXplIG1vZHVsdXNcbiAgICAgICAgaWYgKG5zaCA+IDApIHtcbiAgICAgICAgICAgIHBtLmxTaGlmdFRvKG5zaCwgeSk7XG4gICAgICAgICAgICBwdC5sU2hpZnRUbyhuc2gsIHIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcG0uY29weVRvKHkpO1xuICAgICAgICAgICAgcHQuY29weVRvKHIpO1xuICAgICAgICB9XG4gICAgICAgIHZhciB5cyA9IHkudDtcbiAgICAgICAgdmFyIHkwID0geVt5cyAtIDFdO1xuICAgICAgICBpZiAoeTAgPT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciB5dCA9IHkwICogKDEgPDwgdGhpcy5GMSkgKyAoKHlzID4gMSkgPyB5W3lzIC0gMl0gPj4gdGhpcy5GMiA6IDApO1xuICAgICAgICB2YXIgZDEgPSB0aGlzLkZWIC8geXQ7XG4gICAgICAgIHZhciBkMiA9ICgxIDw8IHRoaXMuRjEpIC8geXQ7XG4gICAgICAgIHZhciBlID0gMSA8PCB0aGlzLkYyO1xuICAgICAgICB2YXIgaSA9IHIudDtcbiAgICAgICAgdmFyIGogPSBpIC0geXM7XG4gICAgICAgIHZhciB0ID0gKHEgPT0gbnVsbCkgPyBuYmkoKSA6IHE7XG4gICAgICAgIHkuZGxTaGlmdFRvKGosIHQpO1xuICAgICAgICBpZiAoci5jb21wYXJlVG8odCkgPj0gMCkge1xuICAgICAgICAgICAgcltyLnQrK10gPSAxO1xuICAgICAgICAgICAgci5zdWJUbyh0LCByKTtcbiAgICAgICAgfVxuICAgICAgICBCaWdJbnRlZ2VyLk9ORS5kbFNoaWZ0VG8oeXMsIHQpO1xuICAgICAgICB0LnN1YlRvKHksIHkpOyAvLyBcIm5lZ2F0aXZlXCIgeSBzbyB3ZSBjYW4gcmVwbGFjZSBzdWIgd2l0aCBhbSBsYXRlclxuICAgICAgICB3aGlsZSAoeS50IDwgeXMpIHtcbiAgICAgICAgICAgIHlbeS50KytdID0gMDtcbiAgICAgICAgfVxuICAgICAgICB3aGlsZSAoLS1qID49IDApIHtcbiAgICAgICAgICAgIC8vIEVzdGltYXRlIHF1b3RpZW50IGRpZ2l0XG4gICAgICAgICAgICB2YXIgcWQgPSAoclstLWldID09IHkwKSA/IHRoaXMuRE0gOiBNYXRoLmZsb29yKHJbaV0gKiBkMSArIChyW2kgLSAxXSArIGUpICogZDIpO1xuICAgICAgICAgICAgaWYgKChyW2ldICs9IHkuYW0oMCwgcWQsIHIsIGosIDAsIHlzKSkgPCBxZCkgeyAvLyBUcnkgaXQgb3V0XG4gICAgICAgICAgICAgICAgeS5kbFNoaWZ0VG8oaiwgdCk7XG4gICAgICAgICAgICAgICAgci5zdWJUbyh0LCByKTtcbiAgICAgICAgICAgICAgICB3aGlsZSAocltpXSA8IC0tcWQpIHtcbiAgICAgICAgICAgICAgICAgICAgci5zdWJUbyh0LCByKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHEgIT0gbnVsbCkge1xuICAgICAgICAgICAgci5kclNoaWZ0VG8oeXMsIHEpO1xuICAgICAgICAgICAgaWYgKHRzICE9IG1zKSB7XG4gICAgICAgICAgICAgICAgQmlnSW50ZWdlci5aRVJPLnN1YlRvKHEsIHEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHIudCA9IHlzO1xuICAgICAgICByLmNsYW1wKCk7XG4gICAgICAgIGlmIChuc2ggPiAwKSB7XG4gICAgICAgICAgICByLnJTaGlmdFRvKG5zaCwgcik7XG4gICAgICAgIH0gLy8gRGVub3JtYWxpemUgcmVtYWluZGVyXG4gICAgICAgIGlmICh0cyA8IDApIHtcbiAgICAgICAgICAgIEJpZ0ludGVnZXIuWkVSTy5zdWJUbyhyLCByKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuaW52RGlnaXQgPSBibnBJbnZEaWdpdDtcbiAgICAvLyAocHJvdGVjdGVkKSByZXR1cm4gXCItMS90aGlzICUgMl5EQlwiOyB1c2VmdWwgZm9yIE1vbnQuIHJlZHVjdGlvblxuICAgIC8vIGp1c3RpZmljYXRpb246XG4gICAgLy8gICAgICAgICB4eSA9PSAxIChtb2QgbSlcbiAgICAvLyAgICAgICAgIHh5ID0gIDEra21cbiAgICAvLyAgIHh5KDIteHkpID0gKDEra20pKDEta20pXG4gICAgLy8geFt5KDIteHkpXSA9IDEta14ybV4yXG4gICAgLy8geFt5KDIteHkpXSA9PSAxIChtb2QgbV4yKVxuICAgIC8vIGlmIHkgaXMgMS94IG1vZCBtLCB0aGVuIHkoMi14eSkgaXMgMS94IG1vZCBtXjJcbiAgICAvLyBzaG91bGQgcmVkdWNlIHggYW5kIHkoMi14eSkgYnkgbV4yIGF0IGVhY2ggc3RlcCB0byBrZWVwIHNpemUgYm91bmRlZC5cbiAgICAvLyBKUyBtdWx0aXBseSBcIm92ZXJmbG93c1wiIGRpZmZlcmVudGx5IGZyb20gQy9DKyssIHNvIGNhcmUgaXMgbmVlZGVkIGhlcmUuXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuaW52RGlnaXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0aGlzLnQgPCAxKSB7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgeCA9IHRoaXNbMF07XG4gICAgICAgIGlmICgoeCAmIDEpID09IDApIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgICAgIHZhciB5ID0geCAmIDM7IC8vIHkgPT0gMS94IG1vZCAyXjJcbiAgICAgICAgeSA9ICh5ICogKDIgLSAoeCAmIDB4ZikgKiB5KSkgJiAweGY7IC8vIHkgPT0gMS94IG1vZCAyXjRcbiAgICAgICAgeSA9ICh5ICogKDIgLSAoeCAmIDB4ZmYpICogeSkpICYgMHhmZjsgLy8geSA9PSAxL3ggbW9kIDJeOFxuICAgICAgICB5ID0gKHkgKiAoMiAtICgoKHggJiAweGZmZmYpICogeSkgJiAweGZmZmYpKSkgJiAweGZmZmY7IC8vIHkgPT0gMS94IG1vZCAyXjE2XG4gICAgICAgIC8vIGxhc3Qgc3RlcCAtIGNhbGN1bGF0ZSBpbnZlcnNlIG1vZCBEViBkaXJlY3RseTtcbiAgICAgICAgLy8gYXNzdW1lcyAxNiA8IERCIDw9IDMyIGFuZCBhc3N1bWVzIGFiaWxpdHkgdG8gaGFuZGxlIDQ4LWJpdCBpbnRzXG4gICAgICAgIHkgPSAoeSAqICgyIC0geCAqIHkgJSB0aGlzLkRWKSkgJSB0aGlzLkRWOyAvLyB5ID09IDEveCBtb2QgMl5kYml0c1xuICAgICAgICAvLyB3ZSByZWFsbHkgd2FudCB0aGUgbmVnYXRpdmUgaW52ZXJzZSwgYW5kIC1EViA8IHkgPCBEVlxuICAgICAgICByZXR1cm4gKHkgPiAwKSA/IHRoaXMuRFYgLSB5IDogLXk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5pc0V2ZW4gPSBibnBJc0V2ZW47XG4gICAgLy8gKHByb3RlY3RlZCkgdHJ1ZSBpZmYgdGhpcyBpcyBldmVuXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuaXNFdmVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gKCh0aGlzLnQgPiAwKSA/ICh0aGlzWzBdICYgMSkgOiB0aGlzLnMpID09IDA7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5leHAgPSBibnBFeHA7XG4gICAgLy8gKHByb3RlY3RlZCkgdGhpc15lLCBlIDwgMl4zMiwgZG9pbmcgc3FyIGFuZCBtdWwgd2l0aCBcInJcIiAoSEFDIDE0Ljc5KVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmV4cCA9IGZ1bmN0aW9uIChlLCB6KSB7XG4gICAgICAgIGlmIChlID4gMHhmZmZmZmZmZiB8fCBlIDwgMSkge1xuICAgICAgICAgICAgcmV0dXJuIEJpZ0ludGVnZXIuT05FO1xuICAgICAgICB9XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHZhciByMiA9IG5iaSgpO1xuICAgICAgICB2YXIgZyA9IHouY29udmVydCh0aGlzKTtcbiAgICAgICAgdmFyIGkgPSBuYml0cyhlKSAtIDE7XG4gICAgICAgIGcuY29weVRvKHIpO1xuICAgICAgICB3aGlsZSAoLS1pID49IDApIHtcbiAgICAgICAgICAgIHouc3FyVG8ociwgcjIpO1xuICAgICAgICAgICAgaWYgKChlICYgKDEgPDwgaSkpID4gMCkge1xuICAgICAgICAgICAgICAgIHoubXVsVG8ocjIsIGcsIHIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSByO1xuICAgICAgICAgICAgICAgIHIgPSByMjtcbiAgICAgICAgICAgICAgICByMiA9IHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHoucmV2ZXJ0KHIpO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuY2h1bmtTaXplID0gYm5wQ2h1bmtTaXplO1xuICAgIC8vIChwcm90ZWN0ZWQpIHJldHVybiB4IHMudC4gcl54IDwgRFZcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5jaHVua1NpemUgPSBmdW5jdGlvbiAocikge1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihNYXRoLkxOMiAqIHRoaXMuREIgLyBNYXRoLmxvZyhyKSk7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS50b1JhZGl4ID0gYm5wVG9SYWRpeDtcbiAgICAvLyAocHJvdGVjdGVkKSBjb252ZXJ0IHRvIHJhZGl4IHN0cmluZ1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnRvUmFkaXggPSBmdW5jdGlvbiAoYikge1xuICAgICAgICBpZiAoYiA9PSBudWxsKSB7XG4gICAgICAgICAgICBiID0gMTA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc2lnbnVtKCkgPT0gMCB8fCBiIDwgMiB8fCBiID4gMzYpIHtcbiAgICAgICAgICAgIHJldHVybiBcIjBcIjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY3MgPSB0aGlzLmNodW5rU2l6ZShiKTtcbiAgICAgICAgdmFyIGEgPSBNYXRoLnBvdyhiLCBjcyk7XG4gICAgICAgIHZhciBkID0gbmJ2KGEpO1xuICAgICAgICB2YXIgeSA9IG5iaSgpO1xuICAgICAgICB2YXIgeiA9IG5iaSgpO1xuICAgICAgICB2YXIgciA9IFwiXCI7XG4gICAgICAgIHRoaXMuZGl2UmVtVG8oZCwgeSwgeik7XG4gICAgICAgIHdoaWxlICh5LnNpZ251bSgpID4gMCkge1xuICAgICAgICAgICAgciA9IChhICsgei5pbnRWYWx1ZSgpKS50b1N0cmluZyhiKS5zdWJzdHIoMSkgKyByO1xuICAgICAgICAgICAgeS5kaXZSZW1UbyhkLCB5LCB6KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gei5pbnRWYWx1ZSgpLnRvU3RyaW5nKGIpICsgcjtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmZyb21SYWRpeCA9IGJucEZyb21SYWRpeDtcbiAgICAvLyAocHJvdGVjdGVkKSBjb252ZXJ0IGZyb20gcmFkaXggc3RyaW5nXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuZnJvbVJhZGl4ID0gZnVuY3Rpb24gKHMsIGIpIHtcbiAgICAgICAgdGhpcy5mcm9tSW50KDApO1xuICAgICAgICBpZiAoYiA9PSBudWxsKSB7XG4gICAgICAgICAgICBiID0gMTA7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNzID0gdGhpcy5jaHVua1NpemUoYik7XG4gICAgICAgIHZhciBkID0gTWF0aC5wb3coYiwgY3MpO1xuICAgICAgICB2YXIgbWkgPSBmYWxzZTtcbiAgICAgICAgdmFyIGogPSAwO1xuICAgICAgICB2YXIgdyA9IDA7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcy5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIHggPSBpbnRBdChzLCBpKTtcbiAgICAgICAgICAgIGlmICh4IDwgMCkge1xuICAgICAgICAgICAgICAgIGlmIChzLmNoYXJBdChpKSA9PSBcIi1cIiAmJiB0aGlzLnNpZ251bSgpID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgbWkgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHcgPSBiICogdyArIHg7XG4gICAgICAgICAgICBpZiAoKytqID49IGNzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kTXVsdGlwbHkoZCk7XG4gICAgICAgICAgICAgICAgdGhpcy5kQWRkT2Zmc2V0KHcsIDApO1xuICAgICAgICAgICAgICAgIGogPSAwO1xuICAgICAgICAgICAgICAgIHcgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChqID4gMCkge1xuICAgICAgICAgICAgdGhpcy5kTXVsdGlwbHkoTWF0aC5wb3coYiwgaikpO1xuICAgICAgICAgICAgdGhpcy5kQWRkT2Zmc2V0KHcsIDApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtaSkge1xuICAgICAgICAgICAgQmlnSW50ZWdlci5aRVJPLnN1YlRvKHRoaXMsIHRoaXMpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mcm9tTnVtYmVyID0gYm5wRnJvbU51bWJlcjtcbiAgICAvLyAocHJvdGVjdGVkKSBhbHRlcm5hdGUgY29uc3RydWN0b3JcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5mcm9tTnVtYmVyID0gZnVuY3Rpb24gKGEsIGIsIGMpIHtcbiAgICAgICAgaWYgKFwibnVtYmVyXCIgPT0gdHlwZW9mIGIpIHtcbiAgICAgICAgICAgIC8vIG5ldyBCaWdJbnRlZ2VyKGludCxpbnQsUk5HKVxuICAgICAgICAgICAgaWYgKGEgPCAyKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcm9tSW50KDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcm9tTnVtYmVyKGEsIGMpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy50ZXN0Qml0KGEgLSAxKSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBmb3JjZSBNU0Igc2V0XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYml0d2lzZVRvKEJpZ0ludGVnZXIuT05FLnNoaWZ0TGVmdChhIC0gMSksIG9wX29yLCB0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNFdmVuKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kQWRkT2Zmc2V0KDEsIDApO1xuICAgICAgICAgICAgICAgIH0gLy8gZm9yY2Ugb2RkXG4gICAgICAgICAgICAgICAgd2hpbGUgKCF0aGlzLmlzUHJvYmFibGVQcmltZShiKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRBZGRPZmZzZXQoMiwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmJpdExlbmd0aCgpID4gYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdWJUbyhCaWdJbnRlZ2VyLk9ORS5zaGlmdExlZnQoYSAtIDEpLCB0aGlzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIG5ldyBCaWdJbnRlZ2VyKGludCxSTkcpXG4gICAgICAgICAgICB2YXIgeCA9IFtdO1xuICAgICAgICAgICAgdmFyIHQgPSBhICYgNztcbiAgICAgICAgICAgIHgubGVuZ3RoID0gKGEgPj4gMykgKyAxO1xuICAgICAgICAgICAgYi5uZXh0Qnl0ZXMoeCk7XG4gICAgICAgICAgICBpZiAodCA+IDApIHtcbiAgICAgICAgICAgICAgICB4WzBdICY9ICgoMSA8PCB0KSAtIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgeFswXSA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmZyb21TdHJpbmcoeCwgMjU2KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuYml0d2lzZVRvID0gYm5wQml0d2lzZVRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIHIgPSB0aGlzIG9wIGEgKGJpdHdpc2UpXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuYml0d2lzZVRvID0gZnVuY3Rpb24gKGEsIG9wLCByKSB7XG4gICAgICAgIHZhciBpO1xuICAgICAgICB2YXIgZjtcbiAgICAgICAgdmFyIG0gPSBNYXRoLm1pbihhLnQsIHRoaXMudCk7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBtOyArK2kpIHtcbiAgICAgICAgICAgIHJbaV0gPSBvcCh0aGlzW2ldLCBhW2ldKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYS50IDwgdGhpcy50KSB7XG4gICAgICAgICAgICBmID0gYS5zICYgdGhpcy5ETTtcbiAgICAgICAgICAgIGZvciAoaSA9IG07IGkgPCB0aGlzLnQ7ICsraSkge1xuICAgICAgICAgICAgICAgIHJbaV0gPSBvcCh0aGlzW2ldLCBmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHIudCA9IHRoaXMudDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGYgPSB0aGlzLnMgJiB0aGlzLkRNO1xuICAgICAgICAgICAgZm9yIChpID0gbTsgaSA8IGEudDsgKytpKSB7XG4gICAgICAgICAgICAgICAgcltpXSA9IG9wKGYsIGFbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgci50ID0gYS50O1xuICAgICAgICB9XG4gICAgICAgIHIucyA9IG9wKHRoaXMucywgYS5zKTtcbiAgICAgICAgci5jbGFtcCgpO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuY2hhbmdlQml0ID0gYm5wQ2hhbmdlQml0O1xuICAgIC8vIChwcm90ZWN0ZWQpIHRoaXMgb3AgKDE8PG4pXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuY2hhbmdlQml0ID0gZnVuY3Rpb24gKG4sIG9wKSB7XG4gICAgICAgIHZhciByID0gQmlnSW50ZWdlci5PTkUuc2hpZnRMZWZ0KG4pO1xuICAgICAgICB0aGlzLmJpdHdpc2VUbyhyLCBvcCwgcik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuYWRkVG8gPSBibnBBZGRUbztcbiAgICAvLyAocHJvdGVjdGVkKSByID0gdGhpcyArIGFcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5hZGRUbyA9IGZ1bmN0aW9uIChhLCByKSB7XG4gICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgdmFyIGMgPSAwO1xuICAgICAgICB2YXIgbSA9IE1hdGgubWluKGEudCwgdGhpcy50KTtcbiAgICAgICAgd2hpbGUgKGkgPCBtKSB7XG4gICAgICAgICAgICBjICs9IHRoaXNbaV0gKyBhW2ldO1xuICAgICAgICAgICAgcltpKytdID0gYyAmIHRoaXMuRE07XG4gICAgICAgICAgICBjID4+PSB0aGlzLkRCO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhLnQgPCB0aGlzLnQpIHtcbiAgICAgICAgICAgIGMgKz0gYS5zO1xuICAgICAgICAgICAgd2hpbGUgKGkgPCB0aGlzLnQpIHtcbiAgICAgICAgICAgICAgICBjICs9IHRoaXNbaV07XG4gICAgICAgICAgICAgICAgcltpKytdID0gYyAmIHRoaXMuRE07XG4gICAgICAgICAgICAgICAgYyA+Pj0gdGhpcy5EQjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGMgKz0gdGhpcy5zO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYyArPSB0aGlzLnM7XG4gICAgICAgICAgICB3aGlsZSAoaSA8IGEudCkge1xuICAgICAgICAgICAgICAgIGMgKz0gYVtpXTtcbiAgICAgICAgICAgICAgICByW2krK10gPSBjICYgdGhpcy5ETTtcbiAgICAgICAgICAgICAgICBjID4+PSB0aGlzLkRCO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYyArPSBhLnM7XG4gICAgICAgIH1cbiAgICAgICAgci5zID0gKGMgPCAwKSA/IC0xIDogMDtcbiAgICAgICAgaWYgKGMgPiAwKSB7XG4gICAgICAgICAgICByW2krK10gPSBjO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGMgPCAtMSkge1xuICAgICAgICAgICAgcltpKytdID0gdGhpcy5EViArIGM7XG4gICAgICAgIH1cbiAgICAgICAgci50ID0gaTtcbiAgICAgICAgci5jbGFtcCgpO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUuZE11bHRpcGx5ID0gYm5wRE11bHRpcGx5O1xuICAgIC8vIChwcm90ZWN0ZWQpIHRoaXMgKj0gbiwgdGhpcyA+PSAwLCAxIDwgbiA8IERWXG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuZE11bHRpcGx5ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgdGhpc1t0aGlzLnRdID0gdGhpcy5hbSgwLCBuIC0gMSwgdGhpcywgMCwgMCwgdGhpcy50KTtcbiAgICAgICAgKyt0aGlzLnQ7XG4gICAgICAgIHRoaXMuY2xhbXAoKTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLmRBZGRPZmZzZXQgPSBibnBEQWRkT2Zmc2V0O1xuICAgIC8vIChwcm90ZWN0ZWQpIHRoaXMgKz0gbiA8PCB3IHdvcmRzLCB0aGlzID49IDBcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5kQWRkT2Zmc2V0ID0gZnVuY3Rpb24gKG4sIHcpIHtcbiAgICAgICAgaWYgKG4gPT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlICh0aGlzLnQgPD0gdykge1xuICAgICAgICAgICAgdGhpc1t0aGlzLnQrK10gPSAwO1xuICAgICAgICB9XG4gICAgICAgIHRoaXNbd10gKz0gbjtcbiAgICAgICAgd2hpbGUgKHRoaXNbd10gPj0gdGhpcy5EVikge1xuICAgICAgICAgICAgdGhpc1t3XSAtPSB0aGlzLkRWO1xuICAgICAgICAgICAgaWYgKCsrdyA+PSB0aGlzLnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzW3RoaXMudCsrXSA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICArK3RoaXNbd107XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLm11bHRpcGx5TG93ZXJUbyA9IGJucE11bHRpcGx5TG93ZXJUbztcbiAgICAvLyAocHJvdGVjdGVkKSByID0gbG93ZXIgbiB3b3JkcyBvZiBcInRoaXMgKiBhXCIsIGEudCA8PSBuXG4gICAgLy8gXCJ0aGlzXCIgc2hvdWxkIGJlIHRoZSBsYXJnZXIgb25lIGlmIGFwcHJvcHJpYXRlLlxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm11bHRpcGx5TG93ZXJUbyA9IGZ1bmN0aW9uIChhLCBuLCByKSB7XG4gICAgICAgIHZhciBpID0gTWF0aC5taW4odGhpcy50ICsgYS50LCBuKTtcbiAgICAgICAgci5zID0gMDsgLy8gYXNzdW1lcyBhLHRoaXMgPj0gMFxuICAgICAgICByLnQgPSBpO1xuICAgICAgICB3aGlsZSAoaSA+IDApIHtcbiAgICAgICAgICAgIHJbLS1pXSA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgaiA9IHIudCAtIHRoaXMudDsgaSA8IGo7ICsraSkge1xuICAgICAgICAgICAgcltpICsgdGhpcy50XSA9IHRoaXMuYW0oMCwgYVtpXSwgciwgaSwgMCwgdGhpcy50KTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBqID0gTWF0aC5taW4oYS50LCBuKTsgaSA8IGo7ICsraSkge1xuICAgICAgICAgICAgdGhpcy5hbSgwLCBhW2ldLCByLCBpLCAwLCBuIC0gaSk7XG4gICAgICAgIH1cbiAgICAgICAgci5jbGFtcCgpO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUubXVsdGlwbHlVcHBlclRvID0gYm5wTXVsdGlwbHlVcHBlclRvO1xuICAgIC8vIChwcm90ZWN0ZWQpIHIgPSBcInRoaXMgKiBhXCIgd2l0aG91dCBsb3dlciBuIHdvcmRzLCBuID4gMFxuICAgIC8vIFwidGhpc1wiIHNob3VsZCBiZSB0aGUgbGFyZ2VyIG9uZSBpZiBhcHByb3ByaWF0ZS5cbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tdWx0aXBseVVwcGVyVG8gPSBmdW5jdGlvbiAoYSwgbiwgcikge1xuICAgICAgICAtLW47XG4gICAgICAgIHZhciBpID0gci50ID0gdGhpcy50ICsgYS50IC0gbjtcbiAgICAgICAgci5zID0gMDsgLy8gYXNzdW1lcyBhLHRoaXMgPj0gMFxuICAgICAgICB3aGlsZSAoLS1pID49IDApIHtcbiAgICAgICAgICAgIHJbaV0gPSAwO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoaSA9IE1hdGgubWF4KG4gLSB0aGlzLnQsIDApOyBpIDwgYS50OyArK2kpIHtcbiAgICAgICAgICAgIHJbdGhpcy50ICsgaSAtIG5dID0gdGhpcy5hbShuIC0gaSwgYVtpXSwgciwgMCwgMCwgdGhpcy50ICsgaSAtIG4pO1xuICAgICAgICB9XG4gICAgICAgIHIuY2xhbXAoKTtcbiAgICAgICAgci5kclNoaWZ0VG8oMSwgcik7XG4gICAgfTtcbiAgICAvLyBCaWdJbnRlZ2VyLnByb3RvdHlwZS5tb2RJbnQgPSBibnBNb2RJbnQ7XG4gICAgLy8gKHByb3RlY3RlZCkgdGhpcyAlIG4sIG4gPCAyXjI2XG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUubW9kSW50ID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgaWYgKG4gPD0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGQgPSB0aGlzLkRWICUgbjtcbiAgICAgICAgdmFyIHIgPSAodGhpcy5zIDwgMCkgPyBuIC0gMSA6IDA7XG4gICAgICAgIGlmICh0aGlzLnQgPiAwKSB7XG4gICAgICAgICAgICBpZiAoZCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgciA9IHRoaXNbMF0gJSBuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IHRoaXMudCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgICAgICAgICAgICAgIHIgPSAoZCAqIHIgKyB0aGlzW2ldKSAlIG47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gQmlnSW50ZWdlci5wcm90b3R5cGUubWlsbGVyUmFiaW4gPSBibnBNaWxsZXJSYWJpbjtcbiAgICAvLyAocHJvdGVjdGVkKSB0cnVlIGlmIHByb2JhYmx5IHByaW1lIChIQUMgNC4yNCwgTWlsbGVyLVJhYmluKVxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLm1pbGxlclJhYmluID0gZnVuY3Rpb24gKHQpIHtcbiAgICAgICAgdmFyIG4xID0gdGhpcy5zdWJ0cmFjdChCaWdJbnRlZ2VyLk9ORSk7XG4gICAgICAgIHZhciBrID0gbjEuZ2V0TG93ZXN0U2V0Qml0KCk7XG4gICAgICAgIGlmIChrIDw9IDApIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgciA9IG4xLnNoaWZ0UmlnaHQoayk7XG4gICAgICAgIHQgPSAodCArIDEpID4+IDE7XG4gICAgICAgIGlmICh0ID4gbG93cHJpbWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgdCA9IGxvd3ByaW1lcy5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGEgPSBuYmkoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0OyArK2kpIHtcbiAgICAgICAgICAgIC8vIFBpY2sgYmFzZXMgYXQgcmFuZG9tLCBpbnN0ZWFkIG9mIHN0YXJ0aW5nIGF0IDJcbiAgICAgICAgICAgIGEuZnJvbUludChsb3dwcmltZXNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbG93cHJpbWVzLmxlbmd0aCldKTtcbiAgICAgICAgICAgIHZhciB5ID0gYS5tb2RQb3cociwgdGhpcyk7XG4gICAgICAgICAgICBpZiAoeS5jb21wYXJlVG8oQmlnSW50ZWdlci5PTkUpICE9IDAgJiYgeS5jb21wYXJlVG8objEpICE9IDApIHtcbiAgICAgICAgICAgICAgICB2YXIgaiA9IDE7XG4gICAgICAgICAgICAgICAgd2hpbGUgKGorKyA8IGsgJiYgeS5jb21wYXJlVG8objEpICE9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgeSA9IHkubW9kUG93SW50KDIsIHRoaXMpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoeS5jb21wYXJlVG8oQmlnSW50ZWdlci5PTkUpID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoeS5jb21wYXJlVG8objEpICE9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuICAgIC8vIEJpZ0ludGVnZXIucHJvdG90eXBlLnNxdWFyZSA9IGJuU3F1YXJlO1xuICAgIC8vIChwdWJsaWMpIHRoaXNeMlxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLnNxdWFyZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5zcXVhcmVUbyhyKTtcbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfTtcbiAgICAvLyNyZWdpb24gQVNZTkNcbiAgICAvLyBQdWJsaWMgQVBJIG1ldGhvZFxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmdjZGEgPSBmdW5jdGlvbiAoYSwgY2FsbGJhY2spIHtcbiAgICAgICAgdmFyIHggPSAodGhpcy5zIDwgMCkgPyB0aGlzLm5lZ2F0ZSgpIDogdGhpcy5jbG9uZSgpO1xuICAgICAgICB2YXIgeSA9IChhLnMgPCAwKSA/IGEubmVnYXRlKCkgOiBhLmNsb25lKCk7XG4gICAgICAgIGlmICh4LmNvbXBhcmVUbyh5KSA8IDApIHtcbiAgICAgICAgICAgIHZhciB0ID0geDtcbiAgICAgICAgICAgIHggPSB5O1xuICAgICAgICAgICAgeSA9IHQ7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGkgPSB4LmdldExvd2VzdFNldEJpdCgpO1xuICAgICAgICB2YXIgZyA9IHkuZ2V0TG93ZXN0U2V0Qml0KCk7XG4gICAgICAgIGlmIChnIDwgMCkge1xuICAgICAgICAgICAgY2FsbGJhY2soeCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGkgPCBnKSB7XG4gICAgICAgICAgICBnID0gaTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZyA+IDApIHtcbiAgICAgICAgICAgIHguclNoaWZ0VG8oZywgeCk7XG4gICAgICAgICAgICB5LnJTaGlmdFRvKGcsIHkpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFdvcmtob3JzZSBvZiB0aGUgYWxnb3JpdGhtLCBnZXRzIGNhbGxlZCAyMDAgLSA4MDAgdGltZXMgcGVyIDUxMiBiaXQga2V5Z2VuLlxuICAgICAgICB2YXIgZ2NkYTEgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoKGkgPSB4LmdldExvd2VzdFNldEJpdCgpKSA+IDApIHtcbiAgICAgICAgICAgICAgICB4LnJTaGlmdFRvKGksIHgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKChpID0geS5nZXRMb3dlc3RTZXRCaXQoKSkgPiAwKSB7XG4gICAgICAgICAgICAgICAgeS5yU2hpZnRUbyhpLCB5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh4LmNvbXBhcmVUbyh5KSA+PSAwKSB7XG4gICAgICAgICAgICAgICAgeC5zdWJUbyh5LCB4KTtcbiAgICAgICAgICAgICAgICB4LnJTaGlmdFRvKDEsIHgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgeS5zdWJUbyh4LCB5KTtcbiAgICAgICAgICAgICAgICB5LnJTaGlmdFRvKDEsIHkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCEoeC5zaWdudW0oKSA+IDApKSB7XG4gICAgICAgICAgICAgICAgaWYgKGcgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHkubFNoaWZ0VG8oZywgeSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkgeyBjYWxsYmFjayh5KTsgfSwgMCk7IC8vIGVzY2FwZVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChnY2RhMSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHNldFRpbWVvdXQoZ2NkYTEsIDEwKTtcbiAgICB9O1xuICAgIC8vIChwcm90ZWN0ZWQpIGFsdGVybmF0ZSBjb25zdHJ1Y3RvclxuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmZyb21OdW1iZXJBc3luYyA9IGZ1bmN0aW9uIChhLCBiLCBjLCBjYWxsYmFjaykge1xuICAgICAgICBpZiAoXCJudW1iZXJcIiA9PSB0eXBlb2YgYikge1xuICAgICAgICAgICAgaWYgKGEgPCAyKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcm9tSW50KDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcm9tTnVtYmVyKGEsIGMpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy50ZXN0Qml0KGEgLSAxKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJpdHdpc2VUbyhCaWdJbnRlZ2VyLk9ORS5zaGlmdExlZnQoYSAtIDEpLCBvcF9vciwgdGhpcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmlzRXZlbigpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZEFkZE9mZnNldCgxLCAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFyIGJucF8xID0gdGhpcztcbiAgICAgICAgICAgICAgICB2YXIgYm5wZm4xXzEgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGJucF8xLmRBZGRPZmZzZXQoMiwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChibnBfMS5iaXRMZW5ndGgoKSA+IGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJucF8xLnN1YlRvKEJpZ0ludGVnZXIuT05FLnNoaWZ0TGVmdChhIC0gMSksIGJucF8xKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoYm5wXzEuaXNQcm9iYWJsZVByaW1lKGIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHsgY2FsbGJhY2soKTsgfSwgMCk7IC8vIGVzY2FwZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChibnBmbjFfMSwgMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoYm5wZm4xXzEsIDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFyIHggPSBbXTtcbiAgICAgICAgICAgIHZhciB0ID0gYSAmIDc7XG4gICAgICAgICAgICB4Lmxlbmd0aCA9IChhID4+IDMpICsgMTtcbiAgICAgICAgICAgIGIubmV4dEJ5dGVzKHgpO1xuICAgICAgICAgICAgaWYgKHQgPiAwKSB7XG4gICAgICAgICAgICAgICAgeFswXSAmPSAoKDEgPDwgdCkgLSAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHhbMF0gPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5mcm9tU3RyaW5nKHgsIDI1Nik7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBCaWdJbnRlZ2VyO1xufSgpKTtcbi8vI3JlZ2lvbiBSRURVQ0VSU1xuLy8jcmVnaW9uIE51bGxFeHBcbnZhciBOdWxsRXhwID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIE51bGxFeHAoKSB7XG4gICAgfVxuICAgIC8vIE51bGxFeHAucHJvdG90eXBlLmNvbnZlcnQgPSBuTm9wO1xuICAgIE51bGxFeHAucHJvdG90eXBlLmNvbnZlcnQgPSBmdW5jdGlvbiAoeCkge1xuICAgICAgICByZXR1cm4geDtcbiAgICB9O1xuICAgIC8vIE51bGxFeHAucHJvdG90eXBlLnJldmVydCA9IG5Ob3A7XG4gICAgTnVsbEV4cC5wcm90b3R5cGUucmV2ZXJ0ID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgcmV0dXJuIHg7XG4gICAgfTtcbiAgICAvLyBOdWxsRXhwLnByb3RvdHlwZS5tdWxUbyA9IG5NdWxUbztcbiAgICBOdWxsRXhwLnByb3RvdHlwZS5tdWxUbyA9IGZ1bmN0aW9uICh4LCB5LCByKSB7XG4gICAgICAgIHgubXVsdGlwbHlUbyh5LCByKTtcbiAgICB9O1xuICAgIC8vIE51bGxFeHAucHJvdG90eXBlLnNxclRvID0gblNxclRvO1xuICAgIE51bGxFeHAucHJvdG90eXBlLnNxclRvID0gZnVuY3Rpb24gKHgsIHIpIHtcbiAgICAgICAgeC5zcXVhcmVUbyhyKTtcbiAgICB9O1xuICAgIHJldHVybiBOdWxsRXhwO1xufSgpKTtcbi8vIE1vZHVsYXIgcmVkdWN0aW9uIHVzaW5nIFwiY2xhc3NpY1wiIGFsZ29yaXRobVxudmFyIENsYXNzaWMgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQ2xhc3NpYyhtKSB7XG4gICAgICAgIHRoaXMubSA9IG07XG4gICAgfVxuICAgIC8vIENsYXNzaWMucHJvdG90eXBlLmNvbnZlcnQgPSBjQ29udmVydDtcbiAgICBDbGFzc2ljLnByb3RvdHlwZS5jb252ZXJ0ID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgaWYgKHgucyA8IDAgfHwgeC5jb21wYXJlVG8odGhpcy5tKSA+PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4geC5tb2QodGhpcy5tKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB4O1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBDbGFzc2ljLnByb3RvdHlwZS5yZXZlcnQgPSBjUmV2ZXJ0O1xuICAgIENsYXNzaWMucHJvdG90eXBlLnJldmVydCA9IGZ1bmN0aW9uICh4KSB7XG4gICAgICAgIHJldHVybiB4O1xuICAgIH07XG4gICAgLy8gQ2xhc3NpYy5wcm90b3R5cGUucmVkdWNlID0gY1JlZHVjZTtcbiAgICBDbGFzc2ljLnByb3RvdHlwZS5yZWR1Y2UgPSBmdW5jdGlvbiAoeCkge1xuICAgICAgICB4LmRpdlJlbVRvKHRoaXMubSwgbnVsbCwgeCk7XG4gICAgfTtcbiAgICAvLyBDbGFzc2ljLnByb3RvdHlwZS5tdWxUbyA9IGNNdWxUbztcbiAgICBDbGFzc2ljLnByb3RvdHlwZS5tdWxUbyA9IGZ1bmN0aW9uICh4LCB5LCByKSB7XG4gICAgICAgIHgubXVsdGlwbHlUbyh5LCByKTtcbiAgICAgICAgdGhpcy5yZWR1Y2Uocik7XG4gICAgfTtcbiAgICAvLyBDbGFzc2ljLnByb3RvdHlwZS5zcXJUbyA9IGNTcXJUbztcbiAgICBDbGFzc2ljLnByb3RvdHlwZS5zcXJUbyA9IGZ1bmN0aW9uICh4LCByKSB7XG4gICAgICAgIHguc3F1YXJlVG8ocik7XG4gICAgICAgIHRoaXMucmVkdWNlKHIpO1xuICAgIH07XG4gICAgcmV0dXJuIENsYXNzaWM7XG59KCkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gTW9udGdvbWVyeVxuLy8gTW9udGdvbWVyeSByZWR1Y3Rpb25cbnZhciBNb250Z29tZXJ5ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIE1vbnRnb21lcnkobSkge1xuICAgICAgICB0aGlzLm0gPSBtO1xuICAgICAgICB0aGlzLm1wID0gbS5pbnZEaWdpdCgpO1xuICAgICAgICB0aGlzLm1wbCA9IHRoaXMubXAgJiAweDdmZmY7XG4gICAgICAgIHRoaXMubXBoID0gdGhpcy5tcCA+PiAxNTtcbiAgICAgICAgdGhpcy51bSA9ICgxIDw8IChtLkRCIC0gMTUpKSAtIDE7XG4gICAgICAgIHRoaXMubXQyID0gMiAqIG0udDtcbiAgICB9XG4gICAgLy8gTW9udGdvbWVyeS5wcm90b3R5cGUuY29udmVydCA9IG1vbnRDb252ZXJ0O1xuICAgIC8vIHhSIG1vZCBtXG4gICAgTW9udGdvbWVyeS5wcm90b3R5cGUuY29udmVydCA9IGZ1bmN0aW9uICh4KSB7XG4gICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgIHguYWJzKCkuZGxTaGlmdFRvKHRoaXMubS50LCByKTtcbiAgICAgICAgci5kaXZSZW1Ubyh0aGlzLm0sIG51bGwsIHIpO1xuICAgICAgICBpZiAoeC5zIDwgMCAmJiByLmNvbXBhcmVUbyhCaWdJbnRlZ2VyLlpFUk8pID4gMCkge1xuICAgICAgICAgICAgdGhpcy5tLnN1YlRvKHIsIHIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gTW9udGdvbWVyeS5wcm90b3R5cGUucmV2ZXJ0ID0gbW9udFJldmVydDtcbiAgICAvLyB4L1IgbW9kIG1cbiAgICBNb250Z29tZXJ5LnByb3RvdHlwZS5yZXZlcnQgPSBmdW5jdGlvbiAoeCkge1xuICAgICAgICB2YXIgciA9IG5iaSgpO1xuICAgICAgICB4LmNvcHlUbyhyKTtcbiAgICAgICAgdGhpcy5yZWR1Y2Uocik7XG4gICAgICAgIHJldHVybiByO1xuICAgIH07XG4gICAgLy8gTW9udGdvbWVyeS5wcm90b3R5cGUucmVkdWNlID0gbW9udFJlZHVjZTtcbiAgICAvLyB4ID0geC9SIG1vZCBtIChIQUMgMTQuMzIpXG4gICAgTW9udGdvbWVyeS5wcm90b3R5cGUucmVkdWNlID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgd2hpbGUgKHgudCA8PSB0aGlzLm10Mikge1xuICAgICAgICAgICAgLy8gcGFkIHggc28gYW0gaGFzIGVub3VnaCByb29tIGxhdGVyXG4gICAgICAgICAgICB4W3gudCsrXSA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLm0udDsgKytpKSB7XG4gICAgICAgICAgICAvLyBmYXN0ZXIgd2F5IG9mIGNhbGN1bGF0aW5nIHUwID0geFtpXSptcCBtb2QgRFZcbiAgICAgICAgICAgIHZhciBqID0geFtpXSAmIDB4N2ZmZjtcbiAgICAgICAgICAgIHZhciB1MCA9IChqICogdGhpcy5tcGwgKyAoKChqICogdGhpcy5tcGggKyAoeFtpXSA+PiAxNSkgKiB0aGlzLm1wbCkgJiB0aGlzLnVtKSA8PCAxNSkpICYgeC5ETTtcbiAgICAgICAgICAgIC8vIHVzZSBhbSB0byBjb21iaW5lIHRoZSBtdWx0aXBseS1zaGlmdC1hZGQgaW50byBvbmUgY2FsbFxuICAgICAgICAgICAgaiA9IGkgKyB0aGlzLm0udDtcbiAgICAgICAgICAgIHhbal0gKz0gdGhpcy5tLmFtKDAsIHUwLCB4LCBpLCAwLCB0aGlzLm0udCk7XG4gICAgICAgICAgICAvLyBwcm9wYWdhdGUgY2FycnlcbiAgICAgICAgICAgIHdoaWxlICh4W2pdID49IHguRFYpIHtcbiAgICAgICAgICAgICAgICB4W2pdIC09IHguRFY7XG4gICAgICAgICAgICAgICAgeFsrK2pdKys7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgeC5jbGFtcCgpO1xuICAgICAgICB4LmRyU2hpZnRUbyh0aGlzLm0udCwgeCk7XG4gICAgICAgIGlmICh4LmNvbXBhcmVUbyh0aGlzLm0pID49IDApIHtcbiAgICAgICAgICAgIHguc3ViVG8odGhpcy5tLCB4KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gTW9udGdvbWVyeS5wcm90b3R5cGUubXVsVG8gPSBtb250TXVsVG87XG4gICAgLy8gciA9IFwieHkvUiBtb2QgbVwiOyB4LHkgIT0gclxuICAgIE1vbnRnb21lcnkucHJvdG90eXBlLm11bFRvID0gZnVuY3Rpb24gKHgsIHksIHIpIHtcbiAgICAgICAgeC5tdWx0aXBseVRvKHksIHIpO1xuICAgICAgICB0aGlzLnJlZHVjZShyKTtcbiAgICB9O1xuICAgIC8vIE1vbnRnb21lcnkucHJvdG90eXBlLnNxclRvID0gbW9udFNxclRvO1xuICAgIC8vIHIgPSBcInheMi9SIG1vZCBtXCI7IHggIT0gclxuICAgIE1vbnRnb21lcnkucHJvdG90eXBlLnNxclRvID0gZnVuY3Rpb24gKHgsIHIpIHtcbiAgICAgICAgeC5zcXVhcmVUbyhyKTtcbiAgICAgICAgdGhpcy5yZWR1Y2Uocik7XG4gICAgfTtcbiAgICByZXR1cm4gTW9udGdvbWVyeTtcbn0oKSk7XG4vLyNlbmRyZWdpb24gTW9udGdvbWVyeVxuLy8jcmVnaW9uIEJhcnJldHRcbi8vIEJhcnJldHQgbW9kdWxhciByZWR1Y3Rpb25cbnZhciBCYXJyZXR0ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEJhcnJldHQobSkge1xuICAgICAgICB0aGlzLm0gPSBtO1xuICAgICAgICAvLyBzZXR1cCBCYXJyZXR0XG4gICAgICAgIHRoaXMucjIgPSBuYmkoKTtcbiAgICAgICAgdGhpcy5xMyA9IG5iaSgpO1xuICAgICAgICBCaWdJbnRlZ2VyLk9ORS5kbFNoaWZ0VG8oMiAqIG0udCwgdGhpcy5yMik7XG4gICAgICAgIHRoaXMubXUgPSB0aGlzLnIyLmRpdmlkZShtKTtcbiAgICB9XG4gICAgLy8gQmFycmV0dC5wcm90b3R5cGUuY29udmVydCA9IGJhcnJldHRDb252ZXJ0O1xuICAgIEJhcnJldHQucHJvdG90eXBlLmNvbnZlcnQgPSBmdW5jdGlvbiAoeCkge1xuICAgICAgICBpZiAoeC5zIDwgMCB8fCB4LnQgPiAyICogdGhpcy5tLnQpIHtcbiAgICAgICAgICAgIHJldHVybiB4Lm1vZCh0aGlzLm0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHguY29tcGFyZVRvKHRoaXMubSkgPCAwKSB7XG4gICAgICAgICAgICByZXR1cm4geDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhciByID0gbmJpKCk7XG4gICAgICAgICAgICB4LmNvcHlUbyhyKTtcbiAgICAgICAgICAgIHRoaXMucmVkdWNlKHIpO1xuICAgICAgICAgICAgcmV0dXJuIHI7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIEJhcnJldHQucHJvdG90eXBlLnJldmVydCA9IGJhcnJldHRSZXZlcnQ7XG4gICAgQmFycmV0dC5wcm90b3R5cGUucmV2ZXJ0ID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgcmV0dXJuIHg7XG4gICAgfTtcbiAgICAvLyBCYXJyZXR0LnByb3RvdHlwZS5yZWR1Y2UgPSBiYXJyZXR0UmVkdWNlO1xuICAgIC8vIHggPSB4IG1vZCBtIChIQUMgMTQuNDIpXG4gICAgQmFycmV0dC5wcm90b3R5cGUucmVkdWNlID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgeC5kclNoaWZ0VG8odGhpcy5tLnQgLSAxLCB0aGlzLnIyKTtcbiAgICAgICAgaWYgKHgudCA+IHRoaXMubS50ICsgMSkge1xuICAgICAgICAgICAgeC50ID0gdGhpcy5tLnQgKyAxO1xuICAgICAgICAgICAgeC5jbGFtcCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubXUubXVsdGlwbHlVcHBlclRvKHRoaXMucjIsIHRoaXMubS50ICsgMSwgdGhpcy5xMyk7XG4gICAgICAgIHRoaXMubS5tdWx0aXBseUxvd2VyVG8odGhpcy5xMywgdGhpcy5tLnQgKyAxLCB0aGlzLnIyKTtcbiAgICAgICAgd2hpbGUgKHguY29tcGFyZVRvKHRoaXMucjIpIDwgMCkge1xuICAgICAgICAgICAgeC5kQWRkT2Zmc2V0KDEsIHRoaXMubS50ICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgeC5zdWJUbyh0aGlzLnIyLCB4KTtcbiAgICAgICAgd2hpbGUgKHguY29tcGFyZVRvKHRoaXMubSkgPj0gMCkge1xuICAgICAgICAgICAgeC5zdWJUbyh0aGlzLm0sIHgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBCYXJyZXR0LnByb3RvdHlwZS5tdWxUbyA9IGJhcnJldHRNdWxUbztcbiAgICAvLyByID0geCp5IG1vZCBtOyB4LHkgIT0gclxuICAgIEJhcnJldHQucHJvdG90eXBlLm11bFRvID0gZnVuY3Rpb24gKHgsIHksIHIpIHtcbiAgICAgICAgeC5tdWx0aXBseVRvKHksIHIpO1xuICAgICAgICB0aGlzLnJlZHVjZShyKTtcbiAgICB9O1xuICAgIC8vIEJhcnJldHQucHJvdG90eXBlLnNxclRvID0gYmFycmV0dFNxclRvO1xuICAgIC8vIHIgPSB4XjIgbW9kIG07IHggIT0gclxuICAgIEJhcnJldHQucHJvdG90eXBlLnNxclRvID0gZnVuY3Rpb24gKHgsIHIpIHtcbiAgICAgICAgeC5zcXVhcmVUbyhyKTtcbiAgICAgICAgdGhpcy5yZWR1Y2Uocik7XG4gICAgfTtcbiAgICByZXR1cm4gQmFycmV0dDtcbn0oKSk7XG4vLyNlbmRyZWdpb25cbi8vI2VuZHJlZ2lvbiBSRURVQ0VSU1xuLy8gcmV0dXJuIG5ldywgdW5zZXQgQmlnSW50ZWdlclxuZnVuY3Rpb24gbmJpKCkgeyByZXR1cm4gbmV3IEJpZ0ludGVnZXIobnVsbCk7IH1cbmZ1bmN0aW9uIHBhcnNlQmlnSW50KHN0ciwgcikge1xuICAgIHJldHVybiBuZXcgQmlnSW50ZWdlcihzdHIsIHIpO1xufVxuLy8gYW06IENvbXB1dGUgd19qICs9ICh4KnRoaXNfaSksIHByb3BhZ2F0ZSBjYXJyaWVzLFxuLy8gYyBpcyBpbml0aWFsIGNhcnJ5LCByZXR1cm5zIGZpbmFsIGNhcnJ5LlxuLy8gYyA8IDMqZHZhbHVlLCB4IDwgMipkdmFsdWUsIHRoaXNfaSA8IGR2YWx1ZVxuLy8gV2UgbmVlZCB0byBzZWxlY3QgdGhlIGZhc3Rlc3Qgb25lIHRoYXQgd29ya3MgaW4gdGhpcyBlbnZpcm9ubWVudC5cbi8vIGFtMTogdXNlIGEgc2luZ2xlIG11bHQgYW5kIGRpdmlkZSB0byBnZXQgdGhlIGhpZ2ggYml0cyxcbi8vIG1heCBkaWdpdCBiaXRzIHNob3VsZCBiZSAyNiBiZWNhdXNlXG4vLyBtYXggaW50ZXJuYWwgdmFsdWUgPSAyKmR2YWx1ZV4yLTIqZHZhbHVlICg8IDJeNTMpXG5mdW5jdGlvbiBhbTEoaSwgeCwgdywgaiwgYywgbikge1xuICAgIHdoaWxlICgtLW4gPj0gMCkge1xuICAgICAgICB2YXIgdiA9IHggKiB0aGlzW2krK10gKyB3W2pdICsgYztcbiAgICAgICAgYyA9IE1hdGguZmxvb3IodiAvIDB4NDAwMDAwMCk7XG4gICAgICAgIHdbaisrXSA9IHYgJiAweDNmZmZmZmY7XG4gICAgfVxuICAgIHJldHVybiBjO1xufVxuLy8gYW0yIGF2b2lkcyBhIGJpZyBtdWx0LWFuZC1leHRyYWN0IGNvbXBsZXRlbHkuXG4vLyBNYXggZGlnaXQgYml0cyBzaG91bGQgYmUgPD0gMzAgYmVjYXVzZSB3ZSBkbyBiaXR3aXNlIG9wc1xuLy8gb24gdmFsdWVzIHVwIHRvIDIqaGR2YWx1ZV4yLWhkdmFsdWUtMSAoPCAyXjMxKVxuZnVuY3Rpb24gYW0yKGksIHgsIHcsIGosIGMsIG4pIHtcbiAgICB2YXIgeGwgPSB4ICYgMHg3ZmZmO1xuICAgIHZhciB4aCA9IHggPj4gMTU7XG4gICAgd2hpbGUgKC0tbiA+PSAwKSB7XG4gICAgICAgIHZhciBsID0gdGhpc1tpXSAmIDB4N2ZmZjtcbiAgICAgICAgdmFyIGggPSB0aGlzW2krK10gPj4gMTU7XG4gICAgICAgIHZhciBtID0geGggKiBsICsgaCAqIHhsO1xuICAgICAgICBsID0geGwgKiBsICsgKChtICYgMHg3ZmZmKSA8PCAxNSkgKyB3W2pdICsgKGMgJiAweDNmZmZmZmZmKTtcbiAgICAgICAgYyA9IChsID4+PiAzMCkgKyAobSA+Pj4gMTUpICsgeGggKiBoICsgKGMgPj4+IDMwKTtcbiAgICAgICAgd1tqKytdID0gbCAmIDB4M2ZmZmZmZmY7XG4gICAgfVxuICAgIHJldHVybiBjO1xufVxuLy8gQWx0ZXJuYXRlbHksIHNldCBtYXggZGlnaXQgYml0cyB0byAyOCBzaW5jZSBzb21lXG4vLyBicm93c2VycyBzbG93IGRvd24gd2hlbiBkZWFsaW5nIHdpdGggMzItYml0IG51bWJlcnMuXG5mdW5jdGlvbiBhbTMoaSwgeCwgdywgaiwgYywgbikge1xuICAgIHZhciB4bCA9IHggJiAweDNmZmY7XG4gICAgdmFyIHhoID0geCA+PiAxNDtcbiAgICB3aGlsZSAoLS1uID49IDApIHtcbiAgICAgICAgdmFyIGwgPSB0aGlzW2ldICYgMHgzZmZmO1xuICAgICAgICB2YXIgaCA9IHRoaXNbaSsrXSA+PiAxNDtcbiAgICAgICAgdmFyIG0gPSB4aCAqIGwgKyBoICogeGw7XG4gICAgICAgIGwgPSB4bCAqIGwgKyAoKG0gJiAweDNmZmYpIDw8IDE0KSArIHdbal0gKyBjO1xuICAgICAgICBjID0gKGwgPj4gMjgpICsgKG0gPj4gMTQpICsgeGggKiBoO1xuICAgICAgICB3W2orK10gPSBsICYgMHhmZmZmZmZmO1xuICAgIH1cbiAgICByZXR1cm4gYztcbn1cbmlmIChqX2xtICYmIChuYXZpZ2F0b3IuYXBwTmFtZSA9PSBcIk1pY3Jvc29mdCBJbnRlcm5ldCBFeHBsb3JlclwiKSkge1xuICAgIEJpZ0ludGVnZXIucHJvdG90eXBlLmFtID0gYW0yO1xuICAgIGRiaXRzID0gMzA7XG59XG5lbHNlIGlmIChqX2xtICYmIChuYXZpZ2F0b3IuYXBwTmFtZSAhPSBcIk5ldHNjYXBlXCIpKSB7XG4gICAgQmlnSW50ZWdlci5wcm90b3R5cGUuYW0gPSBhbTE7XG4gICAgZGJpdHMgPSAyNjtcbn1cbmVsc2UgeyAvLyBNb3ppbGxhL05ldHNjYXBlIHNlZW1zIHRvIHByZWZlciBhbTNcbiAgICBCaWdJbnRlZ2VyLnByb3RvdHlwZS5hbSA9IGFtMztcbiAgICBkYml0cyA9IDI4O1xufVxuQmlnSW50ZWdlci5wcm90b3R5cGUuREIgPSBkYml0cztcbkJpZ0ludGVnZXIucHJvdG90eXBlLkRNID0gKCgxIDw8IGRiaXRzKSAtIDEpO1xuQmlnSW50ZWdlci5wcm90b3R5cGUuRFYgPSAoMSA8PCBkYml0cyk7XG52YXIgQklfRlAgPSA1MjtcbkJpZ0ludGVnZXIucHJvdG90eXBlLkZWID0gTWF0aC5wb3coMiwgQklfRlApO1xuQmlnSW50ZWdlci5wcm90b3R5cGUuRjEgPSBCSV9GUCAtIGRiaXRzO1xuQmlnSW50ZWdlci5wcm90b3R5cGUuRjIgPSAyICogZGJpdHMgLSBCSV9GUDtcbi8vIERpZ2l0IGNvbnZlcnNpb25zXG52YXIgQklfUkMgPSBbXTtcbnZhciBycjtcbnZhciB2djtcbnJyID0gXCIwXCIuY2hhckNvZGVBdCgwKTtcbmZvciAodnYgPSAwOyB2diA8PSA5OyArK3Z2KSB7XG4gICAgQklfUkNbcnIrK10gPSB2djtcbn1cbnJyID0gXCJhXCIuY2hhckNvZGVBdCgwKTtcbmZvciAodnYgPSAxMDsgdnYgPCAzNjsgKyt2dikge1xuICAgIEJJX1JDW3JyKytdID0gdnY7XG59XG5yciA9IFwiQVwiLmNoYXJDb2RlQXQoMCk7XG5mb3IgKHZ2ID0gMTA7IHZ2IDwgMzY7ICsrdnYpIHtcbiAgICBCSV9SQ1tycisrXSA9IHZ2O1xufVxuZnVuY3Rpb24gaW50QXQocywgaSkge1xuICAgIHZhciBjID0gQklfUkNbcy5jaGFyQ29kZUF0KGkpXTtcbiAgICByZXR1cm4gKGMgPT0gbnVsbCkgPyAtMSA6IGM7XG59XG4vLyByZXR1cm4gYmlnaW50IGluaXRpYWxpemVkIHRvIHZhbHVlXG5mdW5jdGlvbiBuYnYoaSkge1xuICAgIHZhciByID0gbmJpKCk7XG4gICAgci5mcm9tSW50KGkpO1xuICAgIHJldHVybiByO1xufVxuLy8gcmV0dXJucyBiaXQgbGVuZ3RoIG9mIHRoZSBpbnRlZ2VyIHhcbmZ1bmN0aW9uIG5iaXRzKHgpIHtcbiAgICB2YXIgciA9IDE7XG4gICAgdmFyIHQ7XG4gICAgaWYgKCh0ID0geCA+Pj4gMTYpICE9IDApIHtcbiAgICAgICAgeCA9IHQ7XG4gICAgICAgIHIgKz0gMTY7XG4gICAgfVxuICAgIGlmICgodCA9IHggPj4gOCkgIT0gMCkge1xuICAgICAgICB4ID0gdDtcbiAgICAgICAgciArPSA4O1xuICAgIH1cbiAgICBpZiAoKHQgPSB4ID4+IDQpICE9IDApIHtcbiAgICAgICAgeCA9IHQ7XG4gICAgICAgIHIgKz0gNDtcbiAgICB9XG4gICAgaWYgKCh0ID0geCA+PiAyKSAhPSAwKSB7XG4gICAgICAgIHggPSB0O1xuICAgICAgICByICs9IDI7XG4gICAgfVxuICAgIGlmICgodCA9IHggPj4gMSkgIT0gMCkge1xuICAgICAgICB4ID0gdDtcbiAgICAgICAgciArPSAxO1xuICAgIH1cbiAgICByZXR1cm4gcjtcbn1cbi8vIFwiY29uc3RhbnRzXCJcbkJpZ0ludGVnZXIuWkVSTyA9IG5idigwKTtcbkJpZ0ludGVnZXIuT05FID0gbmJ2KDEpO1xuXG4vLyBwcm5nNC5qcyAtIHVzZXMgQXJjZm91ciBhcyBhIFBSTkdcbnZhciBBcmNmb3VyID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEFyY2ZvdXIoKSB7XG4gICAgICAgIHRoaXMuaSA9IDA7XG4gICAgICAgIHRoaXMuaiA9IDA7XG4gICAgICAgIHRoaXMuUyA9IFtdO1xuICAgIH1cbiAgICAvLyBBcmNmb3VyLnByb3RvdHlwZS5pbml0ID0gQVJDNGluaXQ7XG4gICAgLy8gSW5pdGlhbGl6ZSBhcmNmb3VyIGNvbnRleHQgZnJvbSBrZXksIGFuIGFycmF5IG9mIGludHMsIGVhY2ggZnJvbSBbMC4uMjU1XVxuICAgIEFyY2ZvdXIucHJvdG90eXBlLmluaXQgPSBmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgIHZhciBpO1xuICAgICAgICB2YXIgajtcbiAgICAgICAgdmFyIHQ7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCAyNTY7ICsraSkge1xuICAgICAgICAgICAgdGhpcy5TW2ldID0gaTtcbiAgICAgICAgfVxuICAgICAgICBqID0gMDtcbiAgICAgICAgZm9yIChpID0gMDsgaSA8IDI1NjsgKytpKSB7XG4gICAgICAgICAgICBqID0gKGogKyB0aGlzLlNbaV0gKyBrZXlbaSAlIGtleS5sZW5ndGhdKSAmIDI1NTtcbiAgICAgICAgICAgIHQgPSB0aGlzLlNbaV07XG4gICAgICAgICAgICB0aGlzLlNbaV0gPSB0aGlzLlNbal07XG4gICAgICAgICAgICB0aGlzLlNbal0gPSB0O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaSA9IDA7XG4gICAgICAgIHRoaXMuaiA9IDA7XG4gICAgfTtcbiAgICAvLyBBcmNmb3VyLnByb3RvdHlwZS5uZXh0ID0gQVJDNG5leHQ7XG4gICAgQXJjZm91ci5wcm90b3R5cGUubmV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHQ7XG4gICAgICAgIHRoaXMuaSA9ICh0aGlzLmkgKyAxKSAmIDI1NTtcbiAgICAgICAgdGhpcy5qID0gKHRoaXMuaiArIHRoaXMuU1t0aGlzLmldKSAmIDI1NTtcbiAgICAgICAgdCA9IHRoaXMuU1t0aGlzLmldO1xuICAgICAgICB0aGlzLlNbdGhpcy5pXSA9IHRoaXMuU1t0aGlzLmpdO1xuICAgICAgICB0aGlzLlNbdGhpcy5qXSA9IHQ7XG4gICAgICAgIHJldHVybiB0aGlzLlNbKHQgKyB0aGlzLlNbdGhpcy5pXSkgJiAyNTVdO1xuICAgIH07XG4gICAgcmV0dXJuIEFyY2ZvdXI7XG59KCkpO1xuLy8gUGx1ZyBpbiB5b3VyIFJORyBjb25zdHJ1Y3RvciBoZXJlXG5mdW5jdGlvbiBwcm5nX25ld3N0YXRlKCkge1xuICAgIHJldHVybiBuZXcgQXJjZm91cigpO1xufVxuLy8gUG9vbCBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiA0IGFuZCBncmVhdGVyIHRoYW4gMzIuXG4vLyBBbiBhcnJheSBvZiBieXRlcyB0aGUgc2l6ZSBvZiB0aGUgcG9vbCB3aWxsIGJlIHBhc3NlZCB0byBpbml0KClcbnZhciBybmdfcHNpemUgPSAyNTY7XG5cbi8vIFJhbmRvbSBudW1iZXIgZ2VuZXJhdG9yIC0gcmVxdWlyZXMgYSBQUk5HIGJhY2tlbmQsIGUuZy4gcHJuZzQuanNcbnZhciBybmdfc3RhdGU7XG52YXIgcm5nX3Bvb2wgPSBudWxsO1xudmFyIHJuZ19wcHRyO1xuLy8gSW5pdGlhbGl6ZSB0aGUgcG9vbCB3aXRoIGp1bmsgaWYgbmVlZGVkLlxuaWYgKHJuZ19wb29sID09IG51bGwpIHtcbiAgICBybmdfcG9vbCA9IFtdO1xuICAgIHJuZ19wcHRyID0gMDtcbiAgICB2YXIgdCA9IHZvaWQgMDtcbiAgICBpZiAod2luZG93LmNyeXB0byAmJiB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcykge1xuICAgICAgICAvLyBFeHRyYWN0IGVudHJvcHkgKDIwNDggYml0cykgZnJvbSBSTkcgaWYgYXZhaWxhYmxlXG4gICAgICAgIHZhciB6ID0gbmV3IFVpbnQzMkFycmF5KDI1Nik7XG4gICAgICAgIHdpbmRvdy5jcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKHopO1xuICAgICAgICBmb3IgKHQgPSAwOyB0IDwgei5sZW5ndGg7ICsrdCkge1xuICAgICAgICAgICAgcm5nX3Bvb2xbcm5nX3BwdHIrK10gPSB6W3RdICYgMjU1O1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIFVzZSBtb3VzZSBldmVudHMgZm9yIGVudHJvcHksIGlmIHdlIGRvIG5vdCBoYXZlIGVub3VnaCBlbnRyb3B5IGJ5IHRoZSB0aW1lXG4gICAgLy8gd2UgbmVlZCBpdCwgZW50cm9weSB3aWxsIGJlIGdlbmVyYXRlZCBieSBNYXRoLnJhbmRvbS5cbiAgICB2YXIgb25Nb3VzZU1vdmVMaXN0ZW5lcl8xID0gZnVuY3Rpb24gKGV2KSB7XG4gICAgICAgIHRoaXMuY291bnQgPSB0aGlzLmNvdW50IHx8IDA7XG4gICAgICAgIGlmICh0aGlzLmNvdW50ID49IDI1NiB8fCBybmdfcHB0ciA+PSBybmdfcHNpemUpIHtcbiAgICAgICAgICAgIGlmICh3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcikge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW91c2VNb3ZlTGlzdGVuZXJfMSwgZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAod2luZG93LmRldGFjaEV2ZW50KSB7XG4gICAgICAgICAgICAgICAgd2luZG93LmRldGFjaEV2ZW50KFwib25tb3VzZW1vdmVcIiwgb25Nb3VzZU1vdmVMaXN0ZW5lcl8xKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIG1vdXNlQ29vcmRpbmF0ZXMgPSBldi54ICsgZXYueTtcbiAgICAgICAgICAgIHJuZ19wb29sW3JuZ19wcHRyKytdID0gbW91c2VDb29yZGluYXRlcyAmIDI1NTtcbiAgICAgICAgICAgIHRoaXMuY291bnQgKz0gMTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gU29tZXRpbWVzIEZpcmVmb3ggd2lsbCBkZW55IHBlcm1pc3Npb24gdG8gYWNjZXNzIGV2ZW50IHByb3BlcnRpZXMgZm9yIHNvbWUgcmVhc29uLiBJZ25vcmUuXG4gICAgICAgIH1cbiAgICB9O1xuICAgIGlmICh3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCBvbk1vdXNlTW92ZUxpc3RlbmVyXzEsIGZhbHNlKTtcbiAgICB9XG4gICAgZWxzZSBpZiAod2luZG93LmF0dGFjaEV2ZW50KSB7XG4gICAgICAgIHdpbmRvdy5hdHRhY2hFdmVudChcIm9ubW91c2Vtb3ZlXCIsIG9uTW91c2VNb3ZlTGlzdGVuZXJfMSk7XG4gICAgfVxufVxuZnVuY3Rpb24gcm5nX2dldF9ieXRlKCkge1xuICAgIGlmIChybmdfc3RhdGUgPT0gbnVsbCkge1xuICAgICAgICBybmdfc3RhdGUgPSBwcm5nX25ld3N0YXRlKCk7XG4gICAgICAgIC8vIEF0IHRoaXMgcG9pbnQsIHdlIG1heSBub3QgaGF2ZSBjb2xsZWN0ZWQgZW5vdWdoIGVudHJvcHkuICBJZiBub3QsIGZhbGwgYmFjayB0byBNYXRoLnJhbmRvbVxuICAgICAgICB3aGlsZSAocm5nX3BwdHIgPCBybmdfcHNpemUpIHtcbiAgICAgICAgICAgIHZhciByYW5kb20gPSBNYXRoLmZsb29yKDY1NTM2ICogTWF0aC5yYW5kb20oKSk7XG4gICAgICAgICAgICBybmdfcG9vbFtybmdfcHB0cisrXSA9IHJhbmRvbSAmIDI1NTtcbiAgICAgICAgfVxuICAgICAgICBybmdfc3RhdGUuaW5pdChybmdfcG9vbCk7XG4gICAgICAgIGZvciAocm5nX3BwdHIgPSAwOyBybmdfcHB0ciA8IHJuZ19wb29sLmxlbmd0aDsgKytybmdfcHB0cikge1xuICAgICAgICAgICAgcm5nX3Bvb2xbcm5nX3BwdHJdID0gMDtcbiAgICAgICAgfVxuICAgICAgICBybmdfcHB0ciA9IDA7XG4gICAgfVxuICAgIC8vIFRPRE86IGFsbG93IHJlc2VlZGluZyBhZnRlciBmaXJzdCByZXF1ZXN0XG4gICAgcmV0dXJuIHJuZ19zdGF0ZS5uZXh0KCk7XG59XG52YXIgU2VjdXJlUmFuZG9tID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlY3VyZVJhbmRvbSgpIHtcbiAgICB9XG4gICAgU2VjdXJlUmFuZG9tLnByb3RvdHlwZS5uZXh0Qnl0ZXMgPSBmdW5jdGlvbiAoYmEpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBiYS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgYmFbaV0gPSBybmdfZ2V0X2J5dGUoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIFNlY3VyZVJhbmRvbTtcbn0oKSk7XG5cbi8vIERlcGVuZHMgb24ganNibi5qcyBhbmQgcm5nLmpzXG4vLyBmdW5jdGlvbiBsaW5lYnJrKHMsbikge1xuLy8gICB2YXIgcmV0ID0gXCJcIjtcbi8vICAgdmFyIGkgPSAwO1xuLy8gICB3aGlsZShpICsgbiA8IHMubGVuZ3RoKSB7XG4vLyAgICAgcmV0ICs9IHMuc3Vic3RyaW5nKGksaStuKSArIFwiXFxuXCI7XG4vLyAgICAgaSArPSBuO1xuLy8gICB9XG4vLyAgIHJldHVybiByZXQgKyBzLnN1YnN0cmluZyhpLHMubGVuZ3RoKTtcbi8vIH1cbi8vIGZ1bmN0aW9uIGJ5dGUySGV4KGIpIHtcbi8vICAgaWYoYiA8IDB4MTApXG4vLyAgICAgcmV0dXJuIFwiMFwiICsgYi50b1N0cmluZygxNik7XG4vLyAgIGVsc2Vcbi8vICAgICByZXR1cm4gYi50b1N0cmluZygxNik7XG4vLyB9XG5mdW5jdGlvbiBwa2NzMXBhZDEocywgbikge1xuICAgIGlmIChuIDwgcy5sZW5ndGggKyAyMikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiTWVzc2FnZSB0b28gbG9uZyBmb3IgUlNBXCIpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgdmFyIGxlbiA9IG4gLSBzLmxlbmd0aCAtIDY7XG4gICAgdmFyIGZpbGxlciA9IFwiXCI7XG4gICAgZm9yICh2YXIgZiA9IDA7IGYgPCBsZW47IGYgKz0gMikge1xuICAgICAgICBmaWxsZXIgKz0gXCJmZlwiO1xuICAgIH1cbiAgICB2YXIgbSA9IFwiMDAwMVwiICsgZmlsbGVyICsgXCIwMFwiICsgcztcbiAgICByZXR1cm4gcGFyc2VCaWdJbnQobSwgMTYpO1xufVxuLy8gUEtDUyMxICh0eXBlIDIsIHJhbmRvbSkgcGFkIGlucHV0IHN0cmluZyBzIHRvIG4gYnl0ZXMsIGFuZCByZXR1cm4gYSBiaWdpbnRcbmZ1bmN0aW9uIHBrY3MxcGFkMihzLCBuKSB7XG4gICAgaWYgKG4gPCBzLmxlbmd0aCArIDExKSB7XG4gICAgICAgIC8vIFRPRE86IGZpeCBmb3IgdXRmLThcbiAgICAgICAgY29uc29sZS5lcnJvcihcIk1lc3NhZ2UgdG9vIGxvbmcgZm9yIFJTQVwiKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBiYSA9IFtdO1xuICAgIHZhciBpID0gcy5sZW5ndGggLSAxO1xuICAgIHdoaWxlIChpID49IDAgJiYgbiA+IDApIHtcbiAgICAgICAgdmFyIGMgPSBzLmNoYXJDb2RlQXQoaS0tKTtcbiAgICAgICAgaWYgKGMgPCAxMjgpIHtcbiAgICAgICAgICAgIC8vIGVuY29kZSB1c2luZyB1dGYtOFxuICAgICAgICAgICAgYmFbLS1uXSA9IGM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYyA+IDEyNyAmJiBjIDwgMjA0OCkge1xuICAgICAgICAgICAgYmFbLS1uXSA9IChjICYgNjMpIHwgMTI4O1xuICAgICAgICAgICAgYmFbLS1uXSA9IChjID4+IDYpIHwgMTkyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYmFbLS1uXSA9IChjICYgNjMpIHwgMTI4O1xuICAgICAgICAgICAgYmFbLS1uXSA9ICgoYyA+PiA2KSAmIDYzKSB8IDEyODtcbiAgICAgICAgICAgIGJhWy0tbl0gPSAoYyA+PiAxMikgfCAyMjQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYmFbLS1uXSA9IDA7XG4gICAgdmFyIHJuZyA9IG5ldyBTZWN1cmVSYW5kb20oKTtcbiAgICB2YXIgeCA9IFtdO1xuICAgIHdoaWxlIChuID4gMikge1xuICAgICAgICAvLyByYW5kb20gbm9uLXplcm8gcGFkXG4gICAgICAgIHhbMF0gPSAwO1xuICAgICAgICB3aGlsZSAoeFswXSA9PSAwKSB7XG4gICAgICAgICAgICBybmcubmV4dEJ5dGVzKHgpO1xuICAgICAgICB9XG4gICAgICAgIGJhWy0tbl0gPSB4WzBdO1xuICAgIH1cbiAgICBiYVstLW5dID0gMjtcbiAgICBiYVstLW5dID0gMDtcbiAgICByZXR1cm4gbmV3IEJpZ0ludGVnZXIoYmEpO1xufVxuLy8gXCJlbXB0eVwiIFJTQSBrZXkgY29uc3RydWN0b3JcbnZhciBSU0FLZXkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gUlNBS2V5KCkge1xuICAgICAgICB0aGlzLm4gPSBudWxsO1xuICAgICAgICB0aGlzLmUgPSAwO1xuICAgICAgICB0aGlzLmQgPSBudWxsO1xuICAgICAgICB0aGlzLnAgPSBudWxsO1xuICAgICAgICB0aGlzLnEgPSBudWxsO1xuICAgICAgICB0aGlzLmRtcDEgPSBudWxsO1xuICAgICAgICB0aGlzLmRtcTEgPSBudWxsO1xuICAgICAgICB0aGlzLmNvZWZmID0gbnVsbDtcbiAgICB9XG4gICAgLy8jcmVnaW9uIFBST1RFQ1RFRFxuICAgIC8vIHByb3RlY3RlZFxuICAgIC8vIFJTQUtleS5wcm90b3R5cGUuZG9QdWJsaWMgPSBSU0FEb1B1YmxpYztcbiAgICAvLyBQZXJmb3JtIHJhdyBwdWJsaWMgb3BlcmF0aW9uIG9uIFwieFwiOiByZXR1cm4geF5lIChtb2QgbilcbiAgICBSU0FLZXkucHJvdG90eXBlLmRvUHVibGljID0gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgcmV0dXJuIHgubW9kUG93SW50KHRoaXMuZSwgdGhpcy5uKTtcbiAgICB9O1xuICAgIC8vIFJTQUtleS5wcm90b3R5cGUuZG9Qcml2YXRlID0gUlNBRG9Qcml2YXRlO1xuICAgIC8vIFBlcmZvcm0gcmF3IHByaXZhdGUgb3BlcmF0aW9uIG9uIFwieFwiOiByZXR1cm4geF5kIChtb2QgbilcbiAgICBSU0FLZXkucHJvdG90eXBlLmRvUHJpdmF0ZSA9IGZ1bmN0aW9uICh4KSB7XG4gICAgICAgIGlmICh0aGlzLnAgPT0gbnVsbCB8fCB0aGlzLnEgPT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIHgubW9kUG93KHRoaXMuZCwgdGhpcy5uKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUT0RPOiByZS1jYWxjdWxhdGUgYW55IG1pc3NpbmcgQ1JUIHBhcmFtc1xuICAgICAgICB2YXIgeHAgPSB4Lm1vZCh0aGlzLnApLm1vZFBvdyh0aGlzLmRtcDEsIHRoaXMucCk7XG4gICAgICAgIHZhciB4cSA9IHgubW9kKHRoaXMucSkubW9kUG93KHRoaXMuZG1xMSwgdGhpcy5xKTtcbiAgICAgICAgd2hpbGUgKHhwLmNvbXBhcmVUbyh4cSkgPCAwKSB7XG4gICAgICAgICAgICB4cCA9IHhwLmFkZCh0aGlzLnApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB4cFxuICAgICAgICAgICAgLnN1YnRyYWN0KHhxKVxuICAgICAgICAgICAgLm11bHRpcGx5KHRoaXMuY29lZmYpXG4gICAgICAgICAgICAubW9kKHRoaXMucClcbiAgICAgICAgICAgIC5tdWx0aXBseSh0aGlzLnEpXG4gICAgICAgICAgICAuYWRkKHhxKTtcbiAgICB9O1xuICAgIC8vI2VuZHJlZ2lvbiBQUk9URUNURURcbiAgICAvLyNyZWdpb24gUFVCTElDXG4gICAgLy8gUlNBS2V5LnByb3RvdHlwZS5zZXRQdWJsaWMgPSBSU0FTZXRQdWJsaWM7XG4gICAgLy8gU2V0IHRoZSBwdWJsaWMga2V5IGZpZWxkcyBOIGFuZCBlIGZyb20gaGV4IHN0cmluZ3NcbiAgICBSU0FLZXkucHJvdG90eXBlLnNldFB1YmxpYyA9IGZ1bmN0aW9uIChOLCBFKSB7XG4gICAgICAgIGlmIChOICE9IG51bGwgJiYgRSAhPSBudWxsICYmIE4ubGVuZ3RoID4gMCAmJiBFLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMubiA9IHBhcnNlQmlnSW50KE4sIDE2KTtcbiAgICAgICAgICAgIHRoaXMuZSA9IHBhcnNlSW50KEUsIDE2KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIFJTQSBwdWJsaWMga2V5XCIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBSU0FLZXkucHJvdG90eXBlLmVuY3J5cHQgPSBSU0FFbmNyeXB0O1xuICAgIC8vIFJldHVybiB0aGUgUEtDUyMxIFJTQSBlbmNyeXB0aW9uIG9mIFwidGV4dFwiIGFzIGFuIGV2ZW4tbGVuZ3RoIGhleCBzdHJpbmdcbiAgICBSU0FLZXkucHJvdG90eXBlLmVuY3J5cHQgPSBmdW5jdGlvbiAodGV4dCkge1xuICAgICAgICB2YXIgbSA9IHBrY3MxcGFkMih0ZXh0LCAodGhpcy5uLmJpdExlbmd0aCgpICsgNykgPj4gMyk7XG4gICAgICAgIGlmIChtID09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHZhciBjID0gdGhpcy5kb1B1YmxpYyhtKTtcbiAgICAgICAgaWYgKGMgPT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGggPSBjLnRvU3RyaW5nKDE2KTtcbiAgICAgICAgaWYgKChoLmxlbmd0aCAmIDEpID09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBoO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIFwiMFwiICsgaDtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICog6ZW/5paH5pys5Yqg5a+GXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHN0cmluZyDlvoXliqDlr4bplb/mlofmnKxcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSDliqDlr4blkI7nmoRiYXNlNjTnvJbnoIFcbiAgICAgKi9cbiAgICBSU0FLZXkucHJvdG90eXBlLmVuY3J5cHRMb25nID0gZnVuY3Rpb24gKHRleHQpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIG1heExlbmd0aCA9ICgodGhpcy5uLmJpdExlbmd0aCgpICsgNykgPj4gMykgLSAxMTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHZhciBjdF8xID0gXCJcIjtcbiAgICAgICAgICAgIGlmICh0ZXh0Lmxlbmd0aCA+IG1heExlbmd0aCkge1xuICAgICAgICAgICAgICAgIHZhciBsdCA9IHRleHQubWF0Y2goLy57MSwxMTd9L2cpO1xuICAgICAgICAgICAgICAgIGx0LmZvckVhY2goZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0MSA9IF90aGlzLmVuY3J5cHQoZW50cnkpO1xuICAgICAgICAgICAgICAgICAgICBjdF8xICs9IHQxO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBoZXgyYjY0KGN0XzEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHQgPSB0aGlzLmVuY3J5cHQodGV4dCk7XG4gICAgICAgICAgICB2YXIgeSA9IGhleDJiNjQodCk7XG4gICAgICAgICAgICByZXR1cm4geTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICog6ZW/5paH5pys6Kej5a+GXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHN0cmluZyDliqDlr4blkI7nmoRiYXNlNjTnvJbnoIFcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSDop6Plr4blkI7nmoTljp/mlodcbiAgICAgKi9cbiAgICBSU0FLZXkucHJvdG90eXBlLmRlY3J5cHRMb25nID0gZnVuY3Rpb24gKHRleHQpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIG1heExlbmd0aCA9ICh0aGlzLm4uYml0TGVuZ3RoKCkgKyA3KSA+PiAzO1xuICAgICAgICB0ZXh0ID0gYjY0dG9oZXgodGV4dCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAodGV4dC5sZW5ndGggPiBtYXhMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY3RfMiA9IFwiXCI7XG4gICAgICAgICAgICAgICAgdmFyIGx0ID0gdGV4dC5tYXRjaCgvLnsxLDI1Nn0vZyk7IC8vIDEyOOS9jeino+WvhuOAguWPljI1NuS9jVxuICAgICAgICAgICAgICAgIGx0LmZvckVhY2goZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0MSA9IF90aGlzLmRlY3J5cHQoZW50cnkpO1xuICAgICAgICAgICAgICAgICAgICBjdF8yICs9IHQxO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBjdF8yO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHkgPSB0aGlzLmRlY3J5cHQodGV4dCk7XG4gICAgICAgICAgICByZXR1cm4geTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gUlNBS2V5LnByb3RvdHlwZS5zZXRQcml2YXRlID0gUlNBU2V0UHJpdmF0ZTtcbiAgICAvLyBTZXQgdGhlIHByaXZhdGUga2V5IGZpZWxkcyBOLCBlLCBhbmQgZCBmcm9tIGhleCBzdHJpbmdzXG4gICAgUlNBS2V5LnByb3RvdHlwZS5zZXRQcml2YXRlID0gZnVuY3Rpb24gKE4sIEUsIEQpIHtcbiAgICAgICAgaWYgKE4gIT0gbnVsbCAmJiBFICE9IG51bGwgJiYgTi5sZW5ndGggPiAwICYmIEUubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5uID0gcGFyc2VCaWdJbnQoTiwgMTYpO1xuICAgICAgICAgICAgdGhpcy5lID0gcGFyc2VJbnQoRSwgMTYpO1xuICAgICAgICAgICAgdGhpcy5kID0gcGFyc2VCaWdJbnQoRCwgMTYpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgUlNBIHByaXZhdGUga2V5XCIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBSU0FLZXkucHJvdG90eXBlLnNldFByaXZhdGVFeCA9IFJTQVNldFByaXZhdGVFeDtcbiAgICAvLyBTZXQgdGhlIHByaXZhdGUga2V5IGZpZWxkcyBOLCBlLCBkIGFuZCBDUlQgcGFyYW1zIGZyb20gaGV4IHN0cmluZ3NcbiAgICBSU0FLZXkucHJvdG90eXBlLnNldFByaXZhdGVFeCA9IGZ1bmN0aW9uIChOLCBFLCBELCBQLCBRLCBEUCwgRFEsIEMpIHtcbiAgICAgICAgaWYgKE4gIT0gbnVsbCAmJiBFICE9IG51bGwgJiYgTi5sZW5ndGggPiAwICYmIEUubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5uID0gcGFyc2VCaWdJbnQoTiwgMTYpO1xuICAgICAgICAgICAgdGhpcy5lID0gcGFyc2VJbnQoRSwgMTYpO1xuICAgICAgICAgICAgdGhpcy5kID0gcGFyc2VCaWdJbnQoRCwgMTYpO1xuICAgICAgICAgICAgdGhpcy5wID0gcGFyc2VCaWdJbnQoUCwgMTYpO1xuICAgICAgICAgICAgdGhpcy5xID0gcGFyc2VCaWdJbnQoUSwgMTYpO1xuICAgICAgICAgICAgdGhpcy5kbXAxID0gcGFyc2VCaWdJbnQoRFAsIDE2KTtcbiAgICAgICAgICAgIHRoaXMuZG1xMSA9IHBhcnNlQmlnSW50KERRLCAxNik7XG4gICAgICAgICAgICB0aGlzLmNvZWZmID0gcGFyc2VCaWdJbnQoQywgMTYpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgUlNBIHByaXZhdGUga2V5XCIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBSU0FLZXkucHJvdG90eXBlLmdlbmVyYXRlID0gUlNBR2VuZXJhdGU7XG4gICAgLy8gR2VuZXJhdGUgYSBuZXcgcmFuZG9tIHByaXZhdGUga2V5IEIgYml0cyBsb25nLCB1c2luZyBwdWJsaWMgZXhwdCBFXG4gICAgUlNBS2V5LnByb3RvdHlwZS5nZW5lcmF0ZSA9IGZ1bmN0aW9uIChCLCBFKSB7XG4gICAgICAgIHZhciBybmcgPSBuZXcgU2VjdXJlUmFuZG9tKCk7XG4gICAgICAgIHZhciBxcyA9IEIgPj4gMTtcbiAgICAgICAgdGhpcy5lID0gcGFyc2VJbnQoRSwgMTYpO1xuICAgICAgICB2YXIgZWUgPSBuZXcgQmlnSW50ZWdlcihFLCAxNik7XG4gICAgICAgIGZvciAoOzspIHtcbiAgICAgICAgICAgIGZvciAoOzspIHtcbiAgICAgICAgICAgICAgICB0aGlzLnAgPSBuZXcgQmlnSW50ZWdlcihCIC0gcXMsIDEsIHJuZyk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMucFxuICAgICAgICAgICAgICAgICAgICAuc3VidHJhY3QoQmlnSW50ZWdlci5PTkUpXG4gICAgICAgICAgICAgICAgICAgIC5nY2QoZWUpXG4gICAgICAgICAgICAgICAgICAgIC5jb21wYXJlVG8oQmlnSW50ZWdlci5PTkUpID09IDAgJiZcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wLmlzUHJvYmFibGVQcmltZSgxMCkpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yICg7Oykge1xuICAgICAgICAgICAgICAgIHRoaXMucSA9IG5ldyBCaWdJbnRlZ2VyKHFzLCAxLCBybmcpO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnFcbiAgICAgICAgICAgICAgICAgICAgLnN1YnRyYWN0KEJpZ0ludGVnZXIuT05FKVxuICAgICAgICAgICAgICAgICAgICAuZ2NkKGVlKVxuICAgICAgICAgICAgICAgICAgICAuY29tcGFyZVRvKEJpZ0ludGVnZXIuT05FKSA9PSAwICYmXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucS5pc1Byb2JhYmxlUHJpbWUoMTApKSB7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLnAuY29tcGFyZVRvKHRoaXMucSkgPD0gMCkge1xuICAgICAgICAgICAgICAgIHZhciB0ID0gdGhpcy5wO1xuICAgICAgICAgICAgICAgIHRoaXMucCA9IHRoaXMucTtcbiAgICAgICAgICAgICAgICB0aGlzLnEgPSB0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHAxID0gdGhpcy5wLnN1YnRyYWN0KEJpZ0ludGVnZXIuT05FKTtcbiAgICAgICAgICAgIHZhciBxMSA9IHRoaXMucS5zdWJ0cmFjdChCaWdJbnRlZ2VyLk9ORSk7XG4gICAgICAgICAgICB2YXIgcGhpID0gcDEubXVsdGlwbHkocTEpO1xuICAgICAgICAgICAgaWYgKHBoaS5nY2QoZWUpLmNvbXBhcmVUbyhCaWdJbnRlZ2VyLk9ORSkgPT0gMCkge1xuICAgICAgICAgICAgICAgIHRoaXMubiA9IHRoaXMucC5tdWx0aXBseSh0aGlzLnEpO1xuICAgICAgICAgICAgICAgIHRoaXMuZCA9IGVlLm1vZEludmVyc2UocGhpKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRtcDEgPSB0aGlzLmQubW9kKHAxKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRtcTEgPSB0aGlzLmQubW9kKHExKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNvZWZmID0gdGhpcy5xLm1vZEludmVyc2UodGhpcy5wKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gUlNBS2V5LnByb3RvdHlwZS5kZWNyeXB0ID0gUlNBRGVjcnlwdDtcbiAgICAvLyBSZXR1cm4gdGhlIFBLQ1MjMSBSU0EgZGVjcnlwdGlvbiBvZiBcImN0ZXh0XCIuXG4gICAgLy8gXCJjdGV4dFwiIGlzIGFuIGV2ZW4tbGVuZ3RoIGhleCBzdHJpbmcgYW5kIHRoZSBvdXRwdXQgaXMgYSBwbGFpbiBzdHJpbmcuXG4gICAgUlNBS2V5LnByb3RvdHlwZS5kZWNyeXB0ID0gZnVuY3Rpb24gKGN0ZXh0KSB7XG4gICAgICAgIHZhciBjID0gcGFyc2VCaWdJbnQoY3RleHQsIDE2KTtcbiAgICAgICAgdmFyIG0gPSB0aGlzLmRvUHJpdmF0ZShjKTtcbiAgICAgICAgaWYgKG0gPT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHBrY3MxdW5wYWQyKG0sICh0aGlzLm4uYml0TGVuZ3RoKCkgKyA3KSA+PiAzKTtcbiAgICB9O1xuICAgIC8vIEdlbmVyYXRlIGEgbmV3IHJhbmRvbSBwcml2YXRlIGtleSBCIGJpdHMgbG9uZywgdXNpbmcgcHVibGljIGV4cHQgRVxuICAgIFJTQUtleS5wcm90b3R5cGUuZ2VuZXJhdGVBc3luYyA9IGZ1bmN0aW9uIChCLCBFLCBjYWxsYmFjaykge1xuICAgICAgICB2YXIgcm5nID0gbmV3IFNlY3VyZVJhbmRvbSgpO1xuICAgICAgICB2YXIgcXMgPSBCID4+IDE7XG4gICAgICAgIHRoaXMuZSA9IHBhcnNlSW50KEUsIDE2KTtcbiAgICAgICAgdmFyIGVlID0gbmV3IEJpZ0ludGVnZXIoRSwgMTYpO1xuICAgICAgICB2YXIgcnNhID0gdGhpcztcbiAgICAgICAgLy8gVGhlc2UgZnVuY3Rpb25zIGhhdmUgbm9uLWRlc2NyaXB0IG5hbWVzIGJlY2F1c2UgdGhleSB3ZXJlIG9yaWdpbmFsbHkgZm9yKDs7KSBsb29wcy5cbiAgICAgICAgLy8gSSBkb24ndCBrbm93IGFib3V0IGNyeXB0b2dyYXBoeSB0byBnaXZlIHRoZW0gYmV0dGVyIG5hbWVzIHRoYW4gbG9vcDEtNC5cbiAgICAgICAgdmFyIGxvb3AxID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGxvb3A0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGlmIChyc2EucC5jb21wYXJlVG8ocnNhLnEpIDw9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHQgPSByc2EucDtcbiAgICAgICAgICAgICAgICAgICAgcnNhLnAgPSByc2EucTtcbiAgICAgICAgICAgICAgICAgICAgcnNhLnEgPSB0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgcDEgPSByc2EucC5zdWJ0cmFjdChCaWdJbnRlZ2VyLk9ORSk7XG4gICAgICAgICAgICAgICAgdmFyIHExID0gcnNhLnEuc3VidHJhY3QoQmlnSW50ZWdlci5PTkUpO1xuICAgICAgICAgICAgICAgIHZhciBwaGkgPSBwMS5tdWx0aXBseShxMSk7XG4gICAgICAgICAgICAgICAgaWYgKHBoaS5nY2QoZWUpLmNvbXBhcmVUbyhCaWdJbnRlZ2VyLk9ORSkgPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICByc2EubiA9IHJzYS5wLm11bHRpcGx5KHJzYS5xKTtcbiAgICAgICAgICAgICAgICAgICAgcnNhLmQgPSBlZS5tb2RJbnZlcnNlKHBoaSk7XG4gICAgICAgICAgICAgICAgICAgIHJzYS5kbXAxID0gcnNhLmQubW9kKHAxKTtcbiAgICAgICAgICAgICAgICAgICAgcnNhLmRtcTEgPSByc2EuZC5tb2QocTEpO1xuICAgICAgICAgICAgICAgICAgICByc2EuY29lZmYgPSByc2EucS5tb2RJbnZlcnNlKHJzYS5wKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgICAgICB9LCAwKTsgLy8gZXNjYXBlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGxvb3AxLCAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdmFyIGxvb3AzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJzYS5xID0gbmJpKCk7XG4gICAgICAgICAgICAgICAgcnNhLnEuZnJvbU51bWJlckFzeW5jKHFzLCAxLCBybmcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgcnNhLnEuc3VidHJhY3QoQmlnSW50ZWdlci5PTkUpLmdjZGEoZWUsIGZ1bmN0aW9uIChyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5jb21wYXJlVG8oQmlnSW50ZWdlci5PTkUpID09IDAgJiYgcnNhLnEuaXNQcm9iYWJsZVByaW1lKDEwKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQobG9vcDQsIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChsb29wMywgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHZhciBsb29wMiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByc2EucCA9IG5iaSgpO1xuICAgICAgICAgICAgICAgIHJzYS5wLmZyb21OdW1iZXJBc3luYyhCIC0gcXMsIDEsIHJuZywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICByc2EucC5zdWJ0cmFjdChCaWdJbnRlZ2VyLk9ORSkuZ2NkYShlZSwgZnVuY3Rpb24gKHIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyLmNvbXBhcmVUbyhCaWdJbnRlZ2VyLk9ORSkgPT0gMCAmJiByc2EucC5pc1Byb2JhYmxlUHJpbWUoMTApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChsb29wMywgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGxvb3AyLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgc2V0VGltZW91dChsb29wMiwgMCk7XG4gICAgICAgIH07XG4gICAgICAgIHNldFRpbWVvdXQobG9vcDEsIDApO1xuICAgIH07XG4gICAgUlNBS2V5LnByb3RvdHlwZS5zaWduID0gZnVuY3Rpb24gKHRleHQsIGRpZ2VzdE1ldGhvZCwgZGlnZXN0TmFtZSkge1xuICAgICAgICB2YXIgaGVhZGVyID0gZ2V0RGlnZXN0SGVhZGVyKGRpZ2VzdE5hbWUpO1xuICAgICAgICB2YXIgZGlnZXN0ID0gaGVhZGVyICsgZGlnZXN0TWV0aG9kKHRleHQpLnRvU3RyaW5nKCk7XG4gICAgICAgIHZhciBtID0gcGtjczFwYWQxKGRpZ2VzdCwgdGhpcy5uLmJpdExlbmd0aCgpIC8gNCk7XG4gICAgICAgIGlmIChtID09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHZhciBjID0gdGhpcy5kb1ByaXZhdGUobSk7XG4gICAgICAgIGlmIChjID09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHZhciBoID0gYy50b1N0cmluZygxNik7XG4gICAgICAgIGlmICgoaC5sZW5ndGggJiAxKSA9PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gaDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBcIjBcIiArIGg7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFJTQUtleS5wcm90b3R5cGUudmVyaWZ5ID0gZnVuY3Rpb24gKHRleHQsIHNpZ25hdHVyZSwgZGlnZXN0TWV0aG9kKSB7XG4gICAgICAgIHZhciBjID0gcGFyc2VCaWdJbnQoc2lnbmF0dXJlLCAxNik7XG4gICAgICAgIHZhciBtID0gdGhpcy5kb1B1YmxpYyhjKTtcbiAgICAgICAgaWYgKG0gPT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHVucGFkZGVkID0gbS50b1N0cmluZygxNikucmVwbGFjZSgvXjFmKzAwLywgXCJcIik7XG4gICAgICAgIHZhciBkaWdlc3QgPSByZW1vdmVEaWdlc3RIZWFkZXIodW5wYWRkZWQpO1xuICAgICAgICByZXR1cm4gZGlnZXN0ID09IGRpZ2VzdE1ldGhvZCh0ZXh0KS50b1N0cmluZygpO1xuICAgIH07XG4gICAgcmV0dXJuIFJTQUtleTtcbn0oKSk7XG4vLyBVbmRvIFBLQ1MjMSAodHlwZSAyLCByYW5kb20pIHBhZGRpbmcgYW5kLCBpZiB2YWxpZCwgcmV0dXJuIHRoZSBwbGFpbnRleHRcbmZ1bmN0aW9uIHBrY3MxdW5wYWQyKGQsIG4pIHtcbiAgICB2YXIgYiA9IGQudG9CeXRlQXJyYXkoKTtcbiAgICB2YXIgaSA9IDA7XG4gICAgd2hpbGUgKGkgPCBiLmxlbmd0aCAmJiBiW2ldID09IDApIHtcbiAgICAgICAgKytpO1xuICAgIH1cbiAgICBpZiAoYi5sZW5ndGggLSBpICE9IG4gLSAxIHx8IGJbaV0gIT0gMikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgKytpO1xuICAgIHdoaWxlIChiW2ldICE9IDApIHtcbiAgICAgICAgaWYgKCsraSA+PSBiLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdmFyIHJldCA9IFwiXCI7XG4gICAgd2hpbGUgKCsraSA8IGIubGVuZ3RoKSB7XG4gICAgICAgIHZhciBjID0gYltpXSAmIDI1NTtcbiAgICAgICAgaWYgKGMgPCAxMjgpIHtcbiAgICAgICAgICAgIC8vIHV0Zi04IGRlY29kZVxuICAgICAgICAgICAgcmV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYyA+IDE5MSAmJiBjIDwgMjI0KSB7XG4gICAgICAgICAgICByZXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZSgoKGMgJiAzMSkgPDwgNikgfCAoYltpICsgMV0gJiA2MykpO1xuICAgICAgICAgICAgKytpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKChjICYgMTUpIDw8IDEyKSB8ICgoYltpICsgMV0gJiA2MykgPDwgNikgfCAoYltpICsgMl0gJiA2MykpO1xuICAgICAgICAgICAgaSArPSAyO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG59XG4vLyBodHRwczovL3Rvb2xzLmlldGYub3JnL2h0bWwvcmZjMzQ0NyNwYWdlLTQzXG52YXIgRElHRVNUX0hFQURFUlMgPSB7XG4gICAgbWQyOiBcIjMwMjAzMDBjMDYwODJhODY0ODg2ZjcwZDAyMDIwNTAwMDQxMFwiLFxuICAgIG1kNTogXCIzMDIwMzAwYzA2MDgyYTg2NDg4NmY3MGQwMjA1MDUwMDA0MTBcIixcbiAgICBzaGExOiBcIjMwMjEzMDA5MDYwNTJiMGUwMzAyMWEwNTAwMDQxNFwiLFxuICAgIHNoYTIyNDogXCIzMDJkMzAwZDA2MDk2MDg2NDgwMTY1MDMwNDAyMDQwNTAwMDQxY1wiLFxuICAgIHNoYTI1NjogXCIzMDMxMzAwZDA2MDk2MDg2NDgwMTY1MDMwNDAyMDEwNTAwMDQyMFwiLFxuICAgIHNoYTM4NDogXCIzMDQxMzAwZDA2MDk2MDg2NDgwMTY1MDMwNDAyMDIwNTAwMDQzMFwiLFxuICAgIHNoYTUxMjogXCIzMDUxMzAwZDA2MDk2MDg2NDgwMTY1MDMwNDAyMDMwNTAwMDQ0MFwiLFxuICAgIHJpcGVtZDE2MDogXCIzMDIxMzAwOTA2MDUyYjI0MDMwMjAxMDUwMDA0MTRcIlxufTtcbmZ1bmN0aW9uIGdldERpZ2VzdEhlYWRlcihuYW1lKSB7XG4gICAgcmV0dXJuIERJR0VTVF9IRUFERVJTW25hbWVdIHx8IFwiXCI7XG59XG5mdW5jdGlvbiByZW1vdmVEaWdlc3RIZWFkZXIoc3RyKSB7XG4gICAgZm9yICh2YXIgbmFtZV8xIGluIERJR0VTVF9IRUFERVJTKSB7XG4gICAgICAgIGlmIChESUdFU1RfSEVBREVSUy5oYXNPd25Qcm9wZXJ0eShuYW1lXzEpKSB7XG4gICAgICAgICAgICB2YXIgaGVhZGVyID0gRElHRVNUX0hFQURFUlNbbmFtZV8xXTtcbiAgICAgICAgICAgIHZhciBsZW4gPSBoZWFkZXIubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKHN0ci5zdWJzdHIoMCwgbGVuKSA9PSBoZWFkZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc3RyLnN1YnN0cihsZW4pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG59XG4vLyBSZXR1cm4gdGhlIFBLQ1MjMSBSU0EgZW5jcnlwdGlvbiBvZiBcInRleHRcIiBhcyBhIEJhc2U2NC1lbmNvZGVkIHN0cmluZ1xuLy8gZnVuY3Rpb24gUlNBRW5jcnlwdEI2NCh0ZXh0KSB7XG4vLyAgdmFyIGggPSB0aGlzLmVuY3J5cHQodGV4dCk7XG4vLyAgaWYoaCkgcmV0dXJuIGhleDJiNjQoaCk7IGVsc2UgcmV0dXJuIG51bGw7XG4vLyB9XG4vLyBwdWJsaWNcbi8vIFJTQUtleS5wcm90b3R5cGUuZW5jcnlwdF9iNjQgPSBSU0FFbmNyeXB0QjY0O1xuXG4vKiFcbkNvcHlyaWdodCAoYykgMjAxMSwgWWFob28hIEluYy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbkNvZGUgbGljZW5zZWQgdW5kZXIgdGhlIEJTRCBMaWNlbnNlOlxuaHR0cDovL2RldmVsb3Blci55YWhvby5jb20veXVpL2xpY2Vuc2UuaHRtbFxudmVyc2lvbjogMi45LjBcbiovXG52YXIgWUFIT08gPSB7fTtcbllBSE9PLmxhbmcgPSB7XG4gICAgLyoqXG4gICAgICogVXRpbGl0eSB0byBzZXQgdXAgdGhlIHByb3RvdHlwZSwgY29uc3RydWN0b3IgYW5kIHN1cGVyY2xhc3MgcHJvcGVydGllcyB0b1xuICAgICAqIHN1cHBvcnQgYW4gaW5oZXJpdGFuY2Ugc3RyYXRlZ3kgdGhhdCBjYW4gY2hhaW4gY29uc3RydWN0b3JzIGFuZCBtZXRob2RzLlxuICAgICAqIFN0YXRpYyBtZW1iZXJzIHdpbGwgbm90IGJlIGluaGVyaXRlZC5cbiAgICAgKlxuICAgICAqIEBtZXRob2QgZXh0ZW5kXG4gICAgICogQHN0YXRpY1xuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IHN1YmMgICB0aGUgb2JqZWN0IHRvIG1vZGlmeVxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IHN1cGVyYyB0aGUgb2JqZWN0IHRvIGluaGVyaXRcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gb3ZlcnJpZGVzICBhZGRpdGlvbmFsIHByb3BlcnRpZXMvbWV0aG9kcyB0byBhZGQgdG8gdGhlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJjbGFzcyBwcm90b3R5cGUuICBUaGVzZSB3aWxsIG92ZXJyaWRlIHRoZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF0Y2hpbmcgaXRlbXMgb2J0YWluZWQgZnJvbSB0aGUgc3VwZXJjbGFzc1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgcHJlc2VudC5cbiAgICAgKi9cbiAgICBleHRlbmQ6IGZ1bmN0aW9uKHN1YmMsIHN1cGVyYywgb3ZlcnJpZGVzKSB7XG4gICAgICAgIGlmICghIHN1cGVyYyB8fCAhIHN1YmMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIllBSE9PLmxhbmcuZXh0ZW5kIGZhaWxlZCwgcGxlYXNlIGNoZWNrIHRoYXQgXCIgK1xuICAgICAgICAgICAgICAgIFwiYWxsIGRlcGVuZGVuY2llcyBhcmUgaW5jbHVkZWQuXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIEYgPSBmdW5jdGlvbigpIHt9O1xuICAgICAgICBGLnByb3RvdHlwZSA9IHN1cGVyYy5wcm90b3R5cGU7XG4gICAgICAgIHN1YmMucHJvdG90eXBlID0gbmV3IEYoKTtcbiAgICAgICAgc3ViYy5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBzdWJjO1xuICAgICAgICBzdWJjLnN1cGVyY2xhc3MgPSBzdXBlcmMucHJvdG90eXBlO1xuXG4gICAgICAgIGlmIChzdXBlcmMucHJvdG90eXBlLmNvbnN0cnVjdG9yID09IE9iamVjdC5wcm90b3R5cGUuY29uc3RydWN0b3IpIHtcbiAgICAgICAgICAgIHN1cGVyYy5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBzdXBlcmM7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAob3ZlcnJpZGVzKSB7XG4gICAgICAgICAgICB2YXIgaTtcbiAgICAgICAgICAgIGZvciAoaSBpbiBvdmVycmlkZXMpIHtcbiAgICAgICAgICAgICAgICBzdWJjLnByb3RvdHlwZVtpXSA9IG92ZXJyaWRlc1tpXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAqIElFIHdpbGwgbm90IGVudW1lcmF0ZSBuYXRpdmUgZnVuY3Rpb25zIGluIGEgZGVyaXZlZCBvYmplY3QgZXZlbiBpZiB0aGVcbiAgICAgICAgICAgICAqIGZ1bmN0aW9uIHdhcyBvdmVycmlkZGVuLiAgVGhpcyBpcyBhIHdvcmthcm91bmQgZm9yIHNwZWNpZmljIGZ1bmN0aW9uc1xuICAgICAgICAgICAgICogd2UgY2FyZSBhYm91dCBvbiB0aGUgT2JqZWN0IHByb3RvdHlwZS5cbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSBfSUVFbnVtRml4XG4gICAgICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSByICB0aGUgb2JqZWN0IHRvIHJlY2VpdmUgdGhlIGF1Z21lbnRhdGlvblxuICAgICAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gcyAgdGhlIG9iamVjdCB0aGF0IHN1cHBsaWVzIHRoZSBwcm9wZXJ0aWVzIHRvIGF1Z21lbnRcbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwcml2YXRlXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIHZhciBfSUVFbnVtRml4ID0gZnVuY3Rpb24oKSB7fSxcbiAgICAgICAgICAgICAgICBBREQgPSBbXCJ0b1N0cmluZ1wiLCBcInZhbHVlT2ZcIl07XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmICgvTVNJRS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSkge1xuICAgICAgICAgICAgICAgICAgICBfSUVFbnVtRml4ID0gZnVuY3Rpb24ociwgcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IEFERC5sZW5ndGg7IGkgPSBpICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBmbmFtZSA9IEFERFtpXSwgZiA9IHNbZm5hbWVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZiA9PT0gJ2Z1bmN0aW9uJyAmJiBmICE9IE9iamVjdC5wcm90b3R5cGVbZm5hbWVdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJbZm5hbWVdID0gZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXgpIHt9ICAgICAgICAgICAgX0lFRW51bUZpeChzdWJjLnByb3RvdHlwZSwgb3ZlcnJpZGVzKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5cbi8qIGFzbjEtMS4wLjEzLmpzIChjKSAyMDEzLTIwMTcgS2VuamkgVXJ1c2hpbWEgfCBranVyLmdpdGh1Yi5jb20vanNyc2FzaWduL2xpY2Vuc2VcbiAqL1xuXG4vKipcbiAqIEBmaWxlT3ZlcnZpZXdcbiAqIEBuYW1lIGFzbjEtMS4wLmpzXG4gKiBAYXV0aG9yIEtlbmppIFVydXNoaW1hIGtlbmppLnVydXNoaW1hQGdtYWlsLmNvbVxuICogQHZlcnNpb24gYXNuMSAxLjAuMTMgKDIwMTctSnVuLTAyKVxuICogQHNpbmNlIGpzcnNhc2lnbiAyLjFcbiAqIEBsaWNlbnNlIDxhIGhyZWY9XCJodHRwczovL2tqdXIuZ2l0aHViLmlvL2pzcnNhc2lnbi9saWNlbnNlL1wiPk1JVCBMaWNlbnNlPC9hPlxuICovXG5cbi8qKlxuICoga2p1cidzIGNsYXNzIGxpYnJhcnkgbmFtZSBzcGFjZVxuICogPHA+XG4gKiBUaGlzIG5hbWUgc3BhY2UgcHJvdmlkZXMgZm9sbG93aW5nIG5hbWUgc3BhY2VzOlxuICogPHVsPlxuICogPGxpPntAbGluayBLSlVSLmFzbjF9IC0gQVNOLjEgcHJpbWl0aXZlIGhleGFkZWNpbWFsIGVuY29kZXI8L2xpPlxuICogPGxpPntAbGluayBLSlVSLmFzbjEueDUwOX0gLSBBU04uMSBzdHJ1Y3R1cmUgZm9yIFguNTA5IGNlcnRpZmljYXRlIGFuZCBDUkw8L2xpPlxuICogPGxpPntAbGluayBLSlVSLmNyeXB0b30gLSBKYXZhIENyeXB0b2dyYXBoaWMgRXh0ZW5zaW9uKEpDRSkgc3R5bGUgTWVzc2FnZURpZ2VzdC9TaWduYXR1cmVcbiAqIGNsYXNzIGFuZCB1dGlsaXRpZXM8L2xpPlxuICogPC91bD5cbiAqIDwvcD5cbiAqIE5PVEU6IFBsZWFzZSBpZ25vcmUgbWV0aG9kIHN1bW1hcnkgYW5kIGRvY3VtZW50IG9mIHRoaXMgbmFtZXNwYWNlLiBUaGlzIGNhdXNlZCBieSBhIGJ1ZyBvZiBqc2RvYzIuXG4gKiBAbmFtZSBLSlVSXG4gKiBAbmFtZXNwYWNlIGtqdXIncyBjbGFzcyBsaWJyYXJ5IG5hbWUgc3BhY2VcbiAqL1xudmFyIEtKVVIgPSB7fTtcblxuLyoqXG4gKiBranVyJ3MgQVNOLjEgY2xhc3MgbGlicmFyeSBuYW1lIHNwYWNlXG4gKiA8cD5cbiAqIFRoaXMgaXMgSVRVLVQgWC42OTAgQVNOLjEgREVSIGVuY29kZXIgY2xhc3MgbGlicmFyeSBhbmRcbiAqIGNsYXNzIHN0cnVjdHVyZSBhbmQgbWV0aG9kcyBpcyB2ZXJ5IHNpbWlsYXIgdG9cbiAqIG9yZy5ib3VuY3ljYXN0bGUuYXNuMSBwYWNrYWdlIG9mXG4gKiB3ZWxsIGtub3duIEJvdW5jeUNhc2x0ZSBDcnlwdG9ncmFwaHkgTGlicmFyeS5cbiAqIDxoND5QUk9WSURJTkcgQVNOLjEgUFJJTUlUSVZFUzwvaDQ+XG4gKiBIZXJlIGFyZSBBU04uMSBERVIgcHJpbWl0aXZlIGNsYXNzZXMuXG4gKiA8dWw+XG4gKiA8bGk+MHgwMSB7QGxpbmsgS0pVUi5hc24xLkRFUkJvb2xlYW59PC9saT5cbiAqIDxsaT4weDAyIHtAbGluayBLSlVSLmFzbjEuREVSSW50ZWdlcn08L2xpPlxuICogPGxpPjB4MDMge0BsaW5rIEtKVVIuYXNuMS5ERVJCaXRTdHJpbmd9PC9saT5cbiAqIDxsaT4weDA0IHtAbGluayBLSlVSLmFzbjEuREVST2N0ZXRTdHJpbmd9PC9saT5cbiAqIDxsaT4weDA1IHtAbGluayBLSlVSLmFzbjEuREVSTnVsbH08L2xpPlxuICogPGxpPjB4MDYge0BsaW5rIEtKVVIuYXNuMS5ERVJPYmplY3RJZGVudGlmaWVyfTwvbGk+XG4gKiA8bGk+MHgwYSB7QGxpbmsgS0pVUi5hc24xLkRFUkVudW1lcmF0ZWR9PC9saT5cbiAqIDxsaT4weDBjIHtAbGluayBLSlVSLmFzbjEuREVSVVRGOFN0cmluZ308L2xpPlxuICogPGxpPjB4MTIge0BsaW5rIEtKVVIuYXNuMS5ERVJOdW1lcmljU3RyaW5nfTwvbGk+XG4gKiA8bGk+MHgxMyB7QGxpbmsgS0pVUi5hc24xLkRFUlByaW50YWJsZVN0cmluZ308L2xpPlxuICogPGxpPjB4MTQge0BsaW5rIEtKVVIuYXNuMS5ERVJUZWxldGV4U3RyaW5nfTwvbGk+XG4gKiA8bGk+MHgxNiB7QGxpbmsgS0pVUi5hc24xLkRFUklBNVN0cmluZ308L2xpPlxuICogPGxpPjB4MTcge0BsaW5rIEtKVVIuYXNuMS5ERVJVVENUaW1lfTwvbGk+XG4gKiA8bGk+MHgxOCB7QGxpbmsgS0pVUi5hc24xLkRFUkdlbmVyYWxpemVkVGltZX08L2xpPlxuICogPGxpPjB4MzAge0BsaW5rIEtKVVIuYXNuMS5ERVJTZXF1ZW5jZX08L2xpPlxuICogPGxpPjB4MzEge0BsaW5rIEtKVVIuYXNuMS5ERVJTZXR9PC9saT5cbiAqIDwvdWw+XG4gKiA8aDQ+T1RIRVIgQVNOLjEgQ0xBU1NFUzwvaDQ+XG4gKiA8dWw+XG4gKiA8bGk+e0BsaW5rIEtKVVIuYXNuMS5BU04xT2JqZWN0fTwvbGk+XG4gKiA8bGk+e0BsaW5rIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZ308L2xpPlxuICogPGxpPntAbGluayBLSlVSLmFzbjEuREVSQWJzdHJhY3RUaW1lfTwvbGk+XG4gKiA8bGk+e0BsaW5rIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cnVjdHVyZWR9PC9saT5cbiAqIDxsaT57QGxpbmsgS0pVUi5hc24xLkRFUlRhZ2dlZE9iamVjdH08L2xpPlxuICogPC91bD5cbiAqIDxoND5TVUIgTkFNRSBTUEFDRVM8L2g0PlxuICogPHVsPlxuICogPGxpPntAbGluayBLSlVSLmFzbjEuY2FkZXN9IC0gQ0FkRVMgbG9uZyB0ZXJtIHNpZ25hdHVyZSBmb3JtYXQ8L2xpPlxuICogPGxpPntAbGluayBLSlVSLmFzbjEuY21zfSAtIENyeXB0b2dyYXBoaWMgTWVzc2FnZSBTeW50YXg8L2xpPlxuICogPGxpPntAbGluayBLSlVSLmFzbjEuY3NyfSAtIENlcnRpZmljYXRlIFNpZ25pbmcgUmVxdWVzdCAoQ1NSL1BLQ1MjMTApPC9saT5cbiAqIDxsaT57QGxpbmsgS0pVUi5hc24xLnRzcH0gLSBSRkMgMzE2MSBUaW1lc3RhbXBpbmcgUHJvdG9jb2wgRm9ybWF0PC9saT5cbiAqIDxsaT57QGxpbmsgS0pVUi5hc24xLng1MDl9IC0gUkZDIDUyODAgWC41MDkgY2VydGlmaWNhdGUgYW5kIENSTDwvbGk+XG4gKiA8L3VsPlxuICogPC9wPlxuICogTk9URTogUGxlYXNlIGlnbm9yZSBtZXRob2Qgc3VtbWFyeSBhbmQgZG9jdW1lbnQgb2YgdGhpcyBuYW1lc3BhY2UuXG4gKiBUaGlzIGNhdXNlZCBieSBhIGJ1ZyBvZiBqc2RvYzIuXG4gKiBAbmFtZSBLSlVSLmFzbjFcbiAqIEBuYW1lc3BhY2VcbiAqL1xuaWYgKHR5cGVvZiBLSlVSLmFzbjEgPT0gXCJ1bmRlZmluZWRcIiB8fCAhS0pVUi5hc24xKSBLSlVSLmFzbjEgPSB7fTtcblxuLyoqXG4gKiBBU04xIHV0aWxpdGllcyBjbGFzc1xuICogQG5hbWUgS0pVUi5hc24xLkFTTjFVdGlsXG4gKiBAY2xhc3MgQVNOMSB1dGlsaXRpZXMgY2xhc3NcbiAqIEBzaW5jZSBhc24xIDEuMC4yXG4gKi9cbktKVVIuYXNuMS5BU04xVXRpbCA9IG5ldyBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmludGVnZXJUb0J5dGVIZXggPSBmdW5jdGlvbihpKSB7XG4gICAgICAgIHZhciBoID0gaS50b1N0cmluZygxNik7XG4gICAgICAgIGlmICgoaC5sZW5ndGggJSAyKSA9PSAxKSBoID0gJzAnICsgaDtcbiAgICAgICAgcmV0dXJuIGg7XG4gICAgfTtcbiAgICB0aGlzLmJpZ0ludFRvTWluVHdvc0NvbXBsZW1lbnRzSGV4ID0gZnVuY3Rpb24oYmlnSW50ZWdlclZhbHVlKSB7XG4gICAgICAgIHZhciBoID0gYmlnSW50ZWdlclZhbHVlLnRvU3RyaW5nKDE2KTtcbiAgICAgICAgaWYgKGguc3Vic3RyKDAsIDEpICE9ICctJykge1xuICAgICAgICAgICAgaWYgKGgubGVuZ3RoICUgMiA9PSAxKSB7XG4gICAgICAgICAgICAgICAgaCA9ICcwJyArIGg7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmICghIGgubWF0Y2goL15bMC03XS8pKSB7XG4gICAgICAgICAgICAgICAgICAgIGggPSAnMDAnICsgaDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgaFBvcyA9IGguc3Vic3RyKDEpO1xuICAgICAgICAgICAgdmFyIHhvckxlbiA9IGhQb3MubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKHhvckxlbiAlIDIgPT0gMSkge1xuICAgICAgICAgICAgICAgIHhvckxlbiArPSAxO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoISBoLm1hdGNoKC9eWzAtN10vKSkge1xuICAgICAgICAgICAgICAgICAgICB4b3JMZW4gKz0gMjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgaE1hc2sgPSAnJztcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgeG9yTGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICBoTWFzayArPSAnZic7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgYmlNYXNrID0gbmV3IEJpZ0ludGVnZXIoaE1hc2ssIDE2KTtcbiAgICAgICAgICAgIHZhciBiaU5lZyA9IGJpTWFzay54b3IoYmlnSW50ZWdlclZhbHVlKS5hZGQoQmlnSW50ZWdlci5PTkUpO1xuICAgICAgICAgICAgaCA9IGJpTmVnLnRvU3RyaW5nKDE2KS5yZXBsYWNlKC9eLS8sICcnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaDtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIGdldCBQRU0gc3RyaW5nIGZyb20gaGV4YWRlY2ltYWwgZGF0YSBhbmQgaGVhZGVyIHN0cmluZ1xuICAgICAqIEBuYW1lIGdldFBFTVN0cmluZ0Zyb21IZXhcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkFTTjFVdGlsXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtTdHJpbmd9IGRhdGFIZXggaGV4YWRlY2ltYWwgc3RyaW5nIG9mIFBFTSBib2R5XG4gICAgICogQHBhcmFtIHtTdHJpbmd9IHBlbUhlYWRlciBQRU0gaGVhZGVyIHN0cmluZyAoZXguICdSU0EgUFJJVkFURSBLRVknKVxuICAgICAqIEByZXR1cm4ge1N0cmluZ30gUEVNIGZvcm1hdHRlZCBzdHJpbmcgb2YgaW5wdXQgZGF0YVxuICAgICAqIEBkZXNjcmlwdGlvblxuICAgICAqIFRoaXMgbWV0aG9kIGNvbnZlcnRzIGEgaGV4YWRlY2ltYWwgc3RyaW5nIHRvIGEgUEVNIHN0cmluZyB3aXRoXG4gICAgICogYSBzcGVjaWZpZWQgaGVhZGVyLiBJdHMgbGluZSBicmVhayB3aWxsIGJlIENSTEYoXCJcXHJcXG5cIikuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiB2YXIgcGVtICA9IEtKVVIuYXNuMS5BU04xVXRpbC5nZXRQRU1TdHJpbmdGcm9tSGV4KCc2MTYxNjEnLCAnUlNBIFBSSVZBVEUgS0VZJyk7XG4gICAgICogLy8gdmFsdWUgb2YgcGVtIHdpbGwgYmU6XG4gICAgICogLS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tXG4gICAgICogWVdGaFxuICAgICAqIC0tLS0tRU5EIFBSSVZBVEUgS0VZLS0tLS1cbiAgICAgKi9cbiAgICB0aGlzLmdldFBFTVN0cmluZ0Zyb21IZXggPSBmdW5jdGlvbihkYXRhSGV4LCBwZW1IZWFkZXIpIHtcbiAgICAgICAgcmV0dXJuIGhleHRvcGVtKGRhdGFIZXgsIHBlbUhlYWRlcik7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIGdlbmVyYXRlIEFTTjFPYmplY3Qgc3BlY2lmZWQgYnkgSlNPTiBwYXJhbWV0ZXJzXG4gICAgICogQG5hbWUgbmV3T2JqZWN0XG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5BU04xVXRpbFxuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtIEpTT04gcGFyYW1ldGVyIHRvIGdlbmVyYXRlIEFTTjFPYmplY3RcbiAgICAgKiBAcmV0dXJuIHtLSlVSLmFzbjEuQVNOMU9iamVjdH0gZ2VuZXJhdGVkIG9iamVjdFxuICAgICAqIEBzaW5jZSBhc24xIDEuMC4zXG4gICAgICogQGRlc2NyaXB0aW9uXG4gICAgICogZ2VuZXJhdGUgYW55IEFTTjFPYmplY3Qgc3BlY2lmaWVkIGJ5IEpTT04gcGFyYW1cbiAgICAgKiBpbmNsdWRpbmcgQVNOLjEgcHJpbWl0aXZlIG9yIHN0cnVjdHVyZWQuXG4gICAgICogR2VuZXJhbGx5ICdwYXJhbScgY2FuIGJlIGRlc2NyaWJlZCBhcyBmb2xsb3dzOlxuICAgICAqIDxibG9ja3F1b3RlPlxuICAgICAqIHtUWVBFLU9GLUFTTk9CSjogQVNOMU9CSi1QQVJBTUVURVJ9XG4gICAgICogPC9ibG9ja3F1b3RlPlxuICAgICAqICdUWVBFLU9GLUFTTjFPQkonIGNhbiBiZSBvbmUgb2YgZm9sbG93aW5nIHN5bWJvbHM6XG4gICAgICogPHVsPlxuICAgICAqIDxsaT4nYm9vbCcgLSBERVJCb29sZWFuPC9saT5cbiAgICAgKiA8bGk+J2ludCcgLSBERVJJbnRlZ2VyPC9saT5cbiAgICAgKiA8bGk+J2JpdHN0cicgLSBERVJCaXRTdHJpbmc8L2xpPlxuICAgICAqIDxsaT4nb2N0c3RyJyAtIERFUk9jdGV0U3RyaW5nPC9saT5cbiAgICAgKiA8bGk+J251bGwnIC0gREVSTnVsbDwvbGk+XG4gICAgICogPGxpPidvaWQnIC0gREVST2JqZWN0SWRlbnRpZmllcjwvbGk+XG4gICAgICogPGxpPidlbnVtJyAtIERFUkVudW1lcmF0ZWQ8L2xpPlxuICAgICAqIDxsaT4ndXRmOHN0cicgLSBERVJVVEY4U3RyaW5nPC9saT5cbiAgICAgKiA8bGk+J251bXN0cicgLSBERVJOdW1lcmljU3RyaW5nPC9saT5cbiAgICAgKiA8bGk+J3BybnN0cicgLSBERVJQcmludGFibGVTdHJpbmc8L2xpPlxuICAgICAqIDxsaT4ndGVsc3RyJyAtIERFUlRlbGV0ZXhTdHJpbmc8L2xpPlxuICAgICAqIDxsaT4naWE1c3RyJyAtIERFUklBNVN0cmluZzwvbGk+XG4gICAgICogPGxpPid1dGN0aW1lJyAtIERFUlVUQ1RpbWU8L2xpPlxuICAgICAqIDxsaT4nZ2VudGltZScgLSBERVJHZW5lcmFsaXplZFRpbWU8L2xpPlxuICAgICAqIDxsaT4nc2VxJyAtIERFUlNlcXVlbmNlPC9saT5cbiAgICAgKiA8bGk+J3NldCcgLSBERVJTZXQ8L2xpPlxuICAgICAqIDxsaT4ndGFnJyAtIERFUlRhZ2dlZE9iamVjdDwvbGk+XG4gICAgICogPC91bD5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIG5ld09iamVjdCh7J3BybnN0cic6ICdhYWEnfSk7XG4gICAgICogbmV3T2JqZWN0KHsnc2VxJzogW3snaW50JzogM30sIHsncHJuc3RyJzogJ2FhYSd9XX0pXG4gICAgICogLy8gQVNOLjEgVGFnZ2VkIE9iamVjdFxuICAgICAqIG5ld09iamVjdCh7J3RhZyc6IHsndGFnJzogJ2ExJyxcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgJ2V4cGxpY2l0JzogdHJ1ZSxcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgJ29iaic6IHsnc2VxJzogW3snaW50JzogM30sIHsncHJuc3RyJzogJ2FhYSd9XX19fSk7XG4gICAgICogLy8gbW9yZSBzaW1wbGUgcmVwcmVzZW50YXRpb24gb2YgQVNOLjEgVGFnZ2VkIE9iamVjdFxuICAgICAqIG5ld09iamVjdCh7J3RhZyc6IFsnYTEnLFxuICAgICAqICAgICAgICAgICAgICAgICAgICB0cnVlLFxuICAgICAqICAgICAgICAgICAgICAgICAgICB7J3NlcSc6IFtcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICB7J2ludCc6IDN9LFxuICAgICAqICAgICAgICAgICAgICAgICAgICAgIHsncHJuc3RyJzogJ2FhYSd9XX1cbiAgICAgKiAgICAgICAgICAgICAgICAgICBdfSk7XG4gICAgICovXG4gICAgdGhpcy5uZXdPYmplY3QgPSBmdW5jdGlvbihwYXJhbSkge1xuICAgICAgICB2YXIgX0tKVVIgPSBLSlVSLFxuICAgICAgICAgICAgX0tKVVJfYXNuMSA9IF9LSlVSLmFzbjEsXG4gICAgICAgICAgICBfREVSQm9vbGVhbiA9IF9LSlVSX2FzbjEuREVSQm9vbGVhbixcbiAgICAgICAgICAgIF9ERVJJbnRlZ2VyID0gX0tKVVJfYXNuMS5ERVJJbnRlZ2VyLFxuICAgICAgICAgICAgX0RFUkJpdFN0cmluZyA9IF9LSlVSX2FzbjEuREVSQml0U3RyaW5nLFxuICAgICAgICAgICAgX0RFUk9jdGV0U3RyaW5nID0gX0tKVVJfYXNuMS5ERVJPY3RldFN0cmluZyxcbiAgICAgICAgICAgIF9ERVJOdWxsID0gX0tKVVJfYXNuMS5ERVJOdWxsLFxuICAgICAgICAgICAgX0RFUk9iamVjdElkZW50aWZpZXIgPSBfS0pVUl9hc24xLkRFUk9iamVjdElkZW50aWZpZXIsXG4gICAgICAgICAgICBfREVSRW51bWVyYXRlZCA9IF9LSlVSX2FzbjEuREVSRW51bWVyYXRlZCxcbiAgICAgICAgICAgIF9ERVJVVEY4U3RyaW5nID0gX0tKVVJfYXNuMS5ERVJVVEY4U3RyaW5nLFxuICAgICAgICAgICAgX0RFUk51bWVyaWNTdHJpbmcgPSBfS0pVUl9hc24xLkRFUk51bWVyaWNTdHJpbmcsXG4gICAgICAgICAgICBfREVSUHJpbnRhYmxlU3RyaW5nID0gX0tKVVJfYXNuMS5ERVJQcmludGFibGVTdHJpbmcsXG4gICAgICAgICAgICBfREVSVGVsZXRleFN0cmluZyA9IF9LSlVSX2FzbjEuREVSVGVsZXRleFN0cmluZyxcbiAgICAgICAgICAgIF9ERVJJQTVTdHJpbmcgPSBfS0pVUl9hc24xLkRFUklBNVN0cmluZyxcbiAgICAgICAgICAgIF9ERVJVVENUaW1lID0gX0tKVVJfYXNuMS5ERVJVVENUaW1lLFxuICAgICAgICAgICAgX0RFUkdlbmVyYWxpemVkVGltZSA9IF9LSlVSX2FzbjEuREVSR2VuZXJhbGl6ZWRUaW1lLFxuICAgICAgICAgICAgX0RFUlNlcXVlbmNlID0gX0tKVVJfYXNuMS5ERVJTZXF1ZW5jZSxcbiAgICAgICAgICAgIF9ERVJTZXQgPSBfS0pVUl9hc24xLkRFUlNldCxcbiAgICAgICAgICAgIF9ERVJUYWdnZWRPYmplY3QgPSBfS0pVUl9hc24xLkRFUlRhZ2dlZE9iamVjdCxcbiAgICAgICAgICAgIF9uZXdPYmplY3QgPSBfS0pVUl9hc24xLkFTTjFVdGlsLm5ld09iamVjdDtcblxuICAgICAgICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKHBhcmFtKTtcbiAgICAgICAgaWYgKGtleXMubGVuZ3RoICE9IDEpXG4gICAgICAgICAgICB0aHJvdyBcImtleSBvZiBwYXJhbSBzaGFsbCBiZSBvbmx5IG9uZS5cIjtcbiAgICAgICAgdmFyIGtleSA9IGtleXNbMF07XG5cbiAgICAgICAgaWYgKFwiOmJvb2w6aW50OmJpdHN0cjpvY3RzdHI6bnVsbDpvaWQ6ZW51bTp1dGY4c3RyOm51bXN0cjpwcm5zdHI6dGVsc3RyOmlhNXN0cjp1dGN0aW1lOmdlbnRpbWU6c2VxOnNldDp0YWc6XCIuaW5kZXhPZihcIjpcIiArIGtleSArIFwiOlwiKSA9PSAtMSlcbiAgICAgICAgICAgIHRocm93IFwidW5kZWZpbmVkIGtleTogXCIgKyBrZXk7XG5cbiAgICAgICAgaWYgKGtleSA9PSBcImJvb2xcIikgICAgcmV0dXJuIG5ldyBfREVSQm9vbGVhbihwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcImludFwiKSAgICAgcmV0dXJuIG5ldyBfREVSSW50ZWdlcihwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcImJpdHN0clwiKSAgcmV0dXJuIG5ldyBfREVSQml0U3RyaW5nKHBhcmFtW2tleV0pO1xuICAgICAgICBpZiAoa2V5ID09IFwib2N0c3RyXCIpICByZXR1cm4gbmV3IF9ERVJPY3RldFN0cmluZyhwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcIm51bGxcIikgICAgcmV0dXJuIG5ldyBfREVSTnVsbChwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcIm9pZFwiKSAgICAgcmV0dXJuIG5ldyBfREVST2JqZWN0SWRlbnRpZmllcihwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcImVudW1cIikgICAgcmV0dXJuIG5ldyBfREVSRW51bWVyYXRlZChwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcInV0ZjhzdHJcIikgcmV0dXJuIG5ldyBfREVSVVRGOFN0cmluZyhwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcIm51bXN0clwiKSAgcmV0dXJuIG5ldyBfREVSTnVtZXJpY1N0cmluZyhwYXJhbVtrZXldKTtcbiAgICAgICAgaWYgKGtleSA9PSBcInBybnN0clwiKSAgcmV0dXJuIG5ldyBfREVSUHJpbnRhYmxlU3RyaW5nKHBhcmFtW2tleV0pO1xuICAgICAgICBpZiAoa2V5ID09IFwidGVsc3RyXCIpICByZXR1cm4gbmV3IF9ERVJUZWxldGV4U3RyaW5nKHBhcmFtW2tleV0pO1xuICAgICAgICBpZiAoa2V5ID09IFwiaWE1c3RyXCIpICByZXR1cm4gbmV3IF9ERVJJQTVTdHJpbmcocGFyYW1ba2V5XSk7XG4gICAgICAgIGlmIChrZXkgPT0gXCJ1dGN0aW1lXCIpIHJldHVybiBuZXcgX0RFUlVUQ1RpbWUocGFyYW1ba2V5XSk7XG4gICAgICAgIGlmIChrZXkgPT0gXCJnZW50aW1lXCIpIHJldHVybiBuZXcgX0RFUkdlbmVyYWxpemVkVGltZShwYXJhbVtrZXldKTtcblxuICAgICAgICBpZiAoa2V5ID09IFwic2VxXCIpIHtcbiAgICAgICAgICAgIHZhciBwYXJhbUxpc3QgPSBwYXJhbVtrZXldO1xuICAgICAgICAgICAgdmFyIGEgPSBbXTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFyYW1MaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIGFzbjFPYmogPSBfbmV3T2JqZWN0KHBhcmFtTGlzdFtpXSk7XG4gICAgICAgICAgICAgICAgYS5wdXNoKGFzbjFPYmopO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG5ldyBfREVSU2VxdWVuY2UoeydhcnJheSc6IGF9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChrZXkgPT0gXCJzZXRcIikge1xuICAgICAgICAgICAgdmFyIHBhcmFtTGlzdCA9IHBhcmFtW2tleV07XG4gICAgICAgICAgICB2YXIgYSA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYXJhbUxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgYXNuMU9iaiA9IF9uZXdPYmplY3QocGFyYW1MaXN0W2ldKTtcbiAgICAgICAgICAgICAgICBhLnB1c2goYXNuMU9iaik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbmV3IF9ERVJTZXQoeydhcnJheSc6IGF9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChrZXkgPT0gXCJ0YWdcIikge1xuICAgICAgICAgICAgdmFyIHRhZ1BhcmFtID0gcGFyYW1ba2V5XTtcbiAgICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodGFnUGFyYW0pID09PSAnW29iamVjdCBBcnJheV0nICYmXG4gICAgICAgICAgICAgICAgdGFnUGFyYW0ubGVuZ3RoID09IDMpIHtcbiAgICAgICAgICAgICAgICB2YXIgb2JqID0gX25ld09iamVjdCh0YWdQYXJhbVsyXSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBfREVSVGFnZ2VkT2JqZWN0KHt0YWc6IHRhZ1BhcmFtWzBdLFxuICAgICAgICAgICAgICAgICAgICBleHBsaWNpdDogdGFnUGFyYW1bMV0sXG4gICAgICAgICAgICAgICAgICAgIG9iajogb2JqfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHZhciBuZXdQYXJhbSA9IHt9O1xuICAgICAgICAgICAgICAgIGlmICh0YWdQYXJhbS5leHBsaWNpdCAhPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICAgICAgICBuZXdQYXJhbS5leHBsaWNpdCA9IHRhZ1BhcmFtLmV4cGxpY2l0O1xuICAgICAgICAgICAgICAgIGlmICh0YWdQYXJhbS50YWcgIT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICAgICAgbmV3UGFyYW0udGFnID0gdGFnUGFyYW0udGFnO1xuICAgICAgICAgICAgICAgIGlmICh0YWdQYXJhbS5vYmogPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgXCJvYmogc2hhbGwgYmUgc3BlY2lmaWVkIGZvciAndGFnJy5cIjtcbiAgICAgICAgICAgICAgICBuZXdQYXJhbS5vYmogPSBfbmV3T2JqZWN0KHRhZ1BhcmFtLm9iaik7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBfREVSVGFnZ2VkT2JqZWN0KG5ld1BhcmFtKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBnZXQgZW5jb2RlZCBoZXhhZGVjaW1hbCBzdHJpbmcgb2YgQVNOMU9iamVjdCBzcGVjaWZlZCBieSBKU09OIHBhcmFtZXRlcnNcbiAgICAgKiBAbmFtZSBqc29uVG9BU04xSEVYXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5BU04xVXRpbFxuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtIEpTT04gcGFyYW1ldGVyIHRvIGdlbmVyYXRlIEFTTjFPYmplY3RcbiAgICAgKiBAcmV0dXJuIGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04xT2JqZWN0XG4gICAgICogQHNpbmNlIGFzbjEgMS4wLjRcbiAgICAgKiBAZGVzY3JpcHRpb25cbiAgICAgKiBBcyBmb3IgQVNOLjEgb2JqZWN0IHJlcHJlc2VudGF0aW9uIG9mIEpTT04gb2JqZWN0LFxuICAgICAqIHBsZWFzZSBzZWUge0BsaW5rIG5ld09iamVjdH0uXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBqc29uVG9BU04xSEVYKHsncHJuc3RyJzogJ2FhYSd9KTtcbiAgICAgKi9cbiAgICB0aGlzLmpzb25Ub0FTTjFIRVggPSBmdW5jdGlvbihwYXJhbSkge1xuICAgICAgICB2YXIgYXNuMU9iaiA9IHRoaXMubmV3T2JqZWN0KHBhcmFtKTtcbiAgICAgICAgcmV0dXJuIGFzbjFPYmouZ2V0RW5jb2RlZEhleCgpO1xuICAgIH07XG59O1xuXG4vKipcbiAqIGdldCBkb3Qgbm90ZWQgb2lkIG51bWJlciBzdHJpbmcgZnJvbSBoZXhhZGVjaW1hbCB2YWx1ZSBvZiBPSURcbiAqIEBuYW1lIG9pZEhleFRvSW50XG4gKiBAbWVtYmVyT2YgS0pVUi5hc24xLkFTTjFVdGlsXG4gKiBAZnVuY3Rpb25cbiAqIEBwYXJhbSB7U3RyaW5nfSBoZXggaGV4YWRlY2ltYWwgdmFsdWUgb2Ygb2JqZWN0IGlkZW50aWZpZXJcbiAqIEByZXR1cm4ge1N0cmluZ30gZG90IG5vdGVkIHN0cmluZyBvZiBvYmplY3QgaWRlbnRpZmllclxuICogQHNpbmNlIGpzcnNhc2lnbiA0LjguMyBhc24xIDEuMC43XG4gKiBAZGVzY3JpcHRpb25cbiAqIFRoaXMgc3RhdGljIG1ldGhvZCBjb252ZXJ0cyBmcm9tIGhleGFkZWNpbWFsIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZlxuICogQVNOLjEgdmFsdWUgb2Ygb2JqZWN0IGlkZW50aWZpZXIgdG8gb2lkIG51bWJlciBzdHJpbmcuXG4gKiBAZXhhbXBsZVxuICogS0pVUi5hc24xLkFTTjFVdGlsLm9pZEhleFRvSW50KCc1NTA0MDYnKSAmcmFycjsgXCIyLjUuNC42XCJcbiAqL1xuS0pVUi5hc24xLkFTTjFVdGlsLm9pZEhleFRvSW50ID0gZnVuY3Rpb24oaGV4KSB7XG4gICAgdmFyIHMgPSBcIlwiO1xuICAgIHZhciBpMDEgPSBwYXJzZUludChoZXguc3Vic3RyKDAsIDIpLCAxNik7XG4gICAgdmFyIGkwID0gTWF0aC5mbG9vcihpMDEgLyA0MCk7XG4gICAgdmFyIGkxID0gaTAxICUgNDA7XG4gICAgdmFyIHMgPSBpMCArIFwiLlwiICsgaTE7XG5cbiAgICB2YXIgYmluYnVmID0gXCJcIjtcbiAgICBmb3IgKHZhciBpID0gMjsgaSA8IGhleC5sZW5ndGg7IGkgKz0gMikge1xuICAgICAgICB2YXIgdmFsdWUgPSBwYXJzZUludChoZXguc3Vic3RyKGksIDIpLCAxNik7XG4gICAgICAgIHZhciBiaW4gPSAoXCIwMDAwMDAwMFwiICsgdmFsdWUudG9TdHJpbmcoMikpLnNsaWNlKC0gOCk7XG4gICAgICAgIGJpbmJ1ZiA9IGJpbmJ1ZiArIGJpbi5zdWJzdHIoMSwgNyk7XG4gICAgICAgIGlmIChiaW4uc3Vic3RyKDAsIDEpID09IFwiMFwiKSB7XG4gICAgICAgICAgICB2YXIgYmkgPSBuZXcgQmlnSW50ZWdlcihiaW5idWYsIDIpO1xuICAgICAgICAgICAgcyA9IHMgKyBcIi5cIiArIGJpLnRvU3RyaW5nKDEwKTtcbiAgICAgICAgICAgIGJpbmJ1ZiA9IFwiXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHM7XG59O1xuXG4vKipcbiAqIGdldCBoZXhhZGVjaW1hbCB2YWx1ZSBvZiBvYmplY3QgaWRlbnRpZmllciBmcm9tIGRvdCBub3RlZCBvaWQgdmFsdWVcbiAqIEBuYW1lIG9pZEludFRvSGV4XG4gKiBAbWVtYmVyT2YgS0pVUi5hc24xLkFTTjFVdGlsXG4gKiBAZnVuY3Rpb25cbiAqIEBwYXJhbSB7U3RyaW5nfSBvaWRTdHJpbmcgZG90IG5vdGVkIHN0cmluZyBvZiBvYmplY3QgaWRlbnRpZmllclxuICogQHJldHVybiB7U3RyaW5nfSBoZXhhZGVjaW1hbCB2YWx1ZSBvZiBvYmplY3QgaWRlbnRpZmllclxuICogQHNpbmNlIGpzcnNhc2lnbiA0LjguMyBhc24xIDEuMC43XG4gKiBAZGVzY3JpcHRpb25cbiAqIFRoaXMgc3RhdGljIG1ldGhvZCBjb252ZXJ0cyBmcm9tIG9iamVjdCBpZGVudGlmaWVyIHZhbHVlIHN0cmluZy5cbiAqIHRvIGhleGFkZWNpbWFsIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiBpdC5cbiAqIEBleGFtcGxlXG4gKiBLSlVSLmFzbjEuQVNOMVV0aWwub2lkSW50VG9IZXgoXCIyLjUuNC42XCIpICZyYXJyOyBcIjU1MDQwNlwiXG4gKi9cbktKVVIuYXNuMS5BU04xVXRpbC5vaWRJbnRUb0hleCA9IGZ1bmN0aW9uKG9pZFN0cmluZykge1xuICAgIHZhciBpdG94ID0gZnVuY3Rpb24oaSkge1xuICAgICAgICB2YXIgaCA9IGkudG9TdHJpbmcoMTYpO1xuICAgICAgICBpZiAoaC5sZW5ndGggPT0gMSkgaCA9ICcwJyArIGg7XG4gICAgICAgIHJldHVybiBoO1xuICAgIH07XG5cbiAgICB2YXIgcm9pZHRveCA9IGZ1bmN0aW9uKHJvaWQpIHtcbiAgICAgICAgdmFyIGggPSAnJztcbiAgICAgICAgdmFyIGJpID0gbmV3IEJpZ0ludGVnZXIocm9pZCwgMTApO1xuICAgICAgICB2YXIgYiA9IGJpLnRvU3RyaW5nKDIpO1xuICAgICAgICB2YXIgcGFkTGVuID0gNyAtIGIubGVuZ3RoICUgNztcbiAgICAgICAgaWYgKHBhZExlbiA9PSA3KSBwYWRMZW4gPSAwO1xuICAgICAgICB2YXIgYlBhZCA9ICcnO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhZExlbjsgaSsrKSBiUGFkICs9ICcwJztcbiAgICAgICAgYiA9IGJQYWQgKyBiO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGIubGVuZ3RoIC0gMTsgaSArPSA3KSB7XG4gICAgICAgICAgICB2YXIgYjggPSBiLnN1YnN0cihpLCA3KTtcbiAgICAgICAgICAgIGlmIChpICE9IGIubGVuZ3RoIC0gNykgYjggPSAnMScgKyBiODtcbiAgICAgICAgICAgIGggKz0gaXRveChwYXJzZUludChiOCwgMikpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBoO1xuICAgIH07XG5cbiAgICBpZiAoISBvaWRTdHJpbmcubWF0Y2goL15bMC05Ll0rJC8pKSB7XG4gICAgICAgIHRocm93IFwibWFsZm9ybWVkIG9pZCBzdHJpbmc6IFwiICsgb2lkU3RyaW5nO1xuICAgIH1cbiAgICB2YXIgaCA9ICcnO1xuICAgIHZhciBhID0gb2lkU3RyaW5nLnNwbGl0KCcuJyk7XG4gICAgdmFyIGkwID0gcGFyc2VJbnQoYVswXSkgKiA0MCArIHBhcnNlSW50KGFbMV0pO1xuICAgIGggKz0gaXRveChpMCk7XG4gICAgYS5zcGxpY2UoMCwgMik7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGggKz0gcm9pZHRveChhW2ldKTtcbiAgICB9XG4gICAgcmV0dXJuIGg7XG59O1xuXG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vLyAgQWJzdHJhY3QgQVNOLjEgQ2xhc3Nlc1xuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcblxuLyoqXG4gKiBiYXNlIGNsYXNzIGZvciBBU04uMSBERVIgZW5jb2RlciBvYmplY3RcbiAqIEBuYW1lIEtKVVIuYXNuMS5BU04xT2JqZWN0XG4gKiBAY2xhc3MgYmFzZSBjbGFzcyBmb3IgQVNOLjEgREVSIGVuY29kZXIgb2JqZWN0XG4gKiBAcHJvcGVydHkge0Jvb2xlYW59IGlzTW9kaWZpZWQgZmxhZyB3aGV0aGVyIGludGVybmFsIGRhdGEgd2FzIGNoYW5nZWRcbiAqIEBwcm9wZXJ0eSB7U3RyaW5nfSBoVExWIGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04uMSBUTFZcbiAqIEBwcm9wZXJ0eSB7U3RyaW5nfSBoVCBoZXhhZGVjaW1hbCBzdHJpbmcgb2YgQVNOLjEgVExWIHRhZyhUKVxuICogQHByb3BlcnR5IHtTdHJpbmd9IGhMIGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04uMSBUTFYgbGVuZ3RoKEwpXG4gKiBAcHJvcGVydHkge1N0cmluZ30gaFYgaGV4YWRlY2ltYWwgc3RyaW5nIG9mIEFTTi4xIFRMViB2YWx1ZShWKVxuICogQGRlc2NyaXB0aW9uXG4gKi9cbktKVVIuYXNuMS5BU04xT2JqZWN0ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGhWID0gJyc7XG5cbiAgICAvKipcbiAgICAgKiBnZXQgaGV4YWRlY2ltYWwgQVNOLjEgVExWIGxlbmd0aChMKSBieXRlcyBmcm9tIFRMViB2YWx1ZShWKVxuICAgICAqIEBuYW1lIGdldExlbmd0aEhleEZyb21WYWx1ZVxuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuQVNOMU9iamVjdCNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcmV0dXJuIHtTdHJpbmd9IGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04uMSBUTFYgbGVuZ3RoKEwpXG4gICAgICovXG4gICAgdGhpcy5nZXRMZW5ndGhIZXhGcm9tVmFsdWUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmhWID09IFwidW5kZWZpbmVkXCIgfHwgdGhpcy5oViA9PSBudWxsKSB7XG4gICAgICAgICAgICB0aHJvdyBcInRoaXMuaFYgaXMgbnVsbCBvciB1bmRlZmluZWQuXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaFYubGVuZ3RoICUgMiA9PSAxKSB7XG4gICAgICAgICAgICB0aHJvdyBcInZhbHVlIGhleCBtdXN0IGJlIGV2ZW4gbGVuZ3RoOiBuPVwiICsgaFYubGVuZ3RoICsgXCIsdj1cIiArIHRoaXMuaFY7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG4gPSB0aGlzLmhWLmxlbmd0aCAvIDI7XG4gICAgICAgIHZhciBoTiA9IG4udG9TdHJpbmcoMTYpO1xuICAgICAgICBpZiAoaE4ubGVuZ3RoICUgMiA9PSAxKSB7XG4gICAgICAgICAgICBoTiA9IFwiMFwiICsgaE47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG4gPCAxMjgpIHtcbiAgICAgICAgICAgIHJldHVybiBoTjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBoTmxlbiA9IGhOLmxlbmd0aCAvIDI7XG4gICAgICAgICAgICBpZiAoaE5sZW4gPiAxNSkge1xuICAgICAgICAgICAgICAgIHRocm93IFwiQVNOLjEgbGVuZ3RoIHRvbyBsb25nIHRvIHJlcHJlc2VudCBieSA4eDogbiA9IFwiICsgbi50b1N0cmluZygxNik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgaGVhZCA9IDEyOCArIGhObGVuO1xuICAgICAgICAgICAgcmV0dXJuIGhlYWQudG9TdHJpbmcoMTYpICsgaE47XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogZ2V0IGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04uMSBUTFYgYnl0ZXNcbiAgICAgKiBAbmFtZSBnZXRFbmNvZGVkSGV4XG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5BU04xT2JqZWN0I1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEByZXR1cm4ge1N0cmluZ30gaGV4YWRlY2ltYWwgc3RyaW5nIG9mIEFTTi4xIFRMVlxuICAgICAqL1xuICAgIHRoaXMuZ2V0RW5jb2RlZEhleCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAodGhpcy5oVExWID09IG51bGwgfHwgdGhpcy5pc01vZGlmaWVkKSB7XG4gICAgICAgICAgICB0aGlzLmhWID0gdGhpcy5nZXRGcmVzaFZhbHVlSGV4KCk7XG4gICAgICAgICAgICB0aGlzLmhMID0gdGhpcy5nZXRMZW5ndGhIZXhGcm9tVmFsdWUoKTtcbiAgICAgICAgICAgIHRoaXMuaFRMViA9IHRoaXMuaFQgKyB0aGlzLmhMICsgdGhpcy5oVjtcbiAgICAgICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IGZhbHNlO1xuICAgICAgICAgICAgLy9hbGVydChcImZpcnN0IHRpbWU6IFwiICsgdGhpcy5oVExWKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5oVExWO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBnZXQgaGV4YWRlY2ltYWwgc3RyaW5nIG9mIEFTTi4xIFRMViB2YWx1ZShWKSBieXRlc1xuICAgICAqIEBuYW1lIGdldFZhbHVlSGV4XG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5BU04xT2JqZWN0I1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEByZXR1cm4ge1N0cmluZ30gaGV4YWRlY2ltYWwgc3RyaW5nIG9mIEFTTi4xIFRMViB2YWx1ZShWKSBieXRlc1xuICAgICAqL1xuICAgIHRoaXMuZ2V0VmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5nZXRFbmNvZGVkSGV4KCk7XG4gICAgICAgIHJldHVybiB0aGlzLmhWO1xuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH07XG59O1xuXG4vLyA9PSBCRUdJTiBERVJBYnN0cmFjdFN0cmluZyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8qKlxuICogYmFzZSBjbGFzcyBmb3IgQVNOLjEgREVSIHN0cmluZyBjbGFzc2VzXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmdcbiAqIEBjbGFzcyBiYXNlIGNsYXNzIGZvciBBU04uMSBERVIgc3RyaW5nIGNsYXNzZXNcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnYWFhJ30pXG4gKiBAcHJvcGVydHkge1N0cmluZ30gcyBpbnRlcm5hbCBzdHJpbmcgb2YgdmFsdWVcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5BU04xT2JqZWN0XG4gKiBAZGVzY3JpcHRpb25cbiAqIDxici8+XG4gKiBBcyBmb3IgYXJndW1lbnQgJ3BhcmFtcycgZm9yIGNvbnN0cnVjdG9yLCB5b3UgY2FuIHNwZWNpZnkgb25lIG9mXG4gKiBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqIDx1bD5cbiAqIDxsaT5zdHIgLSBzcGVjaWZ5IGluaXRpYWwgQVNOLjEgdmFsdWUoVikgYnkgYSBzdHJpbmc8L2xpPlxuICogPGxpPmhleCAtIHNwZWNpZnkgaW5pdGlhbCBBU04uMSB2YWx1ZShWKSBieSBhIGhleGFkZWNpbWFsIHN0cmluZzwvbGk+XG4gKiA8L3VsPlxuICogTk9URTogJ3BhcmFtcycgY2FuIGJlIG9taXR0ZWQuXG4gKi9cbktKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZyA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZy5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcyk7XG5cbiAgICAvKipcbiAgICAgKiBnZXQgc3RyaW5nIHZhbHVlIG9mIHRoaXMgc3RyaW5nIG9iamVjdFxuICAgICAqIEBuYW1lIGdldFN0cmluZ1xuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmcjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHJldHVybiB7U3RyaW5nfSBzdHJpbmcgdmFsdWUgb2YgdGhpcyBzdHJpbmcgb2JqZWN0XG4gICAgICovXG4gICAgdGhpcy5nZXRTdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucztcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IGEgc3RyaW5nXG4gICAgICogQG5hbWUgc2V0U3RyaW5nXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZyNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge1N0cmluZ30gbmV3UyB2YWx1ZSBieSBhIHN0cmluZyB0byBzZXRcbiAgICAgKi9cbiAgICB0aGlzLnNldFN0cmluZyA9IGZ1bmN0aW9uKG5ld1MpIHtcbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zID0gbmV3UztcbiAgICAgICAgdGhpcy5oViA9IHN0b2hleCh0aGlzLnMpO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBzZXQgdmFsdWUgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmdcbiAgICAgKiBAbmFtZSBzZXRTdHJpbmdIZXhcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7U3RyaW5nfSBuZXdIZXhTdHJpbmcgdmFsdWUgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmcgdG8gc2V0XG4gICAgICovXG4gICAgdGhpcy5zZXRTdHJpbmdIZXggPSBmdW5jdGlvbihuZXdIZXhTdHJpbmcpIHtcbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zID0gbnVsbDtcbiAgICAgICAgdGhpcy5oViA9IG5ld0hleFN0cmluZztcbiAgICB9O1xuXG4gICAgdGhpcy5nZXRGcmVzaFZhbHVlSGV4ID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmhWO1xuICAgIH07XG5cbiAgICBpZiAodHlwZW9mIHBhcmFtcyAhPSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGlmICh0eXBlb2YgcGFyYW1zID09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RyaW5nKHBhcmFtcyk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHBhcmFtc1snc3RyJ10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5zZXRTdHJpbmcocGFyYW1zWydzdHInXSk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHBhcmFtc1snaGV4J10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5zZXRTdHJpbmdIZXgocGFyYW1zWydoZXgnXSk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nLCBLSlVSLmFzbjEuQVNOMU9iamVjdCk7XG4vLyA9PSBFTkQgICBERVJBYnN0cmFjdFN0cmluZyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLy8gPT0gQkVHSU4gREVSQWJzdHJhY3RUaW1lID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vKipcbiAqIGJhc2UgY2xhc3MgZm9yIEFTTi4xIERFUiBHZW5lcmFsaXplZC9VVENUaW1lIGNsYXNzXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSQWJzdHJhY3RUaW1lXG4gKiBAY2xhc3MgYmFzZSBjbGFzcyBmb3IgQVNOLjEgREVSIEdlbmVyYWxpemVkL1VUQ1RpbWUgY2xhc3NcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnMTMwNDMwMjM1OTU5Wid9KVxuICogQGV4dGVuZHMgS0pVUi5hc24xLkFTTjFPYmplY3RcbiAqIEBkZXNjcmlwdGlvblxuICogQHNlZSBLSlVSLmFzbjEuQVNOMU9iamVjdCAtIHN1cGVyY2xhc3NcbiAqL1xuS0pVUi5hc24xLkRFUkFic3RyYWN0VGltZSA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFRpbWUuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMpO1xuXG4gICAgLy8gLS0tIFBSSVZBVEUgTUVUSE9EUyAtLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubG9jYWxEYXRlVG9VVEMgPSBmdW5jdGlvbihkKSB7XG4gICAgICAgIHV0YyA9IGQuZ2V0VGltZSgpICsgKGQuZ2V0VGltZXpvbmVPZmZzZXQoKSAqIDYwMDAwKTtcbiAgICAgICAgdmFyIHV0Y0RhdGUgPSBuZXcgRGF0ZSh1dGMpO1xuICAgICAgICByZXR1cm4gdXRjRGF0ZTtcbiAgICB9O1xuXG4gICAgLypcbiAgICAgKiBmb3JtYXQgZGF0ZSBzdHJpbmcgYnkgRGF0YSBvYmplY3RcbiAgICAgKiBAbmFtZSBmb3JtYXREYXRlXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5BYnN0cmFjdFRpbWU7XG4gICAgICogQHBhcmFtIHtEYXRlfSBkYXRlT2JqZWN0XG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHR5cGUgJ3V0Yycgb3IgJ2dlbidcbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IHdpdGhNaWxsaXMgZmxhZyBmb3Igd2l0aCBtaWxsaXNlY3Rpb25zIG9yIG5vdFxuICAgICAqIEBkZXNjcmlwdGlvblxuICAgICAqICd3aXRoTWlsbGlzJyBmbGFnIGlzIHN1cHBvcnRlZCBmcm9tIGFzbjEgMS4wLjYuXG4gICAgICovXG4gICAgdGhpcy5mb3JtYXREYXRlID0gZnVuY3Rpb24oZGF0ZU9iamVjdCwgdHlwZSwgd2l0aE1pbGxpcykge1xuICAgICAgICB2YXIgcGFkID0gdGhpcy56ZXJvUGFkZGluZztcbiAgICAgICAgdmFyIGQgPSB0aGlzLmxvY2FsRGF0ZVRvVVRDKGRhdGVPYmplY3QpO1xuICAgICAgICB2YXIgeWVhciA9IFN0cmluZyhkLmdldEZ1bGxZZWFyKCkpO1xuICAgICAgICBpZiAodHlwZSA9PSAndXRjJykgeWVhciA9IHllYXIuc3Vic3RyKDIsIDIpO1xuICAgICAgICB2YXIgbW9udGggPSBwYWQoU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLCAyKTtcbiAgICAgICAgdmFyIGRheSA9IHBhZChTdHJpbmcoZC5nZXREYXRlKCkpLCAyKTtcbiAgICAgICAgdmFyIGhvdXIgPSBwYWQoU3RyaW5nKGQuZ2V0SG91cnMoKSksIDIpO1xuICAgICAgICB2YXIgbWluID0gcGFkKFN0cmluZyhkLmdldE1pbnV0ZXMoKSksIDIpO1xuICAgICAgICB2YXIgc2VjID0gcGFkKFN0cmluZyhkLmdldFNlY29uZHMoKSksIDIpO1xuICAgICAgICB2YXIgcyA9IHllYXIgKyBtb250aCArIGRheSArIGhvdXIgKyBtaW4gKyBzZWM7XG4gICAgICAgIGlmICh3aXRoTWlsbGlzID09PSB0cnVlKSB7XG4gICAgICAgICAgICB2YXIgbWlsbGlzID0gZC5nZXRNaWxsaXNlY29uZHMoKTtcbiAgICAgICAgICAgIGlmIChtaWxsaXMgIT0gMCkge1xuICAgICAgICAgICAgICAgIHZhciBzTWlsbGlzID0gcGFkKFN0cmluZyhtaWxsaXMpLCAzKTtcbiAgICAgICAgICAgICAgICBzTWlsbGlzID0gc01pbGxpcy5yZXBsYWNlKC9bMF0rJC8sIFwiXCIpO1xuICAgICAgICAgICAgICAgIHMgPSBzICsgXCIuXCIgKyBzTWlsbGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzICsgXCJaXCI7XG4gICAgfTtcblxuICAgIHRoaXMuemVyb1BhZGRpbmcgPSBmdW5jdGlvbihzLCBsZW4pIHtcbiAgICAgICAgaWYgKHMubGVuZ3RoID49IGxlbikgcmV0dXJuIHM7XG4gICAgICAgIHJldHVybiBuZXcgQXJyYXkobGVuIC0gcy5sZW5ndGggKyAxKS5qb2luKCcwJykgKyBzO1xuICAgIH07XG5cbiAgICAvLyAtLS0gUFVCTElDIE1FVEhPRFMgLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvKipcbiAgICAgKiBnZXQgc3RyaW5nIHZhbHVlIG9mIHRoaXMgc3RyaW5nIG9iamVjdFxuICAgICAqIEBuYW1lIGdldFN0cmluZ1xuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVSQWJzdHJhY3RUaW1lI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEByZXR1cm4ge1N0cmluZ30gc3RyaW5nIHZhbHVlIG9mIHRoaXMgdGltZSBvYmplY3RcbiAgICAgKi9cbiAgICB0aGlzLmdldFN0cmluZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBzZXQgdmFsdWUgYnkgYSBzdHJpbmdcbiAgICAgKiBAbmFtZSBzZXRTdHJpbmdcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkFic3RyYWN0VGltZSNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge1N0cmluZ30gbmV3UyB2YWx1ZSBieSBhIHN0cmluZyB0byBzZXQgc3VjaCBsaWtlIFwiMTMwNDMwMjM1OTU5WlwiXG4gICAgICovXG4gICAgdGhpcy5zZXRTdHJpbmcgPSBmdW5jdGlvbihuZXdTKSB7XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMucyA9IG5ld1M7XG4gICAgICAgIHRoaXMuaFYgPSBzdG9oZXgobmV3Uyk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBhIERhdGUgb2JqZWN0XG4gICAgICogQG5hbWUgc2V0QnlEYXRlVmFsdWVcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkFic3RyYWN0VGltZSNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0ludGVnZXJ9IHllYXIgeWVhciBvZiBkYXRlIChleC4gMjAxMylcbiAgICAgKiBAcGFyYW0ge0ludGVnZXJ9IG1vbnRoIG1vbnRoIG9mIGRhdGUgYmV0d2VlbiAxIGFuZCAxMiAoZXguIDEyKVxuICAgICAqIEBwYXJhbSB7SW50ZWdlcn0gZGF5IGRheSBvZiBtb250aFxuICAgICAqIEBwYXJhbSB7SW50ZWdlcn0gaG91ciBob3VycyBvZiBkYXRlXG4gICAgICogQHBhcmFtIHtJbnRlZ2VyfSBtaW4gbWludXRlcyBvZiBkYXRlXG4gICAgICogQHBhcmFtIHtJbnRlZ2VyfSBzZWMgc2Vjb25kcyBvZiBkYXRlXG4gICAgICovXG4gICAgdGhpcy5zZXRCeURhdGVWYWx1ZSA9IGZ1bmN0aW9uKHllYXIsIG1vbnRoLCBkYXksIGhvdXIsIG1pbiwgc2VjKSB7XG4gICAgICAgIHZhciBkYXRlT2JqZWN0ID0gbmV3IERhdGUoRGF0ZS5VVEMoeWVhciwgbW9udGggLSAxLCBkYXksIGhvdXIsIG1pbiwgc2VjLCAwKSk7XG4gICAgICAgIHRoaXMuc2V0QnlEYXRlKGRhdGVPYmplY3QpO1xuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSQWJzdHJhY3RUaW1lLCBLSlVSLmFzbjEuQVNOMU9iamVjdCk7XG4vLyA9PSBFTkQgICBERVJBYnN0cmFjdFRpbWUgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLy8gPT0gQkVHSU4gREVSQWJzdHJhY3RTdHJ1Y3R1cmVkID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vKipcbiAqIGJhc2UgY2xhc3MgZm9yIEFTTi4xIERFUiBzdHJ1Y3R1cmVkIGNsYXNzXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJ1Y3R1cmVkXG4gKiBAY2xhc3MgYmFzZSBjbGFzcyBmb3IgQVNOLjEgREVSIHN0cnVjdHVyZWQgY2xhc3NcbiAqIEBwcm9wZXJ0eSB7QXJyYXl9IGFzbjFBcnJheSBpbnRlcm5hbCBhcnJheSBvZiBBU04xT2JqZWN0XG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuQVNOMU9iamVjdFxuICogQGRlc2NyaXB0aW9uXG4gKiBAc2VlIEtKVVIuYXNuMS5BU04xT2JqZWN0IC0gc3VwZXJjbGFzc1xuICovXG5LSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJ1Y3R1cmVkID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nLnN1cGVyY2xhc3MuY29uc3RydWN0b3IuY2FsbCh0aGlzKTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBhcnJheSBvZiBBU04xT2JqZWN0XG4gICAgICogQG5hbWUgc2V0QnlBU04xT2JqZWN0QXJyYXlcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RydWN0dXJlZCNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge2FycmF5fSBhc24xT2JqZWN0QXJyYXkgYXJyYXkgb2YgQVNOMU9iamVjdCB0byBzZXRcbiAgICAgKi9cbiAgICB0aGlzLnNldEJ5QVNOMU9iamVjdEFycmF5ID0gZnVuY3Rpb24oYXNuMU9iamVjdEFycmF5KSB7XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMuYXNuMUFycmF5ID0gYXNuMU9iamVjdEFycmF5O1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBhcHBlbmQgYW4gQVNOMU9iamVjdCB0byBpbnRlcm5hbCBhcnJheVxuICAgICAqIEBuYW1lIGFwcGVuZEFTTjFPYmplY3RcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RydWN0dXJlZCNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0FTTjFPYmplY3R9IGFzbjFPYmplY3QgdG8gYWRkXG4gICAgICovXG4gICAgdGhpcy5hcHBlbmRBU04xT2JqZWN0ID0gZnVuY3Rpb24oYXNuMU9iamVjdCkge1xuICAgICAgICB0aGlzLmhUTFYgPSBudWxsO1xuICAgICAgICB0aGlzLmlzTW9kaWZpZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLmFzbjFBcnJheS5wdXNoKGFzbjFPYmplY3QpO1xuICAgIH07XG5cbiAgICB0aGlzLmFzbjFBcnJheSA9IG5ldyBBcnJheSgpO1xuICAgIGlmICh0eXBlb2YgcGFyYW1zICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBwYXJhbXNbJ2FycmF5J10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5hc24xQXJyYXkgPSBwYXJhbXNbJ2FycmF5J107XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUkFic3RyYWN0U3RydWN0dXJlZCwgS0pVUi5hc24xLkFTTjFPYmplY3QpO1xuXG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vLyAgQVNOLjEgT2JqZWN0IENsYXNzZXNcbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vKipcbiAqIGNsYXNzIGZvciBBU04uMSBERVIgQm9vbGVhblxuICogQG5hbWUgS0pVUi5hc24xLkRFUkJvb2xlYW5cbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIEJvb2xlYW5cbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5BU04xT2JqZWN0XG4gKiBAZGVzY3JpcHRpb25cbiAqIEBzZWUgS0pVUi5hc24xLkFTTjFPYmplY3QgLSBzdXBlcmNsYXNzXG4gKi9cbktKVVIuYXNuMS5ERVJCb29sZWFuID0gZnVuY3Rpb24oKSB7XG4gICAgS0pVUi5hc24xLkRFUkJvb2xlYW4uc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMpO1xuICAgIHRoaXMuaFQgPSBcIjAxXCI7XG4gICAgdGhpcy5oVExWID0gXCIwMTAxZmZcIjtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSQm9vbGVhbiwgS0pVUi5hc24xLkFTTjFPYmplY3QpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIEludGVnZXJcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJJbnRlZ2VyXG4gKiBAY2xhc3MgY2xhc3MgZm9yIEFTTi4xIERFUiBJbnRlZ2VyXG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuQVNOMU9iamVjdFxuICogQGRlc2NyaXB0aW9uXG4gKiA8YnIvPlxuICogQXMgZm9yIGFyZ3VtZW50ICdwYXJhbXMnIGZvciBjb25zdHJ1Y3RvciwgeW91IGNhbiBzcGVjaWZ5IG9uZSBvZlxuICogZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKiA8dWw+XG4gKiA8bGk+aW50IC0gc3BlY2lmeSBpbml0aWFsIEFTTi4xIHZhbHVlKFYpIGJ5IGludGVnZXIgdmFsdWU8L2xpPlxuICogPGxpPmJpZ2ludCAtIHNwZWNpZnkgaW5pdGlhbCBBU04uMSB2YWx1ZShWKSBieSBCaWdJbnRlZ2VyIG9iamVjdDwvbGk+XG4gKiA8bGk+aGV4IC0gc3BlY2lmeSBpbml0aWFsIEFTTi4xIHZhbHVlKFYpIGJ5IGEgaGV4YWRlY2ltYWwgc3RyaW5nPC9saT5cbiAqIDwvdWw+XG4gKiBOT1RFOiAncGFyYW1zJyBjYW4gYmUgb21pdHRlZC5cbiAqL1xuS0pVUi5hc24xLkRFUkludGVnZXIgPSBmdW5jdGlvbihwYXJhbXMpIHtcbiAgICBLSlVSLmFzbjEuREVSSW50ZWdlci5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcyk7XG4gICAgdGhpcy5oVCA9IFwiMDJcIjtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBUb20gV3UncyBCaWdJbnRlZ2VyIG9iamVjdFxuICAgICAqIEBuYW1lIHNldEJ5QmlnSW50ZWdlclxuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVSSW50ZWdlciNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0JpZ0ludGVnZXJ9IGJpZ0ludGVnZXJWYWx1ZSB0byBzZXRcbiAgICAgKi9cbiAgICB0aGlzLnNldEJ5QmlnSW50ZWdlciA9IGZ1bmN0aW9uKGJpZ0ludGVnZXJWYWx1ZSkge1xuICAgICAgICB0aGlzLmhUTFYgPSBudWxsO1xuICAgICAgICB0aGlzLmlzTW9kaWZpZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLmhWID0gS0pVUi5hc24xLkFTTjFVdGlsLmJpZ0ludFRvTWluVHdvc0NvbXBsZW1lbnRzSGV4KGJpZ0ludGVnZXJWYWx1ZSk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBpbnRlZ2VyIHZhbHVlXG4gICAgICogQG5hbWUgc2V0QnlJbnRlZ2VyXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5ERVJJbnRlZ2VyXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtJbnRlZ2VyfSBpbnRlZ2VyIHZhbHVlIHRvIHNldFxuICAgICAqL1xuICAgIHRoaXMuc2V0QnlJbnRlZ2VyID0gZnVuY3Rpb24oaW50VmFsdWUpIHtcbiAgICAgICAgdmFyIGJpID0gbmV3IEJpZ0ludGVnZXIoU3RyaW5nKGludFZhbHVlKSwgMTApO1xuICAgICAgICB0aGlzLnNldEJ5QmlnSW50ZWdlcihiaSk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBpbnRlZ2VyIHZhbHVlXG4gICAgICogQG5hbWUgc2V0VmFsdWVIZXhcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkludGVnZXIjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtTdHJpbmd9IGhleGFkZWNpbWFsIHN0cmluZyBvZiBpbnRlZ2VyIHZhbHVlXG4gICAgICogQGRlc2NyaXB0aW9uXG4gICAgICogPGJyLz5cbiAgICAgKiBOT1RFOiBWYWx1ZSBzaGFsbCBiZSByZXByZXNlbnRlZCBieSBtaW5pbXVtIG9jdGV0IGxlbmd0aCBvZlxuICAgICAqIHR3bydzIGNvbXBsZW1lbnQgcmVwcmVzZW50YXRpb24uXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoMTIzKTtcbiAgICAgKiBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeydpbnQnOiAxMjN9KTtcbiAgICAgKiBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeydoZXgnOiAnMWZhZCd9KTtcbiAgICAgKi9cbiAgICB0aGlzLnNldFZhbHVlSGV4ID0gZnVuY3Rpb24obmV3SGV4U3RyaW5nKSB7XG4gICAgICAgIHRoaXMuaFYgPSBuZXdIZXhTdHJpbmc7XG4gICAgfTtcblxuICAgIHRoaXMuZ2V0RnJlc2hWYWx1ZUhleCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5oVjtcbiAgICB9O1xuXG4gICAgaWYgKHR5cGVvZiBwYXJhbXMgIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBpZiAodHlwZW9mIHBhcmFtc1snYmlnaW50J10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5zZXRCeUJpZ0ludGVnZXIocGFyYW1zWydiaWdpbnQnXSk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHBhcmFtc1snaW50J10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5zZXRCeUludGVnZXIocGFyYW1zWydpbnQnXSk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHBhcmFtcyA9PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgICB0aGlzLnNldEJ5SW50ZWdlcihwYXJhbXMpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwYXJhbXNbJ2hleCddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0VmFsdWVIZXgocGFyYW1zWydoZXgnXSk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUkludGVnZXIsIEtKVVIuYXNuMS5BU04xT2JqZWN0KTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBlbmNvZGVkIEJpdFN0cmluZyBwcmltaXRpdmVcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJCaXRTdHJpbmdcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIGVuY29kZWQgQml0U3RyaW5nIHByaW1pdGl2ZVxuICogQGV4dGVuZHMgS0pVUi5hc24xLkFTTjFPYmplY3RcbiAqIEBkZXNjcmlwdGlvblxuICogPGJyLz5cbiAqIEFzIGZvciBhcmd1bWVudCAncGFyYW1zJyBmb3IgY29uc3RydWN0b3IsIHlvdSBjYW4gc3BlY2lmeSBvbmUgb2ZcbiAqIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICogPHVsPlxuICogPGxpPmJpbiAtIHNwZWNpZnkgYmluYXJ5IHN0cmluZyAoZXguICcxMDExMScpPC9saT5cbiAqIDxsaT5hcnJheSAtIHNwZWNpZnkgYXJyYXkgb2YgYm9vbGVhbiAoZXguIFt0cnVlLGZhbHNlLHRydWUsdHJ1ZV0pPC9saT5cbiAqIDxsaT5oZXggLSBzcGVjaWZ5IGhleGFkZWNpbWFsIHN0cmluZyBvZiBBU04uMSB2YWx1ZShWKSBpbmNsdWRpbmcgdW51c2VkIGJpdHM8L2xpPlxuICogPGxpPm9iaiAtIHNwZWNpZnkge0BsaW5rIEtKVVIuYXNuMS5BU04xVXRpbC5uZXdPYmplY3R9XG4gKiBhcmd1bWVudCBmb3IgXCJCaXRTdHJpbmcgZW5jYXBzdWxhdGVzXCIgc3RydWN0dXJlLjwvbGk+XG4gKiA8L3VsPlxuICogTk9URTE6ICdwYXJhbXMnIGNhbiBiZSBvbWl0dGVkLjxici8+XG4gKiBOT1RFMjogJ29iaicgcGFyYW1ldGVyIGhhdmUgYmVlbiBzdXBwb3J0ZWQgc2luY2VcbiAqIGFzbjEgMS4wLjExLCBqc3JzYXNpZ24gNi4xLjEgKDIwMTYtU2VwLTI1KS48YnIvPlxuICogQGV4YW1wbGVcbiAqIC8vIGRlZmF1bHQgY29uc3RydWN0b3JcbiAqIG8gPSBuZXcgS0pVUi5hc24xLkRFUkJpdFN0cmluZygpO1xuICogLy8gaW5pdGlhbGl6ZSB3aXRoIGJpbmFyeSBzdHJpbmdcbiAqIG8gPSBuZXcgS0pVUi5hc24xLkRFUkJpdFN0cmluZyh7YmluOiBcIjEwMTFcIn0pO1xuICogLy8gaW5pdGlhbGl6ZSB3aXRoIGJvb2xlYW4gYXJyYXlcbiAqIG8gPSBuZXcgS0pVUi5hc24xLkRFUkJpdFN0cmluZyh7YXJyYXk6IFt0cnVlLGZhbHNlLHRydWUsdHJ1ZV19KTtcbiAqIC8vIGluaXRpYWxpemUgd2l0aCBoZXhhZGVjaW1hbCBzdHJpbmcgKDA0IGlzIHVudXNlZCBiaXRzKVxuICogbyA9IG5ldyBLSlVSLmFzbjEuREVST2N0ZXRTdHJpbmcoe2hleDogXCIwNGJhYzBcIn0pO1xuICogLy8gaW5pdGlhbGl6ZSB3aXRoIEFTTjFVdGlsLm5ld09iamVjdCBhcmd1bWVudCBmb3IgZW5jYXBzdWxhdGVkXG4gKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJCaXRTdHJpbmcoe29iajoge3NlcTogW3tpbnQ6IDN9LCB7cHJuc3RyOiAnYWFhJ31dfX0pO1xuICogLy8gYWJvdmUgZ2VuZXJhdGVzIGEgQVNOLjEgZGF0YSBsaWtlIHRoaXM6XG4gKiAvLyBCSVQgU1RSSU5HLCBlbmNhcHN1bGF0ZXMge1xuICogLy8gICBTRVFVRU5DRSB7XG4gKiAvLyAgICAgSU5URUdFUiAzXG4gKiAvLyAgICAgUHJpbnRhYmxlU3RyaW5nICdhYWEnXG4gKiAvLyAgICAgfVxuICogLy8gICB9XG4gKi9cbktKVVIuYXNuMS5ERVJCaXRTdHJpbmcgPSBmdW5jdGlvbihwYXJhbXMpIHtcbiAgICBpZiAocGFyYW1zICE9PSB1bmRlZmluZWQgJiYgdHlwZW9mIHBhcmFtcy5vYmogIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgdmFyIG8gPSBLSlVSLmFzbjEuQVNOMVV0aWwubmV3T2JqZWN0KHBhcmFtcy5vYmopO1xuICAgICAgICBwYXJhbXMuaGV4ID0gXCIwMFwiICsgby5nZXRFbmNvZGVkSGV4KCk7XG4gICAgfVxuICAgIEtKVVIuYXNuMS5ERVJCaXRTdHJpbmcuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMpO1xuICAgIHRoaXMuaFQgPSBcIjAzXCI7XG5cbiAgICAvKipcbiAgICAgKiBzZXQgQVNOLjEgdmFsdWUoVikgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmcgaW5jbHVkaW5nIHVudXNlZCBiaXRzXG4gICAgICogQG5hbWUgc2V0SGV4VmFsdWVJbmNsdWRpbmdVbnVzZWRCaXRzXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5ERVJCaXRTdHJpbmcjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtTdHJpbmd9IG5ld0hleFN0cmluZ0luY2x1ZGluZ1VudXNlZEJpdHNcbiAgICAgKi9cbiAgICB0aGlzLnNldEhleFZhbHVlSW5jbHVkaW5nVW51c2VkQml0cyA9IGZ1bmN0aW9uKG5ld0hleFN0cmluZ0luY2x1ZGluZ1VudXNlZEJpdHMpIHtcbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5oViA9IG5ld0hleFN0cmluZ0luY2x1ZGluZ1VudXNlZEJpdHM7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCBBU04uMSB2YWx1ZShWKSBieSB1bnVzZWQgYml0IGFuZCBoZXhhZGVjaW1hbCBzdHJpbmcgb2YgdmFsdWVcbiAgICAgKiBAbmFtZSBzZXRVbnVzZWRCaXRzQW5kSGV4VmFsdWVcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkJpdFN0cmluZyNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0ludGVnZXJ9IHVudXNlZEJpdHNcbiAgICAgKiBAcGFyYW0ge1N0cmluZ30gaFZhbHVlXG4gICAgICovXG4gICAgdGhpcy5zZXRVbnVzZWRCaXRzQW5kSGV4VmFsdWUgPSBmdW5jdGlvbih1bnVzZWRCaXRzLCBoVmFsdWUpIHtcbiAgICAgICAgaWYgKHVudXNlZEJpdHMgPCAwIHx8IDcgPCB1bnVzZWRCaXRzKSB7XG4gICAgICAgICAgICB0aHJvdyBcInVudXNlZCBiaXRzIHNoYWxsIGJlIGZyb20gMCB0byA3OiB1ID0gXCIgKyB1bnVzZWRCaXRzO1xuICAgICAgICB9XG4gICAgICAgIHZhciBoVW51c2VkQml0cyA9IFwiMFwiICsgdW51c2VkQml0cztcbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5oViA9IGhVbnVzZWRCaXRzICsgaFZhbHVlO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBzZXQgQVNOLjEgREVSIEJpdFN0cmluZyBieSBiaW5hcnkgc3RyaW5nPGJyLz5cbiAgICAgKiBAbmFtZSBzZXRCeUJpbmFyeVN0cmluZ1xuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVSQml0U3RyaW5nI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7U3RyaW5nfSBiaW5hcnlTdHJpbmcgYmluYXJ5IHZhbHVlIHN0cmluZyAoaS5lLiAnMTAxMTEnKVxuICAgICAqIEBkZXNjcmlwdGlvblxuICAgICAqIEl0cyB1bnVzZWQgYml0cyB3aWxsIGJlIGNhbGN1bGF0ZWQgYXV0b21hdGljYWxseSBieSBsZW5ndGggb2ZcbiAgICAgKiAnYmluYXJ5VmFsdWUnLiA8YnIvPlxuICAgICAqIE5PVEU6IFRyYWlsaW5nIHplcm9zICcwJyB3aWxsIGJlIGlnbm9yZWQuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJCaXRTdHJpbmcoKTtcbiAgICAgKiBvLnNldEJ5Qm9vbGVhbkFycmF5KFwiMDEwMTFcIik7XG4gICAgICovXG4gICAgdGhpcy5zZXRCeUJpbmFyeVN0cmluZyA9IGZ1bmN0aW9uKGJpbmFyeVN0cmluZykge1xuICAgICAgICBiaW5hcnlTdHJpbmcgPSBiaW5hcnlTdHJpbmcucmVwbGFjZSgvMCskLywgJycpO1xuICAgICAgICB2YXIgdW51c2VkQml0cyA9IDggLSBiaW5hcnlTdHJpbmcubGVuZ3RoICUgODtcbiAgICAgICAgaWYgKHVudXNlZEJpdHMgPT0gOCkgdW51c2VkQml0cyA9IDA7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDw9IHVudXNlZEJpdHM7IGkrKykge1xuICAgICAgICAgICAgYmluYXJ5U3RyaW5nICs9ICcwJztcbiAgICAgICAgfVxuICAgICAgICB2YXIgaCA9ICcnO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJpbmFyeVN0cmluZy5sZW5ndGggLSAxOyBpICs9IDgpIHtcbiAgICAgICAgICAgIHZhciBiID0gYmluYXJ5U3RyaW5nLnN1YnN0cihpLCA4KTtcbiAgICAgICAgICAgIHZhciB4ID0gcGFyc2VJbnQoYiwgMikudG9TdHJpbmcoMTYpO1xuICAgICAgICAgICAgaWYgKHgubGVuZ3RoID09IDEpIHggPSAnMCcgKyB4O1xuICAgICAgICAgICAgaCArPSB4O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMuaFYgPSAnMCcgKyB1bnVzZWRCaXRzICsgaDtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogc2V0IEFTTi4xIFRMViB2YWx1ZShWKSBieSBhbiBhcnJheSBvZiBib29sZWFuPGJyLz5cbiAgICAgKiBAbmFtZSBzZXRCeUJvb2xlYW5BcnJheVxuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVSQml0U3RyaW5nI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7YXJyYXl9IGJvb2xlYW5BcnJheSBhcnJheSBvZiBib29sZWFuIChleC4gW3RydWUsIGZhbHNlLCB0cnVlXSlcbiAgICAgKiBAZGVzY3JpcHRpb25cbiAgICAgKiBOT1RFOiBUcmFpbGluZyBmYWxzZXMgd2lsbCBiZSBpZ25vcmVkIGluIHRoZSBBU04uMSBERVIgT2JqZWN0LlxuICAgICAqIEBleGFtcGxlXG4gICAgICogbyA9IG5ldyBLSlVSLmFzbjEuREVSQml0U3RyaW5nKCk7XG4gICAgICogby5zZXRCeUJvb2xlYW5BcnJheShbZmFsc2UsIHRydWUsIGZhbHNlLCB0cnVlLCB0cnVlXSk7XG4gICAgICovXG4gICAgdGhpcy5zZXRCeUJvb2xlYW5BcnJheSA9IGZ1bmN0aW9uKGJvb2xlYW5BcnJheSkge1xuICAgICAgICB2YXIgcyA9ICcnO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJvb2xlYW5BcnJheS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGJvb2xlYW5BcnJheVtpXSA9PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcyArPSAnMSc7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHMgKz0gJzAnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0QnlCaW5hcnlTdHJpbmcocyk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIGdlbmVyYXRlIGFuIGFycmF5IG9mIGZhbHNlcyB3aXRoIHNwZWNpZmllZCBsZW5ndGg8YnIvPlxuICAgICAqIEBuYW1lIG5ld0ZhbHNlQXJyYXlcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkJpdFN0cmluZ1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7SW50ZWdlcn0gbkxlbmd0aCBsZW5ndGggb2YgYXJyYXkgdG8gZ2VuZXJhdGVcbiAgICAgKiBAcmV0dXJuIHthcnJheX0gYXJyYXkgb2YgYm9vbGVhbiBmYWxzZXNcbiAgICAgKiBAZGVzY3JpcHRpb25cbiAgICAgKiBUaGlzIHN0YXRpYyBtZXRob2QgbWF5IGJlIHVzZWZ1bCB0byBpbml0aWFsaXplIGJvb2xlYW4gYXJyYXkuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJCaXRTdHJpbmcoKTtcbiAgICAgKiBvLm5ld0ZhbHNlQXJyYXkoMykgJnJhcnI7IFtmYWxzZSwgZmFsc2UsIGZhbHNlXVxuICAgICAqL1xuICAgIHRoaXMubmV3RmFsc2VBcnJheSA9IGZ1bmN0aW9uKG5MZW5ndGgpIHtcbiAgICAgICAgdmFyIGEgPSBuZXcgQXJyYXkobkxlbmd0aCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbkxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBhW2ldID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfTtcblxuICAgIHRoaXMuZ2V0RnJlc2hWYWx1ZUhleCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5oVjtcbiAgICB9O1xuXG4gICAgaWYgKHR5cGVvZiBwYXJhbXMgIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBpZiAodHlwZW9mIHBhcmFtcyA9PSBcInN0cmluZ1wiICYmIHBhcmFtcy50b0xvd2VyQ2FzZSgpLm1hdGNoKC9eWzAtOWEtZl0rJC8pKSB7XG4gICAgICAgICAgICB0aGlzLnNldEhleFZhbHVlSW5jbHVkaW5nVW51c2VkQml0cyhwYXJhbXMpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwYXJhbXNbJ2hleCddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0SGV4VmFsdWVJbmNsdWRpbmdVbnVzZWRCaXRzKHBhcmFtc1snaGV4J10pO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwYXJhbXNbJ2JpbiddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0QnlCaW5hcnlTdHJpbmcocGFyYW1zWydiaW4nXSk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHBhcmFtc1snYXJyYXknXSAhPSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICB0aGlzLnNldEJ5Qm9vbGVhbkFycmF5KHBhcmFtc1snYXJyYXknXSk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUkJpdFN0cmluZywgS0pVUi5hc24xLkFTTjFPYmplY3QpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIE9jdGV0U3RyaW5nPGJyLz5cbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZ1xuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgT2N0ZXRTdHJpbmdcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnYWFhJ30pXG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmdcbiAqIEBkZXNjcmlwdGlvblxuICogVGhpcyBjbGFzcyBwcm92aWRlcyBBU04uMSBPY3RldFN0cmluZyBzaW1wbGUgdHlwZS48YnIvPlxuICogU3VwcG9ydGVkIFwicGFyYW1zXCIgYXR0cmlidXRlcyBhcmU6XG4gKiA8dWw+XG4gKiA8bGk+c3RyIC0gdG8gc2V0IGEgc3RyaW5nIGFzIGEgdmFsdWU8L2xpPlxuICogPGxpPmhleCAtIHRvIHNldCBhIGhleGFkZWNpbWFsIHN0cmluZyBhcyBhIHZhbHVlPC9saT5cbiAqIDxsaT5vYmogLSB0byBzZXQgYSBlbmNhcHN1bGF0ZWQgQVNOLjEgdmFsdWUgYnkgSlNPTiBvYmplY3RcbiAqIHdoaWNoIGlzIGRlZmluZWQgaW4ge0BsaW5rIEtKVVIuYXNuMS5BU04xVXRpbC5uZXdPYmplY3R9PC9saT5cbiAqIDwvdWw+XG4gKiBOT1RFOiBBIHBhcmFtZXRlciAnb2JqJyBoYXZlIGJlZW4gc3VwcG9ydGVkXG4gKiBmb3IgXCJPQ1RFVCBTVFJJTkcsIGVuY2Fwc3VsYXRlc1wiIHN0cnVjdHVyZS5cbiAqIHNpbmNlIGFzbjEgMS4wLjExLCBqc3JzYXNpZ24gNi4xLjEgKDIwMTYtU2VwLTI1KS5cbiAqIEBzZWUgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nIC0gc3VwZXJjbGFzc1xuICogQGV4YW1wbGVcbiAqIC8vIGRlZmF1bHQgY29uc3RydWN0b3JcbiAqIG8gPSBuZXcgS0pVUi5hc24xLkRFUk9jdGV0U3RyaW5nKCk7XG4gKiAvLyBpbml0aWFsaXplIHdpdGggc3RyaW5nXG4gKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZyh7c3RyOiBcImFhYVwifSk7XG4gKiAvLyBpbml0aWFsaXplIHdpdGggaGV4YWRlY2ltYWwgc3RyaW5nXG4gKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZyh7aGV4OiBcIjYxNjE2MVwifSk7XG4gKiAvLyBpbml0aWFsaXplIHdpdGggQVNOMVV0aWwubmV3T2JqZWN0IGFyZ3VtZW50XG4gKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZyh7b2JqOiB7c2VxOiBbe2ludDogM30sIHtwcm5zdHI6ICdhYWEnfV19fSk7XG4gKiAvLyBhYm92ZSBnZW5lcmF0ZXMgYSBBU04uMSBkYXRhIGxpa2UgdGhpczpcbiAqIC8vIE9DVEVUIFNUUklORywgZW5jYXBzdWxhdGVzIHtcbiAqIC8vICAgU0VRVUVOQ0Uge1xuICogLy8gICAgIElOVEVHRVIgM1xuICogLy8gICAgIFByaW50YWJsZVN0cmluZyAnYWFhJ1xuICogLy8gICAgIH1cbiAqIC8vICAgfVxuICovXG5LSlVSLmFzbjEuREVST2N0ZXRTdHJpbmcgPSBmdW5jdGlvbihwYXJhbXMpIHtcbiAgICBpZiAocGFyYW1zICE9PSB1bmRlZmluZWQgJiYgdHlwZW9mIHBhcmFtcy5vYmogIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgdmFyIG8gPSBLSlVSLmFzbjEuQVNOMVV0aWwubmV3T2JqZWN0KHBhcmFtcy5vYmopO1xuICAgICAgICBwYXJhbXMuaGV4ID0gby5nZXRFbmNvZGVkSGV4KCk7XG4gICAgfVxuICAgIEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZy5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcywgcGFyYW1zKTtcbiAgICB0aGlzLmhUID0gXCIwNFwiO1xufTtcbllBSE9PLmxhbmcuZXh0ZW5kKEtKVVIuYXNuMS5ERVJPY3RldFN0cmluZywgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nKTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBOdWxsXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSTnVsbFxuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgTnVsbFxuICogQGV4dGVuZHMgS0pVUi5hc24xLkFTTjFPYmplY3RcbiAqIEBkZXNjcmlwdGlvblxuICogQHNlZSBLSlVSLmFzbjEuQVNOMU9iamVjdCAtIHN1cGVyY2xhc3NcbiAqL1xuS0pVUi5hc24xLkRFUk51bGwgPSBmdW5jdGlvbigpIHtcbiAgICBLSlVSLmFzbjEuREVSTnVsbC5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcyk7XG4gICAgdGhpcy5oVCA9IFwiMDVcIjtcbiAgICB0aGlzLmhUTFYgPSBcIjA1MDBcIjtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSTnVsbCwgS0pVUi5hc24xLkFTTjFPYmplY3QpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIE9iamVjdElkZW50aWZpZXJcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJPYmplY3RJZGVudGlmaWVyXG4gKiBAY2xhc3MgY2xhc3MgZm9yIEFTTi4xIERFUiBPYmplY3RJZGVudGlmaWVyXG4gKiBAcGFyYW0ge0FycmF5fSBwYXJhbXMgYXNzb2NpYXRpdmUgYXJyYXkgb2YgcGFyYW1ldGVycyAoZXguIHsnb2lkJzogJzIuNS40LjUnfSlcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5BU04xT2JqZWN0XG4gKiBAZGVzY3JpcHRpb25cbiAqIDxici8+XG4gKiBBcyBmb3IgYXJndW1lbnQgJ3BhcmFtcycgZm9yIGNvbnN0cnVjdG9yLCB5b3UgY2FuIHNwZWNpZnkgb25lIG9mXG4gKiBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqIDx1bD5cbiAqIDxsaT5vaWQgLSBzcGVjaWZ5IGluaXRpYWwgQVNOLjEgdmFsdWUoVikgYnkgYSBvaWQgc3RyaW5nIChleC4gMi41LjQuMTMpPC9saT5cbiAqIDxsaT5oZXggLSBzcGVjaWZ5IGluaXRpYWwgQVNOLjEgdmFsdWUoVikgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmc8L2xpPlxuICogPC91bD5cbiAqIE5PVEU6ICdwYXJhbXMnIGNhbiBiZSBvbWl0dGVkLlxuICovXG5LSlVSLmFzbjEuREVST2JqZWN0SWRlbnRpZmllciA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIHZhciBpdG94ID0gZnVuY3Rpb24oaSkge1xuICAgICAgICB2YXIgaCA9IGkudG9TdHJpbmcoMTYpO1xuICAgICAgICBpZiAoaC5sZW5ndGggPT0gMSkgaCA9ICcwJyArIGg7XG4gICAgICAgIHJldHVybiBoO1xuICAgIH07XG4gICAgdmFyIHJvaWR0b3ggPSBmdW5jdGlvbihyb2lkKSB7XG4gICAgICAgIHZhciBoID0gJyc7XG4gICAgICAgIHZhciBiaSA9IG5ldyBCaWdJbnRlZ2VyKHJvaWQsIDEwKTtcbiAgICAgICAgdmFyIGIgPSBiaS50b1N0cmluZygyKTtcbiAgICAgICAgdmFyIHBhZExlbiA9IDcgLSBiLmxlbmd0aCAlIDc7XG4gICAgICAgIGlmIChwYWRMZW4gPT0gNykgcGFkTGVuID0gMDtcbiAgICAgICAgdmFyIGJQYWQgPSAnJztcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWRMZW47IGkrKykgYlBhZCArPSAnMCc7XG4gICAgICAgIGIgPSBiUGFkICsgYjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBiLmxlbmd0aCAtIDE7IGkgKz0gNykge1xuICAgICAgICAgICAgdmFyIGI4ID0gYi5zdWJzdHIoaSwgNyk7XG4gICAgICAgICAgICBpZiAoaSAhPSBiLmxlbmd0aCAtIDcpIGI4ID0gJzEnICsgYjg7XG4gICAgICAgICAgICBoICs9IGl0b3gocGFyc2VJbnQoYjgsIDIpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaDtcbiAgICB9O1xuXG4gICAgS0pVUi5hc24xLkRFUk9iamVjdElkZW50aWZpZXIuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMpO1xuICAgIHRoaXMuaFQgPSBcIjA2XCI7XG5cbiAgICAvKipcbiAgICAgKiBzZXQgdmFsdWUgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmdcbiAgICAgKiBAbmFtZSBzZXRWYWx1ZUhleFxuICAgICAqIEBtZW1iZXJPZiBLSlVSLmFzbjEuREVST2JqZWN0SWRlbnRpZmllciNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge1N0cmluZ30gbmV3SGV4U3RyaW5nIGhleGFkZWNpbWFsIHZhbHVlIG9mIE9JRCBieXRlc1xuICAgICAqL1xuICAgIHRoaXMuc2V0VmFsdWVIZXggPSBmdW5jdGlvbihuZXdIZXhTdHJpbmcpIHtcbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zID0gbnVsbDtcbiAgICAgICAgdGhpcy5oViA9IG5ld0hleFN0cmluZztcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IGEgT0lEIHN0cmluZzxici8+XG4gICAgICogQG5hbWUgc2V0VmFsdWVPaWRTdHJpbmdcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUk9iamVjdElkZW50aWZpZXIjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtTdHJpbmd9IG9pZFN0cmluZyBPSUQgc3RyaW5nIChleC4gMi41LjQuMTMpXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBvID0gbmV3IEtKVVIuYXNuMS5ERVJPYmplY3RJZGVudGlmaWVyKCk7XG4gICAgICogby5zZXRWYWx1ZU9pZFN0cmluZyhcIjIuNS40LjEzXCIpO1xuICAgICAqL1xuICAgIHRoaXMuc2V0VmFsdWVPaWRTdHJpbmcgPSBmdW5jdGlvbihvaWRTdHJpbmcpIHtcbiAgICAgICAgaWYgKCEgb2lkU3RyaW5nLm1hdGNoKC9eWzAtOS5dKyQvKSkge1xuICAgICAgICAgICAgdGhyb3cgXCJtYWxmb3JtZWQgb2lkIHN0cmluZzogXCIgKyBvaWRTdHJpbmc7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGggPSAnJztcbiAgICAgICAgdmFyIGEgPSBvaWRTdHJpbmcuc3BsaXQoJy4nKTtcbiAgICAgICAgdmFyIGkwID0gcGFyc2VJbnQoYVswXSkgKiA0MCArIHBhcnNlSW50KGFbMV0pO1xuICAgICAgICBoICs9IGl0b3goaTApO1xuICAgICAgICBhLnNwbGljZSgwLCAyKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBoICs9IHJvaWR0b3goYVtpXSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5oVExWID0gbnVsbDtcbiAgICAgICAgdGhpcy5pc01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zID0gbnVsbDtcbiAgICAgICAgdGhpcy5oViA9IGg7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBhIE9JRCBuYW1lXG4gICAgICogQG5hbWUgc2V0VmFsdWVOYW1lXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5ERVJPYmplY3RJZGVudGlmaWVyI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7U3RyaW5nfSBvaWROYW1lIE9JRCBuYW1lIChleC4gJ3NlcnZlckF1dGgnKVxuICAgICAqIEBzaW5jZSAxLjAuMVxuICAgICAqIEBkZXNjcmlwdGlvblxuICAgICAqIE9JRCBuYW1lIHNoYWxsIGJlIGRlZmluZWQgaW4gJ0tKVVIuYXNuMS54NTA5Lk9JRC5uYW1lMm9pZExpc3QnLlxuICAgICAqIE90aGVyd2lzZSByYWlzZSBlcnJvci5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIG8gPSBuZXcgS0pVUi5hc24xLkRFUk9iamVjdElkZW50aWZpZXIoKTtcbiAgICAgKiBvLnNldFZhbHVlTmFtZShcInNlcnZlckF1dGhcIik7XG4gICAgICovXG4gICAgdGhpcy5zZXRWYWx1ZU5hbWUgPSBmdW5jdGlvbihvaWROYW1lKSB7XG4gICAgICAgIHZhciBvaWQgPSBLSlVSLmFzbjEueDUwOS5PSUQubmFtZTJvaWQob2lkTmFtZSk7XG4gICAgICAgIGlmIChvaWQgIT09ICcnKSB7XG4gICAgICAgICAgICB0aGlzLnNldFZhbHVlT2lkU3RyaW5nKG9pZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBcIkRFUk9iamVjdElkZW50aWZpZXIgb2lkTmFtZSB1bmRlZmluZWQ6IFwiICsgb2lkTmFtZTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcblxuICAgIGlmIChwYXJhbXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAodHlwZW9mIHBhcmFtcyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgaWYgKHBhcmFtcy5tYXRjaCgvXlswLTJdLlswLTkuXSskLykpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldFZhbHVlT2lkU3RyaW5nKHBhcmFtcyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0VmFsdWVOYW1lKHBhcmFtcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocGFyYW1zLm9pZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLnNldFZhbHVlT2lkU3RyaW5nKHBhcmFtcy5vaWQpO1xuICAgICAgICB9IGVsc2UgaWYgKHBhcmFtcy5oZXggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5zZXRWYWx1ZUhleChwYXJhbXMuaGV4KTtcbiAgICAgICAgfSBlbHNlIGlmIChwYXJhbXMubmFtZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLnNldFZhbHVlTmFtZShwYXJhbXMubmFtZSk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUk9iamVjdElkZW50aWZpZXIsIEtKVVIuYXNuMS5BU04xT2JqZWN0KTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBFbnVtZXJhdGVkXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSRW51bWVyYXRlZFxuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgRW51bWVyYXRlZFxuICogQGV4dGVuZHMgS0pVUi5hc24xLkFTTjFPYmplY3RcbiAqIEBkZXNjcmlwdGlvblxuICogPGJyLz5cbiAqIEFzIGZvciBhcmd1bWVudCAncGFyYW1zJyBmb3IgY29uc3RydWN0b3IsIHlvdSBjYW4gc3BlY2lmeSBvbmUgb2ZcbiAqIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICogPHVsPlxuICogPGxpPmludCAtIHNwZWNpZnkgaW5pdGlhbCBBU04uMSB2YWx1ZShWKSBieSBpbnRlZ2VyIHZhbHVlPC9saT5cbiAqIDxsaT5oZXggLSBzcGVjaWZ5IGluaXRpYWwgQVNOLjEgdmFsdWUoVikgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmc8L2xpPlxuICogPC91bD5cbiAqIE5PVEU6ICdwYXJhbXMnIGNhbiBiZSBvbWl0dGVkLlxuICogQGV4YW1wbGVcbiAqIG5ldyBLSlVSLmFzbjEuREVSRW51bWVyYXRlZCgxMjMpO1xuICogbmV3IEtKVVIuYXNuMS5ERVJFbnVtZXJhdGVkKHtpbnQ6IDEyM30pO1xuICogbmV3IEtKVVIuYXNuMS5ERVJFbnVtZXJhdGVkKHtoZXg6ICcxZmFkJ30pO1xuICovXG5LSlVSLmFzbjEuREVSRW51bWVyYXRlZCA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIEtKVVIuYXNuMS5ERVJFbnVtZXJhdGVkLnN1cGVyY2xhc3MuY29uc3RydWN0b3IuY2FsbCh0aGlzKTtcbiAgICB0aGlzLmhUID0gXCIwYVwiO1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IFRvbSBXdSdzIEJpZ0ludGVnZXIgb2JqZWN0XG4gICAgICogQG5hbWUgc2V0QnlCaWdJbnRlZ2VyXG4gICAgICogQG1lbWJlck9mIEtKVVIuYXNuMS5ERVJFbnVtZXJhdGVkI1xuICAgICAqIEBmdW5jdGlvblxuICAgICAqIEBwYXJhbSB7QmlnSW50ZWdlcn0gYmlnSW50ZWdlclZhbHVlIHRvIHNldFxuICAgICAqL1xuICAgIHRoaXMuc2V0QnlCaWdJbnRlZ2VyID0gZnVuY3Rpb24oYmlnSW50ZWdlclZhbHVlKSB7XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMuaFYgPSBLSlVSLmFzbjEuQVNOMVV0aWwuYmlnSW50VG9NaW5Ud29zQ29tcGxlbWVudHNIZXgoYmlnSW50ZWdlclZhbHVlKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IGludGVnZXIgdmFsdWVcbiAgICAgKiBAbmFtZSBzZXRCeUludGVnZXJcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkVudW1lcmF0ZWQjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtJbnRlZ2VyfSBpbnRlZ2VyIHZhbHVlIHRvIHNldFxuICAgICAqL1xuICAgIHRoaXMuc2V0QnlJbnRlZ2VyID0gZnVuY3Rpb24oaW50VmFsdWUpIHtcbiAgICAgICAgdmFyIGJpID0gbmV3IEJpZ0ludGVnZXIoU3RyaW5nKGludFZhbHVlKSwgMTApO1xuICAgICAgICB0aGlzLnNldEJ5QmlnSW50ZWdlcihiaSk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBpbnRlZ2VyIHZhbHVlXG4gICAgICogQG5hbWUgc2V0VmFsdWVIZXhcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkVudW1lcmF0ZWQjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtTdHJpbmd9IGhleGFkZWNpbWFsIHN0cmluZyBvZiBpbnRlZ2VyIHZhbHVlXG4gICAgICogQGRlc2NyaXB0aW9uXG4gICAgICogPGJyLz5cbiAgICAgKiBOT1RFOiBWYWx1ZSBzaGFsbCBiZSByZXByZXNlbnRlZCBieSBtaW5pbXVtIG9jdGV0IGxlbmd0aCBvZlxuICAgICAqIHR3bydzIGNvbXBsZW1lbnQgcmVwcmVzZW50YXRpb24uXG4gICAgICovXG4gICAgdGhpcy5zZXRWYWx1ZUhleCA9IGZ1bmN0aW9uKG5ld0hleFN0cmluZykge1xuICAgICAgICB0aGlzLmhWID0gbmV3SGV4U3RyaW5nO1xuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcblxuICAgIGlmICh0eXBlb2YgcGFyYW1zICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBwYXJhbXNbJ2ludCddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0QnlJbnRlZ2VyKHBhcmFtc1snaW50J10pO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwYXJhbXMgPT0gXCJudW1iZXJcIikge1xuICAgICAgICAgICAgdGhpcy5zZXRCeUludGVnZXIocGFyYW1zKTtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgcGFyYW1zWydoZXgnXSAhPSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICB0aGlzLnNldFZhbHVlSGV4KHBhcmFtc1snaGV4J10pO1xuICAgICAgICB9XG4gICAgfVxufTtcbllBSE9PLmxhbmcuZXh0ZW5kKEtKVVIuYXNuMS5ERVJFbnVtZXJhdGVkLCBLSlVSLmFzbjEuQVNOMU9iamVjdCk7XG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vKipcbiAqIGNsYXNzIGZvciBBU04uMSBERVIgVVRGOFN0cmluZ1xuICogQG5hbWUgS0pVUi5hc24xLkRFUlVURjhTdHJpbmdcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIFVURjhTdHJpbmdcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnYWFhJ30pXG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmdcbiAqIEBkZXNjcmlwdGlvblxuICogQHNlZSBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmcgLSBzdXBlcmNsYXNzXG4gKi9cbktKVVIuYXNuMS5ERVJVVEY4U3RyaW5nID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUlVURjhTdHJpbmcuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMsIHBhcmFtcyk7XG4gICAgdGhpcy5oVCA9IFwiMGNcIjtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSVVRGOFN0cmluZywgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nKTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBOdW1lcmljU3RyaW5nXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSTnVtZXJpY1N0cmluZ1xuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgTnVtZXJpY1N0cmluZ1xuICogQHBhcmFtIHtBcnJheX0gcGFyYW1zIGFzc29jaWF0aXZlIGFycmF5IG9mIHBhcmFtZXRlcnMgKGV4LiB7J3N0cic6ICdhYWEnfSlcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZ1xuICogQGRlc2NyaXB0aW9uXG4gKiBAc2VlIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZyAtIHN1cGVyY2xhc3NcbiAqL1xuS0pVUi5hc24xLkRFUk51bWVyaWNTdHJpbmcgPSBmdW5jdGlvbihwYXJhbXMpIHtcbiAgICBLSlVSLmFzbjEuREVSTnVtZXJpY1N0cmluZy5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcywgcGFyYW1zKTtcbiAgICB0aGlzLmhUID0gXCIxMlwiO1xufTtcbllBSE9PLmxhbmcuZXh0ZW5kKEtKVVIuYXNuMS5ERVJOdW1lcmljU3RyaW5nLCBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmcpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIFByaW50YWJsZVN0cmluZ1xuICogQG5hbWUgS0pVUi5hc24xLkRFUlByaW50YWJsZVN0cmluZ1xuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgUHJpbnRhYmxlU3RyaW5nXG4gKiBAcGFyYW0ge0FycmF5fSBwYXJhbXMgYXNzb2NpYXRpdmUgYXJyYXkgb2YgcGFyYW1ldGVycyAoZXguIHsnc3RyJzogJ2FhYSd9KVxuICogQGV4dGVuZHMgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nXG4gKiBAZGVzY3JpcHRpb25cbiAqIEBzZWUgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nIC0gc3VwZXJjbGFzc1xuICovXG5LSlVSLmFzbjEuREVSUHJpbnRhYmxlU3RyaW5nID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUlByaW50YWJsZVN0cmluZy5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcywgcGFyYW1zKTtcbiAgICB0aGlzLmhUID0gXCIxM1wiO1xufTtcbllBSE9PLmxhbmcuZXh0ZW5kKEtKVVIuYXNuMS5ERVJQcmludGFibGVTdHJpbmcsIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZyk7XG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vKipcbiAqIGNsYXNzIGZvciBBU04uMSBERVIgVGVsZXRleFN0cmluZ1xuICogQG5hbWUgS0pVUi5hc24xLkRFUlRlbGV0ZXhTdHJpbmdcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIFRlbGV0ZXhTdHJpbmdcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnYWFhJ30pXG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmdcbiAqIEBkZXNjcmlwdGlvblxuICogQHNlZSBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmcgLSBzdXBlcmNsYXNzXG4gKi9cbktKVVIuYXNuMS5ERVJUZWxldGV4U3RyaW5nID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUlRlbGV0ZXhTdHJpbmcuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMsIHBhcmFtcyk7XG4gICAgdGhpcy5oVCA9IFwiMTRcIjtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSVGVsZXRleFN0cmluZywgS0pVUi5hc24xLkRFUkFic3RyYWN0U3RyaW5nKTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBJQTVTdHJpbmdcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJJQTVTdHJpbmdcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIElBNVN0cmluZ1xuICogQHBhcmFtIHtBcnJheX0gcGFyYW1zIGFzc29jaWF0aXZlIGFycmF5IG9mIHBhcmFtZXRlcnMgKGV4LiB7J3N0cic6ICdhYWEnfSlcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZ1xuICogQGRlc2NyaXB0aW9uXG4gKiBAc2VlIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cmluZyAtIHN1cGVyY2xhc3NcbiAqL1xuS0pVUi5hc24xLkRFUklBNVN0cmluZyA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIEtKVVIuYXNuMS5ERVJJQTVTdHJpbmcuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMsIHBhcmFtcyk7XG4gICAgdGhpcy5oVCA9IFwiMTZcIjtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSSUE1U3RyaW5nLCBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJpbmcpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIFVUQ1RpbWVcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJVVENUaW1lXG4gKiBAY2xhc3MgY2xhc3MgZm9yIEFTTi4xIERFUiBVVENUaW1lXG4gKiBAcGFyYW0ge0FycmF5fSBwYXJhbXMgYXNzb2NpYXRpdmUgYXJyYXkgb2YgcGFyYW1ldGVycyAoZXguIHsnc3RyJzogJzEzMDQzMDIzNTk1OVonfSlcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFRpbWVcbiAqIEBkZXNjcmlwdGlvblxuICogPGJyLz5cbiAqIEFzIGZvciBhcmd1bWVudCAncGFyYW1zJyBmb3IgY29uc3RydWN0b3IsIHlvdSBjYW4gc3BlY2lmeSBvbmUgb2ZcbiAqIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICogPHVsPlxuICogPGxpPnN0ciAtIHNwZWNpZnkgaW5pdGlhbCBBU04uMSB2YWx1ZShWKSBieSBhIHN0cmluZyAoZXguJzEzMDQzMDIzNTk1OVonKTwvbGk+XG4gKiA8bGk+aGV4IC0gc3BlY2lmeSBpbml0aWFsIEFTTi4xIHZhbHVlKFYpIGJ5IGEgaGV4YWRlY2ltYWwgc3RyaW5nPC9saT5cbiAqIDxsaT5kYXRlIC0gc3BlY2lmeSBEYXRlIG9iamVjdC48L2xpPlxuICogPC91bD5cbiAqIE5PVEU6ICdwYXJhbXMnIGNhbiBiZSBvbWl0dGVkLlxuICogPGg0PkVYQU1QTEVTPC9oND5cbiAqIEBleGFtcGxlXG4gKiBkMSA9IG5ldyBLSlVSLmFzbjEuREVSVVRDVGltZSgpO1xuICogZDEuc2V0U3RyaW5nKCcxMzA0MzAxMjU5NTlaJyk7XG4gKlxuICogZDIgPSBuZXcgS0pVUi5hc24xLkRFUlVUQ1RpbWUoeydzdHInOiAnMTMwNDMwMTI1OTU5Wid9KTtcbiAqIGQzID0gbmV3IEtKVVIuYXNuMS5ERVJVVENUaW1lKHsnZGF0ZSc6IG5ldyBEYXRlKERhdGUuVVRDKDIwMTUsIDAsIDMxLCAwLCAwLCAwLCAwKSl9KTtcbiAqIGQ0ID0gbmV3IEtKVVIuYXNuMS5ERVJVVENUaW1lKCcxMzA0MzAxMjU5NTlaJyk7XG4gKi9cbktKVVIuYXNuMS5ERVJVVENUaW1lID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUlVUQ1RpbWUuc3VwZXJjbGFzcy5jb25zdHJ1Y3Rvci5jYWxsKHRoaXMsIHBhcmFtcyk7XG4gICAgdGhpcy5oVCA9IFwiMTdcIjtcblxuICAgIC8qKlxuICAgICAqIHNldCB2YWx1ZSBieSBhIERhdGUgb2JqZWN0PGJyLz5cbiAgICAgKiBAbmFtZSBzZXRCeURhdGVcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUlVUQ1RpbWUjXG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtEYXRlfSBkYXRlT2JqZWN0IERhdGUgb2JqZWN0IHRvIHNldCBBU04uMSB2YWx1ZShWKVxuICAgICAqIEBleGFtcGxlXG4gICAgICogbyA9IG5ldyBLSlVSLmFzbjEuREVSVVRDVGltZSgpO1xuICAgICAqIG8uc2V0QnlEYXRlKG5ldyBEYXRlKFwiMjAxNi8xMi8zMVwiKSk7XG4gICAgICovXG4gICAgdGhpcy5zZXRCeURhdGUgPSBmdW5jdGlvbihkYXRlT2JqZWN0KSB7XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMuZGF0ZSA9IGRhdGVPYmplY3Q7XG4gICAgICAgIHRoaXMucyA9IHRoaXMuZm9ybWF0RGF0ZSh0aGlzLmRhdGUsICd1dGMnKTtcbiAgICAgICAgdGhpcy5oViA9IHN0b2hleCh0aGlzLnMpO1xuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmRhdGUgPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2YgdGhpcy5zID09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuZGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICB0aGlzLnMgPSB0aGlzLmZvcm1hdERhdGUodGhpcy5kYXRlLCAndXRjJyk7XG4gICAgICAgICAgICB0aGlzLmhWID0gc3RvaGV4KHRoaXMucyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcblxuICAgIGlmIChwYXJhbXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAocGFyYW1zLnN0ciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLnNldFN0cmluZyhwYXJhbXMuc3RyKTtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgcGFyYW1zID09IFwic3RyaW5nXCIgJiYgcGFyYW1zLm1hdGNoKC9eWzAtOV17MTJ9WiQvKSkge1xuICAgICAgICAgICAgdGhpcy5zZXRTdHJpbmcocGFyYW1zKTtcbiAgICAgICAgfSBlbHNlIGlmIChwYXJhbXMuaGV4ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RyaW5nSGV4KHBhcmFtcy5oZXgpO1xuICAgICAgICB9IGVsc2UgaWYgKHBhcmFtcy5kYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0QnlEYXRlKHBhcmFtcy5kYXRlKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSVVRDVGltZSwgS0pVUi5hc24xLkRFUkFic3RyYWN0VGltZSk7XG5cbi8vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vKipcbiAqIGNsYXNzIGZvciBBU04uMSBERVIgR2VuZXJhbGl6ZWRUaW1lXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSR2VuZXJhbGl6ZWRUaW1lXG4gKiBAY2xhc3MgY2xhc3MgZm9yIEFTTi4xIERFUiBHZW5lcmFsaXplZFRpbWVcbiAqIEBwYXJhbSB7QXJyYXl9IHBhcmFtcyBhc3NvY2lhdGl2ZSBhcnJheSBvZiBwYXJhbWV0ZXJzIChleC4geydzdHInOiAnMjAxMzA0MzAyMzU5NTlaJ30pXG4gKiBAcHJvcGVydHkge0Jvb2xlYW59IHdpdGhNaWxsaXMgZmxhZyB0byBzaG93IG1pbGxpc2Vjb25kcyBvciBub3RcbiAqIEBleHRlbmRzIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFRpbWVcbiAqIEBkZXNjcmlwdGlvblxuICogPGJyLz5cbiAqIEFzIGZvciBhcmd1bWVudCAncGFyYW1zJyBmb3IgY29uc3RydWN0b3IsIHlvdSBjYW4gc3BlY2lmeSBvbmUgb2ZcbiAqIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICogPHVsPlxuICogPGxpPnN0ciAtIHNwZWNpZnkgaW5pdGlhbCBBU04uMSB2YWx1ZShWKSBieSBhIHN0cmluZyAoZXguJzIwMTMwNDMwMjM1OTU5WicpPC9saT5cbiAqIDxsaT5oZXggLSBzcGVjaWZ5IGluaXRpYWwgQVNOLjEgdmFsdWUoVikgYnkgYSBoZXhhZGVjaW1hbCBzdHJpbmc8L2xpPlxuICogPGxpPmRhdGUgLSBzcGVjaWZ5IERhdGUgb2JqZWN0LjwvbGk+XG4gKiA8bGk+bWlsbGlzIC0gc3BlY2lmeSBmbGFnIHRvIHNob3cgbWlsbGlzZWNvbmRzIChmcm9tIDEuMC42KTwvbGk+XG4gKiA8L3VsPlxuICogTk9URTE6ICdwYXJhbXMnIGNhbiBiZSBvbWl0dGVkLlxuICogTk9URTI6ICd3aXRoTWlsbGlzJyBwcm9wZXJ0eSBpcyBzdXBwb3J0ZWQgZnJvbSBhc24xIDEuMC42LlxuICovXG5LSlVSLmFzbjEuREVSR2VuZXJhbGl6ZWRUaW1lID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUkdlbmVyYWxpemVkVGltZS5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcywgcGFyYW1zKTtcbiAgICB0aGlzLmhUID0gXCIxOFwiO1xuICAgIHRoaXMud2l0aE1pbGxpcyA9IGZhbHNlO1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IGEgRGF0ZSBvYmplY3RcbiAgICAgKiBAbmFtZSBzZXRCeURhdGVcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUkdlbmVyYWxpemVkVGltZSNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0RhdGV9IGRhdGVPYmplY3QgRGF0ZSBvYmplY3QgdG8gc2V0IEFTTi4xIHZhbHVlKFYpXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBXaGVuIHlvdSBzcGVjaWZ5IFVUQyB0aW1lLCB1c2UgJ0RhdGUuVVRDJyBtZXRob2QgbGlrZSB0aGlzOjxici8+XG4gICAgICogbzEgPSBuZXcgREVSVVRDVGltZSgpO1xuICAgICAqIG8xLnNldEJ5RGF0ZShkYXRlKTtcbiAgICAgKlxuICAgICAqIGRhdGUgPSBuZXcgRGF0ZShEYXRlLlVUQygyMDE1LCAwLCAzMSwgMjMsIDU5LCA1OSwgMCkpOyAjMjAxNUpBTjMxIDIzOjU5OjU5XG4gICAgICovXG4gICAgdGhpcy5zZXRCeURhdGUgPSBmdW5jdGlvbihkYXRlT2JqZWN0KSB7XG4gICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgIHRoaXMuaXNNb2RpZmllZCA9IHRydWU7XG4gICAgICAgIHRoaXMuZGF0ZSA9IGRhdGVPYmplY3Q7XG4gICAgICAgIHRoaXMucyA9IHRoaXMuZm9ybWF0RGF0ZSh0aGlzLmRhdGUsICdnZW4nLCB0aGlzLndpdGhNaWxsaXMpO1xuICAgICAgICB0aGlzLmhWID0gc3RvaGV4KHRoaXMucyk7XG4gICAgfTtcblxuICAgIHRoaXMuZ2V0RnJlc2hWYWx1ZUhleCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAodGhpcy5kYXRlID09PSB1bmRlZmluZWQgJiYgdGhpcy5zID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuZGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICB0aGlzLnMgPSB0aGlzLmZvcm1hdERhdGUodGhpcy5kYXRlLCAnZ2VuJywgdGhpcy53aXRoTWlsbGlzKTtcbiAgICAgICAgICAgIHRoaXMuaFYgPSBzdG9oZXgodGhpcy5zKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5oVjtcbiAgICB9O1xuXG4gICAgaWYgKHBhcmFtcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChwYXJhbXMuc3RyICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RyaW5nKHBhcmFtcy5zdHIpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwYXJhbXMgPT0gXCJzdHJpbmdcIiAmJiBwYXJhbXMubWF0Y2goL15bMC05XXsxNH1aJC8pKSB7XG4gICAgICAgICAgICB0aGlzLnNldFN0cmluZyhwYXJhbXMpO1xuICAgICAgICB9IGVsc2UgaWYgKHBhcmFtcy5oZXggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5zZXRTdHJpbmdIZXgocGFyYW1zLmhleCk7XG4gICAgICAgIH0gZWxzZSBpZiAocGFyYW1zLmRhdGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5zZXRCeURhdGUocGFyYW1zLmRhdGUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwYXJhbXMubWlsbGlzID09PSB0cnVlKSB7XG4gICAgICAgICAgICB0aGlzLndpdGhNaWxsaXMgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfVxufTtcbllBSE9PLmxhbmcuZXh0ZW5kKEtKVVIuYXNuMS5ERVJHZW5lcmFsaXplZFRpbWUsIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFRpbWUpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIFNlcXVlbmNlXG4gKiBAbmFtZSBLSlVSLmFzbjEuREVSU2VxdWVuY2VcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIFNlcXVlbmNlXG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJ1Y3R1cmVkXG4gKiBAZGVzY3JpcHRpb25cbiAqIDxici8+XG4gKiBBcyBmb3IgYXJndW1lbnQgJ3BhcmFtcycgZm9yIGNvbnN0cnVjdG9yLCB5b3UgY2FuIHNwZWNpZnkgb25lIG9mXG4gKiBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqIDx1bD5cbiAqIDxsaT5hcnJheSAtIHNwZWNpZnkgYXJyYXkgb2YgQVNOMU9iamVjdCB0byBzZXQgZWxlbWVudHMgb2YgY29udGVudDwvbGk+XG4gKiA8L3VsPlxuICogTk9URTogJ3BhcmFtcycgY2FuIGJlIG9taXR0ZWQuXG4gKi9cbktKVVIuYXNuMS5ERVJTZXF1ZW5jZSA9IGZ1bmN0aW9uKHBhcmFtcykge1xuICAgIEtKVVIuYXNuMS5ERVJTZXF1ZW5jZS5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcywgcGFyYW1zKTtcbiAgICB0aGlzLmhUID0gXCIzMFwiO1xuICAgIHRoaXMuZ2V0RnJlc2hWYWx1ZUhleCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgaCA9ICcnO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuYXNuMUFycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgYXNuMU9iaiA9IHRoaXMuYXNuMUFycmF5W2ldO1xuICAgICAgICAgICAgaCArPSBhc24xT2JqLmdldEVuY29kZWRIZXgoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmhWID0gaDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSU2VxdWVuY2UsIEtKVVIuYXNuMS5ERVJBYnN0cmFjdFN0cnVjdHVyZWQpO1xuXG4vLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLyoqXG4gKiBjbGFzcyBmb3IgQVNOLjEgREVSIFNldFxuICogQG5hbWUgS0pVUi5hc24xLkRFUlNldFxuICogQGNsYXNzIGNsYXNzIGZvciBBU04uMSBERVIgU2V0XG4gKiBAZXh0ZW5kcyBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJ1Y3R1cmVkXG4gKiBAZGVzY3JpcHRpb25cbiAqIDxici8+XG4gKiBBcyBmb3IgYXJndW1lbnQgJ3BhcmFtcycgZm9yIGNvbnN0cnVjdG9yLCB5b3UgY2FuIHNwZWNpZnkgb25lIG9mXG4gKiBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqIDx1bD5cbiAqIDxsaT5hcnJheSAtIHNwZWNpZnkgYXJyYXkgb2YgQVNOMU9iamVjdCB0byBzZXQgZWxlbWVudHMgb2YgY29udGVudDwvbGk+XG4gKiA8bGk+c29ydGZsYWcgLSBmbGFnIGZvciBzb3J0IChkZWZhdWx0OiB0cnVlKS4gQVNOLjEgQkVSIGlzIG5vdCBzb3J0ZWQgaW4gJ1NFVCBPRicuPC9saT5cbiAqIDwvdWw+XG4gKiBOT1RFMTogJ3BhcmFtcycgY2FuIGJlIG9taXR0ZWQuPGJyLz5cbiAqIE5PVEUyOiBzb3J0ZmxhZyBpcyBzdXBwb3J0ZWQgc2luY2UgMS4wLjUuXG4gKi9cbktKVVIuYXNuMS5ERVJTZXQgPSBmdW5jdGlvbihwYXJhbXMpIHtcbiAgICBLSlVSLmFzbjEuREVSU2V0LnN1cGVyY2xhc3MuY29uc3RydWN0b3IuY2FsbCh0aGlzLCBwYXJhbXMpO1xuICAgIHRoaXMuaFQgPSBcIjMxXCI7XG4gICAgdGhpcy5zb3J0RmxhZyA9IHRydWU7IC8vIGl0ZW0gc2hhbGwgYmUgc29ydGVkIG9ubHkgaW4gQVNOLjEgREVSXG4gICAgdGhpcy5nZXRGcmVzaFZhbHVlSGV4ID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBhID0gbmV3IEFycmF5KCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5hc24xQXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBhc24xT2JqID0gdGhpcy5hc24xQXJyYXlbaV07XG4gICAgICAgICAgICBhLnB1c2goYXNuMU9iai5nZXRFbmNvZGVkSGV4KCkpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnNvcnRGbGFnID09IHRydWUpIGEuc29ydCgpO1xuICAgICAgICB0aGlzLmhWID0gYS5qb2luKCcnKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcblxuICAgIGlmICh0eXBlb2YgcGFyYW1zICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBwYXJhbXMuc29ydGZsYWcgIT0gXCJ1bmRlZmluZWRcIiAmJlxuICAgICAgICAgICAgcGFyYW1zLnNvcnRmbGFnID09IGZhbHNlKVxuICAgICAgICAgICAgdGhpcy5zb3J0RmxhZyA9IGZhbHNlO1xuICAgIH1cbn07XG5ZQUhPTy5sYW5nLmV4dGVuZChLSlVSLmFzbjEuREVSU2V0LCBLSlVSLmFzbjEuREVSQWJzdHJhY3RTdHJ1Y3R1cmVkKTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8qKlxuICogY2xhc3MgZm9yIEFTTi4xIERFUiBUYWdnZWRPYmplY3RcbiAqIEBuYW1lIEtKVVIuYXNuMS5ERVJUYWdnZWRPYmplY3RcbiAqIEBjbGFzcyBjbGFzcyBmb3IgQVNOLjEgREVSIFRhZ2dlZE9iamVjdFxuICogQGV4dGVuZHMgS0pVUi5hc24xLkFTTjFPYmplY3RcbiAqIEBkZXNjcmlwdGlvblxuICogPGJyLz5cbiAqIFBhcmFtZXRlciAndGFnTm9OZXgnIGlzIEFTTi4xIHRhZyhUKSB2YWx1ZSBmb3IgdGhpcyBvYmplY3QuXG4gKiBGb3IgZXhhbXBsZSwgaWYgeW91IGZpbmQgJ1sxXScgdGFnIGluIGEgQVNOLjEgZHVtcCxcbiAqICd0YWdOb0hleCcgd2lsbCBiZSAnYTEnLlxuICogPGJyLz5cbiAqIEFzIGZvciBvcHRpb25hbCBhcmd1bWVudCAncGFyYW1zJyBmb3IgY29uc3RydWN0b3IsIHlvdSBjYW4gc3BlY2lmeSAqQU5ZKiBvZlxuICogZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKiA8dWw+XG4gKiA8bGk+ZXhwbGljaXQgLSBzcGVjaWZ5IHRydWUgaWYgdGhpcyBpcyBleHBsaWNpdCB0YWcgb3RoZXJ3aXNlIGZhbHNlXG4gKiAgICAgKGRlZmF1bHQgaXMgJ3RydWUnKS48L2xpPlxuICogPGxpPnRhZyAtIHNwZWNpZnkgdGFnIChkZWZhdWx0IGlzICdhMCcgd2hpY2ggbWVhbnMgWzBdKTwvbGk+XG4gKiA8bGk+b2JqIC0gc3BlY2lmeSBBU04xT2JqZWN0IHdoaWNoIGlzIHRhZ2dlZDwvbGk+XG4gKiA8L3VsPlxuICogQGV4YW1wbGVcbiAqIGQxID0gbmV3IEtKVVIuYXNuMS5ERVJVVEY4U3RyaW5nKHsnc3RyJzonYSd9KTtcbiAqIGQyID0gbmV3IEtKVVIuYXNuMS5ERVJUYWdnZWRPYmplY3QoeydvYmonOiBkMX0pO1xuICogaGV4ID0gZDIuZ2V0RW5jb2RlZEhleCgpO1xuICovXG5LSlVSLmFzbjEuREVSVGFnZ2VkT2JqZWN0ID0gZnVuY3Rpb24ocGFyYW1zKSB7XG4gICAgS0pVUi5hc24xLkRFUlRhZ2dlZE9iamVjdC5zdXBlcmNsYXNzLmNvbnN0cnVjdG9yLmNhbGwodGhpcyk7XG4gICAgdGhpcy5oVCA9IFwiYTBcIjtcbiAgICB0aGlzLmhWID0gJyc7XG4gICAgdGhpcy5pc0V4cGxpY2l0ID0gdHJ1ZTtcbiAgICB0aGlzLmFzbjFPYmplY3QgPSBudWxsO1xuXG4gICAgLyoqXG4gICAgICogc2V0IHZhbHVlIGJ5IGFuIEFTTjFPYmplY3RcbiAgICAgKiBAbmFtZSBzZXRTdHJpbmdcbiAgICAgKiBAbWVtYmVyT2YgS0pVUi5hc24xLkRFUlRhZ2dlZE9iamVjdCNcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge0Jvb2xlYW59IGlzRXhwbGljaXRGbGFnIGZsYWcgZm9yIGV4cGxpY2l0L2ltcGxpY2l0IHRhZ1xuICAgICAqIEBwYXJhbSB7SW50ZWdlcn0gdGFnTm9IZXggaGV4YWRlY2ltYWwgc3RyaW5nIG9mIEFTTi4xIHRhZ1xuICAgICAqIEBwYXJhbSB7QVNOMU9iamVjdH0gYXNuMU9iamVjdCBBU04uMSB0byBlbmNhcHN1bGF0ZVxuICAgICAqL1xuICAgIHRoaXMuc2V0QVNOMU9iamVjdCA9IGZ1bmN0aW9uKGlzRXhwbGljaXRGbGFnLCB0YWdOb0hleCwgYXNuMU9iamVjdCkge1xuICAgICAgICB0aGlzLmhUID0gdGFnTm9IZXg7XG4gICAgICAgIHRoaXMuaXNFeHBsaWNpdCA9IGlzRXhwbGljaXRGbGFnO1xuICAgICAgICB0aGlzLmFzbjFPYmplY3QgPSBhc24xT2JqZWN0O1xuICAgICAgICBpZiAodGhpcy5pc0V4cGxpY2l0KSB7XG4gICAgICAgICAgICB0aGlzLmhWID0gdGhpcy5hc24xT2JqZWN0LmdldEVuY29kZWRIZXgoKTtcbiAgICAgICAgICAgIHRoaXMuaFRMViA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLmlzTW9kaWZpZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5oViA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLmhUTFYgPSBhc24xT2JqZWN0LmdldEVuY29kZWRIZXgoKTtcbiAgICAgICAgICAgIHRoaXMuaFRMViA9IHRoaXMuaFRMVi5yZXBsYWNlKC9eLi4vLCB0YWdOb0hleCk7XG4gICAgICAgICAgICB0aGlzLmlzTW9kaWZpZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICB0aGlzLmdldEZyZXNoVmFsdWVIZXggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaFY7XG4gICAgfTtcblxuICAgIGlmICh0eXBlb2YgcGFyYW1zICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBwYXJhbXNbJ3RhZyddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuaFQgPSBwYXJhbXNbJ3RhZyddO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgcGFyYW1zWydleHBsaWNpdCddICE9IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuaXNFeHBsaWNpdCA9IHBhcmFtc1snZXhwbGljaXQnXTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHBhcmFtc1snb2JqJ10gIT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5hc24xT2JqZWN0ID0gcGFyYW1zWydvYmonXTtcbiAgICAgICAgICAgIHRoaXMuc2V0QVNOMU9iamVjdCh0aGlzLmlzRXhwbGljaXQsIHRoaXMuaFQsIHRoaXMuYXNuMU9iamVjdCk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuWUFIT08ubGFuZy5leHRlbmQoS0pVUi5hc24xLkRFUlRhZ2dlZE9iamVjdCwgS0pVUi5hc24xLkFTTjFPYmplY3QpO1xuXG4vKipcbiAqIENyZWF0ZSBhIG5ldyBKU0VuY3J5cHRSU0FLZXkgdGhhdCBleHRlbmRzIFRvbSBXdSdzIFJTQSBrZXkgb2JqZWN0LlxuICogVGhpcyBvYmplY3QgaXMganVzdCBhIGRlY29yYXRvciBmb3IgcGFyc2luZyB0aGUga2V5IHBhcmFtZXRlclxuICogQHBhcmFtIHtzdHJpbmd8T2JqZWN0fSBrZXkgLSBUaGUga2V5IGluIHN0cmluZyBmb3JtYXQsIG9yIGFuIG9iamVjdCBjb250YWluaW5nXG4gKiB0aGUgcGFyYW1ldGVycyBuZWVkZWQgdG8gYnVpbGQgYSBSU0FLZXkgb2JqZWN0LlxuICogQGNvbnN0cnVjdG9yXG4gKi9cbnZhciBKU0VuY3J5cHRSU0FLZXkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKEpTRW5jcnlwdFJTQUtleSwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBKU0VuY3J5cHRSU0FLZXkoa2V5KSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIC8vIENhbGwgdGhlIHN1cGVyIGNvbnN0cnVjdG9yLlxuICAgICAgICAvLyAgUlNBS2V5LmNhbGwodGhpcyk7XG4gICAgICAgIC8vIElmIGEga2V5IGtleSB3YXMgcHJvdmlkZWQuXG4gICAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgICAgIC8vIElmIHRoaXMgaXMgYSBzdHJpbmcuLi5cbiAgICAgICAgICAgIGlmICh0eXBlb2Yga2V5ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMucGFyc2VLZXkoa2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKEpTRW5jcnlwdFJTQUtleS5oYXNQcml2YXRlS2V5UHJvcGVydHkoa2V5KSB8fFxuICAgICAgICAgICAgICAgIEpTRW5jcnlwdFJTQUtleS5oYXNQdWJsaWNLZXlQcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgICAgICAgICAgLy8gU2V0IHRoZSB2YWx1ZXMgZm9yIHRoZSBrZXkuXG4gICAgICAgICAgICAgICAgX3RoaXMucGFyc2VQcm9wZXJ0aWVzRnJvbShrZXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgLyoqXG4gICAgICogTWV0aG9kIHRvIHBhcnNlIGEgcGVtIGVuY29kZWQgc3RyaW5nIGNvbnRhaW5pbmcgYm90aCBhIHB1YmxpYyBvciBwcml2YXRlIGtleS5cbiAgICAgKiBUaGUgbWV0aG9kIHdpbGwgdHJhbnNsYXRlIHRoZSBwZW0gZW5jb2RlZCBzdHJpbmcgaW4gYSBkZXIgZW5jb2RlZCBzdHJpbmcgYW5kXG4gICAgICogd2lsbCBwYXJzZSBwcml2YXRlIGtleSBhbmQgcHVibGljIGtleSBwYXJhbWV0ZXJzLiBUaGlzIG1ldGhvZCBhY2NlcHRzIHB1YmxpYyBrZXlcbiAgICAgKiBpbiB0aGUgcnNhZW5jcnlwdGlvbiBwa2NzICMxIGZvcm1hdCAob2lkOiAxLjIuODQwLjExMzU0OS4xLjEuMSkuXG4gICAgICpcbiAgICAgKiBAdG9kbyBDaGVjayBob3cgbWFueSByc2EgZm9ybWF0cyB1c2UgdGhlIHNhbWUgZm9ybWF0IG9mIHBrY3MgIzEuXG4gICAgICpcbiAgICAgKiBUaGUgZm9ybWF0IGlzIGRlZmluZWQgYXM6XG4gICAgICogUHVibGljS2V5SW5mbyA6Oj0gU0VRVUVOQ0Uge1xuICAgICAqICAgYWxnb3JpdGhtICAgICAgIEFsZ29yaXRobUlkZW50aWZpZXIsXG4gICAgICogICBQdWJsaWNLZXkgICAgICAgQklUIFNUUklOR1xuICAgICAqIH1cbiAgICAgKiBXaGVyZSBBbGdvcml0aG1JZGVudGlmaWVyIGlzOlxuICAgICAqIEFsZ29yaXRobUlkZW50aWZpZXIgOjo9IFNFUVVFTkNFIHtcbiAgICAgKiAgIGFsZ29yaXRobSAgICAgICBPQkpFQ1QgSURFTlRJRklFUiwgICAgIHRoZSBPSUQgb2YgdGhlIGVuYyBhbGdvcml0aG1cbiAgICAgKiAgIHBhcmFtZXRlcnMgICAgICBBTlkgREVGSU5FRCBCWSBhbGdvcml0aG0gT1BUSU9OQUwgKE5VTEwgZm9yIFBLQ1MgIzEpXG4gICAgICogfVxuICAgICAqIGFuZCBQdWJsaWNLZXkgaXMgYSBTRVFVRU5DRSBlbmNhcHN1bGF0ZWQgaW4gYSBCSVQgU1RSSU5HXG4gICAgICogUlNBUHVibGljS2V5IDo6PSBTRVFVRU5DRSB7XG4gICAgICogICBtb2R1bHVzICAgICAgICAgICBJTlRFR0VSLCAgLS0gblxuICAgICAqICAgcHVibGljRXhwb25lbnQgICAgSU5URUdFUiAgIC0tIGVcbiAgICAgKiB9XG4gICAgICogaXQncyBwb3NzaWJsZSB0byBleGFtaW5lIHRoZSBzdHJ1Y3R1cmUgb2YgdGhlIGtleXMgb2J0YWluZWQgZnJvbSBvcGVuc3NsIHVzaW5nXG4gICAgICogYW4gYXNuLjEgZHVtcGVyIGFzIHRoZSBvbmUgdXNlZCBoZXJlIHRvIHBhcnNlIHRoZSBjb21wb25lbnRzOiBodHRwOi8vbGFwby5pdC9hc24xanMvXG4gICAgICogQGFyZ3VtZW50IHtzdHJpbmd9IHBlbSB0aGUgcGVtIGVuY29kZWQgc3RyaW5nLCBjYW4gaW5jbHVkZSB0aGUgQkVHSU4vRU5EIGhlYWRlci9mb290ZXJcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5wcm90b3R5cGUucGFyc2VLZXkgPSBmdW5jdGlvbiAocGVtKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB2YXIgbW9kdWx1cyA9IDA7XG4gICAgICAgICAgICB2YXIgcHVibGljX2V4cG9uZW50ID0gMDtcbiAgICAgICAgICAgIHZhciByZUhleCA9IC9eXFxzKig/OlswLTlBLUZhLWZdWzAtOUEtRmEtZl1cXHMqKSskLztcbiAgICAgICAgICAgIHZhciBkZXIgPSByZUhleC50ZXN0KHBlbSkgPyBIZXguZGVjb2RlKHBlbSkgOiBCYXNlNjQudW5hcm1vcihwZW0pO1xuICAgICAgICAgICAgdmFyIGFzbjEgPSBBU04xLmRlY29kZShkZXIpO1xuICAgICAgICAgICAgLy8gRml4ZXMgYSBidWcgd2l0aCBPcGVuU1NMIDEuMCsgcHJpdmF0ZSBrZXlzXG4gICAgICAgICAgICBpZiAoYXNuMS5zdWIubGVuZ3RoID09PSAzKSB7XG4gICAgICAgICAgICAgICAgYXNuMSA9IGFzbjEuc3ViWzJdLnN1YlswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChhc24xLnN1Yi5sZW5ndGggPT09IDkpIHtcbiAgICAgICAgICAgICAgICAvLyBQYXJzZSB0aGUgcHJpdmF0ZSBrZXkuXG4gICAgICAgICAgICAgICAgbW9kdWx1cyA9IGFzbjEuc3ViWzFdLmdldEhleFN0cmluZ1ZhbHVlKCk7IC8vIGJpZ2ludFxuICAgICAgICAgICAgICAgIHRoaXMubiA9IHBhcnNlQmlnSW50KG1vZHVsdXMsIDE2KTtcbiAgICAgICAgICAgICAgICBwdWJsaWNfZXhwb25lbnQgPSBhc24xLnN1YlsyXS5nZXRIZXhTdHJpbmdWYWx1ZSgpOyAvLyBpbnRcbiAgICAgICAgICAgICAgICB0aGlzLmUgPSBwYXJzZUludChwdWJsaWNfZXhwb25lbnQsIDE2KTtcbiAgICAgICAgICAgICAgICB2YXIgcHJpdmF0ZV9leHBvbmVudCA9IGFzbjEuc3ViWzNdLmdldEhleFN0cmluZ1ZhbHVlKCk7IC8vIGJpZ2ludFxuICAgICAgICAgICAgICAgIHRoaXMuZCA9IHBhcnNlQmlnSW50KHByaXZhdGVfZXhwb25lbnQsIDE2KTtcbiAgICAgICAgICAgICAgICB2YXIgcHJpbWUxID0gYXNuMS5zdWJbNF0uZ2V0SGV4U3RyaW5nVmFsdWUoKTsgLy8gYmlnaW50XG4gICAgICAgICAgICAgICAgdGhpcy5wID0gcGFyc2VCaWdJbnQocHJpbWUxLCAxNik7XG4gICAgICAgICAgICAgICAgdmFyIHByaW1lMiA9IGFzbjEuc3ViWzVdLmdldEhleFN0cmluZ1ZhbHVlKCk7IC8vIGJpZ2ludFxuICAgICAgICAgICAgICAgIHRoaXMucSA9IHBhcnNlQmlnSW50KHByaW1lMiwgMTYpO1xuICAgICAgICAgICAgICAgIHZhciBleHBvbmVudDEgPSBhc24xLnN1Yls2XS5nZXRIZXhTdHJpbmdWYWx1ZSgpOyAvLyBiaWdpbnRcbiAgICAgICAgICAgICAgICB0aGlzLmRtcDEgPSBwYXJzZUJpZ0ludChleHBvbmVudDEsIDE2KTtcbiAgICAgICAgICAgICAgICB2YXIgZXhwb25lbnQyID0gYXNuMS5zdWJbN10uZ2V0SGV4U3RyaW5nVmFsdWUoKTsgLy8gYmlnaW50XG4gICAgICAgICAgICAgICAgdGhpcy5kbXExID0gcGFyc2VCaWdJbnQoZXhwb25lbnQyLCAxNik7XG4gICAgICAgICAgICAgICAgdmFyIGNvZWZmaWNpZW50ID0gYXNuMS5zdWJbOF0uZ2V0SGV4U3RyaW5nVmFsdWUoKTsgLy8gYmlnaW50XG4gICAgICAgICAgICAgICAgdGhpcy5jb2VmZiA9IHBhcnNlQmlnSW50KGNvZWZmaWNpZW50LCAxNik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChhc24xLnN1Yi5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgICAgICAgICAvLyBQYXJzZSB0aGUgcHVibGljIGtleS5cbiAgICAgICAgICAgICAgICB2YXIgYml0X3N0cmluZyA9IGFzbjEuc3ViWzFdO1xuICAgICAgICAgICAgICAgIHZhciBzZXF1ZW5jZSA9IGJpdF9zdHJpbmcuc3ViWzBdO1xuICAgICAgICAgICAgICAgIG1vZHVsdXMgPSBzZXF1ZW5jZS5zdWJbMF0uZ2V0SGV4U3RyaW5nVmFsdWUoKTtcbiAgICAgICAgICAgICAgICB0aGlzLm4gPSBwYXJzZUJpZ0ludChtb2R1bHVzLCAxNik7XG4gICAgICAgICAgICAgICAgcHVibGljX2V4cG9uZW50ID0gc2VxdWVuY2Uuc3ViWzFdLmdldEhleFN0cmluZ1ZhbHVlKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5lID0gcGFyc2VJbnQocHVibGljX2V4cG9uZW50LCAxNik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICogVHJhbnNsYXRlIHJzYSBwYXJhbWV0ZXJzIGluIGEgaGV4IGVuY29kZWQgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgcnNhIGtleS5cbiAgICAgKlxuICAgICAqIFRoZSB0cmFuc2xhdGlvbiBmb2xsb3cgdGhlIEFTTi4xIG5vdGF0aW9uIDpcbiAgICAgKiBSU0FQcml2YXRlS2V5IDo6PSBTRVFVRU5DRSB7XG4gICAgICogICB2ZXJzaW9uICAgICAgICAgICBWZXJzaW9uLFxuICAgICAqICAgbW9kdWx1cyAgICAgICAgICAgSU5URUdFUiwgIC0tIG5cbiAgICAgKiAgIHB1YmxpY0V4cG9uZW50ICAgIElOVEVHRVIsICAtLSBlXG4gICAgICogICBwcml2YXRlRXhwb25lbnQgICBJTlRFR0VSLCAgLS0gZFxuICAgICAqICAgcHJpbWUxICAgICAgICAgICAgSU5URUdFUiwgIC0tIHBcbiAgICAgKiAgIHByaW1lMiAgICAgICAgICAgIElOVEVHRVIsICAtLSBxXG4gICAgICogICBleHBvbmVudDEgICAgICAgICBJTlRFR0VSLCAgLS0gZCBtb2QgKHAxKVxuICAgICAqICAgZXhwb25lbnQyICAgICAgICAgSU5URUdFUiwgIC0tIGQgbW9kIChxLTEpXG4gICAgICogICBjb2VmZmljaWVudCAgICAgICBJTlRFR0VSLCAgLS0gKGludmVyc2Ugb2YgcSkgbW9kIHBcbiAgICAgKiB9XG4gICAgICogQHJldHVybnMge3N0cmluZ30gIERFUiBFbmNvZGVkIFN0cmluZyByZXByZXNlbnRpbmcgdGhlIHJzYSBwcml2YXRlIGtleVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgSlNFbmNyeXB0UlNBS2V5LnByb3RvdHlwZS5nZXRQcml2YXRlQmFzZUtleSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIG9wdGlvbnMgPSB7XG4gICAgICAgICAgICBhcnJheTogW1xuICAgICAgICAgICAgICAgIG5ldyBLSlVSLmFzbjEuREVSSW50ZWdlcih7IGludDogMCB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMubiB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBpbnQ6IHRoaXMuZSB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMuZCB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMucCB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMucSB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMuZG1wMSB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMuZG1xMSB9KSxcbiAgICAgICAgICAgICAgICBuZXcgS0pVUi5hc24xLkRFUkludGVnZXIoeyBiaWdpbnQ6IHRoaXMuY29lZmYgfSlcbiAgICAgICAgICAgIF1cbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHNlcSA9IG5ldyBLSlVSLmFzbjEuREVSU2VxdWVuY2Uob3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBzZXEuZ2V0RW5jb2RlZEhleCgpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogYmFzZTY0IChwZW0pIGVuY29kZWQgdmVyc2lvbiBvZiB0aGUgREVSIGVuY29kZWQgcmVwcmVzZW50YXRpb25cbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSBwZW0gZW5jb2RlZCByZXByZXNlbnRhdGlvbiB3aXRob3V0IGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5wcm90b3R5cGUuZ2V0UHJpdmF0ZUJhc2VLZXlCNjQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBoZXgyYjY0KHRoaXMuZ2V0UHJpdmF0ZUJhc2VLZXkoKSk7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBUcmFuc2xhdGUgcnNhIHBhcmFtZXRlcnMgaW4gYSBoZXggZW5jb2RlZCBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSByc2EgcHVibGljIGtleS5cbiAgICAgKiBUaGUgcmVwcmVzZW50YXRpb24gZm9sbG93IHRoZSBBU04uMSBub3RhdGlvbiA6XG4gICAgICogUHVibGljS2V5SW5mbyA6Oj0gU0VRVUVOQ0Uge1xuICAgICAqICAgYWxnb3JpdGhtICAgICAgIEFsZ29yaXRobUlkZW50aWZpZXIsXG4gICAgICogICBQdWJsaWNLZXkgICAgICAgQklUIFNUUklOR1xuICAgICAqIH1cbiAgICAgKiBXaGVyZSBBbGdvcml0aG1JZGVudGlmaWVyIGlzOlxuICAgICAqIEFsZ29yaXRobUlkZW50aWZpZXIgOjo9IFNFUVVFTkNFIHtcbiAgICAgKiAgIGFsZ29yaXRobSAgICAgICBPQkpFQ1QgSURFTlRJRklFUiwgICAgIHRoZSBPSUQgb2YgdGhlIGVuYyBhbGdvcml0aG1cbiAgICAgKiAgIHBhcmFtZXRlcnMgICAgICBBTlkgREVGSU5FRCBCWSBhbGdvcml0aG0gT1BUSU9OQUwgKE5VTEwgZm9yIFBLQ1MgIzEpXG4gICAgICogfVxuICAgICAqIGFuZCBQdWJsaWNLZXkgaXMgYSBTRVFVRU5DRSBlbmNhcHN1bGF0ZWQgaW4gYSBCSVQgU1RSSU5HXG4gICAgICogUlNBUHVibGljS2V5IDo6PSBTRVFVRU5DRSB7XG4gICAgICogICBtb2R1bHVzICAgICAgICAgICBJTlRFR0VSLCAgLS0gblxuICAgICAqICAgcHVibGljRXhwb25lbnQgICAgSU5URUdFUiAgIC0tIGVcbiAgICAgKiB9XG4gICAgICogQHJldHVybnMge3N0cmluZ30gREVSIEVuY29kZWQgU3RyaW5nIHJlcHJlc2VudGluZyB0aGUgcnNhIHB1YmxpYyBrZXlcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5wcm90b3R5cGUuZ2V0UHVibGljQmFzZUtleSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGZpcnN0X3NlcXVlbmNlID0gbmV3IEtKVVIuYXNuMS5ERVJTZXF1ZW5jZSh7XG4gICAgICAgICAgICBhcnJheTogW1xuICAgICAgICAgICAgICAgIG5ldyBLSlVSLmFzbjEuREVST2JqZWN0SWRlbnRpZmllcih7IG9pZDogXCIxLjIuODQwLjExMzU0OS4xLjEuMVwiIH0pLFxuICAgICAgICAgICAgICAgIG5ldyBLSlVSLmFzbjEuREVSTnVsbCgpXG4gICAgICAgICAgICBdXG4gICAgICAgIH0pO1xuICAgICAgICB2YXIgc2Vjb25kX3NlcXVlbmNlID0gbmV3IEtKVVIuYXNuMS5ERVJTZXF1ZW5jZSh7XG4gICAgICAgICAgICBhcnJheTogW1xuICAgICAgICAgICAgICAgIG5ldyBLSlVSLmFzbjEuREVSSW50ZWdlcih7IGJpZ2ludDogdGhpcy5uIH0pLFxuICAgICAgICAgICAgICAgIG5ldyBLSlVSLmFzbjEuREVSSW50ZWdlcih7IGludDogdGhpcy5lIH0pXG4gICAgICAgICAgICBdXG4gICAgICAgIH0pO1xuICAgICAgICB2YXIgYml0X3N0cmluZyA9IG5ldyBLSlVSLmFzbjEuREVSQml0U3RyaW5nKHtcbiAgICAgICAgICAgIGhleDogXCIwMFwiICsgc2Vjb25kX3NlcXVlbmNlLmdldEVuY29kZWRIZXgoKVxuICAgICAgICB9KTtcbiAgICAgICAgdmFyIHNlcSA9IG5ldyBLSlVSLmFzbjEuREVSU2VxdWVuY2Uoe1xuICAgICAgICAgICAgYXJyYXk6IFtmaXJzdF9zZXF1ZW5jZSwgYml0X3N0cmluZ11cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBzZXEuZ2V0RW5jb2RlZEhleCgpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogYmFzZTY0IChwZW0pIGVuY29kZWQgdmVyc2lvbiBvZiB0aGUgREVSIGVuY29kZWQgcmVwcmVzZW50YXRpb25cbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSBwZW0gZW5jb2RlZCByZXByZXNlbnRhdGlvbiB3aXRob3V0IGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5wcm90b3R5cGUuZ2V0UHVibGljQmFzZUtleUI2NCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIGhleDJiNjQodGhpcy5nZXRQdWJsaWNCYXNlS2V5KCkpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogd3JhcCB0aGUgc3RyaW5nIGluIGJsb2NrIG9mIHdpZHRoIGNoYXJzLiBUaGUgZGVmYXVsdCB2YWx1ZSBmb3IgcnNhIGtleXMgaXMgNjRcbiAgICAgKiBjaGFyYWN0ZXJzLlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgdGhlIHBlbSBlbmNvZGVkIHN0cmluZyB3aXRob3V0IGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHBhcmFtIHtOdW1iZXJ9IFt3aWR0aD02NF0gLSB0aGUgbGVuZ3RoIHRoZSBzdHJpbmcgaGFzIHRvIGJlIHdyYXBwZWQgYXRcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgSlNFbmNyeXB0UlNBS2V5LndvcmR3cmFwID0gZnVuY3Rpb24gKHN0ciwgd2lkdGgpIHtcbiAgICAgICAgd2lkdGggPSB3aWR0aCB8fCA2NDtcbiAgICAgICAgaWYgKCFzdHIpIHtcbiAgICAgICAgICAgIHJldHVybiBzdHI7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHJlZ2V4ID0gXCIoLnsxLFwiICsgd2lkdGggKyBcIn0pKCArfCRcXG4/KXwoLnsxLFwiICsgd2lkdGggKyBcIn0pXCI7XG4gICAgICAgIHJldHVybiBzdHIubWF0Y2goUmVnRXhwKHJlZ2V4LCBcImdcIikpLmpvaW4oXCJcXG5cIik7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZSB0aGUgcGVtIGVuY29kZWQgcHJpdmF0ZSBrZXlcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSB0aGUgcGVtIGVuY29kZWQgcHJpdmF0ZSBrZXkgd2l0aCBoZWFkZXIvZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5wcm90b3R5cGUuZ2V0UHJpdmF0ZUtleSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGtleSA9IFwiLS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLVxcblwiO1xuICAgICAgICBrZXkgKz0gSlNFbmNyeXB0UlNBS2V5LndvcmR3cmFwKHRoaXMuZ2V0UHJpdmF0ZUJhc2VLZXlCNjQoKSkgKyBcIlxcblwiO1xuICAgICAgICBrZXkgKz0gXCItLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLVwiO1xuICAgICAgICByZXR1cm4ga2V5O1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUmV0cmlldmUgdGhlIHBlbSBlbmNvZGVkIHB1YmxpYyBrZXlcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSB0aGUgcGVtIGVuY29kZWQgcHVibGljIGtleSB3aXRoIGhlYWRlci9mb290ZXJcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0UlNBS2V5LnByb3RvdHlwZS5nZXRQdWJsaWNLZXkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBrZXkgPSBcIi0tLS0tQkVHSU4gUFVCTElDIEtFWS0tLS0tXFxuXCI7XG4gICAgICAgIGtleSArPSBKU0VuY3J5cHRSU0FLZXkud29yZHdyYXAodGhpcy5nZXRQdWJsaWNCYXNlS2V5QjY0KCkpICsgXCJcXG5cIjtcbiAgICAgICAga2V5ICs9IFwiLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tXCI7XG4gICAgICAgIHJldHVybiBrZXk7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGUgb2JqZWN0IGNvbnRhaW5zIHRoZSBuZWNlc3NhcnkgcGFyYW1ldGVycyB0byBwb3B1bGF0ZSB0aGUgcnNhIG1vZHVsdXNcbiAgICAgKiBhbmQgcHVibGljIGV4cG9uZW50IHBhcmFtZXRlcnMuXG4gICAgICogQHBhcmFtIHtPYmplY3R9IFtvYmo9e31dIC0gQW4gb2JqZWN0IHRoYXQgbWF5IGNvbnRhaW4gdGhlIHR3byBwdWJsaWMga2V5XG4gICAgICogcGFyYW1ldGVyc1xuICAgICAqIEByZXR1cm5zIHtib29sZWFufSB0cnVlIGlmIHRoZSBvYmplY3QgY29udGFpbnMgYm90aCB0aGUgbW9kdWx1cyBhbmQgdGhlIHB1YmxpYyBleHBvbmVudFxuICAgICAqIHByb3BlcnRpZXMgKG4gYW5kIGUpXG4gICAgICogQHRvZG8gY2hlY2sgZm9yIHR5cGVzIG9mIG4gYW5kIGUuIE4gc2hvdWxkIGJlIGEgcGFyc2VhYmxlIGJpZ0ludCBvYmplY3QsIEUgc2hvdWxkXG4gICAgICogYmUgYSBwYXJzZWFibGUgaW50ZWdlciBudW1iZXJcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIEpTRW5jcnlwdFJTQUtleS5oYXNQdWJsaWNLZXlQcm9wZXJ0eSA9IGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgb2JqID0gb2JqIHx8IHt9O1xuICAgICAgICByZXR1cm4gb2JqLmhhc093blByb3BlcnR5KFwiblwiKSAmJiBvYmouaGFzT3duUHJvcGVydHkoXCJlXCIpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIG9iamVjdCBjb250YWlucyBBTEwgdGhlIHBhcmFtZXRlcnMgb2YgYW4gUlNBIGtleS5cbiAgICAgKiBAcGFyYW0ge09iamVjdH0gW29iaj17fV0gLSBBbiBvYmplY3QgdGhhdCBtYXkgY29udGFpbiBuaW5lIHJzYSBrZXlcbiAgICAgKiBwYXJhbWV0ZXJzXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IHRydWUgaWYgdGhlIG9iamVjdCBjb250YWlucyBhbGwgdGhlIHBhcmFtZXRlcnMgbmVlZGVkXG4gICAgICogQHRvZG8gY2hlY2sgZm9yIHR5cGVzIG9mIHRoZSBwYXJhbWV0ZXJzIGFsbCB0aGUgcGFyYW1ldGVycyBidXQgdGhlIHB1YmxpYyBleHBvbmVudFxuICAgICAqIHNob3VsZCBiZSBwYXJzZWFibGUgYmlnaW50IG9iamVjdHMsIHRoZSBwdWJsaWMgZXhwb25lbnQgc2hvdWxkIGJlIGEgcGFyc2VhYmxlIGludGVnZXIgbnVtYmVyXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBKU0VuY3J5cHRSU0FLZXkuaGFzUHJpdmF0ZUtleVByb3BlcnR5ID0gZnVuY3Rpb24gKG9iaikge1xuICAgICAgICBvYmogPSBvYmogfHwge307XG4gICAgICAgIHJldHVybiAob2JqLmhhc093blByb3BlcnR5KFwiblwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwiZVwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwiZFwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwicFwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwicVwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwiZG1wMVwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwiZG1xMVwiKSAmJlxuICAgICAgICAgICAgb2JqLmhhc093blByb3BlcnR5KFwiY29lZmZcIikpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUGFyc2UgdGhlIHByb3BlcnRpZXMgb2Ygb2JqIGluIHRoZSBjdXJyZW50IHJzYSBvYmplY3QuIE9iaiBzaG91bGQgQVQgTEVBU1RcbiAgICAgKiBpbmNsdWRlIHRoZSBtb2R1bHVzIGFuZCBwdWJsaWMgZXhwb25lbnQgKG4sIGUpIHBhcmFtZXRlcnMuXG4gICAgICogQHBhcmFtIHtPYmplY3R9IG9iaiAtIHRoZSBvYmplY3QgY29udGFpbmluZyByc2EgcGFyYW1ldGVyc1xuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgSlNFbmNyeXB0UlNBS2V5LnByb3RvdHlwZS5wYXJzZVByb3BlcnRpZXNGcm9tID0gZnVuY3Rpb24gKG9iaikge1xuICAgICAgICB0aGlzLm4gPSBvYmoubjtcbiAgICAgICAgdGhpcy5lID0gb2JqLmU7XG4gICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoXCJkXCIpKSB7XG4gICAgICAgICAgICB0aGlzLmQgPSBvYmouZDtcbiAgICAgICAgICAgIHRoaXMucCA9IG9iai5wO1xuICAgICAgICAgICAgdGhpcy5xID0gb2JqLnE7XG4gICAgICAgICAgICB0aGlzLmRtcDEgPSBvYmouZG1wMTtcbiAgICAgICAgICAgIHRoaXMuZG1xMSA9IG9iai5kbXExO1xuICAgICAgICAgICAgdGhpcy5jb2VmZiA9IG9iai5jb2VmZjtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIEpTRW5jcnlwdFJTQUtleTtcbn0oUlNBS2V5KSk7XG5cbi8qKlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucyA9IHt9XSAtIEFuIG9iamVjdCB0byBjdXN0b21pemUgSlNFbmNyeXB0IGJlaGF2aW91clxuICogcG9zc2libGUgcGFyYW1ldGVycyBhcmU6XG4gKiAtIGRlZmF1bHRfa2V5X3NpemUgICAgICAgIHtudW1iZXJ9ICBkZWZhdWx0OiAxMDI0IHRoZSBrZXkgc2l6ZSBpbiBiaXRcbiAqIC0gZGVmYXVsdF9wdWJsaWNfZXhwb25lbnQge3N0cmluZ30gIGRlZmF1bHQ6ICcwMTAwMDEnIHRoZSBoZXhhZGVjaW1hbCByZXByZXNlbnRhdGlvbiBvZiB0aGUgcHVibGljIGV4cG9uZW50XG4gKiAtIGxvZyAgICAgICAgICAgICAgICAgICAgIHtib29sZWFufSBkZWZhdWx0OiBmYWxzZSB3aGV0aGVyIGxvZyB3YXJuL2Vycm9yIG9yIG5vdFxuICogQGNvbnN0cnVjdG9yXG4gKi9cbnZhciBKU0VuY3J5cHQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gSlNFbmNyeXB0KG9wdGlvbnMpIHtcbiAgICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gICAgICAgIHRoaXMuZGVmYXVsdF9rZXlfc2l6ZSA9IHBhcnNlSW50KG9wdGlvbnMuZGVmYXVsdF9rZXlfc2l6ZSwgMTApIHx8IDEwMjQ7XG4gICAgICAgIHRoaXMuZGVmYXVsdF9wdWJsaWNfZXhwb25lbnQgPSBvcHRpb25zLmRlZmF1bHRfcHVibGljX2V4cG9uZW50IHx8IFwiMDEwMDAxXCI7IC8vIDY1NTM3IGRlZmF1bHQgb3BlbnNzbCBwdWJsaWMgZXhwb25lbnQgZm9yIHJzYSBrZXkgdHlwZVxuICAgICAgICB0aGlzLmxvZyA9IG9wdGlvbnMubG9nIHx8IGZhbHNlO1xuICAgICAgICAvLyBUaGUgcHJpdmF0ZSBhbmQgcHVibGljIGtleS5cbiAgICAgICAgdGhpcy5rZXkgPSBudWxsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNZXRob2QgdG8gc2V0IHRoZSByc2Ega2V5IHBhcmFtZXRlciAob25lIG1ldGhvZCBpcyBlbm91Z2ggdG8gc2V0IGJvdGggdGhlIHB1YmxpY1xuICAgICAqIGFuZCB0aGUgcHJpdmF0ZSBrZXksIHNpbmNlIHRoZSBwcml2YXRlIGtleSBjb250YWlucyB0aGUgcHVibGljIGtleSBwYXJhbWVudGVycylcbiAgICAgKiBMb2cgYSB3YXJuaW5nIGlmIGxvZ3MgYXJlIGVuYWJsZWRcbiAgICAgKiBAcGFyYW0ge09iamVjdHxzdHJpbmd9IGtleSB0aGUgcGVtIGVuY29kZWQgc3RyaW5nIG9yIGFuIG9iamVjdCAod2l0aCBvciB3aXRob3V0IGhlYWRlci9mb290ZXIpXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuc2V0S2V5ID0gZnVuY3Rpb24gKGtleSkge1xuICAgICAgICBpZiAodGhpcy5sb2cgJiYgdGhpcy5rZXkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIkEga2V5IHdhcyBhbHJlYWR5IHNldCwgb3ZlcnJpZGluZyBleGlzdGluZy5cIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5rZXkgPSBuZXcgSlNFbmNyeXB0UlNBS2V5KGtleSk7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBQcm94eSBtZXRob2QgZm9yIHNldEtleSwgZm9yIGFwaSBjb21wYXRpYmlsaXR5XG4gICAgICogQHNlZSBzZXRLZXlcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5zZXRQcml2YXRlS2V5ID0gZnVuY3Rpb24gKHByaXZrZXkpIHtcbiAgICAgICAgLy8gQ3JlYXRlIHRoZSBrZXkuXG4gICAgICAgIHRoaXMuc2V0S2V5KHByaXZrZXkpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUHJveHkgbWV0aG9kIGZvciBzZXRLZXksIGZvciBhcGkgY29tcGF0aWJpbGl0eVxuICAgICAqIEBzZWUgc2V0S2V5XG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuc2V0UHVibGljS2V5ID0gZnVuY3Rpb24gKHB1YmtleSkge1xuICAgICAgICAvLyBTZXRzIHRoZSBwdWJsaWMga2V5LlxuICAgICAgICB0aGlzLnNldEtleShwdWJrZXkpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUHJveHkgbWV0aG9kIGZvciBSU0FLZXkgb2JqZWN0J3MgZGVjcnlwdCwgZGVjcnlwdCB0aGUgc3RyaW5nIHVzaW5nIHRoZSBwcml2YXRlXG4gICAgICogY29tcG9uZW50cyBvZiB0aGUgcnNhIGtleSBvYmplY3QuIE5vdGUgdGhhdCBpZiB0aGUgb2JqZWN0IHdhcyBub3Qgc2V0IHdpbGwgYmUgY3JlYXRlZFxuICAgICAqIG9uIHRoZSBmbHkgKGJ5IHRoZSBnZXRLZXkgbWV0aG9kKSB1c2luZyB0aGUgcGFyYW1ldGVycyBwYXNzZWQgaW4gdGhlIEpTRW5jcnlwdCBjb25zdHJ1Y3RvclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgYmFzZTY0IGVuY29kZWQgY3J5cHRlZCBzdHJpbmcgdG8gZGVjcnlwdFxuICAgICAqIEByZXR1cm4ge3N0cmluZ30gdGhlIGRlY3J5cHRlZCBzdHJpbmdcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5kZWNyeXB0ID0gZnVuY3Rpb24gKHN0cikge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIGRlY3J5cHRlZCBzdHJpbmcuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXRLZXkoKS5kZWNyeXB0KGI2NHRvaGV4KHN0cikpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChleCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBQcm94eSBtZXRob2QgZm9yIFJTQUtleSBvYmplY3QncyBlbmNyeXB0LCBlbmNyeXB0IHRoZSBzdHJpbmcgdXNpbmcgdGhlIHB1YmxpY1xuICAgICAqIGNvbXBvbmVudHMgb2YgdGhlIHJzYSBrZXkgb2JqZWN0LiBOb3RlIHRoYXQgaWYgdGhlIG9iamVjdCB3YXMgbm90IHNldCB3aWxsIGJlIGNyZWF0ZWRcbiAgICAgKiBvbiB0aGUgZmx5IChieSB0aGUgZ2V0S2V5IG1ldGhvZCkgdXNpbmcgdGhlIHBhcmFtZXRlcnMgcGFzc2VkIGluIHRoZSBKU0VuY3J5cHQgY29uc3RydWN0b3JcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc3RyIHRoZSBzdHJpbmcgdG8gZW5jcnlwdFxuICAgICAqIEByZXR1cm4ge3N0cmluZ30gdGhlIGVuY3J5cHRlZCBzdHJpbmcgZW5jb2RlZCBpbiBiYXNlNjRcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5lbmNyeXB0ID0gZnVuY3Rpb24gKHN0cikge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIGVuY3J5cHRlZCBzdHJpbmcuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gaGV4MmI2NCh0aGlzLmdldEtleSgpLmVuY3J5cHQoc3RyKSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIOWIhuauteWKoOWvhumVv+Wtl+espuS4slxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgdGhlIHN0cmluZyB0byBlbmNyeXB0XG4gICAgICogQHJldHVybiB7c3RyaW5nfSB0aGUgZW5jcnlwdGVkIHN0cmluZyBlbmNvZGVkIGluIGJhc2U2NFxuICAgICAqIEBwdWJsaWNcbiAgICAgKi9cbiAgICBKU0VuY3J5cHQucHJvdG90eXBlLmVuY3J5cHRMb25nID0gZnVuY3Rpb24gKHN0cikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIGVuY3J5cHRlZCA9IHRoaXMuZ2V0S2V5KCkuZW5jcnlwdExvbmcoc3RyKSB8fCBcIlwiO1xuICAgICAgICAgICAgdmFyIHVuY3J5cHRlZCA9IHRoaXMuZ2V0S2V5KCkuZGVjcnlwdExvbmcoZW5jcnlwdGVkKSB8fCBcIlwiO1xuICAgICAgICAgICAgdmFyIGNvdW50ID0gMDtcbiAgICAgICAgICAgIHZhciByZWcgPSAvbnVsbCQvZztcbiAgICAgICAgICAgIHdoaWxlIChyZWcudGVzdCh1bmNyeXB0ZWQpKSB7XG4gICAgICAgICAgICAgICAgLy8g5aaC5p6c5Yqg5a+G5Ye66ZSZ77yM6YeN5paw5Yqg5a+GXG4gICAgICAgICAgICAgICAgY291bnQrKztcbiAgICAgICAgICAgICAgICBlbmNyeXB0ZWQgPSB0aGlzLmdldEtleSgpLmVuY3J5cHRMb25nKHN0cikgfHwgXCJcIjtcbiAgICAgICAgICAgICAgICB1bmNyeXB0ZWQgPSB0aGlzLmdldEtleSgpLmRlY3J5cHRMb25nKGVuY3J5cHRlZCkgfHwgXCJcIjtcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygn5Yqg5a+G5Ye66ZSZ5qyh5pWwJywgY291bnQpXG4gICAgICAgICAgICAgICAgaWYgKGNvdW50ID4gMTApIHtcbiAgICAgICAgICAgICAgICAgICAgLy8g6YeN5aSN5Yqg5a+G5LiN6IO95aSn5LqOMTDmrKFcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ+WKoOWvhuasoeaVsOi/h+WkmicpXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBlbmNyeXB0ZWQ7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIOWIhuauteino+WvhumVv+Wtl+espuS4slxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgYmFzZTY0IGVuY29kZWQgY3J5cHRlZCBzdHJpbmcgdG8gZGVjcnlwdFxuICAgICAqIEByZXR1cm4ge3N0cmluZ30gdGhlIGRlY3J5cHRlZCBzdHJpbmdcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5kZWNyeXB0TG9uZyA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldEtleSgpLmRlY3J5cHRMb25nKHN0cik7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFByb3h5IG1ldGhvZCBmb3IgUlNBS2V5IG9iamVjdCdzIHNpZ24uXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHN0ciB0aGUgc3RyaW5nIHRvIHNpZ25cbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBkaWdlc3RNZXRob2QgaGFzaCBtZXRob2RcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZGlnZXN0TmFtZSB0aGUgbmFtZSBvZiB0aGUgaGFzaCBhbGdvcml0aG1cbiAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IHRoZSBzaWduYXR1cmUgZW5jb2RlZCBpbiBiYXNlNjRcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5zaWduID0gZnVuY3Rpb24gKHN0ciwgZGlnZXN0TWV0aG9kLCBkaWdlc3ROYW1lKSB7XG4gICAgICAgIC8vIHJldHVybiB0aGUgUlNBIHNpZ25hdHVyZSBvZiAnc3RyJyBpbiAnaGV4JyBmb3JtYXQuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gaGV4MmI2NCh0aGlzLmdldEtleSgpLnNpZ24oc3RyLCBkaWdlc3RNZXRob2QsIGRpZ2VzdE5hbWUpKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICogUHJveHkgbWV0aG9kIGZvciBSU0FLZXkgb2JqZWN0J3MgdmVyaWZ5LlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgdGhlIHN0cmluZyB0byB2ZXJpZnlcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2lnbmF0dXJlIHRoZSBzaWduYXR1cmUgZW5jb2RlZCBpbiBiYXNlNjQgdG8gY29tcGFyZSB0aGUgc3RyaW5nIHRvXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbn0gZGlnZXN0TWV0aG9kIGhhc2ggbWV0aG9kXG4gICAgICogQHJldHVybiB7Ym9vbGVhbn0gd2hldGhlciB0aGUgZGF0YSBhbmQgc2lnbmF0dXJlIG1hdGNoXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUudmVyaWZ5ID0gZnVuY3Rpb24gKHN0ciwgc2lnbmF0dXJlLCBkaWdlc3RNZXRob2QpIHtcbiAgICAgICAgLy8gUmV0dXJuIHRoZSBkZWNyeXB0ZWQgJ2RpZ2VzdCcgb2YgdGhlIHNpZ25hdHVyZS5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldEtleSgpLnZlcmlmeShzdHIsIGI2NHRvaGV4KHNpZ25hdHVyZSksIGRpZ2VzdE1ldGhvZCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEdldHRlciBmb3IgdGhlIGN1cnJlbnQgSlNFbmNyeXB0UlNBS2V5IG9iamVjdC4gSWYgaXQgZG9lc24ndCBleGlzdHMgYSBuZXcgb2JqZWN0XG4gICAgICogd2lsbCBiZSBjcmVhdGVkIGFuZCByZXR1cm5lZFxuICAgICAqIEBwYXJhbSB7Y2FsbGJhY2t9IFtjYl0gdGhlIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBpZiB3ZSB3YW50IHRoZSBrZXkgdG8gYmUgZ2VuZXJhdGVkXG4gICAgICogaW4gYW4gYXN5bmMgZmFzaGlvblxuICAgICAqIEByZXR1cm5zIHtKU0VuY3J5cHRSU0FLZXl9IHRoZSBKU0VuY3J5cHRSU0FLZXkgb2JqZWN0XG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuZ2V0S2V5ID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgIC8vIE9ubHkgY3JlYXRlIG5ldyBpZiBpdCBkb2VzIG5vdCBleGlzdC5cbiAgICAgICAgaWYgKCF0aGlzLmtleSkge1xuICAgICAgICAgICAgLy8gR2V0IGEgbmV3IHByaXZhdGUga2V5LlxuICAgICAgICAgICAgdGhpcy5rZXkgPSBuZXcgSlNFbmNyeXB0UlNBS2V5KCk7XG4gICAgICAgICAgICBpZiAoY2IgJiYge30udG9TdHJpbmcuY2FsbChjYikgPT09IFwiW29iamVjdCBGdW5jdGlvbl1cIikge1xuICAgICAgICAgICAgICAgIHRoaXMua2V5LmdlbmVyYXRlQXN5bmModGhpcy5kZWZhdWx0X2tleV9zaXplLCB0aGlzLmRlZmF1bHRfcHVibGljX2V4cG9uZW50LCBjYik7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gR2VuZXJhdGUgdGhlIGtleS5cbiAgICAgICAgICAgIHRoaXMua2V5LmdlbmVyYXRlKHRoaXMuZGVmYXVsdF9rZXlfc2l6ZSwgdGhpcy5kZWZhdWx0X3B1YmxpY19leHBvbmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMua2V5O1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVtIGVuY29kZWQgcmVwcmVzZW50YXRpb24gb2YgdGhlIHByaXZhdGUga2V5XG4gICAgICogSWYgdGhlIGtleSBkb2Vzbid0IGV4aXN0cyBhIG5ldyBrZXkgd2lsbCBiZSBjcmVhdGVkXG4gICAgICogQHJldHVybnMge3N0cmluZ30gcGVtIGVuY29kZWQgcmVwcmVzZW50YXRpb24gb2YgdGhlIHByaXZhdGUga2V5IFdJVEggaGVhZGVyIGFuZCBmb290ZXJcbiAgICAgKiBAcHVibGljXG4gICAgICovXG4gICAgSlNFbmNyeXB0LnByb3RvdHlwZS5nZXRQcml2YXRlS2V5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIHByaXZhdGUgcmVwcmVzZW50YXRpb24gb2YgdGhpcyBrZXkuXG4gICAgICAgIHJldHVybiB0aGlzLmdldEtleSgpLmdldFByaXZhdGVLZXkoKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHBlbSBlbmNvZGVkIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBwcml2YXRlIGtleVxuICAgICAqIElmIHRoZSBrZXkgZG9lc24ndCBleGlzdHMgYSBuZXcga2V5IHdpbGwgYmUgY3JlYXRlZFxuICAgICAqIEByZXR1cm5zIHtzdHJpbmd9IHBlbSBlbmNvZGVkIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBwcml2YXRlIGtleSBXSVRIT1VUIGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuZ2V0UHJpdmF0ZUtleUI2NCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy8gUmV0dXJuIHRoZSBwcml2YXRlIHJlcHJlc2VudGF0aW9uIG9mIHRoaXMga2V5LlxuICAgICAgICByZXR1cm4gdGhpcy5nZXRLZXkoKS5nZXRQcml2YXRlQmFzZUtleUI2NCgpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVtIGVuY29kZWQgcmVwcmVzZW50YXRpb24gb2YgdGhlIHB1YmxpYyBrZXlcbiAgICAgKiBJZiB0aGUga2V5IGRvZXNuJ3QgZXhpc3RzIGEgbmV3IGtleSB3aWxsIGJlIGNyZWF0ZWRcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSBwZW0gZW5jb2RlZCByZXByZXNlbnRhdGlvbiBvZiB0aGUgcHVibGljIGtleSBXSVRIIGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuZ2V0UHVibGljS2V5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIHByaXZhdGUgcmVwcmVzZW50YXRpb24gb2YgdGhpcyBrZXkuXG4gICAgICAgIHJldHVybiB0aGlzLmdldEtleSgpLmdldFB1YmxpY0tleSgpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVtIGVuY29kZWQgcmVwcmVzZW50YXRpb24gb2YgdGhlIHB1YmxpYyBrZXlcbiAgICAgKiBJZiB0aGUga2V5IGRvZXNuJ3QgZXhpc3RzIGEgbmV3IGtleSB3aWxsIGJlIGNyZWF0ZWRcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfSBwZW0gZW5jb2RlZCByZXByZXNlbnRhdGlvbiBvZiB0aGUgcHVibGljIGtleSBXSVRIT1VUIGhlYWRlciBhbmQgZm9vdGVyXG4gICAgICogQHB1YmxpY1xuICAgICAqL1xuICAgIEpTRW5jcnlwdC5wcm90b3R5cGUuZ2V0UHVibGljS2V5QjY0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIHByaXZhdGUgcmVwcmVzZW50YXRpb24gb2YgdGhpcyBrZXkuXG4gICAgICAgIHJldHVybiB0aGlzLmdldEtleSgpLmdldFB1YmxpY0Jhc2VLZXlCNjQoKTtcbiAgICB9O1xuICAgIEpTRW5jcnlwdC52ZXJzaW9uID0gXCIzLjEuNFwiO1xuICAgIHJldHVybiBKU0VuY3J5cHQ7XG59KCkpO1xuXG53aW5kb3cuSlNFbmNyeXB0ID0gSlNFbmNyeXB0O1xuXG5leHBvcnRzLkpTRW5jcnlwdCA9IEpTRW5jcnlwdDtcbmV4cG9ydHMuZGVmYXVsdCA9IEpTRW5jcnlwdDtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcblxufSkpKTtcbiJdfQ==