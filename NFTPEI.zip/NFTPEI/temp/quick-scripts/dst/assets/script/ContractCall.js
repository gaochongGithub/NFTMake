
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/ContractCall.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '61306zq5E9EqaGNUhYuZ3dY', 'ContractCall');
// script/ContractCall.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var SingtonClass_1 = require("./SingtonClass");
// import Web3 from "./web3/dist/web3.min.js";
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._func = null;
        _this.isChange = true;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.start = function () {
        // this.changeAdress();
    };
    //获取web3
    NewClass.prototype.getWeb3 = function () {
        var w = window;
        if (typeof w.ethereum !== 'undefined') {
            this.web3 = new Web3(w.ethereum); // eslint-disable-line
        }
        else if (w.web3) {
            this.web3 = new Web3(w.web3.currentProvider);
        }
        else {
            this.web3 = new Web3(new Web3.providers.HttpProvider('https://data-seed-prebsc-1-s2.binance.org:8545/'));
        }
    };
    //调起弹框
    NewClass.prototype.clickCall = function () {
        return __awaiter(this, void 0, void 0, function () {
            var w;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        w = window;
                        return [4 /*yield*/, w.ethereum.enable()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NewClass.prototype.getAddress = function (getMsg, cb) {
        return __awaiter(this, void 0, void 0, function () {
            var w, msg;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        w = window;
                        if (!w.ethereum.selectedAddress) return [3 /*break*/, 1];
                        this.myAddr = w.ethereum.selectedAddress;
                        return [3 /*break*/, 3];
                    case 1: return [4 /*yield*/, w.ethereum.request({ method: "eth_requestAccounts" })];
                    case 2:
                        _a.sent();
                        this.myAddr = w.ethereum.address;
                        _a.label = 3;
                    case 3:
                        msg = getMsg;
                        this.web3.currentProvider.sendAsync({
                            method: 'personal_sign',
                            params: [msg, this.myAddr],
                            from: this.myAddr
                        }, function (err, res) {
                            if (err)
                                return console.error(err);
                            if (res.error) {
                                return console.error(res.error.message);
                            }
                            var sig = _this.getWalletType() + " " + res.result;
                            var obj = {
                                address: _this.myAddr,
                                sig: _this.getWalletType() + " " + res.result,
                            };
                            // console.log(obj , "地址")
                            _this.web3Data = obj;
                            cb(sig);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NewClass.prototype.getWeb3Data = function () {
        return this.web3Data;
    };
    NewClass.prototype.getUserAddress = function () {
        return __awaiter(this, void 0, void 0, function () {
            var accounts;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new this.web3.eth.getAccounts()];
                    case 1:
                        accounts = _a.sent();
                        return [2 /*return*/, accounts[0]];
                }
            });
        });
    };
    //获取类型
    NewClass.prototype.getWalletType = function () {
        var w = window;
        if (!w.ethereum) {
            return 'no';
        }
        else if (w.ethereum.isImToken) {
            return 'imtoken';
        }
        else if (w.ethereum.isTokenPocket) {
            return 'tokenpocket';
        }
        else if (w.ethereum.rpcUrl && w.ethereum.rpcUrl.indexOf('bitkeep') !== -1) {
            return 'bitkeep';
        }
        else if (w.ethereum.isMetaMask && w.ethereum._metamask) {
            return 'metamask';
        }
        else if (w.ethereum.isCoin98) {
            return 'coin98';
        }
        else {
            return 'unknown';
        }
    };
    //获取合约信息
    NewClass.prototype.contractCall = function (abi, addres) {
        var MyContract = new this.web3.eth.Contract(abi, addres);
        // this.changeAdress();
        return MyContract;
    };
    //切换钱包地址
    NewClass.prototype.changeAdress = function () {
        var w = window;
        // w.ethereum.on("accountsChanged", function(accounts) {
        //     console.log("切换账套号了",accounts[0],this.web3Data.address);//一旦切换账号这里就会执行
        // });
        var isChange = true;
        var self = this;
        new this.web3.eth.getAccounts().then(function (data) {
            // var draess = data[0].toUpperCase();
            var address = data[0].toLowerCase();
            // console.log(address , this.web3Data.address , address === this.web3Data.address,"供货及");
            if (address === self.web3Data.address) {
                isChange = true;
                self.isChange = true;
                console.log("没有切换");
                //提示
            }
            else {
                isChange = false;
                self.isChange = false;
                console.log("切换账户");
            }
            // console.log(address , this.web3Data.address , address === self.web3Data.address , isChange , "??????");
        });
        console.log(isChange, self.isChange, "回家");
        return isChange;
    };
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(SingtonClass_1.SingtonClass));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxDb250cmFjdENhbGwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFbEYsK0NBQThDO0FBQzlDLDhDQUE4QztBQUV4QyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUs1QztJQUFzQyw0QkFBWTtJQUFsRDtRQUFBLHFFQTZIQztRQTFIVyxXQUFLLEdBQWEsSUFBSyxDQUFDO1FBRXpCLGNBQVEsR0FBVyxJQUFJLENBQUM7O0lBd0huQyxDQUFDO0lBdkhHLHdCQUF3QjtJQUV4QixlQUFlO0lBRWYsd0JBQUssR0FBTDtRQUVJLHVCQUF1QjtJQUMzQixDQUFDO0lBRUQsUUFBUTtJQUNSLDBCQUFPLEdBQVA7UUFFSSxJQUFJLENBQUMsR0FBRyxNQUFhLENBQUM7UUFDdEIsSUFBSSxPQUFPLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ25DLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsc0JBQXNCO1NBQzNEO2FBQU0sSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFO1lBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1NBQ2hEO2FBQU07WUFDSCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsaURBQWlELENBQUMsQ0FBQyxDQUFDO1NBQzVHO0lBQ0wsQ0FBQztJQUVELE1BQU07SUFDQSw0QkFBUyxHQUFmOzs7Ozs7d0JBQ1EsQ0FBQyxHQUFHLE1BQWEsQ0FBQzt3QkFDdEIscUJBQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBQTs7d0JBQXpCLFNBQXlCLENBQUM7Ozs7O0tBQzdCO0lBQ0ssNkJBQVUsR0FBaEIsVUFBaUIsTUFBVyxFQUFFLEVBQVk7Ozs7Ozs7d0JBQ2xDLENBQUMsR0FBRyxNQUFhLENBQUM7NkJBQ2xCLENBQUMsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUExQix3QkFBMEI7d0JBQzFCLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUM7OzRCQUV6QyxxQkFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE1BQU0sRUFBRSxxQkFBcUIsRUFBRSxDQUFDLEVBQUE7O3dCQUEzRCxTQUEyRCxDQUFDO3dCQUM1RCxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDOzs7d0JBTS9CLEdBQUcsR0FBRyxNQUFNLENBQUM7d0JBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQzs0QkFDaEMsTUFBTSxFQUFFLGVBQWU7NEJBQ3ZCLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDOzRCQUMxQixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU07eUJBQ3BCLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRzs0QkFDUixJQUFJLEdBQUc7Z0NBQUUsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBOzRCQUNsQyxJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7Z0NBQ1gsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUE7NkJBQzFDOzRCQUNELElBQUksR0FBRyxHQUFHLEtBQUksQ0FBQyxhQUFhLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQzs0QkFFbEQsSUFBSSxHQUFHLEdBQUc7Z0NBQ04sT0FBTyxFQUFFLEtBQUksQ0FBQyxNQUFNO2dDQUNwQixHQUFHLEVBQUUsS0FBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTTs2QkFDL0MsQ0FBQTs0QkFDRCwwQkFBMEI7NEJBQzFCLEtBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDOzRCQUNwQixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ1osQ0FBQyxDQUFDLENBQUE7Ozs7O0tBQ0w7SUFDRCw4QkFBVyxHQUFYO1FBQ0ksT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3pCLENBQUM7SUFDSyxpQ0FBYyxHQUFwQjs7Ozs7NEJBQ3FCLHFCQUFNLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEVBQUE7O3dCQUFoRCxRQUFRLEdBQUcsU0FBcUM7d0JBQ3RELHNCQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQzs7OztLQUN0QjtJQUNELE1BQU07SUFDTixnQ0FBYSxHQUFiO1FBQ0ksSUFBSSxDQUFDLEdBQUcsTUFBYSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO1lBQ2IsT0FBTyxJQUFJLENBQUE7U0FDZDthQUFNLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7WUFDN0IsT0FBTyxTQUFTLENBQUE7U0FDbkI7YUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO1lBQ2pDLE9BQU8sYUFBYSxDQUFBO1NBQ3ZCO2FBQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDekUsT0FBTyxTQUFTLENBQUE7U0FDbkI7YUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQ3RELE9BQU8sVUFBVSxDQUFBO1NBQ3BCO2FBQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUM1QixPQUFPLFFBQVEsQ0FBQTtTQUNsQjthQUFNO1lBQ0gsT0FBTyxTQUFTLENBQUE7U0FDbkI7SUFDTCxDQUFDO0lBQ0QsUUFBUTtJQUNSLCtCQUFZLEdBQVosVUFBYSxHQUFHLEVBQUUsTUFBYztRQUM1QixJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDekQsdUJBQXVCO1FBQ3ZCLE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFDRCxRQUFRO0lBQ1IsK0JBQVksR0FBWjtRQUNJLElBQUksQ0FBQyxHQUFHLE1BQWEsQ0FBQztRQUN0Qix3REFBd0Q7UUFDeEQsNkVBQTZFO1FBQzdFLE1BQU07UUFDTixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQUMsSUFBSTtZQUN0QyxzQ0FBc0M7WUFDdEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3BDLDBGQUEwRjtZQUMxRixJQUFJLE9BQU8sS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRTtnQkFDbkMsUUFBUSxHQUFHLElBQUksQ0FBQztnQkFDaEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3BCLElBQUk7YUFDUDtpQkFBSTtnQkFDRCxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUN2QjtZQUNELDBHQUEwRztRQUM5RyxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFHLElBQUksQ0FBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0MsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQTVIZ0IsUUFBUTtRQUQ1QixPQUFPO09BQ2EsUUFBUSxDQTZINUI7SUFBRCxlQUFDO0NBN0hELEFBNkhDLENBN0hxQywyQkFBWSxHQTZIakQ7a0JBN0hvQixRQUFRIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuaW1wb3J0IHsgU2luZ3RvbkNsYXNzIH0gZnJvbSBcIi4vU2luZ3RvbkNsYXNzXCI7XHJcbi8vIGltcG9ydCBXZWIzIGZyb20gXCIuL3dlYjMvZGlzdC93ZWIzLm1pbi5qc1wiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbmRlY2xhcmUgdmFyIFdlYjM7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOZXdDbGFzcyBleHRlbmRzIFNpbmd0b25DbGFzcyB7XHJcbiAgICB3ZWIzOiBhbnk7XHJcbiAgICBwcml2YXRlIG15QWRkcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfZnVuYzogRnVuY3Rpb24gPSBudWxsITtcclxuICAgIHB1YmxpYyB3ZWIzRGF0YTogYW55O1xyXG4gICAgcHVibGljIGlzQ2hhbmdlOmJvb2xlYW4gPSB0cnVlO1xyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuY2hhbmdlQWRyZXNzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy/ojrflj5Z3ZWIzXHJcbiAgICBnZXRXZWIzKCkge1xyXG5cclxuICAgICAgICBsZXQgdyA9IHdpbmRvdyBhcyBhbnk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB3LmV0aGVyZXVtICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLndlYjMgPSBuZXcgV2ViMyh3LmV0aGVyZXVtKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxyXG4gICAgICAgIH0gZWxzZSBpZiAody53ZWIzKSB7XHJcbiAgICAgICAgICAgIHRoaXMud2ViMyA9IG5ldyBXZWIzKHcud2ViMy5jdXJyZW50UHJvdmlkZXIpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMud2ViMyA9IG5ldyBXZWIzKG5ldyBXZWIzLnByb3ZpZGVycy5IdHRwUHJvdmlkZXIoJ2h0dHBzOi8vZGF0YS1zZWVkLXByZWJzYy0xLXMyLmJpbmFuY2Uub3JnOjg1NDUvJykpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvL+iwg+i1t+W8ueahhlxyXG4gICAgYXN5bmMgY2xpY2tDYWxsKCkge1xyXG4gICAgICAgIGxldCB3ID0gd2luZG93IGFzIGFueTtcclxuICAgICAgICBhd2FpdCB3LmV0aGVyZXVtLmVuYWJsZSgpO1xyXG4gICAgfVxyXG4gICAgYXN5bmMgZ2V0QWRkcmVzcyhnZXRNc2c6IGFueSwgY2I6IEZ1bmN0aW9uKSB7XHJcbiAgICAgICAgbGV0IHcgPSB3aW5kb3cgYXMgYW55O1xyXG4gICAgICAgIGlmICh3LmV0aGVyZXVtLnNlbGVjdGVkQWRkcmVzcykge1xyXG4gICAgICAgICAgICB0aGlzLm15QWRkciA9IHcuZXRoZXJldW0uc2VsZWN0ZWRBZGRyZXNzO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHcuZXRoZXJldW0ucmVxdWVzdCh7IG1ldGhvZDogXCJldGhfcmVxdWVzdEFjY291bnRzXCIgfSk7XHJcbiAgICAgICAgICAgIHRoaXMubXlBZGRyID0gdy5ldGhlcmV1bS5hZGRyZXNzO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zdCBhY2NvdW50cyA9IGF3YWl0IG5ldyB0aGlzLndlYjMuZXRoLmdldEFjY291bnRzKClcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhhY2NvdW50cywgXCLnu5PmnpxcIik7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5teUFkZHIsIFwi6I635Y+W5Zyw5Z2AXCIpO1xyXG5cclxuICAgICAgICBjb25zdCBtc2cgPSBnZXRNc2c7XHJcbiAgICAgICAgdGhpcy53ZWIzLmN1cnJlbnRQcm92aWRlci5zZW5kQXN5bmMoe1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdwZXJzb25hbF9zaWduJyxcclxuICAgICAgICAgICAgcGFyYW1zOiBbbXNnLCB0aGlzLm15QWRkcl0sXHJcbiAgICAgICAgICAgIGZyb206IHRoaXMubXlBZGRyXHJcbiAgICAgICAgfSwgKGVyciwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlcnIpIHJldHVybiBjb25zb2xlLmVycm9yKGVycilcclxuICAgICAgICAgICAgaWYgKHJlcy5lcnJvcikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnNvbGUuZXJyb3IocmVzLmVycm9yLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IHNpZyA9IHRoaXMuZ2V0V2FsbGV0VHlwZSgpICsgXCIgXCIgKyByZXMucmVzdWx0O1xyXG5cclxuICAgICAgICAgICAgdmFyIG9iaiA9IHtcclxuICAgICAgICAgICAgICAgIGFkZHJlc3M6IHRoaXMubXlBZGRyLFxyXG4gICAgICAgICAgICAgICAgc2lnOiB0aGlzLmdldFdhbGxldFR5cGUoKSArIFwiIFwiICsgcmVzLnJlc3VsdCwgLy8g562+5ZCN77yM5Lik6YOo5YiG77yM56ys5LiA6YOo5YiG5piv6ZKx5YyF57G75Z6L77yM56ys5LqM6YOo5YiG5piv55So56eB6ZKl5a+55raI5oGv6L+b6KGM55qE5Yqg5a+G57uT5p6c77yM5raI5oGvIFwiS0FLQU5GVCBUUk9MQU5EOiBDb25maXJtIHRvIGNvbm5lY3QgeW91ciB3YWxsZXQgdG8gdGhlIGdhbWVcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKG9iaiAsIFwi5Zyw5Z2AXCIpXHJcbiAgICAgICAgICAgIHRoaXMud2ViM0RhdGEgPSBvYmo7XHJcbiAgICAgICAgICAgIGNiKHNpZyk7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIGdldFdlYjNEYXRhKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLndlYjNEYXRhO1xyXG4gICAgfVxyXG4gICAgYXN5bmMgZ2V0VXNlckFkZHJlc3MoKXtcclxuICAgICAgICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IG5ldyB0aGlzLndlYjMuZXRoLmdldEFjY291bnRzKCk7XHJcbiAgICAgICAgcmV0dXJuIGFjY291bnRzWzBdO1xyXG4gICAgfVxyXG4gICAgLy/ojrflj5bnsbvlnotcclxuICAgIGdldFdhbGxldFR5cGUoKSB7XHJcbiAgICAgICAgbGV0IHcgPSB3aW5kb3cgYXMgYW55O1xyXG4gICAgICAgIGlmICghdy5ldGhlcmV1bSkge1xyXG4gICAgICAgICAgICByZXR1cm4gJ25vJ1xyXG4gICAgICAgIH0gZWxzZSBpZiAody5ldGhlcmV1bS5pc0ltVG9rZW4pIHtcclxuICAgICAgICAgICAgcmV0dXJuICdpbXRva2VuJ1xyXG4gICAgICAgIH0gZWxzZSBpZiAody5ldGhlcmV1bS5pc1Rva2VuUG9ja2V0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiAndG9rZW5wb2NrZXQnXHJcbiAgICAgICAgfSBlbHNlIGlmICh3LmV0aGVyZXVtLnJwY1VybCAmJiB3LmV0aGVyZXVtLnJwY1VybC5pbmRleE9mKCdiaXRrZWVwJykgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnYml0a2VlcCdcclxuICAgICAgICB9IGVsc2UgaWYgKHcuZXRoZXJldW0uaXNNZXRhTWFzayAmJiB3LmV0aGVyZXVtLl9tZXRhbWFzaykge1xyXG4gICAgICAgICAgICByZXR1cm4gJ21ldGFtYXNrJ1xyXG4gICAgICAgIH0gZWxzZSBpZiAody5ldGhlcmV1bS5pc0NvaW45OCkge1xyXG4gICAgICAgICAgICByZXR1cm4gJ2NvaW45OCdcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gJ3Vua25vd24nXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy/ojrflj5blkIjnuqbkv6Hmga9cclxuICAgIGNvbnRyYWN0Q2FsbChhYmksIGFkZHJlczogc3RyaW5nKSB7XHJcbiAgICAgICAgdmFyIE15Q29udHJhY3QgPSBuZXcgdGhpcy53ZWIzLmV0aC5Db250cmFjdChhYmksIGFkZHJlcyk7XHJcbiAgICAgICAgLy8gdGhpcy5jaGFuZ2VBZHJlc3MoKTtcclxuICAgICAgICByZXR1cm4gTXlDb250cmFjdDtcclxuICAgIH1cclxuICAgIC8v5YiH5o2i6ZKx5YyF5Zyw5Z2AXHJcbiAgICBjaGFuZ2VBZHJlc3MoKSB7XHJcbiAgICAgICAgbGV0IHcgPSB3aW5kb3cgYXMgYW55O1xyXG4gICAgICAgIC8vIHcuZXRoZXJldW0ub24oXCJhY2NvdW50c0NoYW5nZWRcIiwgZnVuY3Rpb24oYWNjb3VudHMpIHtcclxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCLliIfmjaLotKblpZflj7fkuoZcIixhY2NvdW50c1swXSx0aGlzLndlYjNEYXRhLmFkZHJlc3MpOy8v5LiA5pem5YiH5o2i6LSm5Y+36L+Z6YeM5bCx5Lya5omn6KGMXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgdmFyIGlzQ2hhbmdlID0gdHJ1ZTtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgbmV3IHRoaXMud2ViMy5ldGguZ2V0QWNjb3VudHMoKS50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIHZhciBkcmFlc3MgPSBkYXRhWzBdLnRvVXBwZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIHZhciBhZGRyZXNzID0gZGF0YVswXS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhhZGRyZXNzICwgdGhpcy53ZWIzRGF0YS5hZGRyZXNzICwgYWRkcmVzcyA9PT0gdGhpcy53ZWIzRGF0YS5hZGRyZXNzLFwi5L6b6LSn5Y+KXCIpO1xyXG4gICAgICAgICAgICBpZiAoYWRkcmVzcyA9PT0gc2VsZi53ZWIzRGF0YS5hZGRyZXNzKSB7XHJcbiAgICAgICAgICAgICAgICBpc0NoYW5nZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBzZWxmLmlzQ2hhbmdlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5rKh5pyJ5YiH5o2iXCIpO1xyXG4gICAgICAgICAgICAgICAgLy/mj5DnpLpcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBpc0NoYW5nZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5pc0NoYW5nZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLliIfmjaLotKbmiLdcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYWRkcmVzcyAsIHRoaXMud2ViM0RhdGEuYWRkcmVzcyAsIGFkZHJlc3MgPT09IHNlbGYud2ViM0RhdGEuYWRkcmVzcyAsIGlzQ2hhbmdlICwgXCI/Pz8/Pz9cIik7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coaXNDaGFuZ2UgLCBzZWxmLmlzQ2hhbmdlLFwi5Zue5a62XCIpO1xyXG4gICAgICAgIHJldHVybiBpc0NoYW5nZTtcclxuICAgIH1cclxufVxyXG4iXX0=