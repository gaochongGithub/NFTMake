
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/init.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '80092cWiohCyK8KXCmv9Cxi', 'init');
// script/init.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        // onLoad () {}
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isFullscreenEnabled = null;
        _this.screenHeight = 0;
        _this.isSafari = false;
        _this.rerotation = null;
        _this.swipeTip = null; /**滑动的div */
        _this.initHeight = 0; /**初始高 */
        _this.gameDiv = null;
        _this.gameCanvas = null;
        return _this;
    }
    NewClass.prototype.start = function () {
        this.initFullScreen();
    };
    NewClass.prototype.initFullScreen = function () {
        if (cc.view.getFrameSize().width > cc.view.getFrameSize().height) {
            cc.view.setDesignResolutionSize(1334, 750, cc.ResolutionPolicy.SHOW_ALL);
        }
        if (!cc.sys.isMobile) {
            return;
        }
        if (window.location.search.indexOf("NOFULL") >= 0) {
            return;
        }
        this.initGameDiv();
        var self = this;
        window.addEventListener("resize", function () {
            self.showSwipeTip();
        }, false);
        // window.onresize = function(){
        // }
        this.showSwipeTip();
    };
    NewClass.prototype.initGameDiv = function () {
        document.body.style.margin = "0 auto";
        document.body.style.overflow = "auto";
        // var gameDiv = document.createElement('div');
        // gameDiv.id = 'GameDiv';
        var gameDiv = document.getElementById('GameDiv');
        gameDiv.style.margin = '0 auto';
        gameDiv.style.position = 'relative';
        gameDiv.style.height = '100vh';
        gameDiv.style.width = '100%';
        // document.body.appendChild(gameDiv);
        this.gameDiv = gameDiv;
        var gameCanvas = document.getElementById('GameCanvas');
        // document.body.removeChild(gameCanvas!);
        // gameDiv.appendChild(gameCanvas!);
        this.gameCanvas = gameCanvas;
        this._isFullscreenEnabled = this.isFullscreenEnabled();
        this.swipeTip = document.getElementById('swipeTip');
        this.swipeTip.style.backgroundImage = "url(img/swipe_2.gif)";
        var ua = navigator.userAgent;
        this.isSafari = ua.match(/iPhone/i) != null && ua.match(/safari/i) != null && ua.match(/Version/i) != null;
    };
    NewClass.prototype.showSwipeTip = function () {
        if (this.rerotation != window.orientation) {
            this.rerotation = window.orientation;
            this.initHeight = window.innerHeight;
            if (this.rerotation == 0 || this.rerotation == 180) {
                this.screenHeight = Math.max(window.screen.width, window.screen.height);
            }
            else {
                this.screenHeight = Math.min(window.screen.width, window.screen.height);
            }
        }
        var h = window.innerHeight;
        var isFull = (this.screenHeight == h) || (h > this.initHeight);
        if (isFull) {
            if (this.swipeTip.style.visibility != 'hidden') {
                this.swipeTip.style.zIndex = '-1';
                this.swipeTip.style.visibility = 'hidden';
                // console.log("isFull");
                this.setGameDiv();
                setTimeout(function () {
                    window.scrollTo(0, 1);
                }, 1000);
            }
        }
        else {
            if (this.swipeTip.style.visibility != 'visible') {
                this.swipeTip.style.zIndex = '996';
                this.swipeTip.style.height = (window.innerHeight + 420) + "px";
                this.swipeTip.style.display = 'block';
                this.swipeTip.style.visibility = 'visible';
                setTimeout(function () {
                    window.scrollTo(0, 1);
                }, 500);
            }
        }
    };
    //
    NewClass.prototype.setGameDiv = function () {
        var position = 'absolute';
        var gameWidth = '100%';
        var gameHeight = '100%';
        if (cc.sys.isMobile) {
            var clientWidth = document.documentElement.clientWidth;
            var clientHeight = document.documentElement.clientHeight;
            var widthRatio = clientWidth / 750;
            var heightRatio = clientHeight / 1334;
            var devicePixelRatio = cc.view.getDevicePixelRatio(); // 750 / clientWidth;
            // var width = (widthRatio > heightRatio) ? 750 * heightRatio:'100%';
            var height = (widthRatio > heightRatio) ? window.innerHeight * widthRatio * devicePixelRatio : -1;
            // if(width != '100%') {
            //     if(width > clientWidth)
            //         position = 'relative';
            //     gameWidth += 'px';
            // }
            if (height != -1) {
                if (height > clientHeight) {
                    position = 'relative';
                }
                if (this.isSafari)
                    height = height * 0.97;
                gameHeight = Math.round(height) + 'px';
            }
        }
        document.body.style.position = position;
        this.gameDiv.style.height = gameHeight;
        // gameDiv.style.width = gameWidth;
        // game.canvas!.style.height = gameHeight;
        this.gameCanvas.style.height = gameHeight;
        cc.view._resizeEvent();
        // console.log(gameHeight);
    };
    //
    NewClass.prototype.isFullscreenEnabled = function () {
        var el = document;
        return el.fullscreenEnabled ||
            el.msFullscreenEnabled ||
            // el.webkitFullscreenEnabled ||
            el.mozFullScreenEnabled || false;
    };
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxpbml0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTVFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXNDLDRCQUFZO0lBQWxEO1FBR0ksZUFBZTtRQUhuQixxRUF5SkM7UUExSFcsMEJBQW9CLEdBQVEsSUFBSSxDQUFDO1FBQ2pDLGtCQUFZLEdBQVcsQ0FBQyxDQUFDO1FBQ3pCLGNBQVEsR0FBWSxLQUFLLENBQUM7UUFFMUIsZ0JBQVUsR0FBUSxJQUFJLENBQUM7UUFDdkIsY0FBUSxHQUFRLElBQUksQ0FBQyxDQUFBLFlBQVk7UUFDakMsZ0JBQVUsR0FBVyxDQUFDLENBQUMsQ0FBQSxTQUFTO1FBQ2hDLGFBQU8sR0FBUSxJQUFJLENBQUM7UUFDcEIsZ0JBQVUsR0FBUSxJQUFJLENBQUM7O0lBa0huQyxDQUFDO0lBcEpHLHdCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELGlDQUFjLEdBQWQ7UUFDSSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsTUFBTSxFQUFFO1lBQzlELEVBQUUsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDNUU7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDbEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9DLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRTtZQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ1YsZ0NBQWdDO1FBQ2hDLElBQUk7UUFDSixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFHeEIsQ0FBQztJQVVELDhCQUFXLEdBQVg7UUFDSSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDO1FBQ3RDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7UUFDdEMsK0NBQStDO1FBQy9DLDBCQUEwQjtRQUMxQixJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBRSxDQUFDO1FBQ2xELE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQztRQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDcEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBQy9CLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztRQUM3QixzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFFdkIsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN2RCwwQ0FBMEM7UUFDMUMsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBRTdCLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUV2RCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLHNCQUFzQixDQUFDO1FBRTdELElBQUksRUFBRSxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksQ0FBQztJQUUvRyxDQUFDO0lBQ0QsK0JBQVksR0FBWjtRQUNJLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztZQUNyQyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7WUFDckMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLEdBQUcsRUFBRTtnQkFDaEQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDM0U7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDM0U7U0FDSjtRQUNELElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7UUFDM0IsSUFBSSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMvRCxJQUFJLE1BQU0sRUFBRTtZQUNSLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxJQUFJLFFBQVEsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDbEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQztnQkFDMUMseUJBQXlCO2dCQUN6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBRWxCLFVBQVUsQ0FBQztvQkFDUCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFMUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBRVo7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxVQUFVLElBQUksU0FBUyxFQUFFO2dCQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2dCQUNuQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztnQkFDL0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztnQkFDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQztnQkFDM0MsVUFBVSxDQUFDO29CQUNQLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFFWDtTQUNKO0lBQ0wsQ0FBQztJQUNELEVBQUU7SUFDRiw2QkFBVSxHQUFWO1FBQ0ksSUFBSSxRQUFRLEdBQUcsVUFBVSxDQUFDO1FBQzFCLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQztRQUN2QixJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUM7UUFFeEIsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRTtZQUNqQixJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQztZQUN2RCxJQUFJLFlBQVksR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN6RCxJQUFJLFVBQVUsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDO1lBQ25DLElBQUksV0FBVyxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDdEMsSUFBSSxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQSxxQkFBcUI7WUFFMUUscUVBQXFFO1lBQ3JFLElBQUksTUFBTSxHQUFHLENBQUMsVUFBVSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxHQUFHLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEcsd0JBQXdCO1lBQ3hCLDhCQUE4QjtZQUM5QixpQ0FBaUM7WUFDakMseUJBQXlCO1lBQ3pCLElBQUk7WUFDSixJQUFJLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFDZCxJQUFJLE1BQU0sR0FBRyxZQUFZLEVBQUU7b0JBQ3ZCLFFBQVEsR0FBRyxVQUFVLENBQUM7aUJBQ3pCO2dCQUNELElBQUksSUFBSSxDQUFDLFFBQVE7b0JBQ2IsTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUM7Z0JBQzNCLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQzthQUMxQztTQUVKO1FBRUQsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN4QyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO1FBQ3ZDLG1DQUFtQztRQUNuQywwQ0FBMEM7UUFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQztRQUMxQyxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3ZCLDJCQUEyQjtJQUMvQixDQUFDO0lBQ0QsRUFBRTtJQUNGLHNDQUFtQixHQUFuQjtRQUNJLElBQUksRUFBRSxHQUFHLFFBQWUsQ0FBQztRQUN6QixPQUFPLEVBQUUsQ0FBQyxpQkFBaUI7WUFDdkIsRUFBRSxDQUFDLG1CQUFtQjtZQUN0QixnQ0FBZ0M7WUFDaEMsRUFBRSxDQUFDLG9CQUFvQixJQUFJLEtBQUssQ0FBQztJQUV6QyxDQUFDO0lBeEpnQixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBeUo1QjtJQUFELGVBQUM7Q0F6SkQsQUF5SkMsQ0F6SnFDLEVBQUUsQ0FBQyxTQUFTLEdBeUpqRDtrQkF6Sm9CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ld0NsYXNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuaW5pdEZ1bGxTY3JlZW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBpbml0RnVsbFNjcmVlbigpIHtcclxuICAgICAgICBpZiAoY2Mudmlldy5nZXRGcmFtZVNpemUoKS53aWR0aCA+IGNjLnZpZXcuZ2V0RnJhbWVTaXplKCkuaGVpZ2h0KSB7XHJcbiAgICAgICAgICAgIGNjLnZpZXcuc2V0RGVzaWduUmVzb2x1dGlvblNpemUoMTMzNCwgNzUwLCBjYy5SZXNvbHV0aW9uUG9saWN5LlNIT1dfQUxMKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFjYy5zeXMuaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAod2luZG93LmxvY2F0aW9uLnNlYXJjaC5pbmRleE9mKFwiTk9GVUxMXCIpID49IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmluaXRHYW1lRGl2KCk7XHJcblxyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHNlbGYuc2hvd1N3aXBlVGlwKCk7XHJcbiAgICAgICAgfSwgZmFsc2UpO1xyXG4gICAgICAgIC8vIHdpbmRvdy5vbnJlc2l6ZSA9IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgIHRoaXMuc2hvd1N3aXBlVGlwKCk7XHJcblxyXG5cclxuICAgIH1cclxuICAgIHByaXZhdGUgX2lzRnVsbHNjcmVlbkVuYWJsZWQ6IGFueSA9IG51bGw7XHJcbiAgICBwcml2YXRlIHNjcmVlbkhlaWdodDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgaXNTYWZhcmk6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIHJlcm90YXRpb246IGFueSA9IG51bGw7XHJcbiAgICBwcml2YXRlIHN3aXBlVGlwOiBhbnkgPSBudWxsOy8qKua7keWKqOeahGRpdiAqL1xyXG4gICAgcHJpdmF0ZSBpbml0SGVpZ2h0OiBudW1iZXIgPSAwOy8qKuWIneWni+mrmCAqL1xyXG4gICAgcHJpdmF0ZSBnYW1lRGl2OiBhbnkgPSBudWxsO1xyXG4gICAgcHJpdmF0ZSBnYW1lQ2FudmFzOiBhbnkgPSBudWxsO1xyXG4gICAgaW5pdEdhbWVEaXYoKSB7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5tYXJnaW4gPSBcIjAgYXV0b1wiO1xyXG4gICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImF1dG9cIjtcclxuICAgICAgICAvLyB2YXIgZ2FtZURpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIC8vIGdhbWVEaXYuaWQgPSAnR2FtZURpdic7XHJcbiAgICAgICAgdmFyIGdhbWVEaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnR2FtZURpdicpITtcclxuICAgICAgICBnYW1lRGl2LnN0eWxlLm1hcmdpbiA9ICcwIGF1dG8nO1xyXG4gICAgICAgIGdhbWVEaXYuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xyXG4gICAgICAgIGdhbWVEaXYuc3R5bGUuaGVpZ2h0ID0gJzEwMHZoJztcclxuICAgICAgICBnYW1lRGl2LnN0eWxlLndpZHRoID0gJzEwMCUnO1xyXG4gICAgICAgIC8vIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZ2FtZURpdik7XHJcbiAgICAgICAgdGhpcy5nYW1lRGl2ID0gZ2FtZURpdjtcclxuXHJcbiAgICAgICAgdmFyIGdhbWVDYW52YXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnR2FtZUNhbnZhcycpO1xyXG4gICAgICAgIC8vIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZ2FtZUNhbnZhcyEpO1xyXG4gICAgICAgIC8vIGdhbWVEaXYuYXBwZW5kQ2hpbGQoZ2FtZUNhbnZhcyEpO1xyXG4gICAgICAgIHRoaXMuZ2FtZUNhbnZhcyA9IGdhbWVDYW52YXM7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzRnVsbHNjcmVlbkVuYWJsZWQgPSB0aGlzLmlzRnVsbHNjcmVlbkVuYWJsZWQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5zd2lwZVRpcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzd2lwZVRpcCcpO1xyXG4gICAgICAgIHRoaXMuc3dpcGVUaXAuc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoaW1nL3N3aXBlXzIuZ2lmKVwiO1xyXG5cclxuICAgICAgICB2YXIgdWEgPSBuYXZpZ2F0b3IudXNlckFnZW50O1xyXG4gICAgICAgIHRoaXMuaXNTYWZhcmkgPSB1YS5tYXRjaCgvaVBob25lL2kpICE9IG51bGwgJiYgdWEubWF0Y2goL3NhZmFyaS9pKSAhPSBudWxsICYmIHVhLm1hdGNoKC9WZXJzaW9uL2kpICE9IG51bGw7XHJcblxyXG4gICAgfVxyXG4gICAgc2hvd1N3aXBlVGlwKCkge1xyXG4gICAgICAgIGlmICh0aGlzLnJlcm90YXRpb24gIT0gd2luZG93Lm9yaWVudGF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVyb3RhdGlvbiA9IHdpbmRvdy5vcmllbnRhdGlvbjtcclxuICAgICAgICAgICAgdGhpcy5pbml0SGVpZ2h0ID0gd2luZG93LmlubmVySGVpZ2h0O1xyXG4gICAgICAgICAgICBpZiAodGhpcy5yZXJvdGF0aW9uID09IDAgfHwgdGhpcy5yZXJvdGF0aW9uID09IDE4MCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY3JlZW5IZWlnaHQgPSBNYXRoLm1heCh3aW5kb3cuc2NyZWVuLndpZHRoLCB3aW5kb3cuc2NyZWVuLmhlaWdodCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjcmVlbkhlaWdodCA9IE1hdGgubWluKHdpbmRvdy5zY3JlZW4ud2lkdGgsIHdpbmRvdy5zY3JlZW4uaGVpZ2h0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcclxuICAgICAgICB2YXIgaXNGdWxsID0gKHRoaXMuc2NyZWVuSGVpZ2h0ID09IGgpIHx8IChoID4gdGhpcy5pbml0SGVpZ2h0KTtcclxuICAgICAgICBpZiAoaXNGdWxsKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnN3aXBlVGlwLnN0eWxlLnZpc2liaWxpdHkgIT0gJ2hpZGRlbicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3dpcGVUaXAuc3R5bGUuekluZGV4ID0gJy0xJztcclxuICAgICAgICAgICAgICAgIHRoaXMuc3dpcGVUaXAuc3R5bGUudmlzaWJpbGl0eSA9ICdoaWRkZW4nO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJpc0Z1bGxcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVEaXYoKTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMSk7XHJcblxyXG4gICAgICAgICAgICAgICAgfSwgMTAwMCk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc3dpcGVUaXAuc3R5bGUudmlzaWJpbGl0eSAhPSAndmlzaWJsZScpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3dpcGVUaXAuc3R5bGUuekluZGV4ID0gJzk5Nic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN3aXBlVGlwLnN0eWxlLmhlaWdodCA9ICh3aW5kb3cuaW5uZXJIZWlnaHQgKyA0MjApICsgXCJweFwiO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zd2lwZVRpcC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcclxuICAgICAgICAgICAgICAgIHRoaXMuc3dpcGVUaXAuc3R5bGUudmlzaWJpbGl0eSA9ICd2aXNpYmxlJztcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAxKTtcclxuICAgICAgICAgICAgICAgIH0sIDUwMCk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy9cclxuICAgIHNldEdhbWVEaXYoKSB7XHJcbiAgICAgICAgdmFyIHBvc2l0aW9uID0gJ2Fic29sdXRlJztcclxuICAgICAgICB2YXIgZ2FtZVdpZHRoID0gJzEwMCUnO1xyXG4gICAgICAgIHZhciBnYW1lSGVpZ2h0ID0gJzEwMCUnO1xyXG5cclxuICAgICAgICBpZiAoY2Muc3lzLmlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHZhciBjbGllbnRXaWR0aCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtcclxuICAgICAgICAgICAgdmFyIGNsaWVudEhlaWdodCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIHZhciB3aWR0aFJhdGlvID0gY2xpZW50V2lkdGggLyA3NTA7XHJcbiAgICAgICAgICAgIHZhciBoZWlnaHRSYXRpbyA9IGNsaWVudEhlaWdodCAvIDEzMzQ7XHJcbiAgICAgICAgICAgIHZhciBkZXZpY2VQaXhlbFJhdGlvID0gY2Mudmlldy5nZXREZXZpY2VQaXhlbFJhdGlvKCk7Ly8gNzUwIC8gY2xpZW50V2lkdGg7XHJcblxyXG4gICAgICAgICAgICAvLyB2YXIgd2lkdGggPSAod2lkdGhSYXRpbyA+IGhlaWdodFJhdGlvKSA/IDc1MCAqIGhlaWdodFJhdGlvOicxMDAlJztcclxuICAgICAgICAgICAgdmFyIGhlaWdodCA9ICh3aWR0aFJhdGlvID4gaGVpZ2h0UmF0aW8pID8gd2luZG93LmlubmVySGVpZ2h0ICogd2lkdGhSYXRpbyAqIGRldmljZVBpeGVsUmF0aW8gOiAtMTtcclxuICAgICAgICAgICAgLy8gaWYod2lkdGggIT0gJzEwMCUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICBpZih3aWR0aCA+IGNsaWVudFdpZHRoKVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIHBvc2l0aW9uID0gJ3JlbGF0aXZlJztcclxuICAgICAgICAgICAgLy8gICAgIGdhbWVXaWR0aCArPSAncHgnO1xyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgIGlmIChoZWlnaHQgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPiBjbGllbnRIZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbiA9ICdyZWxhdGl2ZSc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5pc1NhZmFyaSlcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQgPSBoZWlnaHQgKiAwLjk3O1xyXG4gICAgICAgICAgICAgICAgZ2FtZUhlaWdodCA9IE1hdGgucm91bmQoaGVpZ2h0KSArICdweCc7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLnBvc2l0aW9uID0gcG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5nYW1lRGl2LnN0eWxlLmhlaWdodCA9IGdhbWVIZWlnaHQ7XHJcbiAgICAgICAgLy8gZ2FtZURpdi5zdHlsZS53aWR0aCA9IGdhbWVXaWR0aDtcclxuICAgICAgICAvLyBnYW1lLmNhbnZhcyEuc3R5bGUuaGVpZ2h0ID0gZ2FtZUhlaWdodDtcclxuICAgICAgICB0aGlzLmdhbWVDYW52YXMuc3R5bGUuaGVpZ2h0ID0gZ2FtZUhlaWdodDtcclxuICAgICAgICBjYy52aWV3Ll9yZXNpemVFdmVudCgpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGdhbWVIZWlnaHQpO1xyXG4gICAgfVxyXG4gICAgLy9cclxuICAgIGlzRnVsbHNjcmVlbkVuYWJsZWQoKSB7XHJcbiAgICAgICAgbGV0IGVsID0gZG9jdW1lbnQgYXMgYW55O1xyXG4gICAgICAgIHJldHVybiBlbC5mdWxsc2NyZWVuRW5hYmxlZCB8fFxyXG4gICAgICAgICAgICBlbC5tc0Z1bGxzY3JlZW5FbmFibGVkIHx8XHJcbiAgICAgICAgICAgIC8vIGVsLndlYmtpdEZ1bGxzY3JlZW5FbmFibGVkIHx8XHJcbiAgICAgICAgICAgIGVsLm1vekZ1bGxTY3JlZW5FbmFibGVkIHx8IGZhbHNlO1xyXG5cclxuICAgIH1cclxufVxyXG4iXX0=