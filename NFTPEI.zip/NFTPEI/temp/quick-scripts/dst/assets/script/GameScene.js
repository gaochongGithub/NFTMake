
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/GameScene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a127f/KEIxDcLDhi0XykZ41', 'GameScene');
// script/GameScene.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var TextureRender_1 = require("./TextureRender");
// import JSEncrypt from "./rsa/jsencrypt.min";
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameScene = /** @class */ (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bg = null;
        _this.xianglian = null;
        _this.yifu = null;
        _this.toufa = null;
        _this.zui = null;
        _this.bizi = null;
        _this.yan = null;
        _this.baozhi = null;
        _this.youshou = null;
        _this.nfeId = "";
        _this.nfeIdArr = [];
        _this.currentNum = 0;
        _this.repeatNum = 0;
        return _this;
    }
    GameScene.prototype.onLoad = function () {
    };
    GameScene.prototype.start = function () {
        // cc.view.enableRetina(true)
        // cc.view.enableAntiAlias(false);
        var data = {
            list: [],
            num: 0,
            repeat: 0
        };
        // cc.sys.localStorage.setItem("nftID", JSON.stringify(data));
        var idList = JSON.parse(cc.sys.localStorage.getItem("nftID"));
        if (idList && idList.list.length > 0) {
            this.nfeIdArr = idList.list;
            this.currentNum = idList.num;
            this.repeatNum = idList.repeat;
            this.fileNum = idList.num;
        }
        console.log(idList, this.fileNum);
        // var s = this.nfeIdArr.join(",")+",";
        // // console.log(s , "这个是");
        // var arr = [1,3,5,76,156,9,3]
        // for(var i=0;i<this.nfeIdArr.length;i++) {
        //     if(s.replace(this.nfeIdArr[i]+",","").indexOf(this.nfeIdArr[i]+",")>-1) {
        //         console.log("数组中有重复元素：" + this.nfeIdArr[i]);
        //         break;
        //     }
        // }
        // var isBol = this.isRepeat(this.nfeIdArr);
        var w = window;
        if (w.ethereum.isTokenPocket) {
        }
        else {
        }
    };
    GameScene.prototype.isRepeat = function (arr) {
        var hash = {};
        for (var i in arr) {
            if (hash[arr[i]])
                return true;
            hash[arr[i]] = true;
        }
        return false;
    };
    GameScene.prototype.onclickInit = function () {
        var _this = this;
        this.init();
        // create capture
        var self = this;
        this.createCanvas();
        var img = this.createImg();
        // this.shoeImgSrc = img.src;
        this.scheduleOnce(function () {
            for (var i = 0; i < _this.nfeIdArr.length; i++) {
                if (_this.nfeIdArr[i] == _this.nfeId) {
                    console.log(_this.nfeIdArr[i], _this.nfeId);
                    _this.repeatNum++;
                    return;
                }
            }
            _this.nfeIdArr.push(_this.nfeId);
            // this.showImage(img);
            _this.downloadImg();
            var data = {
                list: _this.nfeIdArr,
                num: _this.fileNum,
                repeat: _this.repeatNum,
            };
            cc.sys.localStorage.setItem("nftID", JSON.stringify(data));
        }, 1);
        // this.clickSpecifyShoe();
    };
    //生成指定鞋子
    GameScene.prototype.clickSpecifyShoe = function () {
        var _this = this;
        //1569  
        for (var i = 0; i < 2200; i++) {
            this.scheduleOnce(function () {
                _this.nfeId = "";
                _this.getShoePartImg(_this.randNum(0, 4), _this.bg, "00", "bg");
                _this.getShoePartImg(_this.randNum(0, 3), _this.xianglian, "01", "xianglian");
                _this.getShoePartImg(_this.randNum(0, 3), _this.yifu, "02", "yifu");
                _this.getShoePartImg(_this.randNum(0, 3), _this.toufa, "03", "toufa");
                _this.getShoePartImg(_this.randNum(0, 3), _this.zui, "04", "zui");
                _this.getShoePartImg(_this.randNum(0, 3), _this.bizi, "05", "bizi");
                _this.getShoePartImg(_this.randNum(0, 3), _this.yan, "06", "yan");
                _this.getShoePartImg(_this.randNum(0, 3), _this.baozhi, "07", "baozhi");
                _this.getShoePartImg(_this.randNum(0, 3), _this.youshou, "08", "youshou");
            }, i * 2.5);
            this.scheduleOnce(function () {
                _this.onclickInit();
            }, i * 3.5);
        }
    };
    //获取随机数
    GameScene.prototype.randNum = function (m, n) {
        var num = parseInt(Math.random() * (n - m + 1) + m);
        // num >= 10 ? num : "0" + num
        return (num).toString();
    };
    GameScene.prototype.getShoePartImg = function (rand, spr, pos, file) {
        var self = this;
        this.nfeId += "0" + rand;
        cc.resources.load(file + "/" + rand, cc.SpriteFrame, function (err, spriteFrame) {
            if (err) {
                // spr.node.active = false;
                return;
            }
            // spr.node.active = true;
            spr.spriteFrame = spriteFrame;
        });
    };
    __decorate([
        property({ type: cc.Sprite, tooltip: "背景" })
    ], GameScene.prototype, "bg", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "项链" })
    ], GameScene.prototype, "xianglian", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "衣服" })
    ], GameScene.prototype, "yifu", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "头发" })
    ], GameScene.prototype, "toufa", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "嘴" })
    ], GameScene.prototype, "zui", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "鼻子" })
    ], GameScene.prototype, "bizi", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "眼睛" })
    ], GameScene.prototype, "yan", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "报纸" })
    ], GameScene.prototype, "baozhi", void 0);
    __decorate([
        property({ type: cc.Sprite, tooltip: "右手" })
    ], GameScene.prototype, "youshou", void 0);
    GameScene = __decorate([
        ccclass
    ], GameScene);
    return GameScene;
}(TextureRender_1.default));
exports.default = GameScene;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxHYW1lU2NlbmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT0EsaURBQTRDO0FBRTVDLCtDQUErQztBQUN6QyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUF1Qyw2QkFBYTtJQUFwRDtRQUFBLHFFQW1LQztRQWhLRyxRQUFFLEdBQWMsSUFBSSxDQUFDO1FBR3JCLGVBQVMsR0FBYyxJQUFJLENBQUM7UUFHNUIsVUFBSSxHQUFjLElBQUksQ0FBQztRQUd2QixXQUFLLEdBQWMsSUFBSSxDQUFDO1FBR3hCLFNBQUcsR0FBYyxJQUFJLENBQUM7UUFHdEIsVUFBSSxHQUFjLElBQUksQ0FBQztRQUd2QixTQUFHLEdBQWMsSUFBSSxDQUFDO1FBR3RCLFlBQU0sR0FBYyxJQUFJLENBQUM7UUFHekIsYUFBTyxHQUFjLElBQUksQ0FBQztRQUVsQixXQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ1gsY0FBUSxHQUFHLEVBQUUsQ0FBQztRQUNkLGdCQUFVLEdBQVUsQ0FBQyxDQUFDO1FBQ3RCLGVBQVMsR0FBVSxDQUFDLENBQUM7O0lBbUlqQyxDQUFDO0lBbElHLDBCQUFNLEdBQU47SUFFQSxDQUFDO0lBQ0QseUJBQUssR0FBTDtRQUNJLDZCQUE2QjtRQUM3QixrQ0FBa0M7UUFDbEMsSUFBSSxJQUFJLEdBQUc7WUFDUCxJQUFJLEVBQUMsRUFBRTtZQUNQLEdBQUcsRUFBQyxDQUFDO1lBQ0wsTUFBTSxFQUFDLENBQUM7U0FDWCxDQUFBO1FBQ0QsOERBQThEO1FBRTlELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDOUQsSUFBRyxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDO1lBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQy9CLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQTtTQUM1QjtRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUlqQyx1Q0FBdUM7UUFDdkMsNkJBQTZCO1FBQzdCLCtCQUErQjtRQUMvQiw0Q0FBNEM7UUFDNUMsZ0ZBQWdGO1FBQ2hGLHVEQUF1RDtRQUN2RCxpQkFBaUI7UUFDakIsUUFBUTtRQUNSLElBQUk7UUFFSiw0Q0FBNEM7UUFHNUMsSUFBSSxDQUFDLEdBQUcsTUFBYSxDQUFDO1FBQ3RCLElBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUM7U0FFM0I7YUFBSTtTQUVKO0lBQ0wsQ0FBQztJQUNELDRCQUFRLEdBQVIsVUFBUyxHQUFHO1FBQ1IsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsS0FBSSxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUU7WUFDZixJQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsT0FBTyxJQUFJLENBQUM7WUFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQ3ZCO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBQ0YsK0JBQVcsR0FBWDtRQUFBLGlCQThCQztRQTdCRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDWixpQkFBaUI7UUFDakIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFM0IsNkJBQTZCO1FBQzdCLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDZCxLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQUM7Z0JBQ25DLElBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFJLENBQUMsS0FBSyxFQUFDO29CQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUcsS0FBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUMzQyxLQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ2pCLE9BQU87aUJBQ1Y7YUFDSjtZQUVELEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQix1QkFBdUI7WUFDdkIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ25CLElBQUksSUFBSSxHQUFHO2dCQUNQLElBQUksRUFBQyxLQUFJLENBQUMsUUFBUTtnQkFDbEIsR0FBRyxFQUFDLEtBQUksQ0FBQyxPQUFPO2dCQUNoQixNQUFNLEVBQUMsS0FBSSxDQUFDLFNBQVM7YUFDeEIsQ0FBQTtZQUNELEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRS9ELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVOLDJCQUEyQjtJQUMvQixDQUFDO0lBQ0QsUUFBUTtJQUNSLG9DQUFnQixHQUFoQjtRQUFBLGlCQXdCQztRQXZCRyxRQUFRO1FBQ1IsS0FBSSxJQUFJLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksRUFBQyxDQUFDLEVBQUUsRUFBQztZQUNuQixJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNkLEtBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2dCQUNoQixLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxFQUFFLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6RCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxTQUFTLEVBQUMsSUFBSSxFQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN2RSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3RCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvRCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMzRCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3RCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMzRCxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxNQUFNLEVBQUMsSUFBSSxFQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNqRSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRXZFLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxDQUFDLENBQUE7WUFDUixJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNkLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtZQUN0QixDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxDQUFBO1NBRVg7SUFFTCxDQUFDO0lBRUQsT0FBTztJQUNQLDJCQUFPLEdBQVAsVUFBUSxDQUFDLEVBQUMsQ0FBQztRQUNQLElBQUksR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9DLDhCQUE4QjtRQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUNELGtDQUFjLEdBQWQsVUFBZSxJQUFJLEVBQUMsR0FBRyxFQUFDLEdBQUcsRUFBQyxJQUFJO1FBQzVCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUVoQixJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsR0FBQyxJQUFJLENBQUM7UUFDdkIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLEdBQUcsR0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsRUFBRSxXQUFXO1lBQ3ZFLElBQUksR0FBRyxFQUFFO2dCQUNMLDJCQUEyQjtnQkFDM0IsT0FBTzthQUNWO1lBQ0QsMEJBQTBCO1lBQzFCLEdBQUcsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQS9KRDtRQURDLFFBQVEsQ0FBQyxFQUFDLElBQUksRUFBQyxFQUFFLENBQUMsTUFBTSxFQUFHLE9BQU8sRUFBQyxJQUFJLEVBQUMsQ0FBQzt5Q0FDckI7SUFHckI7UUFEQyxRQUFRLENBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRyxPQUFPLEVBQUMsSUFBSSxFQUFDLENBQUM7Z0RBQ2Q7SUFHNUI7UUFEQyxRQUFRLENBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRyxPQUFPLEVBQUMsSUFBSSxFQUFDLENBQUM7MkNBQ25CO0lBR3ZCO1FBREMsUUFBUSxDQUFDLEVBQUMsSUFBSSxFQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUcsT0FBTyxFQUFDLElBQUksRUFBQyxDQUFDOzRDQUNsQjtJQUd4QjtRQURDLFFBQVEsQ0FBQyxFQUFDLElBQUksRUFBQyxFQUFFLENBQUMsTUFBTSxFQUFHLE9BQU8sRUFBQyxHQUFHLEVBQUMsQ0FBQzswQ0FDbkI7SUFHdEI7UUFEQyxRQUFRLENBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRyxPQUFPLEVBQUMsSUFBSSxFQUFDLENBQUM7MkNBQ25CO0lBR3ZCO1FBREMsUUFBUSxDQUFDLEVBQUMsSUFBSSxFQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUcsT0FBTyxFQUFDLElBQUksRUFBQyxDQUFDOzBDQUNwQjtJQUd0QjtRQURDLFFBQVEsQ0FBQyxFQUFDLElBQUksRUFBQyxFQUFFLENBQUMsTUFBTSxFQUFHLE9BQU8sRUFBQyxJQUFJLEVBQUMsQ0FBQzs2Q0FDakI7SUFHekI7UUFEQyxRQUFRLENBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRyxPQUFPLEVBQUMsSUFBSSxFQUFDLENBQUM7OENBQ2hCO0lBM0JULFNBQVM7UUFEN0IsT0FBTztPQUNhLFNBQVMsQ0FtSzdCO0lBQUQsZ0JBQUM7Q0FuS0QsQUFtS0MsQ0FuS3NDLHVCQUFhLEdBbUtuRDtrQkFuS29CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcbmltcG9ydCB7IEFwcCB9IGZyb20gXCIuL0FwcFwiO1xyXG5pbXBvcnQgVGV4dHVyZVJlbmRlciBmcm9tIFwiLi9UZXh0dXJlUmVuZGVyXCI7XHJcbmltcG9ydCBKU0VuY3J5cHQgZnJvbSBcIi4vcnNhL2pzZW5jcnlwdFwiXHJcbi8vIGltcG9ydCBKU0VuY3J5cHQgZnJvbSBcIi4vcnNhL2pzZW5jcnlwdC5taW5cIjtcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVTY2VuZSBleHRlbmRzIFRleHR1cmVSZW5kZXIge1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7dHlwZTpjYy5TcHJpdGUgLCB0b29sdGlwOlwi6IOM5pmvXCJ9KVxyXG4gICAgYmc6IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHt0eXBlOmNjLlNwcml0ZSAsIHRvb2x0aXA6XCLpobnpk75cIn0pXHJcbiAgICB4aWFuZ2xpYW46IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHt0eXBlOmNjLlNwcml0ZSAsIHRvb2x0aXA6XCLooaPmnI1cIn0pXHJcbiAgICB5aWZ1OiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7dHlwZTpjYy5TcHJpdGUgLCB0b29sdGlwOlwi5aS05Y+RXCJ9KVxyXG4gICAgdG91ZmE6IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHt0eXBlOmNjLlNwcml0ZSAsIHRvb2x0aXA6XCLlmLRcIn0pXHJcbiAgICB6dWk6IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHt0eXBlOmNjLlNwcml0ZSAsIHRvb2x0aXA6XCLpvLvlrZBcIn0pXHJcbiAgICBiaXppOiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7dHlwZTpjYy5TcHJpdGUgLCB0b29sdGlwOlwi55y8552bXCJ9KVxyXG4gICAgeWFuOiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7dHlwZTpjYy5TcHJpdGUgLCB0b29sdGlwOlwi5oql57q4XCJ9KVxyXG4gICAgYmFvemhpOiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7dHlwZTpjYy5TcHJpdGUgLCB0b29sdGlwOlwi5Y+z5omLXCJ9KVxyXG4gICAgeW91c2hvdTogY2MuU3ByaXRlID0gbnVsbDtcclxuXHJcbiAgICBwcml2YXRlIG5mZUlkID0gXCJcIjtcclxuICAgIHByaXZhdGUgbmZlSWRBcnIgPSBbXTtcclxuICAgIHByaXZhdGUgY3VycmVudE51bTpudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSByZXBlYXROdW06bnVtYmVyID0gMDtcclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIC8vIGNjLnZpZXcuZW5hYmxlUmV0aW5hKHRydWUpXHJcbiAgICAgICAgLy8gY2Mudmlldy5lbmFibGVBbnRpQWxpYXMoZmFsc2UpO1xyXG4gICAgICAgIHZhciBkYXRhID0ge1xyXG4gICAgICAgICAgICBsaXN0OltdLFxyXG4gICAgICAgICAgICBudW06MCxcclxuICAgICAgICAgICAgcmVwZWF0OjBcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibmZ0SURcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG5cclxuICAgICAgICB2YXIgaWRMaXN0ID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJuZnRJRFwiKSk7XHJcbiAgICAgICAgaWYoaWRMaXN0ICYmIGlkTGlzdC5saXN0Lmxlbmd0aCA+IDApe1xyXG4gICAgICAgICAgICB0aGlzLm5mZUlkQXJyID0gaWRMaXN0Lmxpc3Q7XHJcbiAgICAgICAgICAgIHRoaXMuY3VycmVudE51bSA9IGlkTGlzdC5udW07XHJcbiAgICAgICAgICAgIHRoaXMucmVwZWF0TnVtID0gaWRMaXN0LnJlcGVhdDtcclxuICAgICAgICAgICAgdGhpcy5maWxlTnVtID0gaWRMaXN0Lm51bVxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZyhpZExpc3QsdGhpcy5maWxlTnVtKTtcclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIC8vIHZhciBzID0gdGhpcy5uZmVJZEFyci5qb2luKFwiLFwiKStcIixcIjtcclxuICAgICAgICAvLyAvLyBjb25zb2xlLmxvZyhzICwgXCLov5nkuKrmmK9cIik7XHJcbiAgICAgICAgLy8gdmFyIGFyciA9IFsxLDMsNSw3NiwxNTYsOSwzXVxyXG4gICAgICAgIC8vIGZvcih2YXIgaT0wO2k8dGhpcy5uZmVJZEFyci5sZW5ndGg7aSsrKSB7XHJcbiAgICAgICAgLy8gICAgIGlmKHMucmVwbGFjZSh0aGlzLm5mZUlkQXJyW2ldK1wiLFwiLFwiXCIpLmluZGV4T2YodGhpcy5uZmVJZEFycltpXStcIixcIik+LTEpIHtcclxuICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwi5pWw57uE5Lit5pyJ6YeN5aSN5YWD57Sg77yaXCIgKyB0aGlzLm5mZUlkQXJyW2ldKTtcclxuICAgICAgICAvLyAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyB2YXIgaXNCb2wgPSB0aGlzLmlzUmVwZWF0KHRoaXMubmZlSWRBcnIpO1xyXG5cclxuXHJcbiAgICAgICAgbGV0IHcgPSB3aW5kb3cgYXMgYW55O1xyXG4gICAgICAgIGlmKHcuZXRoZXJldW0uaXNUb2tlblBvY2tldCl7XHJcbiAgIFxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBpc1JlcGVhdChhcnIpe1xyXG4gICAgICAgIHZhciBoYXNoID0ge307XHJcbiAgICAgICAgZm9yKHZhciBpIGluIGFycikge1xyXG4gICAgICAgICAgIGlmKGhhc2hbYXJyW2ldXSlcclxuICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgIGhhc2hbYXJyW2ldXSA9IHRydWU7XHJcbiAgICAgICB9XHJcbiAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgfVxyXG4gICAgb25jbGlja0luaXQoKSB7XHJcbiAgICAgICAgdGhpcy5pbml0KCk7XHJcbiAgICAgICAgLy8gY3JlYXRlIGNhcHR1cmVcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdGhpcy5jcmVhdGVDYW52YXMoKTtcclxuICAgICAgICB2YXIgaW1nID0gdGhpcy5jcmVhdGVJbWcoKTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5zaG9lSW1nU3JjID0gaW1nLnNyYztcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSgoKSA9PiB7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaT0wO2k8dGhpcy5uZmVJZEFyci5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgICAgIGlmKHRoaXMubmZlSWRBcnJbaV0gPT0gdGhpcy5uZmVJZCl7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5uZmVJZEFycltpXSAsIHRoaXMubmZlSWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwZWF0TnVtKys7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLm5mZUlkQXJyLnB1c2godGhpcy5uZmVJZCk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMuc2hvd0ltYWdlKGltZyk7XHJcbiAgICAgICAgICAgIHRoaXMuZG93bmxvYWRJbWcoKTtcclxuICAgICAgICAgICAgdmFyIGRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICBsaXN0OnRoaXMubmZlSWRBcnIsXHJcbiAgICAgICAgICAgICAgICBudW06dGhpcy5maWxlTnVtLFxyXG4gICAgICAgICAgICAgICAgcmVwZWF0OnRoaXMucmVwZWF0TnVtLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIm5mdElEXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfSwgMSk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuY2xpY2tTcGVjaWZ5U2hvZSgpO1xyXG4gICAgfVxyXG4gICAgLy/nlJ/miJDmjIflrprpnovlrZBcclxuICAgIGNsaWNrU3BlY2lmeVNob2UoKXtcclxuICAgICAgICAvLzE1NjkgIFxyXG4gICAgICAgIGZvcih2YXIgaT0wO2k8MjIwMDtpKyspe1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSgoKT0+e1xyXG4gICAgICAgICAgICAgICAgdGhpcy5uZmVJZCA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldFNob2VQYXJ0SW1nKHRoaXMucmFuZE51bSgwLDQpLHRoaXMuYmcsXCIwMFwiLFwiYmdcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldFNob2VQYXJ0SW1nKHRoaXMucmFuZE51bSgwLDMpLHRoaXMueGlhbmdsaWFuLFwiMDFcIixcInhpYW5nbGlhblwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ2V0U2hvZVBhcnRJbWcodGhpcy5yYW5kTnVtKDAsMyksdGhpcy55aWZ1LFwiMDJcIixcInlpZnVcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXRTaG9lUGFydEltZyh0aGlzLnJhbmROdW0oMCwzKSx0aGlzLnRvdWZhLFwiMDNcIixcInRvdWZhXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXRTaG9lUGFydEltZyh0aGlzLnJhbmROdW0oMCwzKSx0aGlzLnp1aSxcIjA0XCIsXCJ6dWlcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldFNob2VQYXJ0SW1nKHRoaXMucmFuZE51bSgwLDMpLHRoaXMuYml6aSxcIjA1XCIsXCJiaXppXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuZ2V0U2hvZVBhcnRJbWcodGhpcy5yYW5kTnVtKDAsMyksdGhpcy55YW4sXCIwNlwiLFwieWFuXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXRTaG9lUGFydEltZyh0aGlzLnJhbmROdW0oMCwzKSx0aGlzLmJhb3poaSxcIjA3XCIsXCJiYW96aGlcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldFNob2VQYXJ0SW1nKHRoaXMucmFuZE51bSgwLDMpLHRoaXMueW91c2hvdSxcIjA4XCIsXCJ5b3VzaG91XCIpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0saSoyLjUpXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpPT57XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uY2xpY2tJbml0KClcclxuICAgICAgICAgICAgfSxpKjMuNSlcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvL+iOt+WPlumaj+acuuaVsFxyXG4gICAgcmFuZE51bShtLG4pe1xyXG4gICAgICAgIHZhciBudW0gPSBwYXJzZUludChNYXRoLnJhbmRvbSgpKihuIC0gbSArMSkrbSk7XHJcbiAgICAgICAgLy8gbnVtID49IDEwID8gbnVtIDogXCIwXCIgKyBudW1cclxuICAgICAgICByZXR1cm4gKG51bSkudG9TdHJpbmcoKTtcclxuICAgIH1cclxuICAgIGdldFNob2VQYXJ0SW1nKHJhbmQsc3ByLHBvcyxmaWxlKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICB0aGlzLm5mZUlkICs9IFwiMFwiK3JhbmQ7IFxyXG4gICAgICAgIGNjLnJlc291cmNlcy5sb2FkKGZpbGUrXCIvXCIrcmFuZCwgY2MuU3ByaXRlRnJhbWUsIGZ1bmN0aW9uIChlcnIsIHNwcml0ZUZyYW1lKSB7XHJcbiAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIC8vIHNwci5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIHNwci5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHNwci5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==