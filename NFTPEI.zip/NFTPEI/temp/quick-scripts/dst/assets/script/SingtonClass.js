
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/SingtonClass.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6d4058WM2JMRJh2C/oaeBHq', 'SingtonClass');
// script/SingtonClass.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SingtonClass = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SingtonClass = /** @class */ (function () {
    function SingtonClass() {
    }
    /**
     * 获取一个单例
     * @returns {any}
     */
    SingtonClass.getSingtonInstance = function () {
        var param = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            param[_i] = arguments[_i];
        }
        var Class = this;
        if (!Class._instance) {
            Class._instance = new (Class.bind.apply(Class, __spreadArrays([void 0], param)))();
        }
        return Class._instance;
    };
    SingtonClass = __decorate([
        ccclass('SingtonClass')
    ], SingtonClass);
    return SingtonClass;
}());
exports.SingtonClass = SingtonClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxTaW5ndG9uQ2xhc3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQ0k7SUFFQSxDQUFDO0lBQ0Q7OztPQUdHO0lBQ1ksK0JBQWtCLEdBQWhDO1FBQWlDLGVBQWU7YUFBZixVQUFlLEVBQWYscUJBQWUsRUFBZixJQUFlO1lBQWYsMEJBQWU7O1FBQzdDLElBQUksS0FBSyxHQUFRLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRTtZQUNsQixLQUFLLENBQUMsU0FBUyxRQUFPLEtBQUssWUFBTCxLQUFLLDJCQUFJLEtBQUssS0FBQyxDQUFDO1NBQ3pDO1FBQ0QsT0FBTyxLQUFLLENBQUMsU0FBUyxDQUFDO0lBQzNCLENBQUM7SUFkUSxZQUFZO1FBRHhCLE9BQU8sQ0FBQyxjQUFjLENBQUM7T0FDWCxZQUFZLENBZXhCO0lBQUQsbUJBQUM7Q0FmRCxBQWVDLElBQUE7QUFmWSxvQ0FBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ1Npbmd0b25DbGFzcycpXHJcbmV4cG9ydCBjbGFzcyBTaW5ndG9uQ2xhc3N7XHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IoKSB7XHJcblxyXG4gICAgfVxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5bkuIDkuKrljZXkvotcclxuICAgICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICAgKi9cclxuICAgICBwdWJsaWMgc3RhdGljIGdldFNpbmd0b25JbnN0YW5jZSguLi5wYXJhbTogYW55W10pOiBhbnkge1xyXG4gICAgICAgIGxldCBDbGFzczogYW55ID0gdGhpcztcclxuICAgICAgICBpZiAoIUNsYXNzLl9pbnN0YW5jZSkge1xyXG4gICAgICAgICAgICBDbGFzcy5faW5zdGFuY2UgPSBuZXcgQ2xhc3MoLi4ucGFyYW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gQ2xhc3MuX2luc3RhbmNlO1xyXG4gICAgfSBcclxufVxyXG4iXX0=