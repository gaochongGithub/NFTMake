
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/App.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f3521WIyRdLTJyxAyzqcAVg', 'App');
// script/App.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.App = void 0;
var Base64_1 = require("./Base64");
var ContractCall_1 = require("./ContractCall");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var App = /** @class */ (function () {
    function App() {
    }
    Object.defineProperty(App, "ContractCall", {
        /**
       *获取合约
       */
        get: function () {
            return ContractCall_1.default.getSingtonInstance();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(App, "Base64", {
        /**
        *Base64解码
        */
        get: function () {
            return Base64_1.Base64.getSingtonInstance();
        },
        enumerable: false,
        configurable: true
    });
    App = __decorate([
        ccclass('App')
    ], App);
    return App;
}());
exports.App = App;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxBcHAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsbUNBQWtDO0FBQ2xDLCtDQUEwQztBQUNwQyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUs1QztJQUFBO0lBZUEsQ0FBQztJQVhDLHNCQUFrQixtQkFBWTtRQUg5Qjs7U0FFQzthQUNEO1lBQ0UsT0FBTyxzQkFBWSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDM0MsQ0FBQzs7O09BQUE7SUFLRCxzQkFBa0IsYUFBTTtRQUh4Qjs7VUFFRTthQUNGO1lBQ0UsT0FBTyxlQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUNyQyxDQUFDOzs7T0FBQTtJQWJVLEdBQUc7UUFEZixPQUFPLENBQUMsS0FBSyxDQUFDO09BQ0YsR0FBRyxDQWVmO0lBQUQsVUFBQztDQWZELEFBZUMsSUFBQTtBQWZZLGtCQUFHIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IEJhc2U2NCB9IGZyb20gJy4vQmFzZTY0JztcclxuaW1wb3J0IENvbnRyYWN0Q2FsbCBmcm9tICcuL0NvbnRyYWN0Q2FsbCc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcbmV4cG9ydCBpbnRlcmZhY2UgTXlPYmplY3Qge1xyXG4gIFtrZXk6IHN0cmluZ106IGFueVxyXG59XHJcbkBjY2NsYXNzKCdBcHAnKVxyXG5leHBvcnQgY2xhc3MgQXBwIHtcclxuICAvKipcclxuICrojrflj5blkIjnuqZcclxuICovXHJcbiAgcHVibGljIHN0YXRpYyBnZXQgQ29udHJhY3RDYWxsKCk6IENvbnRyYWN0Q2FsbCB7XHJcbiAgICByZXR1cm4gQ29udHJhY3RDYWxsLmdldFNpbmd0b25JbnN0YW5jZSgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgKkJhc2U2NOino+eggVxyXG4gICovXHJcbiAgcHVibGljIHN0YXRpYyBnZXQgQmFzZTY0KCk6IEJhc2U2NCB7XHJcbiAgICByZXR1cm4gQmFzZTY0LmdldFNpbmd0b25JbnN0YW5jZSgpO1xyXG4gIH1cclxuICBcclxufVxyXG4iXX0=