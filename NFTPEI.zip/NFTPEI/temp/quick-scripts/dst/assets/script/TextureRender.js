
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/TextureRender.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '735c8m8F55N0rNIVzD6+UVy', 'TextureRender');
// script/TextureRender.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TextureRender = /** @class */ (function (_super) {
    __extends(TextureRender, _super);
    function TextureRender() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.camera = null;
        _this.fileName = 0;
        _this.fileNum = 0;
        return _this;
        // init() {
        //     let texture = new cc.RenderTexture();
        //     // let gl = cc.game._renderContext;
        //     texture.initWithSize(600, 600,cc.gfx.RB_FMT_S8);
        //     this.camera = this.node.addComponent(cc.Camera);
        //     this.camera.targetTexture = texture;
        //     this.texture = texture;
        // }
        // // create the img element
        // createImg() {
        //     // return the type and dataUrl
        //     var dataURL = this._canvas.toDataURL("image/png");
        //     var img = document.createElement("img");
        //     img.src = dataURL;
        //     return img;
        // }
        // // create the canvas and context, filpY the image Data
        // createCanvas() {
        //     let width = this.texture.width;
        //     let height = this.texture.height;
        //     if (!this._canvas) {
        //         this._canvas = document.createElement('canvas');
        //         this._canvas.width = width;
        //         this._canvas.height = height;
        //     } else {
        //         this.clearCanvas();
        //     }
        //     let ctx = this._canvas.getContext('2d');
        //     this.camera.render();
        //     let data = this.texture.readPixels();
        //     // write the render data
        //     let rowBytes = width * 4;
        //     for (let row = 0; row < height; row++) {
        //         let srow = height - 1 - row;
        //         let imageData = ctx.createImageData(width, 1);
        //         let start = srow * width * 4;
        //         for (let i = 0; i < rowBytes; i++) {
        //             imageData.data[i] = data[start + i];
        //         }
        //         ctx.putImageData(imageData, 0, row);
        //     }
        //     return this._canvas;
        // }
        // getTargetArea() {
        //     let targetPos = this.targetNode.convertToWorldSpaceAR(cc.v2(0, 0))
        //     let y = cc.winSize.height - targetPos.y - this.targetNode.height / 2;
        //     let x = cc.winSize.width - targetPos.x - this.targetNode.width / 2;
        //     return {
        //         x,
        //         y
        //     }
        // }
        // // show on the canvas
        // showImage(img) {
        //     let y = this.getTargetArea().y;
        //     let x = this.getTargetArea().x;
        //     // let rect = new cc.Rect(750, 80, 1334, 750)
        //     let texture = new cc.Texture2D();
        //     texture.initWithElement(img);
        //     let spriteFrame = new cc.SpriteFrame();
        //     spriteFrame.setTexture(texture);
        //     // spriteFrame.setRect(rect)
        //     let node = new cc.Node();
        //     let sprite = node.addComponent(cc.Sprite);
        //     sprite.spriteFrame = spriteFrame;
        //     node.zIndex = cc.macro.MAX_ZINDEX;
        //     node.parent = cc.director.getScene();
        //     // set position
        //     let width = cc.winSize.width;
        //     let height = cc.winSize.height;
        //     node.x = width / 2;
        //     node.y = height / 2;
        //     node.on(cc.Node.EventType.TOUCH_START, () => {
        //         node.parent = null;
        //         node.destroy();
        //     });
        //     // this.captureAction(node, width, height);
        // }
        // // sprite action
        // captureAction(capture, width, height) {
        //     let scaleAction = cc.scaleTo(1, 0.3);
        //     let targetPos = cc.v2(width - width / 6, height / 4);
        //     let moveAction = cc.moveTo(1, targetPos);
        //     let spawn = cc.spawn(scaleAction, moveAction);
        //     let finished = cc.callFunc(() => {
        //         capture.destroy();
        //     })
        //     let action = cc.sequence(spawn, finished);
        //     capture.runAction(action);
        // }
        // clearCanvas() {
        //     let ctx = this._canvas.getContext('2d');
        //     ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
        // }
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    TextureRender.prototype.start = function () {
    };
    TextureRender.prototype.init = function () {
        var texture = new cc.RenderTexture();
        texture.initWithSize(1000, 1000, cc.gfx.RB_FMT_S8);
        // this.camera.alignWithScreen = false;
        this.camera.targetTexture = texture;
        this.texture = texture;
    };
    TextureRender.prototype.createImg = function () {
        var dataURL = this._canvas.toDataURL("image/png");
        var img = document.createElement("img");
        img.src = dataURL;
        return img;
    };
    // create the canvas and context, filpY the image Data
    TextureRender.prototype.createCanvas = function () {
        var width = this.texture.width;
        var height = this.texture.height;
        if (!this._canvas) {
            this._canvas = document.createElement('canvas');
            this._canvas.width = width;
            this._canvas.height = height;
        }
        else {
            this.clearCanvas();
        }
        var ctx = this._canvas.getContext('2d');
        this.camera.render();
        var data = this.texture.readPixels();
        // write the render data
        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = height - 1 - row;
            var imageData = ctx.createImageData(width, 1);
            var start = srow * width * 4;
            for (var i = 0; i < rowBytes; i++) {
                imageData.data[i] = data[start + i];
            }
            ctx.putImageData(imageData, 0, row);
        }
        return this._canvas;
    };
    TextureRender.prototype.clearCanvas = function () {
        var ctx = this._canvas.getContext('2d');
        ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
    };
    // show on the canvas
    TextureRender.prototype.showImage = function (img) {
        var texture = new cc.Texture2D();
        texture.initWithElement(img);
        // let rect = new cc.Rect(0 , 0 , 600, 600)
        var spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture);
        var node = new cc.Node();
        var sprite = node.addComponent(cc.Sprite);
        sprite.spriteFrame = spriteFrame;
        // spriteFrame.setRect(rect);
        // this.shoeSpr.spriteFrame = spriteFrame;
        // this.shoeSpr.targetPos = cc.v2(0,0);
        node.zIndex = cc.macro.MAX_ZINDEX;
        node.parent = cc.director.getScene();
        var width = cc.winSize.width;
        var height = cc.winSize.height;
        node.x = width / 4;
        node.y = height / 2;
        node.on(cc.Node.EventType.TOUCH_START, function () {
            node.parent = null;
            node.destroy();
        });
        // this.captureAction(node, width, height);
        //9771,9000,09771
    };
    TextureRender.prototype.downloadImg = function () {
        this.createImg();
        var img = this.init();
        this.showImage(img);
        var dataURL = this._canvas.toDataURL("image/png");
        var a = document.createElement("a");
        a.href = dataURL;
        if (this.fileNum < 10) {
            this.fileName = "000" + this.fileNum;
        }
        else if (this.fileNum >= 10 && this.fileNum < 100) {
            this.fileName = "00" + this.fileNum;
        }
        else if (this.fileNum >= 100 && this.fileNum < 1000) {
            this.fileName = "0" + this.fileNum;
        }
        else if (this.fileNum >= 1000) {
            this.fileName = this.fileNum;
        }
        this.fileNum++;
        a.download = this.fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };
    TextureRender.catpureNodeForNative = function (node, imageType, imageName) {
        if (imageType === void 0) { imageType = ".png"; }
        if (imageName === void 0) { imageName = "Image"; }
        var camera = node.addComponent(cc.Camera);
        // 由于渲染问题，需要调整垂直翻转
        node.scaleY *= -1;
        // 设置你想要的截图内容的 cullingMask
        // camera.cullingMask = 0xffffffff;
        // 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
        var texture = new cc.RenderTexture();
        var gl = cc.game["_renderContext"];
        // 如果截图内容中不包含 Mask 组件，可以不用传递第三个参数
        var winSize = cc.winSize;
        texture.initWithSize.call(texture, 1000, 1000, imageType == ".png" ? gl.STENCIL_INDEX8 : null);
        // texture.setFlipY(true);
        camera.targetTexture = texture;
        // 渲染一次摄像机，即更新一次内容到 RenderTexture 中
        camera.render(node);
        // 这样我们就能从 RenderTexture 中获取到数据了
        // 获取指定像素的点信息(2.2.0以后改变了相机的渲染方式，需要调整)
        var size = node.getContentSize();
        var pixels = new Uint8Array(size.width * size.height * 4);
        var x = texture.width / 2 - size.width / 2;
        var y = texture.height / 2 - size.height / 2;
        var w = size.width;
        var h = size.height;
        var data = texture.readPixels(pixels, x, y, w, h);
        //存储所截图片
        console.log("路径：", jsb.fileUtils.getWritablePath());
        var filePath = jsb.fileUtils.getWritablePath() + imageName + imageType;
        var success = jsb['saveImageData'](data, size.width, size.height, filePath);
        if (success) {
            return filePath;
        }
        else
            return null;
    };
    __decorate([
        property(cc.Camera)
    ], TextureRender.prototype, "camera", void 0);
    TextureRender = __decorate([
        ccclass
    ], TextureRender);
    return TextureRender;
}(cc.Component));
exports.default = TextureRender;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxUZXh0dXJlUmVuZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTVFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQTJDLGlDQUFZO0lBQXZEO1FBQUEscUVBdVNDO1FBcFNHLFlBQU0sR0FBYyxJQUFJLENBQUM7UUFPbEIsY0FBUSxHQUFPLENBQUMsQ0FBQztRQUNqQixhQUFPLEdBQVUsQ0FBQyxDQUFDOztRQXNMMUIsV0FBVztRQUNYLDRDQUE0QztRQUM1QywwQ0FBMEM7UUFDMUMsdURBQXVEO1FBQ3ZELHVEQUF1RDtRQUN2RCwyQ0FBMkM7UUFDM0MsOEJBQThCO1FBQzlCLElBQUk7UUFDSiw0QkFBNEI7UUFDNUIsZ0JBQWdCO1FBQ2hCLHFDQUFxQztRQUNyQyx5REFBeUQ7UUFDekQsK0NBQStDO1FBQy9DLHlCQUF5QjtRQUN6QixrQkFBa0I7UUFDbEIsSUFBSTtRQUNKLHlEQUF5RDtRQUN6RCxtQkFBbUI7UUFDbkIsc0NBQXNDO1FBQ3RDLHdDQUF3QztRQUN4QywyQkFBMkI7UUFDM0IsMkRBQTJEO1FBQzNELHNDQUFzQztRQUN0Qyx3Q0FBd0M7UUFDeEMsZUFBZTtRQUNmLDhCQUE4QjtRQUM5QixRQUFRO1FBQ1IsK0NBQStDO1FBQy9DLDRCQUE0QjtRQUM1Qiw0Q0FBNEM7UUFDNUMsK0JBQStCO1FBQy9CLGdDQUFnQztRQUNoQywrQ0FBK0M7UUFDL0MsdUNBQXVDO1FBQ3ZDLHlEQUF5RDtRQUN6RCx3Q0FBd0M7UUFDeEMsK0NBQStDO1FBQy9DLG1EQUFtRDtRQUNuRCxZQUFZO1FBRVosK0NBQStDO1FBQy9DLFFBQVE7UUFDUiwyQkFBMkI7UUFDM0IsSUFBSTtRQUNKLG9CQUFvQjtRQUNwQix5RUFBeUU7UUFDekUsNEVBQTRFO1FBQzVFLDBFQUEwRTtRQUMxRSxlQUFlO1FBQ2YsYUFBYTtRQUNiLFlBQVk7UUFDWixRQUFRO1FBQ1IsSUFBSTtRQUVKLHdCQUF3QjtRQUN4QixtQkFBbUI7UUFDbkIsc0NBQXNDO1FBQ3RDLHNDQUFzQztRQUN0QyxvREFBb0Q7UUFDcEQsd0NBQXdDO1FBQ3hDLG9DQUFvQztRQUVwQyw4Q0FBOEM7UUFDOUMsdUNBQXVDO1FBQ3ZDLG1DQUFtQztRQUVuQyxnQ0FBZ0M7UUFDaEMsaURBQWlEO1FBQ2pELHdDQUF3QztRQUV4Qyx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLHNCQUFzQjtRQUN0QixvQ0FBb0M7UUFDcEMsc0NBQXNDO1FBQ3RDLDBCQUEwQjtRQUMxQiwyQkFBMkI7UUFDM0IscURBQXFEO1FBQ3JELDhCQUE4QjtRQUM5QiwwQkFBMEI7UUFDMUIsVUFBVTtRQUNWLGtEQUFrRDtRQUNsRCxJQUFJO1FBQ0osbUJBQW1CO1FBQ25CLDBDQUEwQztRQUMxQyw0Q0FBNEM7UUFDNUMsNERBQTREO1FBQzVELGdEQUFnRDtRQUNoRCxxREFBcUQ7UUFFckQseUNBQXlDO1FBQ3pDLDZCQUE2QjtRQUM3QixTQUFTO1FBQ1QsaURBQWlEO1FBQ2pELGlDQUFpQztRQUNqQyxJQUFJO1FBRUosa0JBQWtCO1FBQ2xCLCtDQUErQztRQUMvQyxvRUFBb0U7UUFDcEUsSUFBSTtJQUVSLENBQUM7SUEzUkcsd0JBQXdCO0lBRXhCLGVBQWU7SUFFZiw2QkFBSyxHQUFMO0lBRUEsQ0FBQztJQUNELDRCQUFJLEdBQUo7UUFDSSxJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNuRCx1Q0FBdUM7UUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0lBQzNCLENBQUM7SUFHRCxpQ0FBUyxHQUFUO1FBQ0ksSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxHQUFHLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQztRQUVsQixPQUFPLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFDRCxzREFBc0Q7SUFDdEQsb0NBQVksR0FBWjtRQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQy9CLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7U0FDaEM7YUFDSTtZQUNELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjtRQUNELElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDckIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNyQyx3QkFBd0I7UUFDeEIsSUFBSSxRQUFRLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUN6QixLQUFLLElBQUksR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQ25DLElBQUksSUFBSSxHQUFHLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO1lBQzVCLElBQUksU0FBUyxHQUFHLEdBQUcsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlDLElBQUksS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQy9CLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQzthQUN2QztZQUVELEdBQUcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUN2QztRQUNELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN4QixDQUFDO0lBRUQsbUNBQVcsR0FBWDtRQUNJLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxxQkFBcUI7SUFDckIsaUNBQVMsR0FBVCxVQUFXLEdBQUc7UUFDVixJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQyxPQUFPLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLDJDQUEyQztRQUMzQyxJQUFJLFdBQVcsR0FBRyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN2QyxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWhDLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3pCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFDLE1BQU0sQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBQ2pDLDZCQUE2QjtRQUM3QiwwQ0FBMEM7UUFDMUMsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDbEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3JDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQzdCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1FBRy9CLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDcEIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUU7WUFDbkMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7WUFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ25CLENBQUMsQ0FBQyxDQUFDO1FBRUgsMkNBQTJDO1FBRTNDLGlCQUFpQjtJQUVyQixDQUFDO0lBQ0QsbUNBQVcsR0FBWDtRQUNJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNuQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQTtRQUNqRCxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ25DLENBQUMsQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDO1FBRWpCLElBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLEVBQUM7WUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUN0QzthQUFLLElBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEVBQUM7WUFDOUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUNyQzthQUFLLElBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLEVBQUM7WUFDaEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUNwQzthQUFLLElBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUM7WUFDMUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2YsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQzNCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNWLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDYSxrQ0FBb0IsR0FBbEMsVUFBbUMsSUFBYSxFQUFFLFNBQWtCLEVBQUUsU0FBbUI7UUFBdkMsMEJBQUEsRUFBQSxrQkFBa0I7UUFBRSwwQkFBQSxFQUFBLG1CQUFtQjtRQUVyRixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUxQyxrQkFBa0I7UUFFbEIsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztRQUVsQiwwQkFBMEI7UUFFMUIsbUNBQW1DO1FBRW5DLDJHQUEyRztRQUUzRyxJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFbkMsaUNBQWlDO1FBRWpDLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFFekIsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFL0YsMEJBQTBCO1FBRTFCLE1BQU0sQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDO1FBRS9CLG1DQUFtQztRQUVuQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXBCLGdDQUFnQztRQUVoQyxxQ0FBcUM7UUFFckMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRWpDLElBQUksTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUUzQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUU3QyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRW5CLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFcEIsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFbEQsUUFBUTtRQUVSLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUVwRCxJQUFJLFFBQVEsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxHQUFHLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFFdkUsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFNUUsSUFBSSxPQUFPLEVBQUU7WUFFYixPQUFPLFFBQVEsQ0FBQztTQUVmOztZQUlELE9BQU8sSUFBSSxDQUFDO0lBRVosQ0FBQztJQTdMTDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO2lEQUNLO0lBSFIsYUFBYTtRQURqQyxPQUFPO09BQ2EsYUFBYSxDQXVTakM7SUFBRCxvQkFBQztDQXZTRCxBQXVTQyxDQXZTMEMsRUFBRSxDQUFDLFNBQVMsR0F1U3REO2tCQXZTb0IsYUFBYSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dHVyZVJlbmRlciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkNhbWVyYSlcclxuICAgIGNhbWVyYTogY2MuQ2FtZXJhID0gbnVsbDtcclxuXHJcbiAgICAvLyBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIC8vIHRhcmdldE5vZGU6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgXHJcbiAgICBfY2FudmFzOmFueTtcclxuICAgIHRleHR1cmU6YW55O1xyXG4gICAgcHVibGljIGZpbGVOYW1lOmFueSA9IDA7XHJcbiAgICBwdWJsaWMgZmlsZU51bTpudW1iZXIgPSAwO1xyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgaW5pdCAoKSB7XHJcbiAgICAgICAgbGV0IHRleHR1cmUgPSBuZXcgY2MuUmVuZGVyVGV4dHVyZSgpO1xyXG4gICAgICAgIHRleHR1cmUuaW5pdFdpdGhTaXplKDEwMDAsIDEwMDAsIGNjLmdmeC5SQl9GTVRfUzgpO1xyXG4gICAgICAgIC8vIHRoaXMuY2FtZXJhLmFsaWduV2l0aFNjcmVlbiA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLnRhcmdldFRleHR1cmUgPSB0ZXh0dXJlO1xyXG4gICAgICAgIHRoaXMudGV4dHVyZSA9IHRleHR1cmU7XHJcbiAgICB9XHJcblxyXG4gICBcclxuICAgIGNyZWF0ZUltZyAoKSB7XHJcbiAgICAgICAgdmFyIGRhdGFVUkwgPSB0aGlzLl9jYW52YXMudG9EYXRhVVJMKFwiaW1hZ2UvcG5nXCIpO1xyXG4gICAgICAgIHZhciBpbWcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpO1xyXG4gICAgICAgIGltZy5zcmMgPSBkYXRhVVJMO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBpbWc7XHJcbiAgICB9XHJcbiAgICAvLyBjcmVhdGUgdGhlIGNhbnZhcyBhbmQgY29udGV4dCwgZmlscFkgdGhlIGltYWdlIERhdGFcclxuICAgIGNyZWF0ZUNhbnZhcyAoKSB7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy50ZXh0dXJlLndpZHRoO1xyXG4gICAgICAgIGxldCBoZWlnaHQgPSB0aGlzLnRleHR1cmUuaGVpZ2h0O1xyXG4gICAgICAgIGlmICghdGhpcy5fY2FudmFzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xyXG4gICAgICAgICAgICB0aGlzLl9jYW52YXMud2lkdGggPSB3aWR0aDtcclxuICAgICAgICAgICAgdGhpcy5fY2FudmFzLmhlaWdodCA9IGhlaWdodDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2xlYXJDYW52YXMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGN0eCA9IHRoaXMuX2NhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLnJlbmRlcigpO1xyXG4gICAgICAgIGxldCBkYXRhID0gdGhpcy50ZXh0dXJlLnJlYWRQaXhlbHMoKTtcclxuICAgICAgICAvLyB3cml0ZSB0aGUgcmVuZGVyIGRhdGFcclxuICAgICAgICBsZXQgcm93Qnl0ZXMgPSB3aWR0aCAqIDQ7IFxyXG4gICAgICAgIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8IGhlaWdodDsgcm93KyspIHtcclxuICAgICAgICAgICAgbGV0IHNyb3cgPSBoZWlnaHQgLSAxIC0gcm93O1xyXG4gICAgICAgICAgICBsZXQgaW1hZ2VEYXRhID0gY3R4LmNyZWF0ZUltYWdlRGF0YSh3aWR0aCwgMSk7XHJcbiAgICAgICAgICAgIGxldCBzdGFydCA9IHNyb3cgKiB3aWR0aCAqIDQ7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcm93Qnl0ZXM7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaW1hZ2VEYXRhLmRhdGFbaV0gPSBkYXRhW3N0YXJ0ICsgaV07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGN0eC5wdXRJbWFnZURhdGEoaW1hZ2VEYXRhLCAwLCByb3cpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FudmFzO1xyXG4gICAgfVxyXG5cclxuICAgIGNsZWFyQ2FudmFzICgpIHtcclxuICAgICAgICBsZXQgY3R4ID0gdGhpcy5fY2FudmFzLmdldENvbnRleHQoJzJkJyk7XHJcbiAgICAgICAgY3R4LmNsZWFyUmVjdCgwLCAwLCB0aGlzLl9jYW52YXMud2lkdGgsIHRoaXMuX2NhbnZhcy5oZWlnaHQpO1xyXG4gICAgfVxyXG4gICAgLy8gc2hvdyBvbiB0aGUgY2FudmFzXHJcbiAgICBzaG93SW1hZ2UgKGltZykge1xyXG4gICAgICAgIGxldCB0ZXh0dXJlID0gbmV3IGNjLlRleHR1cmUyRCgpO1xyXG4gICAgICAgIHRleHR1cmUuaW5pdFdpdGhFbGVtZW50KGltZyk7XHJcbiAgICAgICAgLy8gbGV0IHJlY3QgPSBuZXcgY2MuUmVjdCgwICwgMCAsIDYwMCwgNjAwKVxyXG4gICAgICAgIGxldCBzcHJpdGVGcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSgpO1xyXG4gICAgICAgIHNwcml0ZUZyYW1lLnNldFRleHR1cmUodGV4dHVyZSk7XHJcblxyXG4gICAgICAgIGxldCBub2RlID0gbmV3IGNjLk5vZGUoKTtcclxuICAgICAgICBsZXQgc3ByaXRlID0gbm9kZS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcclxuICAgICAgICAvLyBzcHJpdGVGcmFtZS5zZXRSZWN0KHJlY3QpO1xyXG4gICAgICAgIC8vIHRoaXMuc2hvZVNwci5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xyXG4gICAgICAgIC8vIHRoaXMuc2hvZVNwci50YXJnZXRQb3MgPSBjYy52MigwLDApO1xyXG4gICAgICAgIG5vZGUuekluZGV4ID0gY2MubWFjcm8uTUFYX1pJTkRFWDtcclxuICAgICAgICBub2RlLnBhcmVudCA9IGNjLmRpcmVjdG9yLmdldFNjZW5lKCk7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gY2Mud2luU2l6ZS53aWR0aDtcclxuICAgICAgICBsZXQgaGVpZ2h0ID0gY2Mud2luU2l6ZS5oZWlnaHQ7XHJcblxyXG5cclxuICAgICAgICBub2RlLnggPSB3aWR0aCAvIDQ7XHJcbiAgICAgICAgbm9kZS55ID0gaGVpZ2h0IC8gMjtcclxuICAgICAgICBub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCAoKSA9PiB7XHJcbiAgICAgICAgICAgIG5vZGUucGFyZW50ID0gbnVsbDtcclxuICAgICAgICAgICAgbm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuY2FwdHVyZUFjdGlvbihub2RlLCB3aWR0aCwgaGVpZ2h0KTtcclxuXHJcbiAgICAgICAgLy85NzcxLDkwMDAsMDk3NzFcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIGRvd25sb2FkSW1nKCkge1xyXG4gICAgICAgIHRoaXMuY3JlYXRlSW1nKCk7XHJcbiAgICAgICAgdmFyIGltZyA9IHRoaXMuaW5pdCgpO1xyXG4gICAgICAgIHRoaXMuc2hvd0ltYWdlKGltZylcclxuICAgICAgICB2YXIgZGF0YVVSTCA9IHRoaXMuX2NhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIilcclxuICAgICAgICB2YXIgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpXHJcbiAgICAgICAgYS5ocmVmID0gZGF0YVVSTDtcclxuICAgICAgICBcclxuICAgICAgICBpZih0aGlzLmZpbGVOdW0gPCAxMCl7XHJcbiAgICAgICAgICAgIHRoaXMuZmlsZU5hbWUgPSBcIjAwMFwiK3RoaXMuZmlsZU51bTtcclxuICAgICAgICB9ZWxzZSBpZih0aGlzLmZpbGVOdW0gPj0gMTAgJiYgdGhpcy5maWxlTnVtIDwgMTAwKXtcclxuICAgICAgICAgICAgdGhpcy5maWxlTmFtZSA9IFwiMDBcIit0aGlzLmZpbGVOdW07XHJcbiAgICAgICAgfWVsc2UgaWYodGhpcy5maWxlTnVtID49IDEwMCAmJiB0aGlzLmZpbGVOdW0gPCAxMDAwKXtcclxuICAgICAgICAgICAgdGhpcy5maWxlTmFtZSA9IFwiMFwiK3RoaXMuZmlsZU51bTtcclxuICAgICAgICB9ZWxzZSBpZih0aGlzLmZpbGVOdW0gPj0gMTAwMCl7XHJcbiAgICAgICAgICAgIHRoaXMuZmlsZU5hbWUgPSB0aGlzLmZpbGVOdW07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZmlsZU51bSsrO1xyXG4gICAgICAgIGEuZG93bmxvYWQgPSB0aGlzLmZpbGVOYW1lO1xyXG4gICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XHJcbiAgICAgICAgYS5jbGljaygpO1xyXG4gICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGNhdHB1cmVOb2RlRm9yTmF0aXZlKG5vZGU6IGNjLk5vZGUsIGltYWdlVHlwZSA9IFwiLnBuZ1wiLCBpbWFnZU5hbWUgPSBcIkltYWdlXCIpIHtcclxuXHJcbiAgICAgICAgbGV0IGNhbWVyYSA9IG5vZGUuYWRkQ29tcG9uZW50KGNjLkNhbWVyYSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8g55Sx5LqO5riy5p+T6Zeu6aKY77yM6ZyA6KaB6LCD5pW05Z6C55u057+76L2sXHJcbiAgICAgICAgXHJcbiAgICAgICAgbm9kZS5zY2FsZVkgKj0gLTE7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8g6K6+572u5L2g5oOz6KaB55qE5oiq5Zu+5YaF5a6555qEIGN1bGxpbmdNYXNrXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gY2FtZXJhLmN1bGxpbmdNYXNrID0gMHhmZmZmZmZmZjtcclxuICAgICAgICBcclxuICAgICAgICAvLyDmlrDlu7rkuIDkuKogUmVuZGVyVGV4dHVyZe+8jOW5tuS4lOiuvue9riBjYW1lcmEg55qEIHRhcmdldFRleHR1cmUg5Li65paw5bu655qEIFJlbmRlclRleHR1cmXvvIzov5nmoLcgY2FtZXJhIOeahOWGheWuueWwhuS8mua4suafk+WIsOaWsOW7uueahCBSZW5kZXJUZXh0dXJlIOS4reOAglxyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCB0ZXh0dXJlID0gbmV3IGNjLlJlbmRlclRleHR1cmUoKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgZ2wgPSBjYy5nYW1lW1wiX3JlbmRlckNvbnRleHRcIl07XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8g5aaC5p6c5oiq5Zu+5YaF5a655Lit5LiN5YyF5ZCrIE1hc2sg57uE5Lu277yM5Y+v5Lul5LiN55So5Lyg6YCS56ys5LiJ5Liq5Y+C5pWwXHJcbiAgICAgICAgXHJcbiAgICAgICAgbGV0IHdpblNpemUgPSBjYy53aW5TaXplO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRleHR1cmUuaW5pdFdpdGhTaXplLmNhbGwodGV4dHVyZSwgMTAwMCwgMTAwMCwgaW1hZ2VUeXBlID09IFwiLnBuZ1wiID8gZ2wuU1RFTkNJTF9JTkRFWDggOiBudWxsKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyB0ZXh0dXJlLnNldEZsaXBZKHRydWUpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNhbWVyYS50YXJnZXRUZXh0dXJlID0gdGV4dHVyZTtcclxuICAgICAgICBcclxuICAgICAgICAvLyDmuLLmn5PkuIDmrKHmkYTlg4/mnLrvvIzljbPmm7TmlrDkuIDmrKHlhoXlrrnliLAgUmVuZGVyVGV4dHVyZSDkuK1cclxuICAgICAgICBcclxuICAgICAgICBjYW1lcmEucmVuZGVyKG5vZGUpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIOi/meagt+aIkeS7rOWwseiDveS7jiBSZW5kZXJUZXh0dXJlIOS4reiOt+WPluWIsOaVsOaNruS6hlxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIOiOt+WPluaMh+WumuWDj+e0oOeahOeCueS/oeaBrygyLjIuMOS7peWQjuaUueWPmOS6huebuOacuueahOa4suafk+aWueW8j++8jOmcgOimgeiwg+aVtClcclxuICAgICAgICBcclxuICAgICAgICBsZXQgc2l6ZSA9IG5vZGUuZ2V0Q29udGVudFNpemUoKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgcGl4ZWxzID0gbmV3IFVpbnQ4QXJyYXkoc2l6ZS53aWR0aCAqIHNpemUuaGVpZ2h0ICogNCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgbGV0IHggPSB0ZXh0dXJlLndpZHRoIC8gMiAtIHNpemUud2lkdGggLyAyO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCB5ID0gdGV4dHVyZS5oZWlnaHQgLyAyIC0gc2l6ZS5oZWlnaHQgLyAyO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCB3ID0gc2l6ZS53aWR0aDtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgaCA9IHNpemUuaGVpZ2h0O1xyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCBkYXRhID0gdGV4dHVyZS5yZWFkUGl4ZWxzKHBpeGVscywgeCwgeSwgdywgaCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/lrZjlgqjmiYDmiKrlm77niYdcclxuICAgICAgICBcclxuICAgICAgICBjb25zb2xlLmxvZyhcIui3r+W+hO+8mlwiLCBqc2IuZmlsZVV0aWxzLmdldFdyaXRhYmxlUGF0aCgpKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgZmlsZVBhdGggPSBqc2IuZmlsZVV0aWxzLmdldFdyaXRhYmxlUGF0aCgpICsgaW1hZ2VOYW1lICsgaW1hZ2VUeXBlO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCBzdWNjZXNzID0ganNiWydzYXZlSW1hZ2VEYXRhJ10oZGF0YSwgc2l6ZS53aWR0aCwgc2l6ZS5oZWlnaHQsIGZpbGVQYXRoKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAoc3VjY2Vzcykge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBmaWxlUGF0aDtcclxuICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIC8vIGluaXQoKSB7XHJcbiAgICAvLyAgICAgbGV0IHRleHR1cmUgPSBuZXcgY2MuUmVuZGVyVGV4dHVyZSgpO1xyXG4gICAgLy8gICAgIC8vIGxldCBnbCA9IGNjLmdhbWUuX3JlbmRlckNvbnRleHQ7XHJcbiAgICAvLyAgICAgdGV4dHVyZS5pbml0V2l0aFNpemUoNjAwLCA2MDAsY2MuZ2Z4LlJCX0ZNVF9TOCk7XHJcbiAgICAvLyAgICAgdGhpcy5jYW1lcmEgPSB0aGlzLm5vZGUuYWRkQ29tcG9uZW50KGNjLkNhbWVyYSk7XHJcbiAgICAvLyAgICAgdGhpcy5jYW1lcmEudGFyZ2V0VGV4dHVyZSA9IHRleHR1cmU7XHJcbiAgICAvLyAgICAgdGhpcy50ZXh0dXJlID0gdGV4dHVyZTtcclxuICAgIC8vIH1cclxuICAgIC8vIC8vIGNyZWF0ZSB0aGUgaW1nIGVsZW1lbnRcclxuICAgIC8vIGNyZWF0ZUltZygpIHtcclxuICAgIC8vICAgICAvLyByZXR1cm4gdGhlIHR5cGUgYW5kIGRhdGFVcmxcclxuICAgIC8vICAgICB2YXIgZGF0YVVSTCA9IHRoaXMuX2NhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIik7XHJcbiAgICAvLyAgICAgdmFyIGltZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7XHJcbiAgICAvLyAgICAgaW1nLnNyYyA9IGRhdGFVUkw7XHJcbiAgICAvLyAgICAgcmV0dXJuIGltZztcclxuICAgIC8vIH1cclxuICAgIC8vIC8vIGNyZWF0ZSB0aGUgY2FudmFzIGFuZCBjb250ZXh0LCBmaWxwWSB0aGUgaW1hZ2UgRGF0YVxyXG4gICAgLy8gY3JlYXRlQ2FudmFzKCkge1xyXG4gICAgLy8gICAgIGxldCB3aWR0aCA9IHRoaXMudGV4dHVyZS53aWR0aDtcclxuICAgIC8vICAgICBsZXQgaGVpZ2h0ID0gdGhpcy50ZXh0dXJlLmhlaWdodDtcclxuICAgIC8vICAgICBpZiAoIXRoaXMuX2NhbnZhcykge1xyXG4gICAgLy8gICAgICAgICB0aGlzLl9jYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcclxuICAgIC8vICAgICAgICAgdGhpcy5fY2FudmFzLndpZHRoID0gd2lkdGg7XHJcbiAgICAvLyAgICAgICAgIHRoaXMuX2NhbnZhcy5oZWlnaHQgPSBoZWlnaHQ7XHJcbiAgICAvLyAgICAgfSBlbHNlIHtcclxuICAgIC8vICAgICAgICAgdGhpcy5jbGVhckNhbnZhcygpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICBsZXQgY3R4ID0gdGhpcy5fY2FudmFzLmdldENvbnRleHQoJzJkJyk7XHJcbiAgICAvLyAgICAgdGhpcy5jYW1lcmEucmVuZGVyKCk7XHJcbiAgICAvLyAgICAgbGV0IGRhdGEgPSB0aGlzLnRleHR1cmUucmVhZFBpeGVscygpO1xyXG4gICAgLy8gICAgIC8vIHdyaXRlIHRoZSByZW5kZXIgZGF0YVxyXG4gICAgLy8gICAgIGxldCByb3dCeXRlcyA9IHdpZHRoICogNDtcclxuICAgIC8vICAgICBmb3IgKGxldCByb3cgPSAwOyByb3cgPCBoZWlnaHQ7IHJvdysrKSB7XHJcbiAgICAvLyAgICAgICAgIGxldCBzcm93ID0gaGVpZ2h0IC0gMSAtIHJvdztcclxuICAgIC8vICAgICAgICAgbGV0IGltYWdlRGF0YSA9IGN0eC5jcmVhdGVJbWFnZURhdGEod2lkdGgsIDEpO1xyXG4gICAgLy8gICAgICAgICBsZXQgc3RhcnQgPSBzcm93ICogd2lkdGggKiA0O1xyXG4gICAgLy8gICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJvd0J5dGVzOyBpKyspIHtcclxuICAgIC8vICAgICAgICAgICAgIGltYWdlRGF0YS5kYXRhW2ldID0gZGF0YVtzdGFydCArIGldO1xyXG4gICAgLy8gICAgICAgICB9XHJcbiBcclxuICAgIC8vICAgICAgICAgY3R4LnB1dEltYWdlRGF0YShpbWFnZURhdGEsIDAsIHJvdyk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAgIHJldHVybiB0aGlzLl9jYW52YXM7XHJcbiAgICAvLyB9XHJcbiAgICAvLyBnZXRUYXJnZXRBcmVhKCkge1xyXG4gICAgLy8gICAgIGxldCB0YXJnZXRQb3MgPSB0aGlzLnRhcmdldE5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKVxyXG4gICAgLy8gICAgIGxldCB5ID0gY2Mud2luU2l6ZS5oZWlnaHQgLSB0YXJnZXRQb3MueSAtIHRoaXMudGFyZ2V0Tm9kZS5oZWlnaHQgLyAyO1xyXG4gICAgLy8gICAgIGxldCB4ID0gY2Mud2luU2l6ZS53aWR0aCAtIHRhcmdldFBvcy54IC0gdGhpcy50YXJnZXROb2RlLndpZHRoIC8gMjtcclxuICAgIC8vICAgICByZXR1cm4ge1xyXG4gICAgLy8gICAgICAgICB4LFxyXG4gICAgLy8gICAgICAgICB5XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfVxyXG4gXHJcbiAgICAvLyAvLyBzaG93IG9uIHRoZSBjYW52YXNcclxuICAgIC8vIHNob3dJbWFnZShpbWcpIHtcclxuICAgIC8vICAgICBsZXQgeSA9IHRoaXMuZ2V0VGFyZ2V0QXJlYSgpLnk7XHJcbiAgICAvLyAgICAgbGV0IHggPSB0aGlzLmdldFRhcmdldEFyZWEoKS54O1xyXG4gICAgLy8gICAgIC8vIGxldCByZWN0ID0gbmV3IGNjLlJlY3QoNzUwLCA4MCwgMTMzNCwgNzUwKVxyXG4gICAgLy8gICAgIGxldCB0ZXh0dXJlID0gbmV3IGNjLlRleHR1cmUyRCgpO1xyXG4gICAgLy8gICAgIHRleHR1cmUuaW5pdFdpdGhFbGVtZW50KGltZyk7XHJcbiBcclxuICAgIC8vICAgICBsZXQgc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoKTtcclxuICAgIC8vICAgICBzcHJpdGVGcmFtZS5zZXRUZXh0dXJlKHRleHR1cmUpO1xyXG4gICAgLy8gICAgIC8vIHNwcml0ZUZyYW1lLnNldFJlY3QocmVjdClcclxuIFxyXG4gICAgLy8gICAgIGxldCBub2RlID0gbmV3IGNjLk5vZGUoKTtcclxuICAgIC8vICAgICBsZXQgc3ByaXRlID0gbm9kZS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgIC8vICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcclxuIFxyXG4gICAgLy8gICAgIG5vZGUuekluZGV4ID0gY2MubWFjcm8uTUFYX1pJTkRFWDtcclxuICAgIC8vICAgICBub2RlLnBhcmVudCA9IGNjLmRpcmVjdG9yLmdldFNjZW5lKCk7XHJcbiAgICAvLyAgICAgLy8gc2V0IHBvc2l0aW9uXHJcbiAgICAvLyAgICAgbGV0IHdpZHRoID0gY2Mud2luU2l6ZS53aWR0aDtcclxuICAgIC8vICAgICBsZXQgaGVpZ2h0ID0gY2Mud2luU2l6ZS5oZWlnaHQ7XHJcbiAgICAvLyAgICAgbm9kZS54ID0gd2lkdGggLyAyO1xyXG4gICAgLy8gICAgIG5vZGUueSA9IGhlaWdodCAvIDI7XHJcbiAgICAvLyAgICAgbm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgKCkgPT4ge1xyXG4gICAgLy8gICAgICAgICBub2RlLnBhcmVudCA9IG51bGw7XHJcbiAgICAvLyAgICAgICAgIG5vZGUuZGVzdHJveSgpO1xyXG4gICAgLy8gICAgIH0pO1xyXG4gICAgLy8gICAgIC8vIHRoaXMuY2FwdHVyZUFjdGlvbihub2RlLCB3aWR0aCwgaGVpZ2h0KTtcclxuICAgIC8vIH1cclxuICAgIC8vIC8vIHNwcml0ZSBhY3Rpb25cclxuICAgIC8vIGNhcHR1cmVBY3Rpb24oY2FwdHVyZSwgd2lkdGgsIGhlaWdodCkge1xyXG4gICAgLy8gICAgIGxldCBzY2FsZUFjdGlvbiA9IGNjLnNjYWxlVG8oMSwgMC4zKTtcclxuICAgIC8vICAgICBsZXQgdGFyZ2V0UG9zID0gY2MudjIod2lkdGggLSB3aWR0aCAvIDYsIGhlaWdodCAvIDQpO1xyXG4gICAgLy8gICAgIGxldCBtb3ZlQWN0aW9uID0gY2MubW92ZVRvKDEsIHRhcmdldFBvcyk7XHJcbiAgICAvLyAgICAgbGV0IHNwYXduID0gY2Muc3Bhd24oc2NhbGVBY3Rpb24sIG1vdmVBY3Rpb24pO1xyXG4gXHJcbiAgICAvLyAgICAgbGV0IGZpbmlzaGVkID0gY2MuY2FsbEZ1bmMoKCkgPT4ge1xyXG4gICAgLy8gICAgICAgICBjYXB0dXJlLmRlc3Ryb3koKTtcclxuICAgIC8vICAgICB9KVxyXG4gICAgLy8gICAgIGxldCBhY3Rpb24gPSBjYy5zZXF1ZW5jZShzcGF3biwgZmluaXNoZWQpO1xyXG4gICAgLy8gICAgIGNhcHR1cmUucnVuQWN0aW9uKGFjdGlvbik7XHJcbiAgICAvLyB9XHJcbiBcclxuICAgIC8vIGNsZWFyQ2FudmFzKCkge1xyXG4gICAgLy8gICAgIGxldCBjdHggPSB0aGlzLl9jYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcclxuICAgIC8vICAgICBjdHguY2xlYXJSZWN0KDAsIDAsIHRoaXMuX2NhbnZhcy53aWR0aCwgdGhpcy5fY2FudmFzLmhlaWdodCk7XHJcbiAgICAvLyB9XHJcblxyXG59XHJcbiJdfQ==