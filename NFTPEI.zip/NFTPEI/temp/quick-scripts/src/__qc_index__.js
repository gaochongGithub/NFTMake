
require('./assets/script/App');
require('./assets/script/Base64');
require('./assets/script/ContractCall');
require('./assets/script/GameScene');
require('./assets/script/ShoeCtrl');
require('./assets/script/SingtonClass');
require('./assets/script/TextureRender');
require('./assets/script/init');
require('./assets/script/rsa/jsencrypt');
require('./assets/script/rsa/jsencrypt.min');
